import { useEffect, useMemo, useRef, useState } from 'react';
import { Check, Download, Image as ImageIcon, RotateCcw, ShieldCheck, Upload } from 'lucide-react';

type Preset = { id: string; label: string; width: number; height: number; note: string };

const presets: Preset[] = [
  { id: 'ig-square', label: 'Instagram bài vuông', width: 1080, height: 1080, note: '1:1' },
  { id: 'ig-portrait', label: 'Instagram bài dọc', width: 1080, height: 1350, note: '4:5' },
  { id: 'story', label: 'Story / Reels / TikTok', width: 1080, height: 1920, note: '9:16' },
  { id: 'fb-cover', label: 'Ảnh chia sẻ Facebook', width: 1200, height: 630, note: '1.91:1' },
  { id: 'youtube', label: 'Thumbnail YouTube', width: 1280, height: 720, note: '16:9' },
];

const MAX_DIMENSION = 4000;
const MAX_FILE_SIZE = 30 * 1024 * 1024;

export default function SocialImageResizer() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [presetId, setPresetId] = useState(presets[0].id);
  const [width, setWidth] = useState(presets[0].width);
  const [height, setHeight] = useState(presets[0].height);
  const [fit, setFit] = useState<'cover' | 'contain'>('cover');
  const [background, setBackground] = useState('#ffffff');
  const [format, setFormat] = useState<'image/png' | 'image/jpeg' | 'image/webp'>('image/jpeg');
  const [quality, setQuality] = useState(90);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [dragging, setDragging] = useState(false);

  const selectedPreset = presets.find((preset) => preset.id === presetId);
  const previewDimensions = useMemo(() => `${width} × ${height} px`, [width, height]);

  useEffect(() => {
    document.title = 'Social Image Resizer — Đổi kích thước ảnh mạng xã hội | MaxNgo AI';
    const meta = document.querySelector('meta[name="description"]');
    meta?.setAttribute('content', 'Đổi kích thước ảnh theo các khung Instagram, Facebook, Reels, TikTok và YouTube. Căn ảnh, chọn nền, rồi tải PNG, JPG hoặc WebP ngay trên trình duyệt.');
    const canonical = document.querySelector('link[rel="canonical"]');
    canonical?.setAttribute('href', `${window.location.origin}${window.location.pathname}`);
  }, []);

  useEffect(() => {
    if (!file) {
      setImage(null);
      return;
    }
    const objectUrl = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      setImage(img);
      setError('');
    };
    img.onerror = () => {
      setImage(null);
      setError('Không mở được ảnh này. Hãy thử chọn tệp PNG, JPG hoặc WebP khác.');
    };
    img.src = objectUrl;
    return () => URL.revokeObjectURL(objectUrl);
  }, [file]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const context = canvas?.getContext('2d');
    if (!canvas || !context) return;
    canvas.width = width;
    canvas.height = height;
    context.clearRect(0, 0, width, height);
    if (!image) return;
    if (format !== 'image/png') {
      context.fillStyle = background;
      context.fillRect(0, 0, width, height);
    }

    const scale = fit === 'cover'
      ? Math.max(width / image.naturalWidth, height / image.naturalHeight)
      : Math.min(width / image.naturalWidth, height / image.naturalHeight);
    const drawWidth = image.naturalWidth * scale;
    const drawHeight = image.naturalHeight * scale;
    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = 'high';
    context.drawImage(image, (width - drawWidth) / 2, (height - drawHeight) / 2, drawWidth, drawHeight);
  }, [image, width, height, fit, background, format]);

  const chooseFile = (nextFile?: File) => {
    setNotice('');
    setError('');
    if (!nextFile) return;
    if (!nextFile.type.startsWith('image/')) {
      setError('Tệp bạn chọn không phải hình ảnh. Hãy chọn PNG, JPG hoặc WebP.');
      return;
    }
    if (nextFile.size > MAX_FILE_SIZE) {
      setError('Ảnh vượt quá 30 MB. Hãy chọn ảnh nhẹ hơn để trình duyệt xử lý ổn định.');
      return;
    }
    setFile(nextFile);
  };

  const applyPreset = (id: string) => {
    setPresetId(id);
    const preset = presets.find((item) => item.id === id);
    if (preset) {
      setWidth(preset.width);
      setHeight(preset.height);
    }
  };

  const changeDimension = (axis: 'width' | 'height', value: string) => {
    const next = Math.max(1, Math.min(MAX_DIMENSION, Math.round(Number(value) || 1)));
    setPresetId('custom');
    if (axis === 'width') setWidth(next);
    else setHeight(next);
  };

  const exportImage = () => {
    const canvas = canvasRef.current;
    if (!canvas || !image) return;
    setNotice('');
    canvas.toBlob((blob) => {
      if (!blob) {
        setError('Không thể tạo tệp ảnh. Hãy thử kích thước nhỏ hơn.');
        return;
      }
      const extension = blob.type === 'image/png' ? 'png' : blob.type === 'image/webp' ? 'webp' : 'jpg';
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `social-image-${width}x${height}.${extension}`;
      link.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1500);
      setNotice(`Đã tải ảnh ${width} × ${height} px dạng ${extension.toUpperCase()}.`);
    }, format, format === 'image/png' ? undefined : quality / 100);
  };

  const reset = () => {
    setFile(null);
    setImage(null);
    setPresetId(presets[0].id);
    setWidth(presets[0].width);
    setHeight(presets[0].height);
    setFit('cover');
    setBackground('#ffffff');
    setFormat('image/jpeg');
    setQuality(90);
    setNotice('');
    setError('');
  };

  return <main className="subpage social-resizer-page">
    <div className="tool-intro">
      <a className="back-link" href="/#tools">← Tất cả công cụ</a>
      <div className="tool-intro-label"><span/> ẢNH CHO MỌI NỀN TẢNG</div>
      <h1>Đúng khung ảnh.<br/><span className="gradient-word">Sẵn sàng đăng.</span></h1>
      <p>Chọn ảnh, chọn kích thước theo nền tảng và tải xuống. Ảnh được xử lý ngay trên thiết bị của bạn.</p>
      <div className="tool-badge"><span className="eyebrow-dot"/> Không tải ảnh lên máy chủ</div>
    </div>

    <div className="resizer-layout">
      <section className="resizer-controls" aria-labelledby="resizer-settings-title">
        <div className="social-section-title"><div><span className="section-kicker">BƯỚC 1</span><h2 id="resizer-settings-title">Ảnh và kích thước</h2></div><button type="button" className="icon-action" onClick={reset} aria-label="Đặt lại công cụ"><RotateCcw size={15}/></button></div>
        <label className={`image-dropzone ${file ? 'has-image' : ''} ${dragging ? 'is-dragging' : ''}`} htmlFor="social-image-file" onDragOver={(event) => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={(event) => { event.preventDefault(); setDragging(false); chooseFile(event.dataTransfer.files[0]); }}>
          <input id="social-image-file" type="file" accept="image/png,image/jpeg,image/webp" onChange={(event) => { chooseFile(event.currentTarget.files?.[0]); event.currentTarget.value = ''; }}/>
          {file ? <><ImageIcon size={20}/><b>{file.name}</b><small>{image ? `${image.naturalWidth} × ${image.naturalHeight} px · ${(file.size / 1024 / 1024).toFixed(1)} MB` : 'Đang mở ảnh…'}</small><span className="button secondary"><Upload size={14}/> Chọn ảnh khác</span></> : <><span className="upload-icon"><Upload size={18}/></span><b>Tải ảnh lên</b><small>Kéo ảnh vào đây hoặc chọn từ thiết bị</small><span className="button secondary">Chọn tệp</span><small>PNG, JPG hoặc WebP · tối đa 30 MB</small></>}
        </label>
        <div className="control-block"><label htmlFor="resizer-preset">Kích thước theo nền tảng</label><select id="resizer-preset" value={presetId} onChange={(event) => applyPreset(event.target.value)}>{presets.map((preset) => <option key={preset.id} value={preset.id}>{preset.label} · {preset.width} × {preset.height}</option>)}<option value="custom">Tùy chỉnh</option></select></div>
        <div className="resizer-dimensions"><div className="control-block"><label htmlFor="resizer-width">Rộng (px)</label><input id="resizer-width" type="number" min="1" max={MAX_DIMENSION} value={width} onChange={(event) => changeDimension('width', event.target.value)}/></div><span aria-hidden="true">×</span><div className="control-block"><label htmlFor="resizer-height">Cao (px)</label><input id="resizer-height" type="number" min="1" max={MAX_DIMENSION} value={height} onChange={(event) => changeDimension('height', event.target.value)}/></div></div>
        <fieldset className="resizer-fieldset"><legend>Cách căn ảnh</legend><label className="resizer-radio"><input type="radio" name="image-fit" checked={fit === 'cover'} onChange={() => setFit('cover')}/><span><b>Lấp đầy khung</b><small>Cắt phần thừa, không để viền trống</small></span></label><label className="resizer-radio"><input type="radio" name="image-fit" checked={fit === 'contain'} onChange={() => setFit('contain')}/><span><b>Giữ trọn ảnh</b><small>Hiện toàn bộ ảnh, thêm nền hai bên nếu cần</small></span></label></fieldset>
        {fit === 'contain' && format !== 'image/png' && <div className="control-block"><label htmlFor="resizer-background">Màu nền phần trống</label><div className="background-control"><input id="resizer-background" type="color" value={background} onChange={(event) => setBackground(event.target.value)}/><span>{background.toUpperCase()}</span></div></div>}
        <div className="control-block"><label htmlFor="resizer-format">Định dạng tải xuống</label><select id="resizer-format" value={format} onChange={(event) => setFormat(event.target.value as typeof format)}><option value="image/jpeg">JPG · dung lượng gọn</option><option value="image/png">PNG · có thể giữ nền trong suốt</option><option value="image/webp">WebP · tối ưu cho web</option></select></div>
        {format !== 'image/png' && <div className="control-block quality-control"><label htmlFor="resizer-quality">Chất lượng JPG / WebP <b>{quality}%</b></label><input id="resizer-quality" type="range" min="50" max="100" value={quality} onChange={(event) => setQuality(Number(event.target.value))}/></div>}
        {error && <p className="resizer-message error" role="alert">{error}</p>}
        <button type="button" className="button primary resizer-download" disabled={!image} onClick={exportImage}><Download size={15}/> Tải ảnh {format === 'image/png' ? 'PNG' : format === 'image/webp' ? 'WebP' : 'JPG'}</button>
        {notice && <p className="resizer-message success" role="status"><Check size={14}/>{notice}</p>}
        <p className="resizer-privacy"><ShieldCheck size={14}/> Tệp ảnh chỉ được đọc và chuyển đổi trong trình duyệt.</p>
      </section>

      <section className="resizer-preview" aria-labelledby="resizer-preview-title">
        <div className="resizer-preview-head"><div><span className="section-kicker">BƯỚC 2</span><h2 id="resizer-preview-title">Xem trước</h2></div><span className="resizer-size">{selectedPreset?.note ?? 'Tùy chỉnh'} · {previewDimensions}</span></div>
        <div className="resizer-canvas-stage"><canvas ref={canvasRef} aria-label={image ? `Ảnh xem trước ${previewDimensions}` : 'Khung xem trước ảnh'}/>{!image && <div className="resizer-empty"><span className="empty-spark"><ImageIcon size={20}/></span><b>Ảnh của bạn sẽ hiện ở đây</b><small>Chọn kích thước rồi tải ảnh lên để bắt đầu.</small></div>}</div>
        <p className="resizer-preview-hint">Khung xem trước hiển thị theo đúng tỷ lệ đầu ra. Vị trí hiện căn giữa.{format === 'image/png' && fit === 'contain' ? ' PNG giữ trong suốt ở phần trống.' : ''}</p>
      </section>
    </div>
    <section className="below-tool resizer-info"><div><h2>Kích thước phổ biến đã có sẵn</h2><p>Instagram vuông và dọc, Story/Reels/TikTok, ảnh chia sẻ Facebook và thumbnail YouTube. Bạn cũng có thể nhập kích thước riêng tối đa 4000 × 4000 px.</p></div><div><h2>Ảnh riêng tư trên thiết bị</h2><p>Ảnh không được tải lên máy chủ. Công cụ không thêm watermark; kết quả được tạo thành một tệp ảnh mới để bạn kiểm tra trước khi đăng.</p></div></section>
  </main>;
}
