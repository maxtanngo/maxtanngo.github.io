import { useState } from 'react';
import { ArrowUpRight, Menu, X } from 'lucide-react';

export function Header() {
  const [open, setOpen] = useState(false);

  return <header className="site-header">
    <a className="logo" href="/" aria-label="MaxNgo AI trang chủ">
      <span className="logo-mark">M<span>.</span></span>
      <span>MaxNgo<span className="logo-soft"> AI</span></span>
    </a>
    <button className="menu-toggle" aria-label={open ? 'Đóng menu' : 'Mở menu'} aria-expanded={open} onClick={() => setOpen(!open)}>
      {open ? <X size={20}/> : <Menu size={20}/>}
    </button>
    <nav className={open ? 'nav open' : 'nav'} aria-label="Điều hướng chính">
      <a href="/#tools" onClick={() => setOpen(false)}>Công cụ</a>
      <a href="/downloads/" onClick={() => setOpen(false)}>Tải về</a>
      <a href="/guides/" onClick={() => setOpen(false)}>Hướng dẫn</a>
      <a href="/about/" onClick={() => setOpen(false)}>Về MaxNgo AI</a>
      <a className="nav-cta" href="/#tools" onClick={() => setOpen(false)}>Khám phá công cụ <ArrowUpRight size={14}/></a>
    </nav>
  </header>;
}

export function Footer() {
  return <footer className="site-footer">
    <a className="logo" href="/"><span className="logo-mark">M<span>.</span></span><span>MaxNgo<span className="logo-soft"> AI</span></span></a>
    <p>Công cụ thiết thực cho quy trình làm video marketing.</p>
    <div className="footer-links"><a href="/downloads/">Tải về</a><a href="/guides/">Hướng dẫn</a><a href="/about/">Liên hệ</a><a href="/#responsible-use">Quyền sử dụng</a></div>
    <small>© 2026 MaxNgo AI · Công cụ đang được phát triển và cải tiến.</small>
  </footer>;
}

export function Layout({ children }: { children: React.ReactNode }) {
  return <><Header/>{children}<Footer/></>;
}
