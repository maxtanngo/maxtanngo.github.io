export type Guide = {
  num: string;
  label: string;
  title: string;
  text: string;
  href: string;
  tool: string;
  toolHref: string;
  intro: string;
  sections: { heading: string; paragraphs?: string[]; steps?: string[] }[];
};

export const guides: Guide[] = [
  {
    num: '01', label: 'Dựng video', title: 'Cắt video ngắn để đăng Reels, Shorts và TikTok',
    text: 'Chọn đoạn mở đầu, bỏ phần thừa và xuất video theo đúng mục đích đăng.',
    href: '/guides/cat-video-ngan/', tool: 'Video Editor', toolHref: '/tools/video-editor/',
    intro: 'Một video ngắn dễ xem thường bắt đầu bằng một ý rõ ràng, không phải bằng thật nhiều hiệu ứng. Hãy chọn khoảnh khắc có ích nhất, cắt gọn phần dẫn dài và xem lại trên màn hình điện thoại trước khi xuất.',
    sections: [
      { heading: '1. Chọn một điểm chính cho video', paragraphs: ['Trước khi cắt, hãy viết ra một câu mô tả điều người xem cần nhớ. Những cảnh không giúp làm rõ câu đó thường có thể bỏ đi. Cách này giúp video ngắn hơn mà vẫn giữ được mạch kể.'] },
      { heading: '2. Đưa khoảnh khắc đáng chú ý lên đầu', paragraphs: ['Mở đầu bằng kết quả, câu hỏi hoặc tình huống người xem nhận ra. Cắt khoảng lặng và lời dẫn dài, nhưng giữ đủ bối cảnh để nội dung không bị khó hiểu.'] },
      { heading: '3. Chọn tỷ lệ và kiểm tra phụ đề', paragraphs: ['Dùng khung dọc cho video xem trên điện thoại và khung ngang khi nội dung cần rộng. Đặt phụ đề ở vùng dễ đọc, tránh che mặt, sản phẩm hoặc nút giao diện của nền tảng.'] },
      { heading: 'Trước khi xuất bản', steps: ['Xem lại toàn bộ clip một lần ở kích thước điện thoại.', 'Kiểm tra âm thanh, chính tả và thông tin sản phẩm.', 'Chọn độ phân giải phù hợp với tệp gốc và nhu cầu đăng.'] },
    ],
  },
  {
    num: '02', label: 'Lên ý tưởng', title: 'Viết kịch bản video sản phẩm trong 30 giây',
    text: 'Dùng cấu trúc mở đầu, nhu cầu, lợi ích và lời mời hành động để kể ngắn gọn.',
    href: '/guides/kich-ban-video-30-giay/', tool: 'Social Content Kit', toolHref: '/tools/script-radar/',
    intro: 'Một kịch bản 30 giây không cần nhồi mọi thông tin về sản phẩm. Chọn một nhóm người xem, một nhu cầu cụ thể và một lợi ích đã kiểm chứng; sau đó sắp xếp chúng thành câu chuyện ngắn, tự nhiên.',
    sections: [
      { heading: 'Khung kịch bản 30 giây', steps: ['0–3 giây: Nêu tình huống hoặc câu hỏi thu hút đúng người xem.', '3–10 giây: Cho thấy nhu cầu hoặc vấn đề cụ thể.', '10–23 giây: Minh họa một lợi ích bằng trải nghiệm hoặc bằng chứng thật.', '23–30 giây: Mời người xem thực hiện một bước tiếp theo rõ ràng.'] },
      { heading: 'Viết lời thoại như cách bạn nói', paragraphs: ['Ưu tiên câu ngắn, từ quen thuộc và một ý cho mỗi câu. Đọc thành tiếng để phát hiện câu dài hoặc cách diễn đạt thiếu tự nhiên.'] },
      { heading: 'Giữ nội dung đáng tin', paragraphs: ['Chỉ nêu giá, tính năng, kết quả và ưu đãi mà bạn có thể xác nhận. Nếu chưa có bằng chứng cho một tuyên bố, hãy thay bằng trình diễn sản phẩm hoặc trải nghiệm thực tế.'] },
    ],
  },
  {
    num: '03', label: 'Thiết kế', title: 'Tạo ảnh Hook Card rõ ý, dễ đọc trên điện thoại',
    text: 'Giữ một thông điệp, tương phản tốt và bố cục gọn cho khung hình mở đầu.',
    href: '/guides/thiet-ke-hook-card/', tool: 'Hook Card Studio', toolHref: '/tools/hook-card/',
    intro: 'Hook Card là khung hình giúp người xem nhanh chóng hiểu video nói về điều gì. Một thiết kế rõ ràng thường hiệu quả hơn khi có ít chữ, phân cấp thông tin tốt và màu chữ đủ tương phản với nền.',
    sections: [
      { heading: 'Bắt đầu bằng một câu chính', paragraphs: ['Chọn một câu hỏi, lợi ích hoặc kết quả làm tiêu đề. Nếu cần nhiều dòng, ngắt theo cụm ý và bỏ các từ có thể hiểu từ hình ảnh hoặc ngữ cảnh.'] },
      { heading: 'Tạo thứ bậc thị giác', paragraphs: ['Để tiêu đề lớn nhất, phần giải thích nhỏ hơn và lời kêu gọi hành động ngắn gọn. Giữ khoảng trống quanh chữ để thiết kế không bị nặng khi thu nhỏ.'] },
      { heading: 'Kiểm tra ở kích thước nhỏ', steps: ['Thu nhỏ ảnh xuống gần kích thước hiển thị trên điện thoại.', 'Đọc thử tiêu đề từ khoảng cách bình thường.', 'Kiểm tra tương phản và vùng an toàn quanh các cạnh.'] },
    ],
  },
  {
    num: '04', label: 'Ảnh mạng xã hội', title: 'Đổi kích thước ảnh vừa khung từng nền tảng',
    text: 'Chọn đúng tỷ lệ, căn ảnh và xuất tệp phù hợp cho Instagram, Facebook hoặc YouTube.',
    href: '/guides/doi-kich-thuoc-anh-mang-xa-hoi/', tool: 'Social Image Resizer', toolHref: '/tools/social-image-resizer/',
    intro: 'Ảnh có tỷ lệ không phù hợp dễ bị cắt mất chủ thể hoặc để lại khoảng trống không mong muốn. Hãy bắt đầu bằng vị trí đăng, chọn đúng kích thước đầu ra, rồi quyết định nên lấp đầy khung hay giữ nguyên toàn bộ ảnh.',
    sections: [
      { heading: 'Chọn kích thước theo vị trí đăng', paragraphs: ['Bài đăng vuông, ảnh dọc, Story/Reels và ảnh xem trước liên kết dùng những tỷ lệ khác nhau. Chọn preset tương ứng với vị trí dự định đăng thay vì phóng to hoặc kéo méo ảnh.'] },
      { heading: 'Căn ảnh phủ hoặc giữ trọn', paragraphs: ['Chế độ lấp đầy khung cắt phần thừa để không còn viền. Chế độ giữ trọn ảnh hiển thị toàn bộ hình và có thể thêm nền hai bên. Kiểm tra khuôn mặt, chữ và sản phẩm sau khi căn.'] },
      { heading: 'Chọn định dạng đầu ra', paragraphs: ['JPG thường phù hợp với ảnh chụp cần dung lượng gọn. PNG hữu ích khi cần giữ vùng trong suốt. WebP phù hợp cho nhiều nhu cầu hiển thị trên web. Hãy xem lại chất lượng trước khi đăng.'] },
    ],
  },
];
