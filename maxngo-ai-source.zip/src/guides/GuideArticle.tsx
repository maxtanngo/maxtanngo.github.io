import { ArrowLeft, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import type { Guide } from './content';
import { Layout } from '../site/SiteLayout';

export function GuideArticle({ guide }: { guide: Guide }) {
  return <Layout><main className="subpage text-page guide-article">
    <a className="back-link" href="/guides/"><ArrowLeft size={14}/> Tất cả hướng dẫn</a>
    <div className="tool-intro-label"><span/> {guide.label.toLocaleUpperCase('vi')}</div>
    <h1>{guide.title}</h1>
    <p className="page-lead">{guide.intro}</p>
    <div className="guide-reading-meta"><span>MaxNgo AI</span><span aria-hidden="true">·</span><span>Hướng dẫn thực hành</span></div>
    <article className="guide-article-body">
      {guide.sections.map((section) => <section key={section.heading}>
        <h2>{section.heading}</h2>
        {section.paragraphs?.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
        {section.steps && <ol>{section.steps.map((step) => <li key={step}><CheckCircle2 size={16}/><span>{step}</span></li>)}</ol>}
      </section>)}
    </article>
    <aside className="guide-tool-cta"><div><span className="section-kicker">THỰC HÀNH NGAY</span><h2>Thử với {guide.tool}</h2><p>Mở công cụ và áp dụng các bước trong hướng dẫn vào nội dung của bạn.</p></div><a className="button primary" href={guide.toolHref}>Mở công cụ <ArrowUpRight size={15}/></a></aside>
    <nav className="guide-related" aria-label="Hướng dẫn liên quan"><a href="/guides/">Xem thêm hướng dẫn <ArrowUpRight size={14}/></a><a href="/">Trở về trang chủ <ArrowUpRight size={14}/></a></nav>
  </main></Layout>;
}
