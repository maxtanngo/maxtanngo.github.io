import { useEffect } from 'react';
import { ArrowDown, ArrowRight, ArrowUpRight, AudioLines, Check, Clapperboard, Image as ImageIcon, LockKeyhole, Scissors, ShieldCheck, Sparkles, WandSparkles } from 'lucide-react';
import { Layout } from '../site/SiteLayout';
import { guides } from '../guides/content';

const tools = [
  { id: 'video-editor', name: 'Video Editor', category: 'Chỉnh sửa video', status: 'Phiên bản 1.0', description: 'Cắt clip, thay nhạc, chỉnh màu, thêm phụ đề và xuất video theo tỷ lệ bạn cần.', tags: ['Cắt & ghép', 'Phụ đề', 'MP4'], href: '/tools/video-editor/', icon: Scissors, tone: 'lime', featured: true },
  { id: 'script-radar', name: 'Social Content Kit', category: 'Lên nội dung', status: 'Bản thử nghiệm', description: 'Tạo hook, caption, kịch bản video ngắn và gợi ý cảnh quay từ một brief.', tags: ['Hook', 'Caption', 'Kịch bản'], href: '/tools/script-radar/', icon: WandSparkles, tone: 'blue' },
  { id: 'hook-card', name: 'Hook Card Studio', category: 'Thiết kế hình ảnh', status: 'Dùng được', description: 'Thiết kế ảnh mở đầu cho video với tiêu đề, màu sắc và bố cục tùy chỉnh.', tags: ['Ảnh 16:9', 'PNG', 'Offline'], href: '/tools/hook-card/', icon: ImageIcon, tone: 'violet' },
  { id: 'social-image-resizer', name: 'Social Image Resizer', category: 'Ảnh mạng xã hội', status: 'Dùng được', description: 'Đổi kích thước, căn ảnh và xuất tệp cho Instagram, Facebook, TikTok hoặc YouTube.', tags: ['Preset mạng xã hội', 'PNG · JPG · WebP'], href: '/tools/social-image-resizer/', icon: Clapperboard, tone: 'orange' },
];

function useHomeMeta() {
  useEffect(() => {
    document.title = 'MaxNgo AI — Công cụ video, ảnh và nội dung marketing tiếng Việt';
    const description = 'Cắt và chỉnh sửa video, tạo kịch bản mạng xã hội, thiết kế Hook Card và đổi kích thước ảnh bằng các công cụ tiếng Việt của MaxNgo AI.';
    document.querySelector('meta[name="description"]')?.setAttribute('content', description);
  }, []);
}

function ProductPreview() {
  return <div className="product-stage" aria-label="Minh họa quy trình chỉnh sửa video">
    <div className="product-glow" aria-hidden="true"/>
    <div className="product-window">
      <div className="product-window-bar"><span className="product-dot red"/><span className="product-dot amber"/><span className="product-dot green"/><span className="product-file-name">DỰ ÁN MỚI / 9:16</span><span className="product-export">XUẤT VIDEO <ArrowUpRight size={11}/></span></div>
      <div className="product-workspace">
        <div className="product-sidebar"><span className="product-sidebar-title">ĐIỀU CHỈNH</span><div className="product-setting active"><span><Scissors size={13}/> Khung hình</span><b>9:16</b></div><div className="product-setting"><span><Sparkles size={13}/> Màu sắc</span><b>Ấm</b></div><div className="product-setting"><span><AudioLines size={13}/> Âm thanh</span><b>01 track</b></div><div className="product-setting"><span><Clapperboard size={13}/> Phụ đề</span><b>SRT</b></div></div>
        <div className="product-preview-area"><div className="product-video-still"><div className="still-light"/><span className="still-caption">Một câu chuyện<br/><b>đáng để kể.</b></span><span className="still-play"><ArrowRight size={15}/></span><span className="still-tag">BẢN XEM TRƯỚC</span></div><div className="product-timeline-label"><span>TIMELINE</span><span>00:08 / 00:24</span></div><div className="product-timeline"><i/><b/><em/></div><div className="product-audio-track"><AudioLines size={12}/><span/></div></div>
      </div>
    </div>
    <div className="product-float product-float-top"><span className="product-check"><Check size={13}/></span><span><b>Chỉnh sửa ngay trên web</b><small>Không cần cài đặt</small></span></div>
    <div className="product-float product-float-bottom"><span className="product-float-icon"><LockKeyhole size={14}/></span><span><b>Quyền riêng tư rõ ràng</b><small>Xem cách xử lý tại từng công cụ</small></span></div>
  </div>;
}

function ToolCard({ tool }: { tool: typeof tools[number] }) {
  const Icon = tool.icon;
  return <article className={`home-tool-card ${tool.featured ? 'home-tool-featured' : ''}`}>
    <div className={`home-tool-icon ${tool.tone}`}><Icon size={19} aria-hidden="true"/></div>
    <div className="home-tool-meta"><span>{tool.category}</span><span className={tool.status === 'Dùng được' || tool.status === 'Phiên bản 1.0' ? 'tool-status-ready' : 'tool-status-beta'}>{tool.status}</span></div>
    <h3>{tool.name}</h3><p>{tool.description}</p>
    <div className="home-tool-tags">{tool.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>
    <a className="home-tool-link" href={tool.href}>{tool.id === 'script-radar' ? 'Tạo bộ nội dung' : 'Mở công cụ'}<ArrowUpRight size={15} aria-hidden="true"/></a>
  </article>;
}

export default function Home() {
  useHomeMeta();
  return <Layout><main>
    <section className="hero hero-refined">
      <div className="hero-copy">
        <div className="eyebrow"><span className="eyebrow-dot"/> CÔNG CỤ SÁNG TẠO NỘI DUNG · TIẾNG VIỆT</div>
        <h1>Công cụ làm video marketing, <span className="gradient-word">từ ý tưởng đến bản đăng.</span></h1>
        <p className="hero-desc">Lên kịch bản, hoàn thiện video và chuẩn bị hình ảnh mạng xã hội bằng một bộ công cụ gọn nhẹ, dễ dùng.</p>
        <div className="hero-actions"><a className="button primary" href="/tools/video-editor/">Bắt đầu với Video Editor <ArrowRight size={16} aria-hidden="true"/></a><a className="button secondary" href="#tools">Xem bộ công cụ <ArrowDown size={15} aria-hidden="true"/></a></div>
        <p className="hero-note"><ShieldCheck size={15} aria-hidden="true"/> Không cần cài đặt · Mỗi công cụ nêu rõ cách xử lý dữ liệu</p>
      </div>
      <ProductPreview/>
    </section>

    <div className="trust-strip trust-strip-refined" aria-label="Điểm nổi bật">
      <div><span className="trust-icon"><LockKeyhole size={16}/></span><span><b>Minh bạch quyền riêng tư</b><small>Thông tin ngay trong từng công cụ</small></span></div>
      <div><span className="trust-icon"><Sparkles size={16}/></span><span><b>Dành cho creator Việt</b><small>Giao diện và hướng dẫn tiếng Việt</small></span></div>
      <div><span className="trust-icon"><ArrowUpRight size={16}/></span><span><b>Bắt đầu nhanh</b><small>Dùng trực tiếp trên website</small></span></div>
    </div>

    <section id="tools" className="section tools-section tools-section-refined">
      <div className="section-head"><div><div className="section-kicker">MAXNGO AI TOOLBOX</div><h2>Bạn muốn làm gì <span>hôm nay?</span></h2></div><p>Chọn một việc cụ thể. Mỗi công cụ được thiết kế để giúp bạn bắt đầu nhanh và hoàn thành gọn hơn.</p></div>
      <div className="home-tool-grid">{tools.map((tool) => <ToolCard key={tool.id} tool={tool}/>)}</div>
      <div className="toolbox-footnote"><span className="eyebrow-dot"/> Công cụ mới được bổ sung và cải tiến theo phản hồi thực tế.</div>
    </section>

    <section className="workflow workflow-refined"><div className="workflow-inner"><div className="workflow-heading"><div className="section-kicker">MỘT QUY TRÌNH DỄ THEO</div><h2>Từ bản nháp đến nội dung <span>sẵn sàng chia sẻ.</span></h2><p>Dùng từng công cụ riêng lẻ hoặc kết hợp theo quy trình của bạn.</p></div><div className="flow-steps flow-steps-refined"><div className="flow-step"><span className="flow-num">01 / NỘI DUNG</span><div className="flow-icon blue"><WandSparkles size={20}/></div><b>Tìm góc kể chuyện</b><small>Chọn thông điệp và viết kịch bản ngắn.</small></div><ArrowRight className="flow-arrow" size={18} aria-hidden="true"/><div className="flow-step"><span className="flow-num">02 / HÌNH ẢNH</span><div className="flow-icon violet"><ImageIcon size={20}/></div><b>Tạo điểm nhấn</b><small>Chuẩn bị ảnh mở đầu và ảnh đúng tỷ lệ.</small></div><ArrowRight className="flow-arrow" size={18} aria-hidden="true"/><div className="flow-step"><span className="flow-num">03 / VIDEO</span><div className="flow-icon lime"><Scissors size={20}/></div><b>Hoàn thiện clip</b><small>Cắt, thêm phụ đề và xuất theo nhu cầu.</small></div></div></div></section>

    <section className="responsible responsible-refined" id="responsible-use"><div className="responsible-icon"><ShieldCheck size={20}/></div><div><h2>Dữ liệu của bạn được xử lý minh bạch.</h2><p>Các công cụ xử lý trên trình duyệt sẽ nói rõ điều đó. Nếu một công cụ cần kết nối hoặc dịch vụ bên ngoài, yêu cầu sẽ được giải thích trước khi bạn sử dụng.</p></div><a href="/about/">Nguyên tắc sử dụng <ArrowUpRight size={14}/></a></section>

    <section className="guide-section guide-section-refined"><div className="section-head guide-head"><div><div className="section-kicker">GÓC CHIA SẺ</div><h2>Hướng dẫn ngắn, <span>làm được ngay.</span></h2></div><a className="text-link" href="/guides/">Xem thư viện hướng dẫn <ArrowRight size={15}/></a></div><div className="guide-grid home-guide-grid">{guides.map((guide) => <a href={guide.href} className="guide-card" key={guide.num}><span className="guide-num">{guide.num}</span><div><span className="guide-label">{guide.label}</span><h3>{guide.title}</h3><p>{guide.text}</p><span className="guide-read">Đọc hướng dẫn <ArrowRight size={14}/></span></div></a>)}</div></section>

    <section className="creator-intro"><img src="/images/ngo-thanh-tan.png" alt="Ngô Thanh Tân, người xây dựng MaxNgo AI" loading="lazy"/><div><div className="section-kicker">DỰ ÁN CÁ NHÂN · ĐANG ĐƯỢC HOÀN THIỆN</div><h2>Công cụ hữu ích được làm từ những nhu cầu thật.</h2><p>MaxNgo AI được xây dựng để giúp người làm nội dung rút ngắn những thao tác thường ngày. Góp ý của bạn giúp dự án phát triển đúng hướng.</p><a href="/about/">Tìm hiểu về MaxNgo AI <ArrowUpRight size={14}/></a></div></section>

    <section className="home-faq"><div><div className="section-kicker">CÂU HỎI THƯỜNG GẶP</div><h2>Bắt đầu thật đơn giản.</h2><p>Thông tin cần biết trước khi dùng thử các công cụ.</p></div><div className="faq-list"><details><summary>Có cần cài phần mềm để sử dụng không?</summary><p>Không. Các công cụ chính mở trực tiếp trên website. Video Editor cần tải thư viện xử lý video khi bạn xuất lần đầu; trang sẽ thông báo yêu cầu này.</p></details><details><summary>Video và hình ảnh có được tải lên máy chủ không?</summary><p>Social Image Resizer và Video Editor xử lý tệp trên thiết bị. Mỗi trang công cụ có phần giải thích riêng để bạn kiểm tra cách dữ liệu được sử dụng.</p></details><details><summary>Social Content Kit có tự đăng bài lên mạng xã hội không?</summary><p>Không. Công cụ tạo nội dung để bạn xem lại, chỉnh sửa, sao chép hoặc tải về. Bạn chủ động đăng lên nền tảng mình chọn.</p></details></div></section>

    <section className="closing-cta closing-cta-refined"><div className="closing-spark"><Sparkles size={18}/></div><div><div className="section-kicker">BẮT ĐẦU TỪ MỘT Ý TƯỞNG</div><h2>Mở công cụ phù hợp và làm thử ngay.</h2></div><a className="button primary" href="/#tools">Chọn công cụ <ArrowUpRight size={16}/></a></section>
  </main></Layout>;
}
