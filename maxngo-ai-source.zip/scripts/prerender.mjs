import { readdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import React from 'react';
import { renderToString } from 'react-dom/server';
import { createServer } from 'vite';

const outputDirectory = path.resolve('dist');
const pages = [
  { pathname: '/', file: 'index.html' },
  { pathname: '/guides/', file: 'guides/index.html' },
  { pathname: '/guides/cat-video-ngan/', file: 'guides/cat-video-ngan/index.html' },
  { pathname: '/guides/kich-ban-video-30-giay/', file: 'guides/kich-ban-video-30-giay/index.html' },
  { pathname: '/guides/thiet-ke-hook-card/', file: 'guides/thiet-ke-hook-card/index.html' },
  { pathname: '/guides/doi-kich-thuoc-anh-mang-xa-hoi/', file: 'guides/doi-kich-thuoc-anh-mang-xa-hoi/index.html' },
];
const fontPreconnect = '<link rel="preconnect" href="https://fonts.googleapis.com"/><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>';

async function addFontPreconnect(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const filePath = path.join(directory, entry.name);
    if (entry.isDirectory()) {
      await addFontPreconnect(filePath);
    } else if (entry.name.endsWith('.html')) {
      const html = await readFile(filePath, 'utf8');
      if (!html.includes('fonts.googleapis.com')) {
        await writeFile(filePath, html.replace('</head>', `${fontPreconnect}</head>`));
      }
    }
  }
}

const vite = await createServer({
  configFile: path.resolve('vite.config.ts'),
  appType: 'custom',
  logLevel: 'error',
  server: { middlewareMode: true, hmr: false, ws: false },
});

try {
  const { default: Site } = await vite.ssrLoadModule('/src/Site.tsx');

  for (const page of pages) {
    globalThis.window = { location: { pathname: page.pathname, origin: 'https://maxtanngo.github.io' } };
    const markup = renderToString(React.createElement(Site));
    const filePath = path.join(outputDirectory, page.file);
    const html = await readFile(filePath, 'utf8');

    if (!html.includes('<div id="root"></div>')) {
      throw new Error(`Expected an empty React root in ${page.file}`);
    }

    await writeFile(filePath, html.replace('<div id="root"></div>', `<div id="root">${markup}</div>`));
    console.log(`Prerendered ${page.pathname}`);
  }

  await addFontPreconnect(outputDirectory);
} finally {
  delete globalThis.window;
  await vite.close();
}
