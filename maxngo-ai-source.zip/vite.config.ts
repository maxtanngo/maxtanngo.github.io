import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  base: '/',
  plugins: [react()],
  build: {
    rollupOptions: {
      input: {
        home: 'index.html',
        videoEditor: 'tools/video-editor/index.html',
        hookCard: 'tools/hook-card/index.html',
        scriptRadar: 'tools/script-radar/index.html',
        socialImageResizer: 'tools/social-image-resizer/index.html',
        downloads: 'downloads/index.html',
        guides: 'guides/index.html',
        guideVideo: 'guides/cat-video-ngan/index.html',
        guideScript: 'guides/kich-ban-video-30-giay/index.html',
        guideHookCard: 'guides/thiet-ke-hook-card/index.html',
        guideImage: 'guides/doi-kich-thuoc-anh-mang-xa-hoi/index.html',
        about: 'about/index.html',
      },
    },
  },
});
