# Vật Lý MaxNgo

Mở tệp HTML trong trình duyệt. Bài học, mô phỏng, bài luyện và chấm điểm chạy trực tiếp. Cần Internet để mở tài liệu đề gốc và đáp án nguồn.

- THCS có chủ đề Vật lí thuộc Khoa học tự nhiên lớp 6–9. Kho đề lớp 9 có bài kiểm tra trường, đề học sinh giỏi và đề tuyển sinh chuyên.
- THPT có chủ đề lớp 10–12. Kho đề lớp 12 có đề tốt nghiệp, đề trường, tài liệu tham khảo và phòng thi 50 phút.
- Với mã 0201 và 0214 năm 2026, mở đề gốc ở tab bên cạnh và nhập đáp án vào phiếu. App đối chiếu bảng đáp án của Bộ. Đề mô phỏng hiển thị trực tiếp và có lời giải.
- Tiến độ luyện tập và lượt thi gần nhất được lưu trên trình duyệt. Thời gian thi tiếp tục chạy khi rời phòng. Bắt đầu đề mới thay lượt thi gần nhất.
- Mỗi thẻ tài liệu ghi loại đề, năm và nguồn. Một số tài liệu cũ theo chương trình trước GDPT 2018 được ghi chú.
- Chạy `python3 configure.py` trong thư mục mã nguồn để tạo hai bản HTML và hai bản ZIP. Có thể chỉnh các tệp nguồn riêng rồi tạo lại bản xem thử.
