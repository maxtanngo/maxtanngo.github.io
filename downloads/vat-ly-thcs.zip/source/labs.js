const mathLabs=(()=>{
 const configs={
  force:['Độ dãn lò xo','Lực kéo (N)',1,10,3,'N',x=>x/2,'cm','Lò xo có độ cứng 200 N/m và còn trong giới hạn đàn hồi.'],
  speed:['Quãng đường theo thời gian','Thời gian (s)',1,10,3,'s',x=>3*x,'m','Vật chuyển động đều với tốc độ 3 m/s.'],
  pressure:['Áp suất theo diện tích','Diện tích (m²)',1,10,3,'m²',x=>60/x,'Pa','Giữ lực ép không đổi ở 60 N.'],
  ohm9:['Dòng điện qua điện trở','Hiệu điện thế (V)',1,12,6,'V',x=>x/6,'A','Giữ điện trở ở 6 Ω.'],
  motion10:['Vận tốc theo thời gian','Thời gian (s)',1,10,3,'s',x=>2*x,'m/s','Vật xuất phát từ nghỉ với gia tốc 2 m/s².'],
  wave11:['Bước sóng theo tần số','Tần số (Hz)',1,10,3,'Hz',x=>12/x,'m','Giữ tốc độ truyền sóng ở 12 m/s.'],
  gas12:['Nén khí đẳng nhiệt','Thể tích (L)',1,10,5,'L',x=>500/x,'kPa','Khí ở 100 kPa khi thể tích là 5 L. Nhiệt độ không đổi.']
 };
 function markup(id){
  const t=configs[id];
  return t?`<section class="panel physics-lab"><h2>${t[0]}</h2><p>${t[8]}</p><label for="lab-parameter">${t[1]}</label><input id="lab-parameter" type="range" min="${t[2]}" max="${t[3]}" value="${t[4]}"><p id="lab-note" aria-live="polite"></p><canvas id="lab-canvas" width="600" height="230" aria-hidden="true"></canvas></section>`:'';
 }
 function bind(id){
  const t=configs[id],slider=document.getElementById('lab-parameter');
  if(!t||!slider)return;
  const c=document.getElementById('lab-canvas').getContext('2d');
  const scale=165/Math.max(t[6](t[2]),t[6](t[3]));
  const px=x=>44+500*(x-t[2])/(t[3]-t[2]);
  const py=y=>198-y*scale;
  const format=x=>x.toLocaleString('vi-VN',{maximumFractionDigits:2});
  function update(){
   const value=Number(slider.value),out=t[6](value);
   document.getElementById('lab-note').textContent=format(value)+' '+t[5]+' → '+format(out)+' '+t[7];
   c.clearRect(0,0,600,230);
   c.strokeStyle='#688392';c.lineWidth=1;c.beginPath();c.moveTo(44,20);c.lineTo(44,198);c.lineTo(554,198);c.stroke();
   c.fillStyle='#355463';c.font='14px system-ui';c.fillText(t[7],8,24);c.fillText(t[5],555,213);
   c.strokeStyle='#117481';c.lineWidth=3;c.beginPath();
   for(let i=0;i<=100;i++){const x=t[2]+(t[3]-t[2])*i/100; if(i)c.lineTo(px(x),py(t[6](x)));else c.moveTo(px(x),py(t[6](x)));}
   c.stroke();c.fillStyle='#9a4516';c.beginPath();c.arc(px(value),py(out),5,0,2*Math.PI);c.fill();
  }
  slider.addEventListener('input',update);update();
 }
 return {byGrade:{6:'force',7:'speed',8:'pressure',9:'ohm9',10:'motion10',11:'wave11',12:'gas12'},markup,bind};
})();
