const mockExam=(()=>{
 const points=[0,10,25,50,100];
 const {versions,mocks,parts,make}=physicsExam;
 const key='maxngo-vatly-exam-v1';
 let attempt,host,timer,storageError=false;
 const escape=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[char]);
 const format=value=>value.toLocaleString('vi-VN',{maximumFractionDigits:2});
 const current=()=>versions.find(v=>v.id===attempt?.version);
 const external=(url,label)=>`<a class="button secondary" target="_blank" rel="noopener" href="${escape(url)}">${label} ↗</a>`;
 function number(value){
  const input=String(value??'').trim().replace(',','.').replace(/−/g,'-');
  if(/^[+-]?(?:\d+(?:\.\d+)?|\.\d+)$/.test(input))return Number(input);
  const fraction=input.match(/^([+-]?\d+)\s*\/\s*([+-]?\d+)$/);
  if(fraction&&Number(fraction[2]))return Number(fraction[1])/Number(fraction[2]);
  return NaN;
 }
 function grade(questions,answers){
  return questions.map((q,i)=>{
   const a=answers[i];
   if(q.part===0)return a===q.answer?25:0;
   if(q.part===1)return points[q.statements.filter(([,right],j)=>a?.[j]===String(right)).length];
   return Math.abs(number(a)-q.answer)<1e-9?25:0;
  });
 }
 function load(){
  try{
   const saved=JSON.parse(localStorage.getItem(key));
   if(saved&&versions.some(v=>v.id===saved.version)&&Array.isArray(saved.answers)&&Number.isFinite(saved.deadline)&&Number.isInteger(saved.index)&&saved.index>=0&&saved.index<28)attempt=saved;
  }catch{storageError=true;}
 }
 function save(){
  try{localStorage.setItem(key,JSON.stringify(attempt));storageError=false;}catch{storageError=true;}
 }
 const full=(q,a)=>q.part===1?q.statements.every((_,i)=>a?.[i]==='true'||a?.[i]==='false'):String(a??'').trim()!=='';
 function detach(){clearInterval(timer);host=null;}
 function frame(html){
  host.innerHTML=`<div class="mock"><a class="text-link" href="#luyen-de">← Luyện đề</a>${storageError?'<p role="alert" class="form-error">Trình duyệt chưa lưu được đề đang làm.</p>':''}${html}</div>`;
  return host.lastElementChild;
 }
 function room(preselected){
  const start=v=>`<button class="button secondary" data-version="${v.id}">${escape(v.name)}</button>`;
  const root=frame(`<header class="page-title"><h1>Phòng thi Vật lí lớp 12</h1><p>50 phút · 28 câu · Thang điểm 10</p></header><section class="panel"><h2>Đề thi chính thức năm 2026</h2><p>Mở đề gốc ở tab khác rồi nhập đáp án vào phiếu. App chấm theo bảng đáp án của Bộ GD&ĐT.</p><div class="actions">${versions.filter(v=>v.mode==='official').map(start).join('')}</div></section><section class="panel"><h2>Đề mô phỏng tự biên soạn</h2><p>18 câu chọn đáp án, 4 câu Đúng/Sai và 6 câu trả lời ngắn. Có lời giải sau khi nộp.</p><div class="actions">${mocks.map(start).join('')}</div></section>${attempt?`<section class="panel"><h2>Lượt làm đã lưu</h2><button class="button primary" id="resume">${attempt.finished?'Xem kết quả':'Tiếp tục làm'} · ${escape(current().name)}</button></section>`:''}`);
  root.querySelector('#resume')?.addEventListener('click',showAttempt);
  root.querySelectorAll('[data-version]').forEach(button=>button.addEventListener('click',()=>{
   if(attempt&&!confirm('Bắt đầu đề mới sẽ thay thế lượt thi đang lưu. Em có muốn tiếp tục?'))return;
   const v=versions.find(x=>x.id===button.dataset.version);
   attempt={version:v.id,answers:[],index:0,deadline:Date.now()+v.minutes*60*1000,finished:false};
   save();showAttempt();
  }));
  if(preselected){
   const v=versions.find(x=>x.id===preselected&&x.mode==='official');
   if(!v)return;
   const button=root.querySelector(`[data-version="${v.id}"]`);
   if(attempt?.version===v.id)root.querySelector('#resume')?.focus();
   else button?.focus();
  }

 }
 function finish(){
  if(attempt.finished)return;
  attempt.finished=true;save();result();
 }
 function showAttempt(){
  clearInterval(timer);
  if(attempt.finished){result();return;}
  if(Date.now()>=attempt.deadline){finish();return;}
  const v=current(),questions=make(attempt.version);
  const i=attempt.index, q=questions[i], a=attempt.answers[i];
  const controls=q.part===0?q.options.map(option=>`<label class="mock-choice"><input type="radio" name="mock-option" value="${escape(option)}" ${a===option?'checked':''}> <span>${escape(option)}</span></label>`).join(''):
   q.part===1?q.statements.map(([statement],j)=>`<fieldset class="mock-statement"><legend>${'abcd'[j]}) ${escape(statement)}</legend>${['true','false'].map((value,k)=>`<label><input type="radio" name="mock-statement-${j}" data-statement="${j}" value="${value}" ${a?.[j]===value?'checked':''}> ${k?'Sai':'Đúng'}</label>`).join('')}</fieldset>`).join(''):
   `<label for="mock-number">Đáp án số</label><input class="answer-input mock-number" id="mock-number" type="text" inputmode="decimal" value="${escape(a)}" autocomplete="off" maxlength="32"><p class="mock-help">Dùng dấu phẩy hoặc dấu chấm cho số thập phân.</p>`;
  const root=frame(`<header class="page-title mock-title"><div><h1>${escape(v.name)}</h1><p id="mock-progress"></p></div><strong id="mock-timer" aria-label="Thời gian còn lại"></strong></header>${v.mode==='official'?`<div class="panel archive-instructions"><p>Giữ đúng mã đề. Phần II trong đề đánh số lại từ câu 1.</p>${external(v.file||v.url,'Mở đề gốc')}</div>`:''}<div class="mock-layout"><section class="panel" aria-labelledby="mock-prompt"><p class="tag">${parts[q.part]} · Câu ${questions.slice(0,i+1).filter(x=>x.part===q.part).length}</p><h2 id="mock-prompt" tabindex="-1">${escape(q.prompt)}</h2><div class="mock-options">${controls}</div><div class="actions"><button class="button secondary" id="mock-prev" ${i===0?'disabled':''}>← Câu trước</button><button class="button secondary" id="mock-next" ${i===questions.length-1?'disabled':''}>Câu sau →</button></div></section><aside class="panel mock-nav" aria-label="Đi đến câu hỏi">${parts.map((label,p)=>`<p>${label}</p><div class="mock-grid">${questions.map((question,j)=>question.part===p?`<button type="button" data-jump="${j}" ${j===i?'aria-current="step"':''}>${questions.slice(0,j+1).filter(x=>x.part===p).length}</button>`:'').join('')}</div>`).join('')}<button class="button primary" id="mock-submit">Nộp bài</button></aside></div>`);
  function mark(){
   root.querySelector('#mock-progress').textContent=`Đã trả lời đủ ${questions.filter((item,j)=>full(item,attempt.answers[j])).length}/${questions.length} câu`;
   root.querySelectorAll('[data-jump]').forEach(button=>{
    const j=Number(button.dataset.jump), item=questions[j], done=full(item,attempt.answers[j]);
    const within=questions.slice(0,j+1).filter(x=>x.part===item.part).length;
    button.classList.toggle('answered',done);
    button.setAttribute('aria-label',`${parts[item.part]}, câu ${within}, ${done?'đã trả lời':'chưa trả lời đủ'}`);
   });
  }
  root.querySelector('.mock-options').addEventListener('input',event=>{
   const field=event.target;
   if(q.part===1){
    if(!Array.isArray(attempt.answers[i]))attempt.answers[i]=[];
    attempt.answers[i][Number(field.dataset.statement)]=field.value;
   }else attempt.answers[i]=field.value;
   save();mark();
  });
  function jump(j){attempt.index=j;save();showAttempt();host.querySelector('#mock-prompt')?.focus();}
  root.querySelectorAll('[data-jump]').forEach(button=>button.addEventListener('click',()=>jump(Number(button.dataset.jump))));
  root.querySelector('#mock-prev').addEventListener('click',()=>jump(i-1));
  root.querySelector('#mock-next').addEventListener('click',()=>jump(i+1));
  root.querySelector('#mock-submit').addEventListener('click',()=>{
   const missing=questions.filter((item,j)=>!full(item,attempt.answers[j])).length;
   if(confirm(missing?`Còn ${missing} câu chưa trả lời đủ. Em muốn nộp bài?`:'Em muốn nộp bài và xem kết quả?'))finish();
  });
  function tick(){
   const seconds=Math.max(0,Math.ceil((attempt.deadline-Date.now())/1000));
   root.querySelector('#mock-timer').textContent=Math.floor(seconds/60)+':'+String(seconds%60).padStart(2,'0');
   if(!seconds)finish();
  }
  mark();timer=setInterval(tick,250);tick();
 }
 function result(){
  clearInterval(timer);
  const v=current(),questions=make(attempt.version),scores=grade(questions,attempt.answers);
  const total=scores.reduce((sum,p)=>sum+p,0);
  const root=frame(`<header class="page-title"><h1>Kết quả · ${escape(v.name)}</h1><p>Điểm toàn bài · <strong id="mock-score">${format(total/100)}/10</strong></p></header><div class="stats">${parts.map((name,p)=>`<div class="stat"><strong>${format(scores.reduce((sum,score,j)=>sum+(questions[j].part===p?score:0),0)/100)}/${format(v.max[p])}</strong><span>${name}</span></div>`).join('')}</div><section class="panel"><h2>${v.mode==='official'?'Đối chiếu đáp án Bộ GD&ĐT':'Đáp án và lời giải'}</h2>${v.key?external(v.key,'Mở bảng đáp án nguồn'):''}${questions.map((q,i)=>`<details class="mock-review"><summary>${parts[q.part]} · Câu ${questions.slice(0,i+1).filter(x=>x.part===q.part).length} · ${format(scores[i]/100)} điểm</summary><p><strong>${escape(q.prompt)}</strong></p>${q.part===1?q.statements.map(([statement,correct,solution],j)=>`<p>${'abcd'[j]}) ${escape(statement)}<br>Em chọn: ${choice(attempt.answers[i]?.[j])} · Đáp án: <strong>${choice(String(correct))}</strong><br>${escape(solution)}</p>`).join(''):`<p>Em trả lời: ${escape(attempt.answers[i]||'Bỏ trống')} · Đáp án: <strong>${escape(q.part===2?format(q.answer):q.answer)}</strong></p><p>${escape(q.solution)}</p>`}</details>`).join('')}</section><button class="button secondary" id="mock-room">Về phòng thi</button>`);
  root.querySelector('#mock-room').addEventListener('click',()=>room());
  root.querySelector('h1').setAttribute('tabindex','-1');root.querySelector('h1').focus();
 }
 const choice=value=>value==='true'?'Đúng':value==='false'?'Sai':'Bỏ trống';
 function render(target,preselected){host=target;room(preselected);}
 if(typeof localStorage!=='undefined')load();
 return {render,detach,make,grade,versions};
})();

