const A='Cơ học', G='Sóng và quang học', D='Điện và từ', H='Nhiệt và vật chất', N='Hạt nhân';
const topics=[];
const q=(prompt,answer,solution,hint,choices)=>({prompt,answer:String(answer),solution,hint,choices});
const mc=(prompt,answer,others,solution,hint)=>q(prompt,answer,solution,hint,[answer,...others].map(String));
const lesson=(grade,id,strand,title,rule,...examples)=>topics.push({grade,id,strand,title,rule,examples});

lesson(6,'measure',A,'Đo chiều dài và thời gian','Đặt vạch 0 của thước ngang đầu vật, nhìn vuông góc với thước. Dùng đơn vị thống nhất khi tính toán.',
 n=>q(`Một đoạn dây dài ${n} m. Đổi sang cm.`,100*n,'1 m = 100 cm nên nhân với 100.','Đổi mét sang xăng-ti-mét.'),
 n=>q(`Đổi ${n} phút sang giây.`,60*n,'1 phút có 60 giây.','Nhân với 60.'),
 n=>q(`Hai đầu bút nằm tại vạch 2 cm và ${n+2} cm. Bút dài bao nhiêu cm?`,n,'Lấy số chỉ đầu cuối trừ đầu đầu.','Lấy hiệu hai số chỉ.'));
lesson(6,'force',A,'Lực và biến dạng','Lực có thể làm vật đổi chuyển động hoặc biến dạng. Đơn vị lực là newton (N), đo bằng lực kế.',
 ()=>mc('Dụng cụ đo độ lớn của lực là gì?','Lực kế',['Nhiệt kế','Đồng hồ','Cân đong thể tích'],'Lực kế cho số chỉ theo newton.','Tìm dụng cụ có thang chia N.'),
 n=>q(`Lò xo dài tự nhiên 10 cm. Khi treo vật, chiều dài là ${10+n} cm. Độ dãn bằng bao nhiêu cm?`,n,'Độ dãn bằng chiều dài khi treo trừ chiều dài tự nhiên.','Trừ 10 cm.'),
 ()=>mc('Lực nào giữ xe đạp đang phanh giảm tốc?','Lực ma sát',['Lực đẩy Ác-si-mét','Lực đàn hồi của lò xo bất kỳ','Lực hút của nam châm'],'Ma sát giữa má phanh và bộ phận quay góp phần làm xe chậm lại.','Xét lực xuất hiện khi các bề mặt tiếp xúc.'));
lesson(6,'energy6',H,'Năng lượng và nhiệt độ','Năng lượng có thể truyền và chuyển hoá. Nhiệt tự truyền từ vật nóng hơn sang vật lạnh hơn.',
 ()=>mc('Quạt điện chủ yếu chuyển điện năng thành dạng nào?','Động năng của cánh quạt',['Thế năng hấp dẫn','Năng lượng hoá học','Năng lượng hạt nhân'],'Động cơ làm cánh quạt quay.','Xét bộ phận chuyển động.'),
 n=>q(`Nhiệt độ tăng từ 20 °C đến ${20+n} °C. Độ tăng bằng bao nhiêu °C?`,n,'Lấy nhiệt độ cuối trừ nhiệt độ đầu.','Lấy hiệu.'),
 ()=>mc('Khi đặt thìa lạnh vào cốc nước ấm, nhiệt truyền ban đầu theo chiều nào?','Từ nước sang thìa',['Từ thìa sang nước','Hai vật không truyền nhiệt','Từ thìa lên thành cốc rồi mới tới nước'],'Nước có nhiệt độ cao hơn thìa.','Nhiệt truyền từ nơi có nhiệt độ cao hơn.'));

lesson(7,'speed',A,'Tốc độ chuyển động','Tốc độ trung bình bằng tổng quãng đường chia tổng thời gian. 1 m/s = 3,6 km/h.',
 n=>q(`Xe đi ${n*12} km trong ${n} giờ. Tốc độ trung bình là bao nhiêu km/h?`,12,'Lấy quãng đường chia thời gian.','Dùng v = s/t.'),
 n=>q(`Một vật đi với tốc độ ${n} m/s trong 4 s. Quãng đường bao nhiêu m?`,4*n,'Nhân tốc độ với thời gian.','Dùng s = vt.'),
 n=>q(`Đổi ${n*36} km/h sang m/s.`,10*n,'Chia cho 3,6.','Mỗi km bằng 1000 m, mỗi giờ bằng 3600 s.'));
lesson(7,'sound',G,'Âm thanh','Nguồn âm dao động. Tần số (Hz) là số dao động trong một giây; tần số lớn hơn cho âm cao hơn trong cùng điều kiện.',
 n=>q(`Nguồn thực hiện ${120*n} dao động trong ${n} s. Tần số bằng bao nhiêu Hz?`,120,'Chia số dao động cho thời gian.','Đếm số lần trong một giây.'),
 ()=>mc('Âm truyền được qua môi trường nào?','Nước',['Chân không hoàn hảo','Chỉ khoảng trống tuyệt đối','Không cần môi trường'],'Nước là môi trường vật chất truyền được âm.','Âm cần môi trường vật chất.'),
 ()=>mc('Tần số tăng trong khi biên độ giữ nguyên, âm thay đổi thế nào?','Cao hơn',['Thấp hơn','Chắc chắn to hơn','Không đổi độ cao'],'Độ cao liên quan tới tần số.','Phân biệt cao/thấp với to/nhỏ.'));
lesson(7,'mirror',G,'Phản xạ ánh sáng','Góc tới và góc phản xạ đo từ pháp tuyến. Với gương phẳng, góc phản xạ bằng góc tới.',
 n=>q(`Tia tới tạo với pháp tuyến góc ${n*5}°. Góc phản xạ bằng bao nhiêu độ?`,n*5,'Góc phản xạ bằng góc tới.','Hai góc đều tính từ pháp tuyến.'),
 n=>q(`Vật cách gương phẳng ${n} cm. Khoảng cách từ vật đến ảnh là bao nhiêu cm?`,2*n,'Ảnh ở sau gương một khoảng bằng khoảng cách từ vật đến gương.','Cộng hai khoảng cách tới mặt gương.'),
 ()=>mc('Ảnh của vật trước gương phẳng có tính chất nào?','Ảnh ảo, bằng vật',['Ảnh thật, lớn hơn vật','Ảnh thật, nhỏ hơn vật','Ảnh ảo, luôn nhỏ hơn vật'],'Ảnh và vật đối xứng qua mặt gương.','Có hứng được ảnh trên màn không?'));
lesson(7,'magnet',D,'Nam châm và từ trường','Hai cực cùng tên đẩy nhau, hai cực khác tên hút nhau. Kim la bàn chỉ phương của từ trường tại nơi đặt.',
 ()=>mc('Cực Bắc của nam châm đặt gần cực Nam của nam châm khác sẽ thế nào?','Hút nhau',['Đẩy nhau','Không tương tác','Lúc nào cũng mất từ tính'],'Hai cực khác tên hút nhau.','So sánh tên của hai cực.'),
 ()=>mc('Dụng cụ nào nhận biết hướng từ trường tại một điểm?','Kim la bàn',['Thước thẳng','Ống đong','Lực kế lò xo'],'Kim từ định hướng theo từ trường tại vị trí đặt.','Tìm dụng cụ có kim nam châm.'),
 ()=>mc('Khi cắt một thanh nam châm làm hai, mỗi mảnh thường có gì?','Cả cực Bắc và cực Nam',['Chỉ một cực Bắc','Chỉ một cực Nam','Không còn cực nào'],'Mỗi mảnh vẫn có hai cực từ.','Các cực từ của nam châm thường xuất hiện thành cặp.'));

lesson(8,'pressure',A,'Khối lượng riêng và áp suất','Khối lượng riêng ρ = m/V. Áp suất trên mặt bị ép p = F/S, với lực ép vuông góc và S tính bằng m².',
 n=>q(`Một khối có khối lượng ${2*n} kg và thể tích ${n} lít. Khối lượng riêng bằng bao nhiêu kg/m³?`,2000,'Đổi lít ra m³ rồi lấy khối lượng chia thể tích.','1 lít = 0,001 m³.'),
 n=>q(`Lực ép ${100*n} N tác dụng đều lên diện tích ${n} m². Áp suất bằng bao nhiêu Pa?`,100,'Áp suất bằng lực ép chia diện tích.','Dùng p = F/S.'),
 ()=>mc('Với cùng lực ép, diện tích tiếp xúc giảm một nửa thì áp suất thay đổi thế nào?','Tăng gấp đôi',['Giảm một nửa','Không đổi','Tăng gấp bốn'],'Áp suất tỉ lệ nghịch với diện tích nếu lực ép không đổi.','Xét diện tích ở mẫu số.'));
lesson(8,'moment8',A,'Tác dụng làm quay của lực','Moment của lực quanh trục bằng lực nhân với khoảng cách vuông góc từ trục quay đến giá của lực.',
 n=>q(`Lực ${n*10} N vuông góc với tay đòn dài 0,5 m. Moment bằng bao nhiêu N·m?`,5*n,'Nhân lực với 0,5 m.','Dùng M = Fd.'),
 n=>q(`Lực ${n*8} N đặt ở tay đòn 0,25 m. Lực cân bằng ở tay đòn 0,5 m bằng bao nhiêu N?`,4*n,'Cân bằng khi hai moment ngược chiều bằng nhau.','Lập F₁d₁ = F₂d₂.'),
 ()=>mc('Đẩy cửa tại vị trí xa bản lề hơn, cùng lực và cùng phương vuông góc, tác dụng quay ra sao?','Mạnh hơn',['Yếu hơn','Không đổi','Luôn bằng 0'],'Tay đòn dài hơn làm moment tăng.','Xét khoảng cách đến trục quay.'));
lesson(8,'thermal8',H,'Dẫn nhiệt, đối lưu và bức xạ','Dẫn nhiệt xảy ra qua tiếp xúc. Đối lưu đi kèm dòng chuyển động của chất lỏng hoặc khí. Bức xạ nhiệt truyền được qua chân không.',
 ()=>mc('Năng lượng từ Mặt Trời đến Trái Đất chủ yếu bằng cách nào?','Bức xạ nhiệt',['Dẫn nhiệt','Đối lưu của không khí giữa hai thiên thể','Truyền âm'],'Bức xạ truyền qua khoảng không.','Xét khả năng truyền qua chân không.'),
 ()=>mc('Nước nóng đi lên và nước lạnh đi xuống khi đun là ví dụ của gì?','Đối lưu',['Bức xạ đơn thuần','Phản xạ','Sự nhiễm điện'],'Chuyển động của nước tạo dòng đối lưu.','Có dòng vật chất chuyển động.'),
 ()=>mc('Tay cầm nồi thường bọc vật liệu nào để giảm truyền nhiệt?','Nhựa chịu nhiệt',['Đồng','Nhôm','Sắt'],'Nhựa chịu nhiệt thường dẫn nhiệt kém hơn kim loại.','Tìm vật liệu cách nhiệt.'));
lesson(8,'circuit8',D,'Mạch điện và đo điện','Ampe kế mắc nối tiếp để đo cường độ dòng điện. Vôn kế mắc song song với bộ phận cần đo hiệu điện thế.',
 ()=>mc('Mắc ampe kế thế nào để đo dòng qua đèn?','Nối tiếp với đèn',['Song song với đèn','Không cần nối vào mạch','Chỉ nối một đầu dây'],'Dòng qua đèn phải đi qua ampe kế.','Chọn cách mắc chung một nhánh.'),
 n=>q(`Đổi ${50*n} mA sang A.`,n*.05,'Chia số miliampe cho 1000.','1 A = 1000 mA.'),
 ()=>mc('Mạch chỉ gồm nguồn, dây, công tắc và đèn mắc nối tiếp. Khi công tắc mở, đèn thế nào?','Tắt',['Sáng hơn','Sáng như cũ','Luôn nhấp nháy'],'Mạch hở nên dòng điện ổn định không chạy qua đèn.','Xét đường đi kín của dòng điện.'));

lesson(9,'work9',A,'Công, công suất và cơ năng','Khi lực cùng hướng chuyển động, A = Fs. P = A/t. Động năng bằng mv²/2, thế năng gần mặt đất bằng mgh so với mốc đã chọn.',
 n=>q(`Dùng lực ${10*n} N kéo vật đi 5 m theo phương của lực. Công là bao nhiêu J?`,50*n,'Nhân lực với quãng đường cùng hướng.','Dùng A = Fs.'),
 n=>q(`Một thiết bị thực hiện công ${120*n} J trong ${n} s. Công suất bao nhiêu W?`,120,'Công suất là công mỗi giây.','Dùng P = A/t.'),
 n=>q(`Vật khối lượng ${2*n} kg chuyển động với tốc độ 3 m/s. Động năng bằng bao nhiêu J?`,9*n,'Thay m và v vào mv²/2.','Bình phương tốc độ.'));
lesson(9,'ohm9',D,'Định luật Ohm và mạch điện','Với điện trở không đổi, I = U/R. Điện trở nối tiếp cộng trực tiếp; với hai nhánh song song, 1/Rtđ = 1/R₁ + 1/R₂.',
 n=>q(`Điện trở ${n} Ω đặt dưới hiệu điện thế ${2*n} V. Dòng điện bao nhiêu A?`,2,'Lấy hiệu điện thế chia điện trở.','Dùng I = U/R.'),
 n=>q(`Hai điện trở ${n} Ω và ${2*n} Ω mắc nối tiếp. Điện trở tương đương bao nhiêu Ω?`,3*n,'Cộng điện trở hai phần tử.','Dòng điện đi lần lượt qua cả hai.'),
 n=>q(`Hai điện trở bằng nhau, mỗi cái ${2*n} Ω, mắc song song. Điện trở tương đương bao nhiêu Ω?`,n,'Hai điện trở bằng nhau mắc song song cho Rtđ bằng một nửa.','Cộng nghịch đảo rồi đảo kết quả.'));
lesson(9,'electric9',D,'Công suất và điện năng','P = UI. Điện năng A = Pt; dùng P theo kW và t theo giờ để tính kWh.',
 n=>q(`Một điện trở hoạt động ở 12 V với dòng ${n} A. Công suất bao nhiêu W?`,12*n,'P = UI.','Nhân hiệu điện thế với dòng điện.'),
 n=>q(`Máy công suất 0,5 kW chạy ${2*n} giờ. Dùng bao nhiêu kWh?`,n,'Nhân kW với giờ.','Không cần đổi giờ sang giây khi tính kWh.'),
 n=>q(`Một điện trở ${n} Ω có dòng 2 A chạy qua. Công suất tỏa nhiệt bao nhiêu W?`,4*n,'Kết hợp P = UI với U = IR, được P = I²R.','Bình phương 2 A.'));
lesson(9,'lens9',G,'Khúc xạ và thấu kính','Khi ánh sáng đi từ không khí vào nước với góc tới khác 0, tia khúc xạ lệch về phía pháp tuyến. Với thấu kính hội tụ, vật ngoài tiêu cự cho ảnh thật, vật trong tiêu cự cho ảnh ảo.',
 n=>q(`Thấu kính hội tụ có tiêu cự ${n} cm. Đặt vật cách kính ${2*n} cm. Ảnh thật cách kính bao nhiêu cm?`,2*n,'Vật ở 2f thì ảnh thật ở 2f phía bên kia kính.','Dựng tia song song và tia qua quang tâm.'),
 ()=>mc('Đặt vật trong khoảng tiêu cự của kính lúp. Ảnh qua kính là gì?','Ảnh ảo, cùng chiều và lớn hơn vật',['Ảnh thật, cùng chiều','Ảnh thật, ngược chiều và nhỏ hơn vật','Ảnh ảo, ngược chiều'],'Kính lúp hoạt động như thấu kính hội tụ với vật trong tiêu cự.','So sánh vị trí vật với tiêu điểm.'),
 ()=>mc('Ánh sáng xiên từ không khí đi vào nước. Góc khúc xạ so với góc tới ra sao?','Nhỏ hơn',['Lớn hơn','Luôn bằng 90°','Luôn bằng góc tới'],'Tia khúc xạ lệch về pháp tuyến.','Đo góc từ pháp tuyến.'));
lesson(9,'induction9',D,'Cảm ứng điện từ và dòng xoay chiều','Dòng cảm ứng xuất hiện trong mạch kín khi từ thông qua mạch biến thiên. Khi sự biến thiên đổi chiều lặp lại, dòng có thể đổi chiều tuần hoàn.',
 ()=>mc('Đưa nam châm lại gần cuộn dây kín đang đứng yên có thể tạo ra gì?','Dòng điện cảm ứng',['Luôn không có dòng','Dòng chỉ khi nam châm dừng hẳn','Chỉ dòng do nguồn pin'],'Từ thông qua vòng dây thay đổi khi khoảng cách thay đổi.','Xét từ thông qua cuộn dây.'),
 ()=>mc('Nam châm đứng yên so với cuộn dây kín, từ thông không đổi. Có dòng cảm ứng duy trì không?','Không',['Có, luôn rất lớn','Có, nếu cuộn dây dài','Có, bất kể từ thông'],'Không có biến thiên từ thông nên không có suất điện động cảm ứng.','Đứng yên và từ thông không đổi.'),
 ()=>mc('Dòng điện xoay chiều có đặc điểm nào?','Đổi chiều tuần hoàn',['Luôn chỉ chạy một chiều','Luôn bằng 0','Luôn do pin một chiều trực tiếp tạo ra'],'Chiều dòng điện luân phiên đổi theo thời gian.','Nhớ nghĩa của “xoay chiều”.'));

lesson(10,'motion10',A,'Động học và đồ thị vận tốc','Chuyển động thẳng biến đổi đều có v = v₀ + at và độ dịch chuyển x − x₀ = v₀t + at²/2.',
 n=>q(`Vật xuất phát từ nghỉ với gia tốc 2 m/s². Sau ${n} s tốc độ bao nhiêu m/s?`,2*n,'Thay v₀ = 0 vào v = v₀ + at.','Tích a·t.'),
 n=>q(`Vật xuất phát từ nghỉ với gia tốc 2 m/s² trong ${n} s. Độ dịch chuyển bao nhiêu m?`,n*n,'Với v₀ = 0, độ dịch chuyển bằng at²/2.','Bình phương thời gian.'),
 ()=>mc('Độ dốc của đồ thị vận tốc theo thời gian bằng đại lượng nào?','Gia tốc',['Quãng đường','Động lượng','Khối lượng'],'Độ dốc bằng Δv/Δt.','Chia độ biến thiên vận tốc cho thời gian.'));
lesson(10,'newton10',A,'Định luật Newton','Hợp lực gây ra gia tốc, ΣF = ma. Hai lực tương tác trong định luật III cùng độ lớn, ngược chiều và tác dụng lên hai vật khác nhau.',
 n=>q(`Hợp lực ${n*6} N tác dụng lên vật khối lượng ${n} kg. Gia tốc bao nhiêu m/s²?`,6,'Chia hợp lực cho khối lượng.','Dùng a = F/m.'),
 ()=>mc('Khi xe đột ngột phanh, hành khách có xu hướng chúi về trước do đâu?','Quán tính',['Áp suất khí quyển','Lực nổi','Vận tốc của xe tăng'],'Cơ thể có xu hướng duy trì trạng thái chuyển động đang có.','Nghĩ về định luật I Newton.'),
 ()=>mc('Cặp lực theo định luật III Newton tác dụng lên đâu?','Hai vật khác nhau',['Cùng một vật','Chỉ vật nặng hơn','Chỉ vật đứng yên'],'Hai lực của một tương tác tác dụng lên hai vật tham gia tương tác.','Xác định vật nhận mỗi lực.'));
lesson(10,'momentum10',A,'Động lượng và va chạm','Động lượng p = mv là vectơ. Tổng động lượng được bảo toàn khi xung lượng của ngoại lực không đáng kể.',
 n=>q(`Vật ${n} kg chuyển động với tốc độ 3 m/s. Độ lớn động lượng bao nhiêu kg·m/s?`,3*n,'Nhân khối lượng với tốc độ.','Dùng p = mv.'),
 n=>q(`Hai xe đều có khối lượng ${n} kg. Xe thứ nhất có vận tốc 6 m/s, xe kia đứng yên. Sau va chạm dính, bỏ qua ngoại lực, tốc độ chung bao nhiêu m/s?`,3,'Bảo toàn động lượng cho mv = 2mV.','Tổng khối lượng sau va chạm gấp đôi.'),
 ()=>mc('Động lượng cùng hướng với đại lượng nào?','Vận tốc',['Gia tốc trong mọi trường hợp','Hợp lực trong mọi trường hợp','Trọng lực trong mọi trường hợp'],'Khối lượng dương nên mv cùng hướng v.','Động lượng là đại lượng vectơ.'));
lesson(10,'circle10',A,'Chuyển động tròn và năng lượng','Gia tốc hướng tâm aₕₜ = v²/r. Công của lực không đổi bằng Fs cos α. Động năng Eđ = mv²/2.',
 n=>q(`Vật quay với tốc độ ${2*n} m/s trên đường tròn bán kính ${n} m. Gia tốc hướng tâm bao nhiêu m/s²?`,4*n,'Lấy bình phương tốc độ chia bán kính.','Dùng a = v²/r.'),
 n=>q(`Lực ${10*n} N tác dụng theo hướng hợp với độ dịch chuyển 60°. Vật dịch chuyển 2 m. Công bằng bao nhiêu J?`,10*n,'A = Fs cos 60°, với cos 60° = 0,5.','Dùng thành phần lực theo hướng dịch chuyển.'),
 ()=>mc('Nếu tốc độ tăng gấp đôi và khối lượng giữ nguyên, động năng tăng bao nhiêu lần?','4 lần',['2 lần','Không đổi','8 lần'],'Động năng tỉ lệ với bình phương tốc độ.','Bình phương hệ số thay đổi.'));

lesson(11,'osc11',G,'Dao động điều hòa','Với x = A cos(ωt + φ), T = 2π/ω, f = 1/T và tốc độ cực đại vₘₐₓ = ωA.',
 n=>q(`Một vật dao động với chu kì ${n} s. Sau ${3*n} s thực hiện bao nhiêu dao động toàn phần?`,3,'Lấy thời gian chia chu kì.','Mỗi chu kì là một dao động.'),
 n=>q(`Vật dao động với biên độ ${n} cm và ω = 4 rad/s. Tốc độ cực đại bao nhiêu cm/s?`,4*n,'Tích ωA cho tốc độ cực đại.','Nhân tần số góc với biên độ.'),
 ()=>mc('Tốc độ của vật dao động điều hòa lớn nhất ở đâu?','Vị trí cân bằng',['Biên dương','Biên âm','Mọi vị trí đều như nhau'],'Tại cân bằng, động năng cực đại.','Ở hai biên tốc độ bằng 0.'));
lesson(11,'wave11',G,'Sóng cơ và giao thoa','Bước sóng λ = v/f. Hai nguồn đồng pha tạo cực đại tại nơi hiệu đường đi bằng số nguyên lần bước sóng.',
 n=>q(`Sóng có tần số ${n} Hz, tốc độ ${4*n} m/s. Bước sóng bao nhiêu m?`,4,'Chia tốc độ truyền sóng cho tần số.','Dùng λ = v/f.'),
 n=>q(`Sóng có bước sóng ${n} m và chu kì 0,5 s. Tốc độ truyền bao nhiêu m/s?`,2*n,'Tốc độ bằng λ/T.','Chia bước sóng cho chu kì.'),
 ()=>mc('Hai nguồn cùng pha, hai đường đi đến điểm M có độ dài bằng nhau. M thuộc loại nào?','Cực đại giao thoa',['Cực tiểu giao thoa','Không có sóng truyền tới','M luôn đứng yên'],'Hiệu đường đi bằng 0 lần bước sóng.','Hai dao động tới M cùng pha.'));
lesson(11,'field11',D,'Điện trường và tụ điện','Độ lớn lực điện lên điện tích q trong điện trường đều là |q|E. Với tụ điện, Q = CU; năng lượng W = CU²/2.',
 n=>q(`Điện tích ${n} μC ở nơi E = 1000 V/m. Lực điện có độ lớn bao nhiêu mN?`,n,'Nhân E với điện tích đổi ra C, sau đó đổi N sang mN.','1 μC = 10⁻⁶ C, 1 mN = 10⁻³ N.'),
 n=>q(`Tụ ${n} μF đặt dưới hiệu điện thế 5 V. Điện tích của tụ bao nhiêu μC?`,5*n,'Dùng Q = CU.','μF nhân V cho μC.'),
 ()=>mc('Lực điện tác dụng lên điện tích âm có chiều nào so với vectơ điện trường?','Ngược chiều',['Cùng chiều','Vuông góc','Luôn bằng 0'],'Vectơ F = qE với q âm.','Dấu của điện tích quyết định chiều.'));
lesson(11,'source11',D,'Nguồn điện và mạch kín','Với nguồn có suất điện động ℰ và điện trở trong r mắc với điện trở ngoài R, I = ℰ/(R+r).',
 n=>q(`Nguồn ${3*n} V có điện trở trong ${n} Ω mắc điện trở ngoài ${2*n} Ω. Dòng bao nhiêu A?`,1,'Điện trở toàn mạch bằng 3n Ω.','Cộng điện trở trong và ngoài.'),
 n=>q(`Pin có suất điện động ${n+2} V, điện trở trong 1 Ω, cấp dòng 2 A. Điện áp đầu cực bao nhiêu V?`,n,'Hiệu điện thế mạch ngoài U = ℰ − Ir.','Trừ độ sụt áp trong nguồn.'),
 ()=>mc('Vì sao không nên nối trực tiếp hai cực của pin bằng dây dẫn?','Có thể gây dòng điện lớn và nóng',['Hiệu điện thế mạch ngoài tăng vô hạn','Điện trở toàn mạch tăng vô hạn','Pin không còn khả năng sinh dòng'],'Khi điện trở ngoài rất nhỏ, dòng bị giới hạn chủ yếu bởi điện trở trong.','Xét I khi R gần 0.'));

lesson(12,'heat12',H,'Nhiệt lượng và chuyển thể','Khi nhiệt độ thay đổi mà không chuyển thể, Q = mcΔT. Nóng chảy ở nhiệt độ nóng chảy cần Q = mλ.',
 n=>q(`Đun ${n} kg nước tăng 10 °C. Biết c = 4200 J/(kg·K). Nhiệt lượng bao nhiêu kJ?`,42*n,'Nhân m, c và 10; chia 1000 để đổi sang kJ.','Độ tăng 10 °C bằng 10 K.'),
 n=>q(`Nóng chảy ${n} kg nước đá ở 0 °C, λ = 334 kJ/kg. Nhiệt lượng bao nhiêu kJ?`,334*n,'Dùng Q = mλ khi chuyển thể.','Không dùng mcΔT ở giai đoạn nóng chảy.'),
 ()=>mc('Ở áp suất không đổi, nhiệt độ của chất tinh khiết trong quá trình nóng chảy thế nào?','Giữ ở nhiệt độ nóng chảy',['Tăng đều','Giảm đều','Phụ thuộc vào khối lượng theo tỉ lệ thuận'],'Nhiệt cung cấp dùng cho chuyển thể.','Xét giai đoạn cả rắn và lỏng cùng tồn tại.'));
lesson(12,'first12',H,'Nội năng và định luật I','Theo quy ước nhiệt lượng nhận vào Q > 0 và công hệ nhận A > 0, độ biến thiên nội năng ΔU = Q + A.',
 n=>q(`Khí nhận ${20*n} J nhiệt và thực hiện ${5*n} J công. Nội năng tăng bao nhiêu J?`,15*n,'Công khí thực hiện tương ứng A âm theo quy ước công nhận vào.','Lấy nhiệt nhận trừ công khí thực hiện.'),
 n=>q(`Hệ nhận công ${n*10} J và tỏa ${n*3} J nhiệt. ΔU bằng bao nhiêu J?`,7*n,'Q âm, A dương, cộng đại số.','Xác định dấu trước khi thế số.'),
 ()=>mc('Quá trình đoạn nhiệt có đại lượng nào bằng 0?','Nhiệt lượng trao đổi',['Công trong mọi trường hợp','Áp suất','Nội năng trong mọi trường hợp'],'Đoạn nhiệt nghĩa là không trao đổi nhiệt với môi trường.','Xét đại lượng Q.'));
lesson(12,'gas12',H,'Khí lí tưởng và các đẳng quá trình','Với lượng khí không đổi, pV/T không đổi, T tính bằng kelvin. Đẳng nhiệt dùng p₁V₁ = p₂V₂.',
 n=>q(`Khí chiếm ${2*n} lít ở 100 kPa. Nén đẳng nhiệt còn ${n} lít. Áp suất mới bao nhiêu kPa?`,200,'Thể tích giảm một nửa thì áp suất tăng gấp đôi.','Dùng p₁V₁ = p₂V₂.'),
 n=>q(`Ở áp suất không đổi, khí có thể tích ${n} lít ở 300 K. Ở 450 K thể tích bao nhiêu lít?`,1.5*n,'Dùng V₂ = V₁T₂/T₁.','Dùng nhiệt độ tuyệt đối.'),
 ()=>mc('Bình kín, cứng chứa khí lí tưởng được làm nóng. Áp suất thay đổi thế nào?','Tăng',['Giảm','Không đổi','Luôn về 0'],'Lượng khí và thể tích cố định nên p tỉ lệ với T tuyệt đối.','Dùng pV = nRT.'));
lesson(12,'mag12',D,'Từ trường và lực từ','Dây dài L mang dòng I trong từ trường đều B chịu lực F = BIL sin α, với α là góc giữa chiều dòng và vectơ B.',
 n=>q(`Dây dài ${n} m vuông góc với B = 0,5 T, có dòng 2 A. Lực từ bao nhiêu N?`,n,'sin 90° = 1; nhân BIL.','Dây vuông góc với từ trường.'),
 ()=>mc('Dây dẫn song song với đường sức của từ trường đều. Lực từ có độ lớn thế nào?','Bằng 0',['Cực đại','Bằng BIL/2','Không xác định nếu biết góc 0°'],'sin 0° = 0.','Dùng thừa số sin α.'),
 n=>q(`Dây 1 m đặt vuông góc với từ trường, dòng 2 A, lực từ ${n*2} N. Độ lớn B bao nhiêu T?`,n,'Chia lực cho tích dòng điện và chiều dài.','B = F/(IL).'));
lesson(12,'em12',D,'Từ thông và cảm ứng điện từ','Từ thông qua một vòng phẳng là Φ = BS cos α, với α là góc giữa B và pháp tuyến. Độ lớn suất điện động cảm ứng trung bình là N|ΔΦ/Δt|.',
 n=>q(`Từ thông mỗi vòng đổi ${n} mWb trong 0,1 s. Cuộn có 100 vòng. Suất điện động trung bình bao nhiêu V?`,n,'Đổi mWb thành Wb rồi nhân 100, chia 0,1.','Dùng độ biến thiên qua mỗi vòng.'),
 ()=>mc('Từ thông lớn nhất theo độ lớn khi B hướng như thế nào so với mặt vòng dây?','Vuông góc mặt vòng',['Nằm trong mặt vòng','Tạo góc 45° với mặt vòng','Song song một cạnh trong mặt vòng'],'Khi B dọc theo pháp tuyến, |cos α| = 1.','Góc α đo với pháp tuyến.'),
 n=>q(`Máy biến áp lí tưởng có cuộn thứ cấp gấp ${n} lần số vòng sơ cấp. Điện áp hiệu dụng sơ cấp 20 V. Thứ cấp bao nhiêu V?`,20*n,'Tỉ số điện áp bằng tỉ số số vòng dây.','Tăng áp theo số vòng.'));
lesson(12,'nuclear12',N,'Hạt nhân và phóng xạ','Số khối bằng tổng proton và neutron. Sau k chu kì bán rã, số hạt chưa phân rã bằng N₀/2ᵏ.',
 n=>q(`Một mẫu có ${8*n} triệu hạt chưa phân rã lúc đầu. Sau 3 chu kì bán rã còn bao nhiêu triệu hạt?`,n,'Chia 2 ba lần, tức chia 8.','Mỗi chu kì số hạt còn lại giảm một nửa.'),
 n=>q(`Một hạt nhân có số khối ${20+n}, số proton là 10. Có bao nhiêu neutron?`,10+n,'Lấy số khối trừ số proton.','A = Z + N.'),
 ()=>mc('Hạt α là hạt nhân của nguyên tử nào?','Heli-4',['Hiđrô-1','Hiđrô-2','Liti-7'],'Hạt α có 2 proton và 2 neutron.','Số proton là 2, số khối là 4.'));
const content=topics.map(t=>({...t,examples:t.examples.map((make,i)=>make(3+i))}));
if(typeof module!=='undefined')module.exports={topics,content};

const physicsPacks9={
 work9:{title:'Luyện lớp 9 · Cơ năng',items:[
  ...topics.find(t=>t.id==='work9').examples.map(fn=>fn(4)),
  q('Nâng đều vật 3 kg lên cao 2 m, lấy g = 10 m/s². Thế năng tăng bao nhiêu J?',60,'ΔEt = mgh = 3×10×2 = 60 J.','Lấy độ cao so với vị trí lúc đầu.'),
  q('Một động cơ nâng vật với lực 150 N theo phương thẳng đứng lên 4 m trong 3 s. Công suất trung bình bằng bao nhiêu W?',200,'A = 150×4 = 600 J. P = 600/3 = 200 W.','Tính công trước rồi chia thời gian.'),
  q('Vật 2 kg giảm tốc từ 6 m/s xuống 4 m/s. Động năng giảm bao nhiêu J?',20,'Động năng đầu 36 J, cuối 16 J, giảm 20 J.','Tính hiệu hai giá trị mv²/2.'),
  mc('Vật được ném thẳng đứng lên. Bỏ qua lực cản, khi vật đi lên, dạng năng lượng nào tăng?','Thế năng hấp dẫn',['Động năng','Cả động năng và thế năng','Nội năng do ma sát không khí'],'Độ cao tăng nên thế năng tăng; động năng giảm tương ứng.','Theo dõi độ cao.'),
  q('Vật rơi từ trạng thái nghỉ, giảm độ cao 5 m, bỏ qua lực cản. Với g = 10 m/s², tốc độ cuối là bao nhiêu m/s?',10,'Bảo toàn cơ năng: mgh = mv²/2, suy ra v = √(2gh) = 10.','Thế năng giảm bằng động năng tăng.'),
  q('Máy nhận 500 J năng lượng, làm công có ích 350 J. Hiệu suất bằng bao nhiêu phần trăm?',70,'Chia 350 cho 500 rồi nhân 100%.','Lấy phần có ích chia năng lượng toàn phần.')
 ]},
 ohm9:{title:'Luyện lớp 9 · Điện và từ',items:[
  ...topics.find(t=>t.id==='ohm9').examples.map(fn=>fn(4)),
  ...topics.find(t=>t.id==='electric9').examples.map(fn=>fn(3)),
  q('Điện trở 6 Ω song song 3 Ω, rồi cả cụm nối tiếp 4 Ω. Mắc vào nguồn 12 V. Tính dòng mạch chính theo A.',2,'Cụm song song có 2 Ω. Toàn mạch có 6 Ω. I = 12/6 = 2 A.','Rút gọn từng cụm.'),
  q('Thiết bị 240 W chạy 30 phút mỗi ngày trong 10 ngày. Tính điện năng theo kWh.',1.2,'P = 0,24 kW, tổng thời gian 5 h, A = 1,2 kWh.','Đổi sang kW và giờ.'),
  mc('Khi đưa một cực nam châm lại gần cuộn dây kín, rồi kéo ra xa theo cùng đường, chiều dòng cảm ứng thay đổi thế nào?','Đổi chiều',['Giữ nguyên','Luôn bằng 0','Chỉ phụ thuộc màu dây'],'Chiều biến thiên từ thông đảo nên dòng cảm ứng đảo chiều.','So sánh từ thông tăng và giảm.')
 ]},
 lens9:{title:'Luyện lớp 9 · Quang học',items:[
  ...topics.find(t=>t.id==='lens9').examples.map(fn=>fn(5)),
  mc('Tia chiếu từ nước ra không khí có góc tới đủ lớn để xảy ra phản xạ toàn phần. Tia truyền ra ngoài có xuất hiện không?','Không',['Có, luôn vuông góc','Có, luôn song song với pháp tuyến','Có, luôn đi theo đường cũ'],'Tại góc tới lớn hơn góc giới hạn, không có tia khúc xạ truyền đi trong không khí.','Điều kiện là đi từ chiết suất lớn sang nhỏ.'),
  mc('Tia tới song song trục chính của thấu kính hội tụ. Sau khi qua kính, tia đi qua điểm nào?','Tiêu điểm ảnh',['Tâm nguồn sáng','Mọi điểm trên trục','Tiêu điểm phía vật với mọi vị trí'],'Tia tới song song trục ló qua tiêu điểm ảnh.','Dùng một trong ba tia đặc biệt.'),
  mc('Tia đi qua quang tâm của thấu kính mỏng theo mô hình tia gần trục có tính chất gì?','Truyền thẳng',['Phản xạ ngược lại','Luôn đi song song trục chính','Đổi chiều 90°'],'Theo mô hình thấu kính mỏng, tia qua quang tâm truyền thẳng.','Dựng tia đặc biệt qua tâm kính.'),
  q('Vật đặt cách thấu kính hội tụ 30 cm, ảnh thật cách kính 15 cm. Tính tiêu cự theo cm bằng hệ thức 1/f = 1/d + 1/d′.',10,'1/f = 1/30 + 1/15 = 1/10.','Quy đồng hai phân số.'),
  q('Một ảnh thật cao 2 cm ứng với vật cao 4 cm. Tính độ lớn độ phóng đại.',0.5,'Độ lớn độ phóng đại là chiều cao ảnh chia chiều cao vật.','Lấy 2 chia 4.'),
  mc('Muốn kiểm tra một ảnh của thấu kính có phải ảnh thật, có thể làm gì?','Đặt màn tại vị trí ảnh để hứng',['Chỉ nhìn từ phía vật','Che kín thấu kính','Luôn đưa vật vào trong tiêu cự'],'Ảnh thật do các tia ló hội tụ nên hứng được trên màn.','Xét khả năng hứng ảnh.')
 ]}
};
