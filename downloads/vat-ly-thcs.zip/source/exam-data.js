const physicsExam=(()=>{
 const parts=['I · Chọn đáp án','II · Đúng / Sai','III · Trả lời ngắn'];
 const levels=['Cơ bản','Vận dụng','Nâng cao'];
 const mocks=levels.map((level,i)=>({id:'mo-phong-'+i,name:'Đề mô phỏng · '+level,minutes:50,mode:'mock',max:[4.5,4,1.5]}));
 const registry=archive.records.filter(r=>r.answers).map(r=>({...r,minutes:50,mode:'official',max:[4.5,4,1.5]}));
 const versions=[...mocks,...registry];
 const mc=(prompt,answer,options,solution)=>({part:0,prompt,answer:String(answer),options:[answer,...options].map(String),solution});
 const tf=(prompt,statements)=>({part:1,prompt,statements});
 const num=(prompt,answer,solution)=>({part:2,prompt,answer,solution});
 function mock(v){
  const level=mocks.indexOf(v),n=level+2;
  const questions=topics.filter(t=>t.grade===12).flatMap(t=>t.examples.map(make=>{
   const item=make(n);
   if(item.choices)return {part:0,prompt:item.prompt,answer:item.answer,options:item.choices,solution:item.solution};
   const x=Number(item.answer);
   return mc(item.prompt,x,[x+1,x*2+1,x*3+2],item.solution);
  }));
  if(level>0){
   questions[0]=mc(`Đun nóng ${n} kg nước từ 20 °C lên 30 °C bằng bếp có hiệu suất 70%. Cho c = 4200 J/(kg·K). Năng lượng bếp tiêu thụ là bao nhiêu kJ?`,60*n,[42*n,30*n,70*n],'Nhiệt nước nhận là 42n kJ. Chia cho hiệu suất 0,70.');
   questions[6]=mc(`Một bình cứng chứa khí lí tưởng ở áp suất tuyệt đối 90 kPa và nhiệt độ 300 K. Sau khi làm nóng thêm ${20*n} K, áp suất bằng bao nhiêu kPa?`,90+6*n,[90-6*n,90+3*n,90+20*n],'V không đổi nên p₂/p₁ = T₂/T₁.');
  }
  if(level===2){
   questions[12]=mc('Một cuộn dây quay đều trong từ trường đều. Khi từ thông tức thời qua cuộn dây bằng 0, độ lớn suất điện động tức thời bằng bao nhiêu?','Cực đại',['Bằng 0','Bằng nửa cực đại','Không phụ thuộc trạng thái quay'],'Từ thông và suất điện động lệch pha π/2; tại lúc từ thông bằng 0, tốc độ biến thiên lớn nhất.');
   questions[15]=mc('Mẫu phóng xạ còn 25% số hạt ban đầu sau 8 ngày. Sau 12 ngày, phần trăm hạt đã phân rã là bao nhiêu?',87.5,[12.5,75,50],'8 ngày là 2 chu kì nên T = 4 ngày. Sau 3 chu kì còn 12,5%, tức đã phân rã 87,5%.');
  }
  questions.push(
   tf(`Một hệ nhận ${30*n} J nhiệt và thực hiện ${10*n} J công trong một quá trình.`,[
    ['Nhiệt lượng hệ nhận là dương.',true,'Q > 0 khi nhận nhiệt.'],
    ['Công mà hệ nhận là dương.',false,'Hệ thực hiện công nên công nhận vào âm.'],
    [`Nội năng hệ tăng ${20*n} J.`,true,'ΔU = Q + A.'],
    ['Quá trình là đoạn nhiệt.',false,'Hệ có trao đổi nhiệt.']]),
   tf(`Một lượng khí lí tưởng ở 300 K và 100 kPa chiếm ${2*n} lít. Khí được nén đẳng nhiệt đến ${n} lít.`,[
    ['Áp suất tăng lên 200 kPa.',true,'Thể tích giảm một nửa, pV giữ nguyên.'],
    ['Nhiệt độ tuyệt đối tăng gấp đôi.',false,'Nhiệt độ không đổi trong quá trình đẳng nhiệt.'],
    ['Động năng tịnh tiến trung bình của phân tử không đổi.',true,'Đại lượng này tỉ lệ với nhiệt độ tuyệt đối.'],
    ['Khối lượng riêng của khí giảm.',false,'Khối lượng không đổi, thể tích giảm.']]),
   tf(`Cuộn ${100*n} vòng, mỗi vòng có diện tích 0,02 m². Từ trường vuông góc mặt vòng, B tăng đều từ 0 tới 0,5 T trong 0,2 s.`,[
    ['Từ thông mỗi vòng lúc cuối là 0,01 Wb.',true,'Φ = BS vì B song song pháp tuyến.'],
    [`Độ lớn suất điện động cảm ứng là ${5*n} V.`,true,'NΔΦ/Δt = 100n×0,01/0,2.'],
    ['Nếu B giữ nguyên sau đó, suất điện động tiếp tục như cũ.',false,'Khi từ thông ổn định, đạo hàm bằng 0.'],
    ['Đảo chiều biến thiên của B mà giữ tốc độ biến thiên thì độ lớn suất điện động giảm.',false,'Độ lớn phụ thuộc |ΔΦ/Δt|.']]),
   tf(`Mẫu có chu kì bán rã ${n} ngày và chứa 8 triệu hạt ban đầu.`,[
    [`Sau ${n} ngày còn 4 triệu hạt.`,true,'Một chu kì giảm một nửa.'],
    [`Sau ${2*n} ngày còn 2 triệu hạt.`,true,'Hai chu kì giảm còn một phần tư.'],
    [`Sau ${3*n} ngày còn 0 hạt theo mô hình bán rã.`,false,'Giá trị dự kiến là một triệu hạt.'],
    ['Hằng số phân rã lớn hơn khi chu kì bán rã lớn hơn.',false,'λ = ln 2/T.']]),
   num(`Một thanh đồng ${n} kg tăng 25 K. Cho c = 380 J/(kg·K). Tính nhiệt lượng theo kJ.`,9.5*n,'Q = mcΔT; chia 1000 để đổi sang kJ.'),
   num(`Bình kín cứng chứa khí ở 300 K, áp suất 120 kPa. Nhiệt độ tăng ${25*n} K. Tính áp suất cuối theo kPa.`,120+10*n,'p₂ = p₁T₂/T₁ do thể tích và lượng khí không đổi.'),
   num(`Một dây dài ${n*10} cm vuông góc với từ trường 0,5 T, mang dòng 4 A. Tính lực từ theo N.`,.2*n,'Đổi cm sang m rồi nhân BIL.'),
   num(`Cuộn ${50*n} vòng có từ thông mỗi vòng giảm 0,02 Wb trong 0,5 s. Tính độ lớn suất điện động trung bình theo V.`,2*n,'Nhân N với 0,02 rồi chia 0,5.'),
   num(`Mẫu phóng xạ có ${16*n} triệu hạt ban đầu. Sau 4 chu kì bán rã còn bao nhiêu triệu hạt?`,n,'Chia số ban đầu cho 2⁴ = 16.'),
   num(`Nguồn 12 V có điện trở trong 1 Ω mắc với điện trở ngoài ${n-1} Ω. Tính dòng điện theo A.`,12/n,'I = ℰ/(R+r) = 12/n.'));
  if(level===2){
   questions[22]=num('Pha 200 g nước ở 80 °C với 300 g nước ở 20 °C trong bình cách nhiệt, bỏ qua nhiệt dung bình. Tính nhiệt độ cân bằng theo °C.',44,'Bảo toàn nhiệt lượng: 0,2(80−t)=0,3(t−20), suy ra t = 44 °C.');
   questions[23]=num('Khí trong lốp ở 300 K có áp suất dư 200 kPa. Tăng nhiệt độ lên 330 K, thể tích không đổi. Với áp suất khí quyển 100 kPa, tính áp suất dư mới theo kPa.',230,'Đổi áp suất dư thành tuyệt đối 300 kPa. Sau tăng nhiệt được 330 kPa tuyệt đối. Trừ 100 kPa khí quyển.');
  }
  return questions.map((q,i)=>{
   if(!q.options)return q;
   const offset=(i*3+n)%4;
   return {...q,options:[...q.options.slice(offset),...q.options.slice(0,offset)]};
  });
 }
 function make(id){
  const v=versions.find(x=>x.id===id);
  if(!v)return [];
  if(v.mode==='mock')return mock(v);
  const [single,groups,numbers]=v.answers;
  const note='Đáp án đối chiếu bảng công bố của Bộ GD&ĐT. Mở đề gốc để xem nội dung và hình minh họa.';
  return [
   ...[...single].map((a,i)=>mc('Phần I · Câu '+(i+1)+' trong đề gốc',a,['A','B','C','D'].filter(x=>x!==a),note)),
   ...groups.map((g,i)=>tf('Phần II · Câu '+(i+1)+' trong đề gốc',[...g].map((a,j)=>['Ý '+'abcd'[j]+' của đề gốc',a==='D',note]))),
   ...numbers.map((a,i)=>num('Phần III · Câu '+(i+1)+' trong đề gốc',a,note))
  ].map(q=>q.part===0?{...q,options:['A','B','C','D']}:q);
 }
 return {versions,mocks,parts,make};
})();
