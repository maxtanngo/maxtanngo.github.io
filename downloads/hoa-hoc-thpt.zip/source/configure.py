from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
base=Path(__file__).parent
output=base.parent.parent/'outputs' if base.name=='hoahoc' else base/'outputs'
output.mkdir(exist_ok=True)
for level,low,high in [('THCS',6,9),('THPT',10,12)]:
    page=(base/'index.html').read_text()
    page=page.replace('__LEVEL__',level).replace('__RANGE__',f'{low}–{high}').replace('__GRADE_OPTIONS__',''.join(f'<option value="{g}">Lớp {g}</option>' for g in range(low,high+1)))
    page=page.replace('<link rel="stylesheet" href="style.css">','<style>\n'+(base/'style.css').read_text()+'\n</style>')
    scripts=('content.js','labs.js','archive.js','exam-data.js','mock-exam.js','app.js')
    for filename in scripts:
        code=(base/filename).read_text()
        assert '</script' not in code.lower()
        page=page.replace(f'<script src="{filename}"></script>',f'<script>\n{code}\n</script>')
    name=f'HoaHoc-{level}-MaxNgo'
    dest=output/(name+'.html')
    dest.write_text(page)
    with ZipFile(output/(name+'.zip'),'w',ZIP_DEFLATED) as z:
        z.write(dest,dest.name)
        for filename in ('README.md','index.html','style.css','configure.py',*scripts):
            z.write(base/filename,'source/'+filename)
