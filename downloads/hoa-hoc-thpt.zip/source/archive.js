const archive=(()=>{
 const records=[
  {id:'ptnk26',grade:9,year:2026,kind:'Chuyên lớp 10',name:'Phổ thông Năng khiếu · Hóa học chuyên',note:'Đề chính thức. Chọn môn Hóa học trong thư mục của trường.',url:'https://ptnk.edu.vn/de-thi-chinh-thuc-ky-thi-tuyen-sinh-vao-lop-10-nam-2026-cua-truong-ptnk/'},
  {id:'tantrung26',grade:9,year:2026,kind:'Kiểm tra học kỳ',name:'TH&THCS Tân Trung · Khoa học tự nhiên 9',note:'Đề và đáp án cuối học kỳ I năm học 2025–2026. Chọn tệp khối 9 để luyện phần Hóa học.',url:'https://th-thcstantrung.hcm.edu.vn/bac-hoc-trung-hoc-co-so/de-kiem-tra-khoi-6-7-8-9-mon-khoa-hoc-tu-nhien-cuoi-hoc-ki-i-nam-hoc-2025-2026/ct/107756/733948'},
  {id:'ptnk25',grade:9,year:2025,kind:'Chuyên lớp 10',name:'Phổ thông Năng khiếu · Hóa học chuyên',note:'Đề chính thức tuyển sinh vào lớp 10.',url:'https://ptnk.edu.vn/de-thi-chinh-thuc-ky-thi-tuyen-sinh-lop-10-nam-2025/'},
  {id:'ptnk24',grade:9,year:2024,kind:'Chuyên lớp 10',name:'Phổ thông Năng khiếu · Hóa học chuyên',note:'Đề tuyển sinh năm học 2024–2025. Nội dung dành để ôn mở rộng theo chương trình cũ.',url:'https://ptnk.edu.vn/cong-bo-de-thi-chinh-thuc-tuyen-sinh-lop-10-nam-hoc-2024-2025/'},
  {id:'bo26-0330',grade:12,year:2026,kind:'Tốt nghiệp THPT',name:'Bộ GD&ĐT · Mã đề 0330',note:'Đề chính thức, 50 phút. Mở bản quét trên Báo Điện tử Chính phủ. Phiếu tự chấm dùng bảng đáp án của Bộ.',url:'https://xaydungchinhsach.chinhphu.vn/thi-tot-nghiep-thpt-2026-de-thi-mon-hoa-hoc-goi-y-dap-an-11926061210550049.htm',key:'https://xdcs.cdnchinhphu.vn/446259493575335936/2026/6/20/4-dapanhoahocthitotnghiep2026-1781917325905640488803.pdf',answers:['ABAAABACADCDADCACA',['SSDD','SSSD','DSDD','DDSS'],[3412,0.64,1256,4.95,42.9,17.2]]},
  {id:'ngogiatu25',grade:12,year:2025,kind:'Thi thử của trường',name:'THPT số 1 Ngô Gia Tự · Thi thử lần 1',note:'Chọn Hóa học để xem đề và đáp án do trường công bố.',url:'https://thpt-ngogiatu-daklak.edu.vn/de-dap-an-thi-thu-tot-nghiep-thpt-lan-1-nam-hoc-2024-2025.htm'},
  {id:'hsg25',grade:12,year:2025,kind:'Học sinh giỏi quốc gia',name:'Bộ GD&ĐT · Đề chọn học sinh giỏi quốc gia',note:'Đề và đáp án năm học 2024–2025. Dành để luyện nâng cao.',url:'https://xaydungchinhsach.chinhphu.vn/de-thi-va-dap-an-mon-hoa-hoc-chon-hoc-sinh-gioi-quoc-gia-thpt-nam-hoc-2024-2025-119250121123357822.htm'},
  {id:'bo24',grade:12,year:2024,kind:'Tốt nghiệp THPT',name:'Bộ GD&ĐT · Đề tốt nghiệp 2024',note:'Đề đã thi và đáp án. Định dạng theo chương trình cũ.',url:'https://xaydungchinhsach.chinhphu.vn/thi-tot-nghiep-thpt-2024-de-thi-goi-y-dap-an-mon-hoa-hoc-119240628114416212.htm'},
  {id:'thamkhao25',grade:12,year:2025,kind:'Đề tham khảo',name:'Bộ GD&ĐT · Minh họa định dạng từ 2025',note:'Tài liệu Bộ công bố để minh họa cấu trúc và cách tính điểm.',url:'https://xaydungchinhsach.chinhphu.vn/de-thi-minh-hoa-mon-hoa-hoc-tot-nghiep-thpt-tu-nam-2025-119231230182020605.htm'}
 ];
 const link=(url,label)=>`<a class="button secondary" href="${url}" target="_blank" rel="noopener">${label} ↗</a>`;
 function render(root,grade){
  const pool=records.filter(x=>x.grade===grade);
  const years=[...new Set(pool.map(x=>x.year))].sort((a,b)=>b-a);
  const kinds=[...new Set(pool.map(x=>x.kind))];
  root.innerHTML=`<header class="page-title"><h1>Kho đề lớp ${grade}</h1><p>Tài liệu do trường, Bộ GD&ĐT hoặc đơn vị giáo dục công bố. Mở đề gốc để xem đầy đủ hình và dữ kiện.</p></header><div class="filters archive-filters"><label>Năm <select id="archive-year"><option value="">Tất cả</option>${years.map(y=>`<option>${y}</option>`).join('')}</select></label><label>Loại đề <select id="archive-kind"><option value="">Tất cả</option>${kinds.map(k=>`<option>${k}</option>`).join('')}</select></label></div><div id="archive-grid" class="mode-grid"></div>`;
  const year=root.querySelector('#archive-year'),kind=root.querySelector('#archive-kind');
  function paint(){
   const list=pool.filter(x=>(!year.value||String(x.year)===year.value)&&(!kind.value||x.kind===kind.value));
   root.querySelector('#archive-grid').innerHTML=list.length?list.map(x=>`<article class="mode"><p class="eyebrow">${x.year} · ${x.kind}</p><h2>${x.name}</h2><p>${x.note}</p><div class="actions">${link(x.url,'Mở đề gốc')}${x.file?link(x.file,'Mở tệp đề'):''}${x.key?link(x.key,'Đáp án nguồn'):''}${x.answers?`<a class="button primary" href="#phieu/${x.id}">Mở phiếu tự chấm</a>`:''}</div></article>`).join(''):'<p class="panel">Chưa có tài liệu phù hợp với bộ lọc.</p>';
  }
  year.addEventListener('change',paint);kind.addEventListener('change',paint);paint();
 }
 return {records,render};
})();
if(typeof module!=='undefined')module.exports=archive;
