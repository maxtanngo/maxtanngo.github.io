const chemistryExam=(()=>{
 const parts=['I · Chọn đáp án','II · Đúng / Sai','III · Trả lời ngắn'];
 const max=[4.5,4,1.5];
 const mocks=['Cơ bản','Vận dụng','Nâng cao'].map((level,i)=>({id:'mo-phong-'+i,name:'Đề mô phỏng · '+level,minutes:50,mode:'mock',max}));
 const versions=[...mocks,...archive.records.filter(r=>r.answers).map(r=>({...r,minutes:50,mode:'official',max}))];
 const single=(prompt,answer,options,solution)=>({part:0,prompt,answer:String(answer),options:[answer,...options].map(String),solution});
 const tf=(prompt,statements)=>({part:1,prompt,statements});
 const num=(prompt,answer,solution)=>({part:2,prompt,answer,solution});
 function mock(v){
  const level=mocks.indexOf(v),n=level+2;
  const question=(id,index)=>{
   const q=topics.find(t=>t.id===id).examples[index](n);
   const x=Number(q.answer);
   return q.choices?{part:0,prompt:q.prompt,answer:q.answer,options:q.choices,solution:q.solution}:single(q.prompt,x,[x+1,x*2+1,x*3+2],q.solution);
  };
  const list=[
   ...['ester12','carb12','amine12','poly12','cell12','ions12'].flatMap(id=>[question(id,0),question(id,1)]),
   question('atom10',0),question('redox10',2),question('rate10',0),
   question('eq11',1),question('ph11',1),question('organic11',0),
   tf(`Thủy phân hoàn toàn ${n} mmol methyl acetate bằng dung dịch NaOH dư.`,[
    ['Methyl acetate có công thức CH₃COOCH₃.',true,'Nhóm acetate liên kết với methyl qua oxygen.'],
    ['Sản phẩm hữu cơ gồm sodium acetate và methanol.',true,'CH₃COOCH₃ + NaOH → CH₃COONa + CH₃OH.'],
    [`Lượng NaOH đã phản ứng bằng ${2*n} mmol.`,false,'Ester đơn chức phản ứng với NaOH theo tỉ lệ 1:1.'],
    ['Phản ứng này tạo glycerol.',false,'Gốc alkoxy là methyl nên alcohol thu được là methanol.']]),
   tf('Xét glucose, sucrose và tinh bột trong các điều kiện phản ứng phù hợp.',[
    ['Glucose là monosaccharide.',true,'Glucose không thủy phân thành carbohydrate đơn giản hơn.'],
    ['Sucrose thủy phân hoàn toàn chỉ tạo glucose.',false,'Thu được glucose và fructose theo tỉ lệ mol 1:1.'],
    ['Tinh bột có thể nhận biết bằng iodine.',true,'Tinh bột cho màu xanh tím với iodine.'],
    ['Dung dịch glucose không có khả năng tham gia phản ứng tráng bạc.',false,'Dạng mạch hở có nhóm aldehyde, phản ứng được với thuốc thử Tollens.']]),
   tf('Xét pin điện hóa Zn–Cu khi hoạt động, bỏ qua phản ứng phụ.',[
    ['Zn bị oxi hóa ở anode.',true,'Zn → Zn²⁺ + 2e⁻.'],
    ['Electron đi từ Cu sang Zn qua dây dẫn.',false,'Electron đi từ Zn tới Cu.'],
    ['Cầu muối dẫn electron trực tiếp giữa hai điện cực.',false,'Cầu muối cho ion di chuyển để duy trì trung hòa điện tích.'],
    ['Cu²⁺ bị khử ở cathode.',true,'Cu²⁺ + 2e⁻ → Cu.']]),
   tf(`Có dung dịch ${n} mmol HCl và dung dịch chứa cùng số mmol NaOH. Trộn hoàn toàn ở 25 °C.`,[
    ['HCl là acid mạnh trong nước.',true,'HCl phân li gần như hoàn toàn.'],
    ['Phương trình ion rút gọn là H⁺ + OH⁻ → H₂O.',true,'Na⁺ và Cl⁻ là các ion không tham gia phản ứng rút gọn.'],
    ['Sau phản ứng, HCl dư.',false,'Hai chất ban đầu bằng mol và phản ứng tỉ lệ 1:1.'],
    ['Nếu bỏ qua ảnh hưởng hoạt độ ion, dung dịch sau phản ứng có pH xấp xỉ 7.',true,'Dung dịch còn NaCl trong nước, gần trung tính ở 25 °C.']]),
   num(`Xà phòng hóa hoàn toàn ${2*n} mmol triglyceride. Tính số mmol NaOH phản ứng.`,6*n,'Mỗi triglyceride phản ứng với ba NaOH.'),
   num(`Thủy phân hoàn toàn ${4*n} g sucrose. Lấy M sucrose = 342 và M glucose = 180 g/mol. Tính khối lượng glucose theo g, làm tròn đến hàng phần mười.`,Math.round(4*n*180/342*10)/10,'Mỗi mol sucrose sinh một mol glucose. Lấy m sucrose chia 342 rồi nhân 180 và làm tròn.'),
   num(`Điện phân dung dịch chứa Cu²⁺ dư. Có ${6*n} mmol electron dùng để khử Cu²⁺. Tính số mmol Cu tạo thành.`,3*n,'Hai mol electron tạo một mol Cu.'),
   num(`Hòa tan ${n} mmol NaOH rồi pha thành 200 mL dung dịch. Tính nồng độ NaOH theo mmol/L.`,5*n,'Đổi 200 mL thành 0,2 L, rồi chia số mmol cho 0,2.'),
   num(`Đốt cháy hoàn toàn ${n} mmol ethanol. Tính số mmol O₂ đã phản ứng.`,3*n,'C₂H₅OH + 3O₂ → 2CO₂ + 3H₂O.'),
   num(`Thủy phân hoàn toàn ${n} mmol tripeptide mạch hở thành amino acid. Tính số mmol liên kết peptide bị cắt.`,2*n,'Mỗi tripeptide mạch hở có hai liên kết peptide.')
  ];
  if(level>=1){
   list[0]=single(`Thủy phân hoàn toàn ${2*n} mmol ethyl acetate trong NaOH dư. Khối lượng ethanol tạo thành là bao nhiêu mg? Lấy M = 46 g/mol.`,92*n,[46*n,138*n,184*n],'Số mmol ethanol bằng 2n, nhân 46 mg/mmol.');
   list[8]=single(`Cần bao nhiêu mmol electron để đồng thời khử ${n} mmol Cu²⁺ và ${2*n} mmol Ag⁺ thành kim loại?`,4*n,[2*n,3*n,6*n],'Cu²⁺ cần 2e⁻ mỗi ion và Ag⁺ cần 1e⁻. Cộng 2n + 2n.');
   list[23]=num(`Một hỗn hợp chứa ${n} mmol methyl acetate và ${2*n} mmol triglyceride. Xà phòng hóa hoàn toàn. Tính số mmol NaOH phản ứng.`,7*n,'Ester đơn chức cần n mmol; triglyceride cần 6n mmol.');
   list[27]=num(`Hỗn hợp gồm ${n} mmol glycine và ${2*n} mmol alanine. Tính số mmol HCl tối thiểu để tạo muối hydrochloride của cả hai chất.`,3*n,'Mỗi phân tử có một nhóm amino nhận một proton.');
  }
  if(level===2){
   list[3]=single('Một dung dịch sucrose bị thủy phân một phần. Trong các chất tạo thành, chất nào phản ứng tráng bạc trong môi trường kiềm?','Glucose và fructose',['Chỉ glucose','Chỉ fructose','Chỉ sucrose'],'Glucose có dạng aldehyde. Fructose chuyển hóa trong môi trường kiềm thành aldose, nên cũng cho phản ứng.');
   list[18]=tf('Xà phòng hóa hỗn hợp 2 mmol methyl acetate và 1 mmol tristearin bằng 6 mmol NaOH.',[
    ['NaOH dư 1 mmol sau khi phản ứng hoàn toàn.',true,'NaOH tiêu thụ 2 + 3 = 5 mmol.'],
    ['Cả hai ester đều sinh glycerol.',false,'Methyl acetate sinh methanol, tristearin sinh glycerol.'],
    ['Tổng số mol muối carboxylate thu được là 5 mmol.',true,'Có 2 mmol acetate và 3 mmol stearate.'],
    ['Lượng NaOH phản ứng vẫn là 5 mmol nếu thay tristearin bằng 1 mmol ethyl acetate.',false,'Nhu cầu mới là 2 + 1 = 3 mmol, khác 5 mmol.']]);
   list[24]=num('Điện phân dung dịch có Cu²⁺ dư. Dòng điện truyền tổng 10 mmol electron, hiệu suất dòng tạo Cu là 80%. Tính số mmol Cu thu được.',4,'8 mmol electron hữu ích. Cần 2 electron cho mỗi Cu.');
   list[26]=num('Đốt cháy hoàn toàn hỗn hợp ethanol và methane, thu 7 mmol CO₂ và 12 mmol H₂O. Tính số mmol ethanol.',2,'Gọi x, y là mmol ethanol và methane. 2x+y=7 và 3x+2y=12, suy ra x=2.');
  }
  return list.map((q,i)=>{
   if(!q.options)return q;
   const offset=(i*3+n)%4;
   return {...q,options:[...q.options.slice(offset),...q.options.slice(0,offset)]};
  });
 }
 function make(id){
  const v=versions.find(x=>x.id===id);
  if(!v)return [];
  if(v.mode==='mock')return mock(v);
  const [answers,groups,numbers]=v.answers;
  const note='Đáp án đối chiếu với bảng chính thức của Bộ GD&ĐT.';
  return [
   ...Array.from(answers,(answer,i)=>({part:0,prompt:'Phần I · Câu '+(i+1)+' trong đề gốc',answer,options:['A','B','C','D'],solution:note})),
   ...groups.map((g,i)=>tf('Phần II · Câu '+(i+1)+' trong đề gốc',Array.from(g,(a,j)=>['Ý '+'abcd'[j]+' của đề gốc',a==='D',note]))),
   ...numbers.map((a,i)=>num('Phần III · Câu '+(i+1)+' trong đề gốc',a,note))
  ];
 }
 return {versions,mocks,parts,make};
})();
