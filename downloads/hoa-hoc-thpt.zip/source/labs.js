const chemistryLabs=(()=>{
 const labs={
  mixture6:['Nồng độ của nước muối','Lượng muối (g)',1,20,5,x=>x/(100+x)*100,'%', 'Giữ nguyên 100 g nước. Khối lượng dung dịch bằng tổng khối lượng nước và muối.'],
  atoms7:['Nguyên tử và số proton','Số proton',1,10,3,x=>x,'electron','Nguyên tử trung hòa có số electron bằng số proton.'],
  mole8:['Pha dung dịch','Thể tích dung dịch (mL)',100,1000,500,x=>100/x,'mol/L','Giữ nguyên 0,1 mol chất tan. Cₘ = n/V với V tính theo lít.'],
  metal9:['Lượng khí từ phản ứng của Mg','Magnesium (mmol)',1,20,5,x=>x,'mmol H₂','Mg + 2HCl → MgCl₂ + H₂. Giả sử acid dư và Mg phản ứng hoàn toàn.'],
  atom10:['Tỉ lệ đồng vị chlorine','Tỉ lệ đồng vị ³⁷Cl (%)',0,100,25,x=>35+2*x/100,'amu','Mô hình lấy khối lượng hai đồng vị gần đúng là 35 và 37 amu.'],
  ph11:['Nồng độ H⁺ và pH','Số mũ k trong [H⁺] = 10⁻ᵏ',1,7,3,x=>x,'pH','Nồng độ tính bằng mol/L. Với mô hình dung dịch loãng, pH = −log₁₀[H⁺].'],
  cell12:['Điện phân ion đồng','Lượng electron (mmol)',1,20,4,x=>x/2,'mmol Cu','Cu²⁺ + 2e⁻ → Cu. Giả sử Cu²⁺ dư và toàn bộ dòng điện dùng cho quá trình này.']
 };
 const f=x=>x.toLocaleString('vi-VN',{maximumFractionDigits:2});
 function markup(id){
  const t=labs[id];
  return t?`<section class="panel physics-lab"><h2>${t[0]}</h2><p>${t[7]}</p><label for="lab-parameter">${t[1]}</label><input id="lab-parameter" type="range" min="${t[2]}" max="${t[3]}" value="${t[4]}" step="${id==='mole8'?50:1}"><p id="lab-note" aria-live="polite"></p><canvas id="lab-canvas" width="600" height="230" aria-hidden="true"></canvas></section>`:'';
 }
 function bind(id){
  const t=labs[id],slider=document.getElementById('lab-parameter');
  if(!t||!slider)return;
  const ctx=document.getElementById('lab-canvas').getContext('2d');
  const lo=Math.min(t[5](t[2]),t[5](t[3]),0),hi=Math.max(t[5](t[2]),t[5](t[3]));
  const x=n=>58+492*(n-t[2])/(t[3]-t[2]),y=n=>198-161*(n-lo)/(hi-lo);
  function update(){
   const k=Number(slider.value);
   document.getElementById('lab-note').textContent=f(k)+' → '+f(t[5](k))+' '+t[6];
   ctx.clearRect(0,0,600,230);
   ctx.strokeStyle='#59766c';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(58,26);ctx.lineTo(58,198);ctx.lineTo(560,198);ctx.stroke();
   ctx.fillStyle='#2d4c43';ctx.font='14px system-ui';ctx.fillText(t[6],6,22);ctx.fillText(f(t[2]),58,221);ctx.fillText(f(t[3]),530,221);
   ctx.strokeStyle='#17674c';ctx.lineWidth=3;ctx.beginPath();
   for(let i=0;i<=100;i++){const n=t[2]+(t[3]-t[2])*i/100;if(i)ctx.lineTo(x(n),y(t[5](n)));else ctx.moveTo(x(n),y(t[5](n)));}
   ctx.stroke();ctx.fillStyle='#a55721';ctx.beginPath();ctx.arc(x(k),y(t[5](k)),5,0,2*Math.PI);ctx.fill();
  }
  slider.addEventListener('input',update);update();
 }
 return {byGrade:{6:'mixture6',7:'atoms7',8:'mole8',9:'metal9',10:'atom10',11:'ph11',12:'cell12'},markup,bind};
})();
