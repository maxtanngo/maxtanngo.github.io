const A='Cấu tạo và liên kết', R='Phản ứng và dung dịch', O='Hóa hữu cơ', M='Kim loại và vật liệu';
const topics=[];
const q=(prompt,answer,solution,hint)=>({prompt,answer:String(answer),solution,hint});
const mc=(prompt,answer,others,solution,hint)=>({...q(prompt,answer,solution,hint),choices:[answer,...others].map(String)});
function lesson(grade,id,strand,title,rule,...examples){topics.push({grade,id,strand,title,rule,examples});}

lesson(6,'states6',A,'Trạng thái của chất','Chất có thể ở thể rắn, lỏng hoặc khí. Khi chuyển thể, bản chất hóa học của chất giữ nguyên.',
 ()=>mc('Nước đá chuyển thành nước lỏng gọi là gì?','Nóng chảy',['Đông đặc','Ngưng tụ','Thăng hoa'],'Nóng chảy là chuyển từ rắn sang lỏng.','Xét thể đầu và thể cuối.'),
 ()=>mc('Hơi nước tạo thành giọt trên thành cốc lạnh là quá trình gì?','Ngưng tụ',['Sôi','Nóng chảy','Đông đặc'],'Hơi nước chuyển từ khí sang lỏng khi gặp lạnh.','Xét hơi nước trước khi tạo giọt.'),
 ()=>mc('Ví dụ nào là sự chuyển thể?','Nến sáp nóng chảy',['Sắt gỉ','Than cháy','Trứng chín'],'Sáp nóng chảy giữ nguyên bản chất hóa học.','Tìm trường hợp chỉ đổi trạng thái.'));
lesson(6,'mixture6',R,'Hỗn hợp, dung dịch và tách chất','Dung dịch là hỗn hợp đồng nhất. Có thể tách chất dựa vào kích thước hạt, tính tan hoặc nhiệt độ sôi.',
 ()=>mc('Tách cát không tan khỏi nước bằng cách nào?','Lọc',['Cô cạn toàn bộ nước','Dùng nam châm','Làm nóng chảy cát'],'Hạt cát bị giữ lại trên giấy lọc.','Dựa vào kích thước hạt.'),
 ()=>mc('Khi cô cạn nước muối, chất nào còn lại?','Muối',['Nước lỏng','Khí oxygen','Cát'],'Nước bay hơi, muối còn lại.','Chất tan ít bay hơi.'),
 n=>q(`Hòa tan ${n} g muối vào 100 g nước, không hao hụt. Khối lượng dung dịch bằng bao nhiêu g?`,100+n,'Cộng khối lượng muối và nước.','Tính khối lượng của cả hỗn hợp.'));
lesson(6,'oxygen6',R,'Oxygen, không khí và sự cháy','Oxygen duy trì sự cháy. Trong không khí khô, oxygen chiếm khoảng 21% theo thể tích.',
 ()=>mc('Khí nào chiếm khoảng 21% thể tích không khí khô?','Oxygen',['Nitrogen','Carbon dioxide','Hydrogen'],'Oxygen chiếm gần một phần năm thể tích.','Nitrogen chiếm phần lớn hơn.'),
 n=>q(`Lấy ${100*n} L không khí khô có 21% oxygen. Thể tích oxygen là bao nhiêu L?`,21*n,'Nhân tổng thể tích với 0,21.','Đổi phần trăm thành số thập phân.'),
 ()=>mc('Vì sao nến tắt dần khi bị úp kín?','Oxygen bị tiêu hao',['Nitrogen biến thành nước','Nến hết sáp ngay lập tức','Không khí trở nên tinh khiết'],'Sự cháy tiếp tục tiêu thụ oxygen trong khoảng không kín.','Xét điều kiện duy trì cháy.'));

lesson(7,'atoms7',A,'Nguyên tử và nguyên tố','Nguyên tố được xác định bằng số proton Z. Nguyên tử trung hòa có số electron bằng Z.',
 n=>q(`Nguyên tử trung hòa có ${n+3} proton. Có bao nhiêu electron?`,n+3,'Số điện tích âm bằng số điện tích dương.','Nguyên tử đang trung hòa.'),
 ()=>mc('Đại lượng nào xác định nguyên tố?','Số proton',['Số neutron','Số khối riêng lẻ','Số lớp electron trong mọi trường hợp'],'Các nguyên tử cùng nguyên tố có cùng Z.','Xét điện tích hạt nhân.'),
 n=>q(`Hạt nhân có ${n+2} proton và ${n+4} neutron. Số khối bằng bao nhiêu?`,2*n+6,'Số khối là tổng proton và neutron.','Cộng hai loại hạt trong hạt nhân.'));
lesson(7,'formula7',A,'Phân tử và công thức hóa học','Chỉ số dưới trong công thức cho biết số nguyên tử của nguyên tố trong một phân tử hoặc tỉ lệ ion trong đơn vị công thức.',
 n=>q(`Trong ${n} phân tử CO₂ có bao nhiêu nguyên tử oxygen?`,2*n,'Mỗi CO₂ có hai nguyên tử oxygen.','Nhân với chỉ số 2.'),
 ()=>mc('Chất nào là hợp chất?','H₂O',['O₂','N₂','Fe'],'H₂O chứa hai nguyên tố khác nhau.','Xét số loại nguyên tố.'),
 ()=>q('Dùng H = 1 và O = 16. Khối lượng phân tử H₂O bằng bao nhiêu amu?',18,'2×1 + 16 = 18.','Cộng theo số nguyên tử.'));
lesson(7,'bond7',A,'Liên kết ion và cộng hóa trị','Liên kết ion dựa vào lực hút giữa ion trái dấu. Liên kết cộng hóa trị hình thành khi các nguyên tử dùng chung electron.',
 ()=>mc('Liên kết trong phân tử H₂ thuộc loại nào?','Cộng hóa trị',['Ion','Kim loại','Liên kết hydrogen giữa hai phân tử'],'Hai nguyên tử H dùng chung một cặp electron.','Xét hai nguyên tử phi kim giống nhau.'),
 ()=>mc('Trong NaCl, ion nào mang điện âm?','Cl⁻',['Na⁺','Na trung hòa','Cl₂'],'Chloride nhận thêm một electron.','Dấu trừ chỉ ion âm.'),
 ()=>q('Ion Mg²⁺ tạo từ nguyên tử Mg bằng cách nhường bao nhiêu electron?',2,'Mất hai electron tạo điện tích +2.','Xét điện tích ion.'));

lesson(8,'balance8',R,'Cân bằng phương trình','Phương trình đúng có số nguyên tử mỗi nguyên tố bằng nhau ở hai vế. Chỉ thay hệ số đứng trước công thức.',
 ()=>q('Cân bằng CH₄ + O₂ → CO₂ + H₂O bằng hệ số nguyên tối giản. Hệ số O₂ bằng bao nhiêu?',2,'Một CO₂ và hai H₂O chứa bốn nguyên tử O. Cần hai O₂.','Cân bằng C và H trước.'),
 ()=>q('Cân bằng Al + O₂ → Al₂O₃ bằng hệ số nguyên tối giản. Hệ số Al bằng bao nhiêu?',4,'2 Al₂O₃ chứa 6 O và 4 Al.','Bội chung nhỏ nhất của 2 và 3 là 6.'),
 ()=>mc('Khi cân bằng phương trình, được thay đổi gì?','Hệ số trước công thức',['Chỉ số dưới của nguyên tố','Tên chất','Thành phần một phân tử'],'Thay chỉ số làm đổi chất.','Giữ nguyên công thức.'));
lesson(8,'mole8',R,'Mol, khối lượng và dung dịch','n = m/M và Cₘ = n/V với V theo lít. Nồng độ phần trăm khối lượng là 100m chất tan/m dung dịch.',
 n=>q(`Có ${18*n} g nước, M = 18 g/mol. Số mol là bao nhiêu?`,n,'Chia khối lượng cho khối lượng mol.','Dùng n = m/M.'),
 n=>q(`Có ${n} mol chất tan trong 2 L dung dịch. Nồng độ mol là bao nhiêu mol/L?`,n/2,'Chia số mol cho 2 L.','Dùng Cₘ = n/V.'),
 n=>q(`Dung dịch 100 g chứa ${2*n} g chất tan. Nồng độ phần trăm là bao nhiêu?`,2*n,'Mẫu số là 100 g dung dịch nên phần trăm bằng số gam chất tan.','Dùng tổng khối lượng dung dịch.'));
lesson(8,'acid8',R,'Acid, base và pH','Ở 25 °C, dung dịch có pH < 7 có tính acid, pH > 7 có tính base. Acid và base có thể phản ứng trung hòa.',
 ()=>mc('Dung dịch nào có tính acid ở 25 °C?','pH = 3',['pH = 7','pH = 9','pH = 12'],'pH nhỏ hơn 7 biểu thị tính acid ở 25 °C.','So sánh với 7.'),
 ()=>mc('HCl và NaOH phản ứng vừa đủ. Sản phẩm là gì?','NaCl và H₂O',['Na và Cl₂','H₂ và O₂','Na₂O và H₂'],'H⁺ kết hợp OH⁻ tạo nước, còn ion tạo muối.','Đây là phản ứng trung hòa.'),
 n=>q(`Cần bao nhiêu mmol NaOH để trung hòa vừa đủ ${n} mmol HCl?`,n,'HCl + NaOH → NaCl + H₂O, tỉ lệ 1:1.','Đọc hệ số phản ứng.'));

lesson(9,'metal9',M,'Dãy hoạt động và tính chất kim loại','Kim loại hoạt động hơn có thể đẩy kim loại yếu hơn khỏi dung dịch muối trong điều kiện phù hợp. Kim loại đứng trước hydrogen thường phản ứng với acid loãng thích hợp.',
 ()=>mc('Cho đinh sắt sạch vào dung dịch CuSO₄. Kim loại bám lên đinh là gì?','Đồng',['Kẽm','Nhôm','Bạc'],'Fe + CuSO₄ → FeSO₄ + Cu.','So sánh hoạt động của Fe và Cu.'),
 n=>q(`Cho ${n} mmol Mg phản ứng hoàn toàn với HCl dư. Thu bao nhiêu mmol H₂?`,n,'Mg + 2HCl → MgCl₂ + H₂; tỉ lệ Mg:H₂ là 1:1.','Cân bằng phương trình.'),
 ()=>mc('Chất nào phản ứng với HCl loãng tạo hydrogen?','Zn',['Cu','Ag','Au'],'Kẽm đứng trước hydrogen trong dãy hoạt động.','Chọn kim loại có tính khử mạnh hơn hydrogen.'));
lesson(9,'fuel9',O,'Hydrocarbon và nhiên liệu','Hydrocarbon chỉ chứa C và H. Cháy hoàn toàn tạo CO₂ và H₂O. Ethylene có liên kết đôi, có thể tham gia phản ứng cộng.',
 n=>q(`Đốt cháy hoàn toàn ${n} mol CH₄. Thu bao nhiêu mol CO₂?`,n,'Một mol CH₄ có một mol nguyên tử C nên tạo một mol CO₂.','Bảo toàn carbon.'),
 n=>q(`Đốt cháy hoàn toàn ${n} mol C₂H₄. Thu bao nhiêu mol H₂O?`,2*n,'Mỗi C₂H₄ có bốn H, tạo hai H₂O.','Bảo toàn hydrogen.'),
 ()=>mc('Khí nào phản ứng cộng làm mất màu dung dịch bromine ở điều kiện thường?','C₂H₄',['CH₄','CO₂','N₂'],'Liên kết đôi trong C₂H₄ tham gia phản ứng cộng.','Tìm chất có liên kết đôi C=C.'));
lesson(9,'ethanol9',O,'Ethanol và acetic acid','Ethanol có nhóm –OH. Acetic acid có nhóm –COOH và phản ứng với base hoặc carbonate.',
 ()=>mc('Công thức của acetic acid là gì?','CH₃COOH',['C₂H₅OH','CH₄','HCOONa'],'Nhóm carboxyl gắn với nhóm CH₃.','Tìm nhóm –COOH.'),
 n=>q(`Trung hòa ${n} mmol CH₃COOH cần bao nhiêu mmol NaOH?`,n,'Tỉ lệ phản ứng 1:1.','Một nhóm carboxyl cung cấp một H có tính acid.'),
 ()=>mc('Giấm có thể sủi bọt khi gặp NaHCO₃. Khí thoát ra là gì?','CO₂',['H₂','N₂','O₂'],'Acid tác dụng với hydrogencarbonate tạo carbon dioxide.','Xét phản ứng của acid với muối hydrogencarbonate.'));
lesson(9,'materials9',O,'Chất béo, carbohydrate và polymer','Chất béo là triester của glycerol với acid béo. Tinh bột tạo màu xanh tím với iodine. Polymer gồm nhiều mắt xích nối nhau.',
 ()=>mc('Thuốc thử nhận biết tinh bột là gì?','Dung dịch iodine',['Nước cất','Dung dịch NaCl','Giấy lọc'],'Tinh bột cho màu xanh tím với iodine.','Tìm thuốc thử cho màu đặc trưng.'),
 ()=>mc('Polyethylene được tạo từ monomer nào?','Ethylene',['Ethanol','Acetic acid','Methane'],'Trùng hợp CH₂=CH₂ tạo mạch polyethylene.','Liên kết đôi mở để tạo mạch.'),
 ()=>mc('Thủy phân chất béo trong môi trường kiềm gọi là gì?','Xà phòng hóa',['Trùng hợp','Nóng chảy','Thăng hoa'],'Sản phẩm gồm glycerol và muối của acid béo.','Liên hệ cách sản xuất xà phòng.'));

lesson(10,'atom10',A,'Đồng vị và nguyên tử khối','Đồng vị của một nguyên tố có cùng Z và khác số neutron. Nguyên tử khối trung bình là trung bình có trọng số theo tỉ lệ đồng vị.',
 ()=>q('Chlorine có 75% đồng vị khối lượng 35 và 25% đồng vị khối lượng 37. Tính khối lượng trung bình theo amu.',35.5,'35×0,75 + 37×0,25 = 35,5.','Dùng phần trăm làm trọng số.'),
 n=>q(`Hạt nhân có số khối ${20+n} và Z = 10. Số neutron là bao nhiêu?`,10+n,'Lấy số khối trừ số proton.','N = A − Z.'),
 ()=>mc('Hai đồng vị của cùng nguyên tố luôn có cùng đại lượng nào?','Số proton',['Số neutron','Số khối','Khối lượng nguyên tử'],'Số proton xác định nguyên tố.','So sánh Z.'));
lesson(10,'period10',A,'Bảng tuần hoàn và liên kết','Số thứ tự ô bằng Z. Các nguyên tố cùng nhóm chính thường có cấu hình electron hóa trị tương tự.',
 ()=>mc('Na và K cùng nhóm nào?','Nhóm 1',['Nhóm 2','Nhóm 17','Nhóm 18'],'Cả hai có một electron hóa trị kiểu ns¹.','Đây là nhóm kim loại kiềm.'),
 ()=>mc('Cặp nguyên tố nào thường tạo liên kết ion?','Na và Cl',['H và H','Cl và Cl','C và H'],'Na dễ nhường electron, Cl dễ nhận electron.','Tìm cặp kim loại và phi kim có độ âm điện chênh đáng kể.'),
 ()=>q('Nguyên tử có cấu hình lớp ngoài cùng 3s²3p⁵ có bao nhiêu electron lớp ngoài cùng?',7,'Cộng 2 và 5.','Đọc số mũ trong cấu hình.'));
lesson(10,'redox10',R,'Oxi hóa – khử','Oxi hóa là nhường electron, số oxi hóa tăng. Khử là nhận electron, số oxi hóa giảm.',
 ()=>q('Số oxi hóa của S trong H₂SO₄ là bao nhiêu?',6,'2(+1) + S + 4(−2) = 0 nên S = +6.','Tổng số oxi hóa trong phân tử trung hòa bằng 0.'),
 n=>q(`Có ${n} mol Fe²⁺ chuyển thành Fe³⁺. Số mol electron nhường là bao nhiêu?`,n,'Mỗi ion Fe²⁺ nhường một electron.','So sánh điện tích đầu và cuối.'),
 ()=>mc('Trong Zn + Cu²⁺ → Zn²⁺ + Cu, chất khử là chất nào?','Zn',['Cu²⁺','Zn²⁺','Cu'],'Zn nhường electron nên là chất khử.','Tìm chất bị oxi hóa.'));
lesson(10,'rate10',R,'Tốc độ phản ứng và năng lượng','Tốc độ phụ thuộc nồng độ, nhiệt độ, diện tích bề mặt và chất xúc tác. Phản ứng tỏa nhiệt có ΔH < 0.',
 ()=>mc('Chất xúc tác làm tăng tốc độ phản ứng bằng cách nào?','Tạo đường phản ứng có năng lượng hoạt hóa thấp hơn',['Tăng ΔH phản ứng','Đổi thành phần nguyên tố','Làm mọi phản ứng thành tỏa nhiệt'],'Xúc tác thay đổi cơ chế, không đổi ΔH phản ứng.','Xét hàng rào năng lượng.'),
 ()=>mc('Dấu của ΔH đối với phản ứng tỏa nhiệt là gì?','Âm',['Dương','Luôn bằng 0','Không phụ thuộc phản ứng'],'Hệ giải phóng nhiệt ở áp suất không đổi.','Sản phẩm có enthalpy thấp hơn chất phản ứng.'),
 n=>q(`Nồng độ giảm từ ${4*n} xuống ${2*n} mmol/L sau 2 s. Tốc độ giảm trung bình là bao nhiêu mmol/(L·s)?`,n,'Chia độ giảm 2n cho 2 giây.','Dùng độ giảm nồng độ trên thời gian.'));

lesson(11,'eq11',R,'Cân bằng hóa học','Ở cân bằng động, tốc độ thuận bằng tốc độ nghịch. Thay đổi điều kiện có thể làm cân bằng chuyển dịch.',
 ()=>mc('Ở trạng thái cân bằng, quan hệ giữa hai tốc độ là gì?','Bằng nhau',['Cả hai luôn bằng 0','Thuận luôn gấp đôi nghịch','Chỉ có phản ứng nghịch'],'Hai phản ứng vẫn diễn ra với tốc độ bằng nhau.','Cân bằng là trạng thái động.'),
 ()=>mc('Với N₂ + 3H₂ ⇌ 2NH₃, nén đẳng nhiệt hệ khí ở cân bằng chuyển dịch theo chiều nào?','Tạo NH₃',['Tạo N₂ và H₂','Luôn không đổi','Chỉ tạo H₂'],'Chiều tạo NH₃ làm giảm số mol khí.','Đếm số mol khí theo hệ số hai vế.'),
 ()=>mc('Chất xúc tác có làm thay đổi hằng số cân bằng ở cùng nhiệt độ không?','Không',['Luôn tăng','Luôn giảm','Bằng 0'],'Hằng số cân bằng phụ thuộc nhiệt độ.','Xúc tác tác động lên tốc độ cả hai chiều.'));
lesson(11,'ph11',R,'Acid, base và pH','Với dung dịch loãng, pH ≈ −log₁₀[H⁺]. Dùng nồng độ theo mol/L và phân biệt acid mạnh với acid yếu.',
 n=>q(`Dung dịch có [H⁺] = 10⁻${['','¹','²','³','⁴','⁵','⁶','⁷','⁸','⁹'][n]} mol/L. Tính pH.`,n,'Áp dụng −log₁₀(10⁻ᵏ) = k.','Đọc số mũ âm.'),
 ()=>mc('Chất nào là acid mạnh trong nước?','HCl',['CH₃COOH','H₂CO₃','H₂O'],'HCl phân li gần như hoàn toàn trong nước.','So sánh acid vô cơ mạnh với acid yếu.'),
 n=>q(`Trộn ${n} mmol HCl với ${n+2} mmol NaOH. Sau phản ứng còn dư bao nhiêu mmol NaOH?`,2,'Hai chất phản ứng theo tỉ lệ 1:1.','Lấy lượng base ban đầu trừ lượng acid.'));
lesson(11,'hydro11',O,'Alkane và alkene','Alkane mạch hở có CₙH₂ₙ₊₂. Alkene mạch hở có một liên kết đôi có CₙH₂ₙ.',
 n=>q(`Alkane mạch hở có ${n} carbon. Có bao nhiêu hydrogen?`,2*n+2,'Thay vào công thức CₙH₂ₙ₊₂.','Gấp đôi số carbon rồi cộng 2.'),
 n=>q(`Alkene mạch hở có một liên kết đôi và ${n} carbon. Có bao nhiêu hydrogen?`,2*n,'Thay vào công thức CₙH₂ₙ.','Nhân số carbon với 2.'),
 ()=>mc('Ethylene có thể tạo polyethylene bằng phản ứng nào?','Trùng hợp',['Trung hòa','Thủy phân','Nhiệt phân'],'Nhiều phân tử ethylene cộng nối thành mạch dài.','Xét vai trò của liên kết đôi.'));
lesson(11,'organic11',O,'Alcohol, aldehyde và acid carboxylic','Alcohol có –OH gắn carbon no. Aldehyde có –CHO. Acid carboxylic có –COOH.',
 ()=>mc('Chất nào thuộc loại aldehyde?','CH₃CHO',['CH₃COOH','C₂H₅OH','CH₄'],'CH₃CHO có nhóm –CHO.','Đọc nhóm chức ở cuối công thức.'),
 ()=>mc('Chất nào phản ứng với NaHCO₃ tạo CO₂?','CH₃COOH',['C₂H₅OH','C₂H₄','CH₄'],'Nhóm –COOH phản ứng với hydrogencarbonate.','Tìm acid carboxylic.'),
 n=>q(`Đốt cháy hoàn toàn ${n} mol ethanol, thu bao nhiêu mol CO₂?`,2*n,'Ethanol có hai carbon mỗi phân tử.','Bảo toàn nguyên tố carbon.'));

lesson(12,'ester12',O,'Ester và lipid','Ester đơn chức có nhóm –COO–. Phản ứng với NaOH có thể tạo muối carboxylate và alcohol.',
 ()=>mc('Chất nào là ester?','CH₃COOCH₃',['CH₃COOH','CH₃CHO','CH₃OCH₃'],'CH₃COOCH₃ có nhóm –COO– nối hai phần hữu cơ.','Phân biệt ester với acid và ether.'),
 n=>q(`Xà phòng hóa hoàn toàn ${n} mmol methyl acetate. Cần bao nhiêu mmol NaOH?`,n,'Ester đơn chức phản ứng theo tỉ lệ 1:1 với NaOH.','Đếm số nhóm ester.'),
 n=>q(`Xà phòng hóa hoàn toàn ${n} mmol triglyceride. Cần bao nhiêu mmol NaOH?`,3*n,'Mỗi phân tử triglyceride có ba liên kết ester.','Nhân số mol chất béo với 3.'));
lesson(12,'carb12',O,'Carbohydrate','Glucose là monosaccharide; sucrose là disaccharide. Thủy phân hoàn toàn tinh bột tạo glucose.',
 ()=>mc('Sản phẩm khi thủy phân hoàn toàn tinh bột là gì?','Glucose',['Fructose','Glycerol','Ethanol'],'Tinh bột gồm các gốc glucose nối với nhau.','Xét mắt xích của tinh bột.'),
 n=>q(`Thủy phân hoàn toàn ${n} mmol sucrose, thu bao nhiêu mmol monosaccharide tổng cộng?`,2*n,'Mỗi sucrose cho một glucose và một fructose.','Nhân số mol sucrose với 2.'),
 ()=>mc('Chất nào cho phản ứng tráng bạc trong điều kiện thích hợp?','Glucose',['Sucrose chưa thủy phân','Tinh bột chưa thủy phân','Cellulose chưa thủy phân'],'Glucose có dạng mạch hở chứa nhóm aldehyde.','Tìm carbohydrate có tính khử rõ rệt.'));
lesson(12,'amine12',O,'Amine, amino acid và peptide','Amine có tính base. Amino acid có nhóm amino và carboxyl. Liên kết peptide có dạng –CO–NH– giữa các gốc amino acid.',
 n=>q(`Peptide mạch hở gồm ${n} gốc amino acid. Có bao nhiêu liên kết peptide?`,n-1,'Mỗi cặp gốc liền kề có một liên kết peptide.','Số liên kết nhỏ hơn số gốc một đơn vị.'),
 ()=>mc('Glycine có thể tác dụng với cặp nào?','HCl và NaOH',['Chỉ NaCl và KCl','Chỉ H₂ và N₂','Chỉ O₂ và Ar'],'Nhóm amino nhận H⁺, nhóm carboxyl phản ứng với base.','Xét tính lưỡng tính.'),
 n=>q(`Cần bao nhiêu mmol HCl để proton hóa hoàn toàn ${n} mmol methylamine?`,n,'Mỗi phân tử methylamine nhận một proton.','Tỉ lệ acid:amine là 1:1.'));
lesson(12,'poly12',M,'Polymer và vật liệu','Trùng hợp nối monomer thành mạch. Trùng ngưng thường tạo phân tử nhỏ như nước kèm theo sản phẩm polymer.',
 ()=>mc('Monomer tạo PVC là gì?','CH₂=CHCl',['CH₂=CH₂','CH₃COOH','C₆H₆'],'Vinyl chloride trùng hợp tạo PVC.','Tìm monomer chứa chlorine.'),
 ()=>mc('Polymer nào có nhiều liên kết amide trên mạch chính?','Nylon-6,6',['Polyethylene','Polypropylene','PVC'],'Nylon là polyamide, có nhóm –CO–NH–.','Xét cấu trúc polyamide.'),
 ()=>q('Mỗi mắt xích polyethylene có khối lượng mol 28 g/mol. Với hệ số trùng hợp 100, khối lượng mol gần đúng là bao nhiêu g/mol?',2800,'Lấy 100×28, bỏ qua ảnh hưởng nhóm cuối mạch.','Nhân số mắt xích với khối lượng mol mỗi mắt xích.'));
lesson(12,'cell12',M,'Pin điện hóa và điện phân','Tại anode xảy ra oxi hóa; tại cathode xảy ra khử. Trong pin Zn–Cu, electron đi từ Zn đến Cu qua mạch ngoài.',
 ()=>mc('Trong pin Zn–Cu, điện cực nào xảy ra oxi hóa Zn thành Zn²⁺?','Anode Zn',['Cathode Cu','Cầu muối','Dung dịch CuSO₄'],'Oxi hóa luôn xảy ra ở anode.','Xét nơi nhường electron.'),
 n=>q(`Khử hoàn toàn ${n} mmol Cu²⁺ thành Cu cần bao nhiêu mmol electron?`,2*n,'Cu²⁺ + 2e⁻ → Cu.','Đọc hệ số electron.'),
 ()=>mc('Trong mạch ngoài của pin Zn–Cu, electron chuyển động theo chiều nào?','Từ Zn đến Cu',['Từ Cu đến Zn','Từ cầu muối đến Zn','Chỉ trong dung dịch'],'Zn nhường electron, Cu²⁺ nhận electron tại cathode.','Theo dõi electron, không dùng chiều dòng điện quy ước.'));
lesson(12,'ions12',M,'Kim loại, nước cứng và ion kim loại','Nước cứng chứa nhiều ion Ca²⁺ và Mg²⁺. Nước cứng tạm thời do hydrogencarbonate có thể giảm độ cứng bằng đun sôi.',
 ()=>mc('Hai ion chính gây độ cứng của nước là gì?','Ca²⁺ và Mg²⁺',['Na⁺ và K⁺','Cl⁻ và NO₃⁻','H⁺ và OH⁻'],'Ion calcium và magnesium làm tăng độ cứng.','Tìm ion kim loại kiềm thổ.'),
 n=>q(`Có ${n} mmol Ca²⁺. Tối thiểu bao nhiêu mmol CO₃²⁻ cần để tạo CaCO₃ nếu bỏ qua cân bằng tan?`,n,'Ca²⁺ + CO₃²⁻ → CaCO₃ theo tỉ lệ 1:1.','Xét hệ số ion.'),
 ()=>mc('Phương pháp nào phù hợp để giảm độ cứng tạm thời?','Đun sôi',['Chỉ khuấy','Chỉ làm lạnh','Thêm nước muối NaCl đặc'],'Đun làm phân hủy hydrogencarbonate và tạo kết tủa.','Xét độ cứng do hydrogencarbonate.'));

const content=topics.map(t=>({...t,examples:t.examples.map((make,i)=>make(3+i))}));
const chemistryPacks9=Object.fromEntries([
 ['metal9','Kim loại',['metal9','mole8','balance8']],
 ['fuel9','Hydrocarbon',['fuel9','balance8','materials9']],
 ['ethanol9','Ethanol và acetic acid',['ethanol9','mole8','acid8']]
].map(([id,title,ids])=>[id,{title:'Luyện lớp 9 · '+title,items:ids.flatMap(key=>topics.find(t=>t.id===key).examples.map(make=>make(3)))}]));
