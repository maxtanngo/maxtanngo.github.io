# Hóa Học MaxNgo

Giải nén và mở tệp HTML bằng trình duyệt. Bài học, mô phỏng, bài luyện và đề tự chấm chạy ngoại tuyến. Kho đề dẫn tới nguồn công bố và cần Internet.

- THCS gồm các chủ đề Hóa học trong Khoa học tự nhiên lớp 6–9, bài luyện lớp 9 và kho đề trường.
- THPT gồm các chủ đề lớp 10–12, kho đề lớp 12 và phòng thi 50 phút. Ba đề mô phỏng có lời giải. Phiếu mã 0330 năm 2026 dùng bản đề gốc và đáp án chính thức của Bộ GD&ĐT.
- Tiến độ và lượt thi gần nhất lưu trên trình duyệt. Đồng hồ tiếp tục khi rời phòng thi.
- Mã nguồn nằm trong thư mục source. Chạy python3 configure.py để tạo lại bản đóng gói.
