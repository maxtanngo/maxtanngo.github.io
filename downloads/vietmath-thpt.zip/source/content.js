const A='Số & Đại số', G='Hình học & Đo lường', D='Thống kê & Xác suất';
const topics=[];
const q=(prompt,answer,solution,hint,choices)=>({prompt,answer:String(answer),solution,hint,choices});
const mc=(prompt,answer,others,solution,hint)=>q(prompt,answer,solution,hint,[answer,...others].map(String));
const f=(a,b)=>a+'/'+b;
const lesson=(grade,id,strand,title,rule,...examples)=>topics.push({grade,id,strand,title,rule,examples});

lesson(10,'sets',A,'Mệnh đề và tập hợp','Phủ định của “mọi” là “tồn tại ít nhất một … không”. Giao tập hợp lấy các phần tử chung, hợp lấy tất cả phần tử.',
 n=>q(`A={1; 2; …; ${n+4}}, B={${n}; ${n+1}; …; ${n+6}}. A ∩ B có bao nhiêu phần tử?`,5,`Giao gồm các số từ ${n} đến ${n+4}, có 5 phần tử.`,'Tìm phần chung của hai khoảng số nguyên.'),
 ()=>mc('Phủ định của “Mọi học sinh đều nộp bài” là gì?','Có ít nhất một học sinh chưa nộp bài',['Mọi học sinh đều chưa nộp bài','Có học sinh đã nộp bài','Không có học sinh nào'],'Để phủ định mệnh đề với “mọi”, chỉ cần một phản ví dụ.','Đổi “mọi” thành “tồn tại”.'),
 n=>q(`Hai tập có ${n+3} và ${n+2} phần tử, giao có ${n} phần tử. Hợp có bao nhiêu phần tử?`,n+5,'Cộng số phần tử hai tập rồi trừ số phần tử chung.','Phần giao bị đếm hai lần.'));
lesson(10,'linear-region',A,'Bất phương trình bậc nhất hai ẩn','Đường biên ax + by = c chia mặt phẳng thành hai nửa. Thử một điểm ngoài đường biên để chọn miền nghiệm; dấu ≤ hoặc ≥ lấy cả đường biên.',
 n=>mc(`Điểm nào thỏa x + y ≤ ${n}?`,`(${n}; 0)`,[`(${n+1}; 0)`,`(0; ${n+2})`,`(${n}; 1)`],'Thay tọa độ vào vế trái. Chỉ điểm có tổng bằng n thỏa.','Dấu ≤ bao gồm trường hợp bằng.'),
 n=>q(`Miền x ≥ 0, y ≥ 0, x + y ≤ ${n}. Giá trị lớn nhất của 2x + y là bao nhiêu?`,2*n,`2x+y ≤ 2(x+y) ≤ ${2*n}; đạt tại (${n};0).`,'Thử các đỉnh của miền tam giác.'),
 n=>q(`Tại giao của x+y=${n+3} và y=3, x bằng bao nhiêu?`,n,'Thế y=3 vào đường biên rồi trừ 3.','Dùng phép thế.'));
lesson(10,'quadratic10',A,'Hàm số và tam thức bậc hai','Đỉnh của y = ax² + bx + c có hoành độ −b/(2a). Dấu của tam thức phụ thuộc hệ số a và các nghiệm thực.',
 n=>q(`Tìm hoành độ đỉnh của y=x²−${2*n}x+1.`,n,'Hoành độ đỉnh bằng −b/(2a).','Ở đây a=1.'),
 n=>q(`Tìm giá trị nhỏ nhất của y=(x−${n})²+3.`,3,'Bình phương không âm và bằng 0 tại x='+n+'.','Tìm khi bình phương bằng 0.'),
 n=>mc(`Khi nào (x−${n})(x−${n+2}) < 0?`,`${n} < x < ${n+2}`,[`x < ${n}`,`x > ${n+2}`,'Mọi x'],'Giữa hai nghiệm, hai nhân tử trái dấu.','Lập bảng dấu của hai nhân tử.'));
lesson(10,'trig10',G,'Hệ thức lượng trong tam giác','Định lí cosin: a²=b²+c²−2bc cos A. Diện tích bằng một nửa tích hai cạnh với sin góc xen giữa.',
 n=>q(`Tam giác có b=${3*n}, c=${4*n}, A=90°. Tính cạnh a.`,5*n,'cos 90°=0 nên dùng bộ cạnh 3–4–5 cùng tỉ lệ.','Áp dụng định lí cosin.'),
 n=>q(`Hai cạnh dài ${2*n} và 6, góc xen giữa 30°. Tính diện tích.`,3*n,'S=½·'+2*n+'·6·½.','sin 30°=1/2.'),
 ()=>q('Tính cos 120° (có thể nhập phân số).','-1/2','cos(180°−60°)=−cos 60°=−1/2.','Cos của góc tù mang dấu âm.'));
lesson(10,'vectors10',G,'Vectơ và tích vô hướng','Tích vô hướng của (a,b) và (c,d) bằng ac+bd. Hai vectơ khác vectơ không vuông góc khi tích vô hướng bằng 0.',
 n=>q(`Tính tích vô hướng của (${n}; 2) và (3; −1).`,3*n-2,'Nhân tọa độ tương ứng rồi cộng.','Tính n×3 + 2×(−1).'),
 n=>q(`A=(1; 2), B=(${n+1}; 4). Tìm hoành độ vectơ AB.`,n,'Lấy tọa độ điểm cuối trừ điểm đầu.','Hoành độ là xB−xA.'),
 n=>q(`Tìm k để (2; k) vuông góc với (${n}; 1).`,-2*n,'Tích vô hướng bằng 2·'+n+'+k. Đặt bằng 0.','Hai vectơ không bằng vectơ không.'));
lesson(10,'coordinates10',G,'Đường thẳng, đường tròn và conic','Đường tròn tâm (a,b), bán kính R có phương trình (x−a)²+(y−b)²=R². Phương trình đường thẳng tổng quát ax+by+c=0 có vectơ pháp tuyến (a,b).',
 n=>q(`Tính bán kính đường tròn (x−1)²+(y+2)²=${n*n}.`,n,'Vế phải là bình phương bán kính.','Lấy căn dương.'),
 n=>q(`Tìm tung độ giao điểm của x+2y−${2*n}=0 với trục tung.`,n,'Trên trục tung x=0, nên 2y='+2*n+'.','Thế x=0.'),
 ()=>mc('Conic có phương trình x²/9 + y²/4 = 1 là gì?','Elip',['Parabol','Hyperbol','Đường thẳng'],'Đây là dạng chính tắc của elip với hai mẫu số dương khác nhau.','Xét dấu cộng và các mẫu dương.'));
lesson(10,'combinatorics10',D,'Quy tắc đếm, tổ hợp và nhị thức','Nhân số cách khi các công đoạn nối tiếp. Tổ hợp không xét thứ tự; chỉnh hợp có xét thứ tự.',
 n=>q(`Có ${n} áo và 4 quần. Chọn một áo và một quần có bao nhiêu cách?`,4*n,'Mỗi áo kết hợp với 4 quần, dùng quy tắc nhân.','Có hai công đoạn.'),
 n=>q(`Chọn 2 bạn từ ${n+3} bạn, không xét thứ tự. Có bao nhiêu cách?`,(n+3)*(n+2)/2,'Dùng C(m,2)=m(m−1)/2.','Mỗi cặp không thứ tự bị đếm hai lần khi chọn lần lượt.'),
 n=>q(`Hệ số của x trong (1+x)^${n} là bao nhiêu?`,n,'Chọn đúng một thừa số x từ '+n+' thừa số.','Hệ số là C(n,1).'));
lesson(10,'data10',D,'Mẫu số liệu, số trung bình và độ phân tán','Số trung bình là tổng chia số quan sát. Khoảng biến thiên bằng giá trị lớn nhất trừ nhỏ nhất. Trung vị nằm ở giữa dãy đã sắp.',
 n=>q(`Tìm trung bình của ${n}; ${n+3}; ${n+6}.`,n+3,'Cộng ba giá trị, chia 3.','Dãy cách đều nên trung bình là giá trị giữa.'),
 n=>q(`Tìm khoảng biến thiên của ${n}; ${n+2}; ${n+9}.`,9,'Lấy '+(n+9)+' trừ '+n+'.','Dùng hai giá trị cực biên.'),
 n=>q(`Tìm trung vị của ${n+4}; ${n}; ${n+3}; ${n+2}; ${n+9}.`,n+3,'Sắp thứ tự rồi chọn giá trị đứng thứ ba.','Sắp dữ liệu trước khi lấy trung vị.'));
lesson(10,'prob10',D,'Xác suất cổ điển','Với các kết quả đồng khả năng, xác suất bằng số kết quả thuận lợi chia tổng số kết quả có thể.',
 n=>q(`Hộp có ${n} bi đỏ và ${3*n} bi xanh. Lấy đều ngẫu nhiên một bi. Xác suất lấy bi đỏ?`,'1/4','Có '+n+' bi đỏ trên tổng '+4*n+' bi.','Đếm trên toàn bộ hộp.'),
 ()=>q('Gieo hai xúc xắc cân đối độc lập. Xác suất tổng bằng 7?','1/6','Có 6 cặp có tổng 7 trên 36 cặp.','Liệt kê từ (1;6) đến (6;1).'),
 ()=>q('Gieo xúc xắc cân đối. Xác suất ra số lớn hơn 4?','1/3','Hai mặt 5 và 6 thuận lợi trong sáu mặt.','Đếm các kết quả thỏa bất đẳng thức.'));

lesson(11,'trig11',A,'Hàm số và phương trình lượng giác','Dùng đường tròn lượng giác để đọc dấu. Phương trình sin x=0 có nghiệm x=kπ với k nguyên.',
 n=>q(`Trong đoạn [0; ${n}π], phương trình sin x=0 có bao nhiêu nghiệm?`,n+1,'Các nghiệm là kπ với k từ 0 đến '+n+', kể cả hai đầu mút.','Đếm cả nghiệm x=0.'),
 ()=>q('Tính sin(5π/6).','1/2','sin(π−π/6)=sin(π/6)=1/2.','Góc ở góc phần tư II.'),
 ()=>mc('Chu kì dương nhỏ nhất của y = cos x?','2π',['π','π/2','4π'],'Giá trị cos lặp lại sau một vòng tròn.','Một vòng bằng 2π radian.'));
lesson(11,'sequences11',A,'Dãy số, cấp số cộng và cấp số nhân','Cấp số cộng có uₙ=u₁+(n−1)d. Cấp số nhân có uₙ=u₁qⁿ⁻¹.',
 n=>q(`Cấp số cộng có u₁=${n}, d=3. Tính u₅.`,n+12,'Từ u₁ tới u₅ có bốn lần cộng công sai.','Dùng n−1 bước.'),
 n=>q(`Cấp số nhân có u₁=${n}, q=2. Tính u₄.`,8*n,'Nhân u₁ với 2³.','Từ số hạng thứ nhất đến thứ tư có ba bước.'),
 n=>q(`Tính tổng bốn số hạng đầu của cấp số cộng u₁=${n}, d=2.`,4*n+12,'Các số là n, n+2, n+4, n+6.','Có thể dùng 4(u₁+u₄)/2.'));
lesson(11,'limits11',A,'Giới hạn và tính liên tục','Có thể thay trực tiếp vào hàm liên tục. Với dạng 0/0, thử phân tích nhân tử hoặc rút gọn trước khi lấy giới hạn.',
 n=>q(`Tính giới hạn (x²−${n*n})/(x−${n}) khi x tiến tới ${n}.`,2*n,'Với x khác '+n+', rút gọn thành x+'+n+', rồi lấy giới hạn.','Phân tích hiệu hai bình phương.'),
 n=>q(`Tính giới hạn (${n}x+1)/(2x−1) khi x tiến tới +∞.`,f(n,2),'Chia cả tử và mẫu cho x, các số hạng 1/x tiến về 0.','So hệ số của bậc cao nhất.'),
 n=>q(`Tìm giá trị f(${n}) để f liên tục tại x=${n}, biết f(x)=x+2 khi x≠${n}.`,n+2,'Giá trị tại điểm phải bằng giới hạn tại điểm.','Tính giới hạn của x+2.'));
lesson(11,'exp11',A,'Hàm số mũ và lôgarit','logₐ b=c khi aᶜ=b với a>0, a≠1 và b>0. Khi lấy log cần kiểm tra biểu thức trong log dương.',
 n=>q(`Giải 2ˣ=${2**n}. Nhập x.`,n,'Đưa hai vế về cùng cơ số 2.','Hàm mũ cơ số 2 là đơn điệu.'),
 n=>q(`Tính log₃(${3**n}).`,n,'Vì '+3**n+'=3^'+n+'.','Đọc số mũ của cơ số 3.'),
 n=>mc(`Điều kiện để log₂(x−${n}) xác định?`,`x > ${n}`,[`x ≥ ${n}`,`x < ${n}`,'Mọi x'],'Biểu thức trong log phải dương nghiêm ngặt.','Số 0 không thuộc tập xác định.'));
lesson(11,'derivative11',A,'Đạo hàm và tiếp tuyến','Đạo hàm xⁿ là nxⁿ⁻¹. Hệ số góc tiếp tuyến tại x₀ bằng f′(x₀).',
 n=>q(`Tính f′(${n}) với f(x)=x²+3x.`,2*n+3,'f′(x)=2x+3; thay x='+n+'.','Đạo hàm từng hạng tử.'),
 n=>q(`Hệ số góc tiếp tuyến của y=x³ tại x=${n}?`,3*n*n,'Đạo hàm bằng 3x².','Thế hoành độ vào đạo hàm.'),
 n=>q(`Vị trí s(t)=t²+${n}t. Tốc độ tức thời tại t=2 bằng bao nhiêu?`,n+4,'Vận tốc s′(t)=2t+'+n+'; thay t=2.','Đạo hàm của quãng đường theo thời gian.'));
lesson(11,'parallel11',G,'Quan hệ song song trong không gian','Nếu đường thẳng không nằm trong mặt phẳng và song song với một đường thẳng của mặt phẳng thì song song với mặt phẳng.',
 ()=>mc('Đường d nằm ngoài (P) và song song với a nằm trong (P). Kết luận gì?','d song song với (P)',['d nằm trong (P)','d vuông góc với (P)','d cắt (P)'],'Áp dụng dấu hiệu đường thẳng song song mặt phẳng.','Chú ý d nằm ngoài mặt phẳng.'),
 n=>q(`Hình lăng trụ đứng có cạnh bên dài ${n}. Khoảng cách giữa hai đáy là bao nhiêu?`,n,'Cạnh bên vuông góc với hai đáy nên là chiều cao.','Hai mặt đáy song song.'),
 ()=>mc('Qua điểm A ngoài mặt phẳng (P), có bao nhiêu mặt phẳng song song với (P)?','Một',['Không có','Hai','Vô số'],'Qua một điểm ngoài mặt phẳng có duy nhất một mặt phẳng song song với mặt phẳng đã cho.','Xét tính duy nhất.'));
lesson(11,'perpendicular11',G,'Vuông góc, khoảng cách và thể tích','Đường thẳng vuông góc hai đường cắt nhau của một mặt phẳng thì vuông góc với mặt phẳng. Thể tích chóp bằng một phần ba tích diện tích đáy và chiều cao.',
 n=>q(`Hình chóp có diện tích đáy ${3*n}, chiều cao 4. Tính thể tích.`,4*n,'V=⅓·'+3*n+'·4.','Nhớ hệ số 1/3.'),
 n=>q(`Hình lập phương cạnh ${n}. Khoảng cách giữa hai mặt đối diện?`,n,'Một cạnh nối hai mặt đối diện vuông góc với cả hai mặt.','Tìm đoạn vuông góc chung.'),
 n=>q(`Lăng trụ có diện tích đáy ${n+2}, chiều cao 5. Tính thể tích.`,5*(n+2),'Nhân diện tích đáy với chiều cao.','Dùng V=S·h.'));
lesson(11,'grouped11',D,'Số liệu ghép nhóm','Ước lượng trung bình bằng tổng các tích giá trị đại diện của nhóm với tần số, chia tổng tần số. Giá trị đại diện là trung điểm nhóm.',
 n=>q(`Giá trị đại diện của nhóm [${n}; ${n+8}) là bao nhiêu?`,n+4,'Lấy trung điểm của hai đầu mút.','Cộng hai đầu mút rồi chia 2.'),
 n=>q(`Hai nhóm có giá trị đại diện ${n} và ${n+4}, tần số lần lượt 3 và 1. Trung bình xấp xỉ?`,n+1,'Tính trung bình có trọng số: (3n+n+4)/4.','Nhân giá trị đại diện với tần số tương ứng.'),
 ()=>q('Nhóm [20;30) có độ dài bằng bao nhiêu?',10,'Độ dài nhóm là 30−20.','Dùng hiệu hai đầu mút.'));
lesson(11,'prob11',D,'Biến cố độc lập, hợp và giao','Nếu A và B độc lập thì P(A∩B)=P(A)P(B). Với mọi A,B, P(A∪B)=P(A)+P(B)−P(A∩B).',
 ()=>q('A, B độc lập, P(A)=1/2 và P(B)=1/3. Tính P(A∩B).','1/6','Nhân hai xác suất do hai biến cố độc lập.','Dùng quy tắc nhân.'),
 ()=>q('P(A)=0,4, P(B)=0,5 và P(A∩B)=0,2. Tính P(A∪B).',0.7,'Cộng 0,4 và 0,5, trừ phần giao 0,2.','Phần giao bị đếm hai lần.'),
 ()=>q('Xác suất A xảy ra là 0,3. Xác suất biến cố đối của A?',0.7,'Hai biến cố bù nhau có tổng xác suất 1.','Tính 1−P(A).'));

lesson(12,'variation12',A,'Đạo hàm, biến thiên và cực trị','Dùng dấu f′ để xét đồng biến, nghịch biến. Nếu f′ đổi dấu từ âm sang dương qua x₀ thì x₀ là điểm cực tiểu.',
 n=>q(`Tìm hoành độ cực tiểu của y=x²−${2*n}x+1.`,n,'f′=2x−'+2*n+'; đạo hàm đổi dấu từ âm sang dương tại x='+n+'.','Giải f′=0 rồi xét dấu.'),
 n=>q(`Tìm giá trị lớn nhất của y=−(x−${n})²+7.`,7,'Phần âm của bình phương không dương và bằng 0 khi x='+n+'.','Xét giá trị lớn nhất của phần −(x−n)².'),
 ()=>mc('f′ đổi dấu từ dương sang âm qua x₀. Kết luận gì?','Cực đại tại x₀',['Cực tiểu tại x₀','Luôn đồng biến','Luôn nghịch biến'],'Hàm tăng trước x₀ rồi giảm sau x₀.','Theo dõi hướng đổi dấu.'));
lesson(12,'asymptote12',A,'Tiệm cận và khảo sát đồ thị','Nếu giới hạn khi x tiến tới ±∞ bằng b thì y=b là tiệm cận ngang. Nếu một giới hạn một phía tại a vô hạn thì x=a là tiệm cận đứng.',
 n=>q(`Tung độ tiệm cận ngang của y=(${n}x+1)/(x−2)?`,n,'Chia tử mẫu cho x, giới hạn bằng hệ số bậc nhất của tử chia hệ số bậc nhất của mẫu.','So hệ số của x.'),
 n=>q(`Hoành độ tiệm cận đứng của y=1/(x−${n})?`,n,'Mẫu tiến về 0, tử bằng 1 nên giới hạn một phía vô hạn.','Giải x−n=0.'),
 n=>q(`Hệ số góc tiệm cận xiên của y=${n}x+2+1/x?`,n,'Hiệu giữa hàm và đường thẳng nx+2 tiến về 0.','Số hạng 1/x tiến về 0.'));
lesson(12,'optimization12',A,'Tối ưu hóa bằng đạo hàm','Lập hàm mục tiêu theo một biến, xác định miền giá trị và so sánh tại điểm tới hạn cùng các đầu mút phù hợp.',
 n=>q(`Hình chữ nhật có chu vi ${8*n}. Tính diện tích lớn nhất.`,4*n*n,`Tổng hai cạnh là ${4*n}; tích lớn nhất khi hai cạnh bằng ${2*n}.`,'Viết diện tích x(4n−x).'),
 n=>q(`Trên [0; ${2*n}], tìm x làm lớn nhất x(${2*n}−x).`,n,'Hàm bậc hai mở xuống đạt lớn nhất tại đỉnh x='+n+'.','Lấy đạo hàm và giải bằng 0.'),
 n=>q(`Chi phí C(x)=x²−${2*n}x+100. Tại x nào chi phí nhỏ nhất?`,n,'C′=2x−'+2*n+', đổi dấu từ âm sang dương tại x='+n+'.','Tìm đỉnh hoặc dùng đạo hàm.'));
lesson(12,'integral12',A,'Nguyên hàm, tích phân và ứng dụng','Nếu F′=f thì tích phân từ a đến b của f bằng F(b)−F(a). Diện tích hình phẳng dùng tích phân của giá trị tuyệt đối hiệu hai đồ thị.',
 n=>q(`Tính ∫₀^${n} 2x dx.`,n*n,'Nguyên hàm 2x là x². Thay cận trên rồi trừ cận dưới.','Dùng F(b)−F(a).'),
 n=>q(`Tính diện tích giới hạn bởi y=2x, trục hoành, x=0 và x=${n}.`,n*n,'Trên đoạn này 2x≥0, nên S=∫ 2x dx với hai cận đã cho.','Hàm ở phía trên trục hoành.'),
 n=>q(`Quay hình dưới y=${n} trên đoạn [0;2] quanh trục Ox. Thể tích bằng bao nhiêu lần π?`,2*n*n,'V=π∫ y² dx, với y²='+n*n+' và đoạn dài 2.','Bình phương bán kính lát cắt.'));
lesson(12,'vectors12',G,'Vectơ và tọa độ trong không gian Oxyz','Độ dài vectơ (x,y,z) là √(x²+y²+z²). Tích vô hướng là tổng tích ba cặp tọa độ.',
 n=>q(`Tính độ dài vectơ (${3*n}; ${4*n}; 0).`,5*n,'Áp dụng công thức căn tổng bình phương.','Dùng bộ 3–4–5.'),
 n=>q(`Tính tích vô hướng của (${n}; 2; 1) và (2; −1; 3).`,2*n+1,'Tích bằng 2n−2+3.','Nhân từng cặp tọa độ.'),
 n=>q(`A=(1; 2; 3), B=(${n+1}; 2; 3). Độ dài AB là bao nhiêu?`,n,'Chỉ hoành độ thay đổi, hiệu bằng '+n+'.','Hai điểm có cùng tung độ và cao độ.'));
lesson(12,'space12',G,'Mặt phẳng, đường thẳng và mặt cầu','Mặt phẳng ax+by+cz+d=0 có pháp tuyến (a,b,c). Mặt cầu tâm I(a,b,c), bán kính R có tổng ba bình phương khoảng cách tọa độ bằng R².',
 n=>q(`Khoảng cách từ O đến mặt phẳng z−${n}=0?`,n,'Mặt phẳng song song Oxy, chân chiếu của O là (0;0;'+n+').','Khoảng cách là độ chênh cao độ.'),
 n=>q(`Tìm bán kính mặt cầu x²+y²+(z−1)²=${n*n}.`,n,'Vế phải bằng R².','Lấy căn dương.'),
 n=>q(`Đường thẳng x=1+t, y=2, z=3. Tại t=${n}, x bằng bao nhiêu?`,n+1,'Thế tham số t='+n+' vào biểu thức x.','Các tọa độ phụ thuộc tham số t.'));
lesson(12,'grouped12',D,'Độ phân tán của mẫu số liệu ghép nhóm','Phương sai xấp xỉ là trung bình có trọng số của bình phương độ lệch. Độ lệch chuẩn bằng căn bậc hai của phương sai.',
 n=>q(`Phương sai của một mẫu là ${n*n}. Độ lệch chuẩn?`,n,'Độ lệch chuẩn bằng căn dương của phương sai.','Lấy căn bậc hai.'),
 n=>q(`Tứ phân vị Q₁=${n}, Q₃=${n+8}. Khoảng tứ phân vị?`,8,'Khoảng tứ phân vị bằng Q₃−Q₁.','Lấy hiệu, không lấy trung bình.'),
 ()=>mc('Đơn vị của độ lệch chuẩn của chiều cao đo bằng cm là gì?','cm',['cm²','cm³','Không có đơn vị'],'Phương sai có đơn vị cm², lấy căn cho đơn vị cm.','Độ lệch chuẩn dùng cùng đơn vị dữ liệu.'));
lesson(12,'bayes12',D,'Xác suất có điều kiện và Bayes','P(A|B)=P(A∩B)/P(B), với P(B)>0. Công thức xác suất toàn phần cộng các nhánh. Bayes đảo điều kiện bằng cách chia xác suất giao cho xác suất biến cố đã biết.',
 ()=>q('P(A∩B)=0,15; P(B)=0,5. Tính P(A|B).',0.3,'Lấy 0,15 chia 0,5.','Mẫu số là xác suất của điều kiện B.'),
 ()=>q('Hai nguồn A và B chiếm 40% và 60%. Tỉ lệ lỗi tương ứng 10% và 20%. Xác suất lấy sản phẩm lỗi?',0.16,'P(lỗi)=0,4·0,1+0,6·0,2=0,16.','Cộng hai xác suất theo từng nhánh.'),
 ()=>q('Nguồn A chiếm 40%, có tỉ lệ lỗi 10%; nguồn B chiếm 60%, có tỉ lệ lỗi 20%. Biết sản phẩm lỗi, xác suất nó từ A?',0.25,'P(A∩lỗi)=0,04 và P(lỗi)=0,16. Chia được 0,25.','Dùng công thức Bayes.'));

const content=topics.map(t=>({...t,examples:t.examples.map((make,i)=>make(3+i))}));
if(typeof module!=='undefined')module.exports={topics,content};
