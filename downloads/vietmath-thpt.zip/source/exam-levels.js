const examLevels=(()=>{
 const bands=['Cơ bản','Vận dụng','Nâng cao'];
 const mc=(prompt,answer,options,solution)=>({part:0,prompt,answer:String(answer),options:[answer,...options].map(String),solution});
 const tf=(prompt,statements)=>({part:1,prompt,statements});
 const short=(prompt,answer,solution)=>({part:2,prompt,answer,solution});
 function apply(questions,version){
  const code=Number(version), band=Math.floor((code-1)/3);
  if(!band)return questions;
  const n=2+(code-1)%3;
  const a=band===2;
  questions[0]=a
   ?mc(`Có bao nhiêu số nguyên m để y=x³−3mx²+${3*n*n}x đồng biến trên ℝ?`,2*n+1,[2*n,2*n-1,2*n+2],`Đạo hàm bằng 3[(x−m)²+${n*n}−m²]. Điều kiện |m|≤${n}, kể cả hai đầu vì đạo hàm chỉ bằng 0 tại một điểm.`)
   :mc(`Đồ thị y=x³−${3*n*n}x+c có hai cực trị. Hiệu giá trị cực đại và cực tiểu là bao nhiêu?`,4*n**3,[2*n**3,3*n**3,n**3],`Các hoành độ cực trị là ±${n}. Hiệu f(−${n})−f(${n}) bằng ${4*n**3}, độc lập với c.`);
  questions[1]=mc(`Có bao nhiêu tiệm cận đứng của y=(x−${n})/((x−${n})(x+${n}))?`,1,[0,2,3],`Rút gọn còn 1/(x+${n}) trên tập xác định. Giới hạn tại ${n} hữu hạn; chỉ x=−${n} là tiệm cận đứng.`);
  questions[2]=mc(`Tìm giá trị lớn nhất của f(x)=x(${2*n}−x) trên [${n+1}; ${2*n}].`,n*n-1,[n*n,0,n*n-2],`Đỉnh ở x=${n} ngoài đoạn. Hàm giảm trên đoạn nên giá trị lớn nhất đạt tại x=${n+1}.`);
  questions[3]=mc(`Cho F′(x)=${n}x² và F(0)=3. Tính F(3).`,9*n+3,[9*n,27*n+3,3*n+3],`F(x)=${n}x³/3+3.`);
  questions[4]=mc(`Diện tích giữa y=x−${n} và trục Ox trên [0; ${2*n}] bằng bao nhiêu?`,n*n,[0,2*n*n,n*n/2],`Đồ thị cắt trục tại ${n}. Hai tam giác có tổng diện tích ${n*n}.`);
  questions[5]=mc(`Hai vectơ (1; m; ${n}) và (2; −1; ${n}) vuông góc. Tìm m.`,n*n+2,[n*n-2,-(n*n+2),n+2],`Tích vô hướng bằng 2−m+${n*n}=0.`);
  questions[6]=mc(`Mặt cầu tâm (0; 0; ${n}) tiếp xúc mặt phẳng 2x+2y+z=0. Bán kính bằng bao nhiêu?`,`${n}/3`,[n,`${n}/2`,3*n],`Khoảng cách từ tâm đến mặt phẳng bằng ${n}/√(4+4+1).`);
  questions[7]=mc(`Mẫu ghép nhóm có hai giá trị đại diện 1 và ${2*n+1}, mỗi nhóm cùng tần số. Phương sai ước lượng là bao nhiêu?`,n*n,[n,2*n*n,n*n+1],`Trung bình là ${n+1}. Hai độ lệch là ±${n}; bình phương rồi lấy trung bình.`);
  questions[8]=mc(`Một thùng có ${n} bi đỏ và ${2*n} bi trắng. Lấy liên tiếp hai bi không hoàn lại. Biết bi đầu màu đỏ, xác suất bi sau màu trắng là bao nhiêu?`,`${2*n}/${3*n-1}`,['2/3',`${n-1}/${3*n-1}`,`${2*n-1}/${3*n-1}`],`Sau lượt đầu còn ${2*n} bi trắng trong ${3*n-1} bi.`);
  questions[9]=mc(`Một lượng tiền ban đầu là ${n} triệu đồng, tăng 10% mỗi năm theo lãi kép. Sau 2 năm có bao nhiêu triệu đồng?`,Number((1.21*n).toFixed(2)),[1.2*n,1.1*n,1.02*n].map(x=>Number(x.toFixed(2))),`Nhân số tiền ban đầu với (1+0,1)².`);
  questions[10]=mc(`Có ${n} học sinh lớp A và ${n+2} học sinh lớp B. Chọn một nhóm hai người có cả hai lớp. Có bao nhiêu cách?`,n*(n+2),[2*n+1,2*n*(n+2),n*(n+1)],'Chọn một bạn từ mỗi lớp theo quy tắc nhân.');
  questions[11]=mc(`Đường thẳng (x; y; z)=(1+t; 2; ${n}−t) gặp mặt phẳng x+2z=1 tại điểm có hoành độ bao nhiêu?`,2*n+1,[2*n-1,n,1],`Thay vào phương trình mặt phẳng được 1+2×${n}−t=1.`);
  questions[12]=tf(`Xét f(x)=x+${n*n}/x với x>0.`,[
   [`f′(x)=1−${n*n}/x².`,true,'Lấy đạo hàm x và 1/x.'],
   [`Hàm số tăng trên (0; ${n}).`,false,'Đạo hàm âm trong khoảng đó.'],
   [`Giá trị nhỏ nhất bằng ${2*n}.`,true,`Tại x=${n}, đạo hàm đổi dấu từ âm sang dương.`],
   [`Đường y=${2*n+1} cắt đồ thị đúng một điểm trên x>0.`,false,'Giá trị này lớn hơn cực tiểu và cả hai nhánh đều tiến tới +∞.']
  ]);
  questions[13]=tf(`Xét hình phẳng giới hạn bởi y=x², y=${n}x với x∈[0; ${n}].`,[
   [`Hai đồ thị gặp nhau tại x=0 và x=${n}.`,true,'Giải x(x−n)=0.'],
   ['Parabol nằm phía trên đường thẳng trong miền giữa hai giao điểm.',false,'x(n−x)>0 trong khoảng.'],
   [`Diện tích hình phẳng bằng ${n**3}/6.`,true,'Lấy tích phân của nx−x² từ 0 đến n.'],
   [`Khi quay quanh Ox, thể tích bằng π∫ từ 0 đến ${n} của (nx−x²)² dx.`,false,'Diện tích vành khăn là π[(nx)²−(x²)²].']
  ]);
  questions[14]=tf(`Trong Oxyz, A=(0; 0; ${n}), B=(${n}; 0; 0), P là mặt phẳng x+z=${n}.`,[
   ['Cả hai điểm A và B thuộc P.',true,'Thế từng bộ tọa độ.'],
   ['Đường AB vuông góc với P.',false,'AB nằm trong P.'],
   ['Vectơ (1; 0; 1) là pháp tuyến của P.',true,'Đọc hệ số x, y, z.'],
   [`Khoảng cách từ O đến P bằng ${n}.`,false,`Khoảng cách là ${n}/√2.`]
  ]);
  questions[15]=tf(`Hộp có ${n} bi xanh và ${n} bi đỏ. Rút hai bi không hoàn lại. A là biến cố bi đầu xanh, B là biến cố bi sau xanh.`,[
   ['P(A)=1/2.',true,'Hai màu có số lượng bằng nhau.'],
   ['A và B độc lập.',false,'Lượt đầu làm thay đổi thành phần của hộp.'],
   [`P(B|A)=${n-1}/${2*n-1}.`,true,'Khi bi đầu xanh, bớt một bi xanh và một bi tổng.'],
   ['P(B)=1/2.',true,'Mỗi viên có cùng cơ hội nằm ở vị trí rút thứ hai.']
  ]);
  questions[16]=a
   ?short(`Cho f(x)=x³−${3*n*n}x. Tiếp tuyến có hệ số góc nhỏ nhất cắt đường thẳng y=${3*n*n} tại hoành độ nào?`,-1,`Hệ số góc 3x²−${3*n*n} nhỏ nhất tại x=0. Tiếp tuyến y=−${3*n*n}x nên x=−1.`)
   :short(`Chi phí trung bình của một xưởng là C(x)=x+${n*n}/x+10 với x>0. Tính chi phí trung bình thấp nhất.`,2*n+10,`x+${n*n}/x≥${2*n} theo bất đẳng thức AM–GM. Đẳng thức tại x=${n}.`);
  questions[17]=short(`Vận tốc v(t)=t−${n} m/s. Tính tổng quãng đường đi được từ t=0 đến t=${2*n} giây.`,n*n,`Vật đổi chiều ở t=${n}. Tích phân của |v| là tổng diện tích hai tam giác, bằng ${n*n}.`);
  questions[18]=short(`Từ A=(${n}; ${n}; 0) kẻ hình chiếu H lên đường d: (x; y; z)=(t; 0; t). Tính tổng xᴴ+zᴴ.`,n,`AH vuông góc (1;0;1) nên 2t−${n}=0, do đó tổng hai tọa độ là ${n}.`);
  questions[19]=short(`Mẫu ghép nhóm có các khoảng [0; 2), [2; 4), [4; 6) với tần số ${n}, ${2*n}, ${n}. Ước lượng phương sai theo giá trị đại diện.`,2,'Trung bình là 3. Phương sai là (4n+0+4n)/(4n)=2.');
  questions[20]=short(`Hộp có ${n} bi đỏ và ${n} bi xanh. Rút hai bi không hoàn lại. Biết có ít nhất một bi đỏ, xác suất có hai bi đỏ là bao nhiêu phần trăm? Làm tròn đến hàng đơn vị và nhập số.`,Math.round(100*(n-1)/(3*n-1)),`Số cặp hai đỏ là n(n−1)/2. Số cặp có đỏ là n(n−1)/2+n². Lấy tỉ số rồi đổi ra phần trăm.`);
  questions[21]=short(`Đường thẳng (x; y; z)=(t; t; ${n}) cắt mặt cầu x²+y²+z²=${3*n*n} tại hai điểm M, N. Tính MN².`,8*n*n,`Phương trình giao điểm cho t²=${n*n}. Vectơ MN có hai tọa độ chênh nhau 2n và cao độ bằng nhau; MN²=8n².`);
  if(a){
   questions[3]=mc(`Biết ∫ từ 0 đến ${n} của f(x) dx = 5. Tính ∫ từ 0 đến ${n} của f(${n}−x)+2 dx.`,5+2*n,[5,2*n-5,5+4*n],'Đổi biến u=n−x đảo cận và đổi dấu vi phân, nên tích phân của f giữ nguyên. Tích phân của 2 bằng 2n.');
   questions[8]=mc(`Một lô hàng có ${n}% hàng lỗi. Máy báo lỗi đúng 90% trên hàng lỗi, báo nhầm 10% trên hàng tốt. Trong số hàng máy báo lỗi, tỉ lệ hàng thật sự lỗi là bao nhiêu?`,`${9*n}/${100+8*n}`,[`${n}/100`,'9/10',`${9*n}/100`],'Chia xác suất hàng lỗi và được báo (0,9n/100) cho xác suất máy báo trên cả hai loại.');
   questions[12]=tf(`Xét f(x)=x³−3mx với m>0.`,[
    ['Đồ thị có hai điểm cực trị.',true,'f′=3(x²−m) có hai nghiệm phân biệt và đổi dấu.'],
    ['Tích hai giá trị cực trị bằng 4m³.',false,'Hai giá trị là ±2m√m nên tích âm.'],
    ['Phương trình f(x)=0 có đúng ba nghiệm phân biệt.',true,'Phân tích x(x²−3m)=0.'],
    [`Để hai hoành độ cực trị cách nhau ${2*n}, cần m=${n*n}.`,true,'Khoảng cách giữa ±√m là 2√m.']
   ]);
   questions[13]=tf(`Vật có v(t)=(t−${n})(t−${2*n}) trên [0; ${3*n}] (m/s).`,[
    [`Vật đổi chiều hai lần.`,true,'Vận tốc đổi dấu qua cả hai nghiệm.'],
    [`Trên (${n}; ${2*n}) vật đi theo chiều dương.`,false,'Hai thừa số trái dấu.'],
    [`Quãng đường bằng tích phân của |v(t)| trên [0; ${3*n}].`,true,'Lấy tích phân tốc độ.'],
    ['Gia tốc tăng đều theo thời gian.',true,'v′(t)=2t−3n có hệ số góc dương.']
   ]);
   questions[17]=short(`Tìm b>0 để diện tích phần nằm giữa y=x² và y=bx trên [0; b] bằng ${n**3*36}.`,6*n,`Diện tích bằng b³/6. Vậy b³=${(6*n)**3}.`);
   questions[19]=short(`Các giá trị đại diện 1, 3, 5 có tần số lần lượt ${n}, k, ${n}. Phương sai ước lượng bằng 1. Tìm k.`,6*n,`Do đối xứng, trung bình bằng 3. Phương sai là 8×${n}/(2×${n}+k)=1.`);
   questions[21]=short(`Tìm khoảng cách giữa hai mặt phẳng song song x+2y+2z=${n} và x+2y+2z=${7*n}.`,2*n,`Lấy hiệu hai vế phải theo trị tuyệt đối rồi chia √(1+4+4)=3.`);
  }
  return questions;
 }
 return {bands,apply};
})();
if(typeof module!=='undefined')module.exports=examLevels;
