const mockExam=(()=>{
 const points=[0,10,25,50,100];
 const levels=typeof module!=='undefined'?require('./exam-levels'):examLevels;
 const versions=['01','02','03','04','05','06','07','08','09'];
 const bandFor=v=>Math.floor((Number(v)-1)/3);
 const key='vietmath-thpt-mock-v1';
 const parts=['I · Chọn đáp án','II · Đúng / Sai','III · Trả lời ngắn'];
 let attempt,host,timer,storageError=false;
 const escape=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[char]);
 const format=value=>value.toLocaleString('vi-VN',{maximumFractionDigits:2});
 function make(version){
  const n=versions.indexOf(version)%3+2;
  const single=(prompt,answer,distractors,solution)=>({part:0,prompt,answer:String(answer),options:[answer,...distractors].map(String),solution});
  const group=(prompt,statements)=>({part:1,prompt,statements});
  const numeric=(prompt,answer,solution)=>({part:2,prompt,answer,solution});
  const questions=[
   single(`Hàm số y=x³−${3*n*n}x nghịch biến trên khoảng nào?`,`(−${n}; ${n})`,[`(${n}; +∞)`,`(−∞; −${n})`,'ℝ'],`y′=3(x²−${n*n}), âm khi −${n}<x<${n}.`),
   single(`Tiệm cận ngang của đồ thị y=(${n}x+1)/(x+1) là đường nào?`,`y=${n}`,['x=−1','y=1',`x=${n}`],'Chia tử và mẫu cho x rồi lấy giới hạn ở vô cực.'),
   single(`Giá trị nhỏ nhất của f(x)=x²−${2*n}x+${n*n+2} trên [0; ${n+1}] bằng bao nhiêu?`,2,[1,0,n*n+2],`f(x)=(x−${n})²+2. Đạt tại x=${n} thuộc đoạn.`),
   single(`Một nguyên hàm của f(x)=${n}eˣ là hàm số nào?`,`${n}eˣ`,[`eˣ/${n}`,`${n}xeˣ`,`${n}e²ˣ`],'Đạo hàm eˣ bằng eˣ.'),
   single(`Tính tích phân của f(x)=2x+1 từ x=0 đến x=${n}.`,n*n+n,[n*n,n*n+n+1,2*n+1],`Nguyên hàm x²+x. Hiệu hai giá trị tại cận là ${n*n+n}.`),
   single(`Trong Oxyz, tích vô hướng của u=(${n}; 1; 2) và v=(2; −1; 1) bằng bao nhiêu?`,2*n+1,[2*n-1,2*n,2*n+3],'Nhân từng cặp tọa độ rồi cộng, được 2n−1+2.'),
   single(`Vectơ nào là pháp tuyến của mặt phẳng ${n}x−y+2z+5=0?`,`(${n}; −1; 2)`,[`(${n}; 1; 2)`,`(−${n}; −1; 2)`,`(${n}; −1; 5)`],'Lấy ba hệ số của x, y, z.'),
   single(`Một mẫu số liệu ghép nhóm có Q₁=${n+4} và Q₃=${n+11}. Khoảng tứ phân vị bằng bao nhiêu?`,7,[5,n+11,2*n+15],'Khoảng tứ phân vị là Q₃−Q₁.'),
   single(`Cho P(B)=0,5 và P(A∩B)=0,${n}. Tính P(A|B).`,`0,${2*n}`,[`0,${n}`,'0,5','1'],`Chia 0,${n} cho 0,5.`),
   single(`Cấp số cộng có u₁=${n}, công sai 3. Số hạng thứ tư bằng bao nhiêu?`,n+9,[n+3,n+12,3*n],`u₄=u₁+3d=${n+9}.`),
   single(`Tập hợp gồm ${n+3} phần tử. Có bao nhiêu cách chọn một tập con gồm hai phần tử?`,(n+3)*(n+2)/2,[(n+3)*(n+2),n+3,(n+3)**2],'Chọn hai phần tử phân biệt, không xét thứ tự.'),
   single(`Đường thẳng đi qua A(0; 1; 2) có vectơ chỉ phương (1; ${n}; 0). Điểm nào thuộc đường thẳng?`,`(1; ${n+1}; 2)`,[`(1; ${n}; 2)`,`(1; ${n+1}; 0)`,`(0; ${n+1}; 2)`],'Thế t=1 vào (t; 1+nt; 2).'),
   group(`Xét hàm số f(x)=x³−${3*n*n}x trên ℝ.`,[
    [`f′(0)=−${3*n*n}.`,true,'f′(x)=3x²−3n².'],
    [`Hàm số đồng biến trên (−${n}; ${n}).`,false,'Đạo hàm âm trên khoảng này.'],
    [`Hàm số đạt cực đại tại x=−${n}.`,true,'Đạo hàm đổi dấu từ dương sang âm.'],
    [`Giá trị cực tiểu là ${2*n**3}.`,false,`f(${n})=−${2*n**3}.`]
   ]),
   group(`Một vật chuyển động thẳng có vận tốc v(t)=${n}t+2 (m/s) trong 4 giây đầu.`,[
    [`Vận tốc lúc t=0 là ${n} m/s.`,n===2,'v(0)=2 m/s.'],
    [`Gia tốc không đổi, bằng ${n} m/s².`,true,'Đạo hàm v′(t)=n.'],
    [`Quãng đường từ giây 0 đến giây 2 là ${2*n+4} m.`,true,'v(t)>0, lấy tích phân từ 0 đến 2.'],
    [`Quãng đường trong hai giây sau bằng quãng đường trong hai giây đầu.`,false,'Vận tốc tăng đều nên quãng đường trong hai giây sau lớn hơn.']
   ]),
   group(`Trong Oxyz, mặt cầu (S) có phương trình (x−${n})²+y²+z²=${n*n}. Gọi I là tâm.`,[
    ['Gốc tọa độ O nằm trên (S).',true,'Khoảng cách OI bằng bán kính n.'],
    [`I có tọa độ (−${n}; 0; 0).`,false,`Tâm có hoành độ ${n}.`],
    ['Mặt phẳng x=0 tiếp xúc với (S).',true,'Khoảng cách từ tâm đến mặt phẳng bằng bán kính.'],
    [`Điểm (${3*n}; 0; 0) nằm trong mặt cầu.`,false,'Điểm cách tâm 2n, lớn hơn bán kính.']
   ]),
   group(`Một xưởng có hai dây chuyền A và B sản xuất số lượng bằng nhau. Tỉ lệ lỗi của A là ${n}% và của B là ${3*n}%. Chọn ngẫu nhiên một sản phẩm.`,[
    ['Xác suất lấy sản phẩm từ A là 0,5.',true,'Hai dây chuyền sản xuất số lượng bằng nhau.'],
    [`Xác suất lấy sản phẩm lỗi là ${2*n}%.`,true,'Dùng xác suất toàn phần, lấy trung bình hai tỉ lệ lỗi.'],
    ['Nếu sản phẩm bị lỗi, xác suất nó từ A là 0,5.',false,'Theo Bayes, kết quả là 1/4.'],
    ['Nếu sản phẩm bị lỗi, xác suất nó từ B là 0,75.',true,'Chia xác suất đồng thời từ B và lỗi cho xác suất lỗi.']
   ]),
   numeric(`Dùng ${2*n+12} mét lưới rào ba cạnh của một mảnh vườn chữ nhật, cạnh còn lại giáp tường. Tìm diện tích lớn nhất (m²), làm tròn đến một chữ số thập phân.`,Math.round((n+6)**2*5)/10,`Gọi chiều rộng x, diện tích x(${2*n+12}−2x). Đỉnh đạt tại x=${format((n+6)/2)}, diện tích chính xác bằng ${format((n+6)**2/2)}.`),
   numeric(`Một bể ban đầu chứa 20 lít nước. Nước chảy vào với tốc độ q(t)=${n}t+3 lít/phút. Sau 4 phút bể có bao nhiêu lít?`,32+8*n,`Tích phân từ 0 đến 4 cho ${12+8*n} lít. Cộng 20 lít ban đầu.`),
   numeric(`Trong Oxyz, A=(1; 2; 3), B=(${n+1}; ${2*n+2}; ${2*n+3}). Tính độ dài AB.`,3*n,'Vectơ AB=(n; 2n; 2n), độ dài là căn của 9n².'),
   numeric(`Mẫu ghép nhóm gồm hai khoảng [0; 2), [2; 4) có tần số lần lượt ${n} và ${3*n}. Tính trung bình ước lượng của mẫu.`,2.5,'Trung điểm là 1 và 3. Trung bình có trọng số là (n+9n)/(4n)=2,5.'),
   numeric(`Một phòng khám có ${n*5}% người đến từ khu A. Tỉ lệ đặt hẹn ở A là 80%, ở khu còn lại là 20%. Biết người được chọn đã đặt hẹn, xác suất người đó thuộc khu A là bao nhiêu phần trăm? Làm tròn đến hàng đơn vị và nhập số.`,Math.round(400*n/(20+3*n)),`Bayes cho P(A|hẹn)=4×${n}/(20+3×${n}). Đổi ra phần trăm rồi làm tròn.`),
   numeric(`Mặt phẳng 2x−2y+z−${3*n}=0. Tính khoảng cách từ O đến mặt phẳng.`,n,`Tử số là ${3*n}, mẫu số là √(4+4+1)=3.`)
  ];
  return levels.apply(questions,version).map((q,i)=>{
   if(!q.options)return q;
   const shift=(i*3+n)%4;
   return {...q,options:[...q.options.slice(shift),...q.options.slice(0,shift)]};
  });
 }
 function number(value){
  const input=String(value??'').trim().replace(',','.').replace(/−/g,'-');
  if(/^[+-]?(?:\d+(?:\.\d+)?|\.\d+)$/.test(input))return Number(input);
  const fraction=input.match(/^([+-]?\d+)\s*\/\s*([+-]?\d+)$/);
  if(fraction&&Number(fraction[2]))return Number(fraction[1])/Number(fraction[2]);
  return NaN;
 }
 function grade(questions,answers){
  return questions.map((q,i)=>{
   const a=answers[i];
   if(q.part===0)return a===q.answer?25:0;
   if(q.part===1)return points[q.statements.filter(([,right],j)=>a?.[j]===String(right)).length];
   return Math.abs(number(a)-q.answer)<1e-9?50:0;
  });
 }
 function load(){
  try{
   const saved=JSON.parse(localStorage.getItem(key));
   if(saved&&versions.includes(saved.version)&&Array.isArray(saved.answers)&&Number.isFinite(saved.deadline)&&Number.isInteger(saved.index)&&saved.index>=0&&saved.index<22)attempt=saved;
  }catch{storageError=true;}
 }
 function save(){
  try{localStorage.setItem(key,JSON.stringify(attempt));storageError=false;}catch{storageError=true;}
 }
 const full=(q,a)=>q.part===1?q.statements.every((_,i)=>a?.[i]==='true'||a?.[i]==='false'):String(a??'').trim()!=='';
 function detach(){clearInterval(timer);host=null;}
 function frame(html){
  host.innerHTML=`<div class="mock"><a class="text-link" href="#luyen-de">← Luyện đề</a>${storageError?'<p role="alert" class="form-error">Trình duyệt chưa lưu được đề đang làm.</p>':''}${html}</div>`;
  return host.lastElementChild;
 }
 function room(){
  const root=frame(`<header class="page-title"><h1>Thi thử Toán tốt nghiệp THPT</h1><p>90 phút · 22 câu · Thang điểm 10</p></header><section class="panel"><h2>Chọn đề mô phỏng</h2><ol><li>12 câu chọn một đáp án</li><li>4 câu đúng/sai, mỗi câu có 4 ý</li><li>6 câu trả lời ngắn</li></ol><p>Đề tự biên soạn, tập trung vào lớp 12. Chọn mức phù hợp. Mỗi mức có ba mã đề với số liệu khác nhau.</p><p>Đồng hồ tiếp tục chạy khi em rời trang. Sau khi nộp, em có thể xem điểm từng phần và lời giải.</p><div class="actions">${attempt?`<button class="button primary" id="resume">${attempt.finished?'Xem kết quả':'Tiếp tục làm'} đề ${attempt.version}</button>`:''}</div><div class="exam-levels">${levels.bands.map((band,index)=>`<div class="exam-level"><h3>${band}</h3><p>${['Công thức và dạng bài nền tảng','Bài toán nhiều bước và ứng dụng','Câu hỏi có tham số và yêu cầu suy luận'][index]}</p><div class="actions">${versions.filter(v=>bandFor(v)===index).map(v=>`<button class="button secondary" data-version="${v}" aria-label="Bắt đầu đề ${v}">Đề ${v}</button>`).join('')}</div></div>`).join('')}</div></section>`);
  root.querySelector('#resume')?.addEventListener('click',showAttempt);
  root.querySelectorAll('[data-version]').forEach(button=>button.addEventListener('click',()=>{
   if(attempt&&!confirm('Bắt đầu đề mới sẽ thay thế lượt thi đang lưu. Em có muốn tiếp tục?'))return;
   attempt={version:button.dataset.version,answers:[],index:0,deadline:Date.now()+90*60*1000,finished:false};
   save();showAttempt();
  }));
 }
 function finish(){
  if(attempt.finished)return;
  attempt.finished=true;save();result();
 }
 function showAttempt(){
  clearInterval(timer);
  if(attempt.finished){result();return;}
  if(Date.now()>=attempt.deadline){finish();return;}
  const questions=make(attempt.version);
  const i=attempt.index, q=questions[i], a=attempt.answers[i];
  const controls=q.part===0?q.options.map(option=>`<label class="mock-choice"><input type="radio" name="mock-option" value="${escape(option)}" ${a===option?'checked':''}> <span>${escape(option)}</span></label>`).join(''):
   q.part===1?q.statements.map(([statement],j)=>`<fieldset class="mock-statement"><legend>${'abcd'[j]}) ${escape(statement)}</legend>${['true','false'].map((value,k)=>`<label><input type="radio" name="mock-statement-${j}" data-statement="${j}" value="${value}" ${a?.[j]===value?'checked':''}> ${k?'Sai':'Đúng'}</label>`).join('')}</fieldset>`).join(''):
   `<label for="mock-number">Đáp án số</label><input class="answer-input mock-number" id="mock-number" type="text" inputmode="decimal" value="${escape(a)}" autocomplete="off" maxlength="32"><p class="mock-help">Dùng dấu phẩy hoặc dấu chấm cho số thập phân.</p>`;
  const root=frame(`<header class="page-title mock-title"><div><h1>Đề mô phỏng ${attempt.version}</h1><p id="mock-progress"></p></div><strong id="mock-timer" aria-label="Thời gian còn lại"></strong></header><div class="mock-layout"><section class="panel" aria-labelledby="mock-prompt"><p class="tag">${parts[q.part]} · Câu ${questions.slice(0,i+1).filter(x=>x.part===q.part).length}</p><h2 id="mock-prompt" tabindex="-1">${escape(q.prompt)}</h2><div class="mock-options">${controls}</div><div class="actions"><button class="button secondary" id="mock-prev" ${i===0?'disabled':''}>← Câu trước</button><button class="button secondary" id="mock-next" ${i===questions.length-1?'disabled':''}>Câu sau →</button></div></section><aside class="panel mock-nav" aria-label="Đi đến câu hỏi">${parts.map((label,p)=>`<p>${label}</p><div class="mock-grid">${questions.map((question,j)=>question.part===p?`<button type="button" data-jump="${j}" ${j===i?'aria-current="step"':''}>${questions.slice(0,j+1).filter(x=>x.part===p).length}</button>`:'').join('')}</div>`).join('')}<button class="button primary" id="mock-submit">Nộp bài</button></aside></div>`);
  function mark(){
   root.querySelector('#mock-progress').textContent=`Đã trả lời đủ ${questions.filter((item,j)=>full(item,attempt.answers[j])).length}/${questions.length} câu`;
   root.querySelectorAll('[data-jump]').forEach(button=>{
    const j=Number(button.dataset.jump), item=questions[j], done=full(item,attempt.answers[j]);
    const within=questions.slice(0,j+1).filter(x=>x.part===item.part).length;
    button.classList.toggle('answered',done);
    button.setAttribute('aria-label',`${parts[item.part]}, câu ${within}, ${done?'đã trả lời':'chưa trả lời đủ'}`);
   });
  }
  root.querySelector('.mock-options').addEventListener('input',event=>{
   const field=event.target;
   if(q.part===1){
    if(!Array.isArray(attempt.answers[i]))attempt.answers[i]=[];
    attempt.answers[i][Number(field.dataset.statement)]=field.value;
   }else attempt.answers[i]=field.value;
   save();mark();
  });
  function jump(j){attempt.index=j;save();showAttempt();host.querySelector('#mock-prompt')?.focus();}
  root.querySelectorAll('[data-jump]').forEach(button=>button.addEventListener('click',()=>jump(Number(button.dataset.jump))));
  root.querySelector('#mock-prev').addEventListener('click',()=>jump(i-1));
  root.querySelector('#mock-next').addEventListener('click',()=>jump(i+1));
  root.querySelector('#mock-submit').addEventListener('click',()=>{
   const missing=questions.filter((item,j)=>!full(item,attempt.answers[j])).length;
   if(confirm(missing?`Còn ${missing} câu chưa trả lời đủ. Em muốn nộp bài?`:'Em muốn nộp bài và xem kết quả?'))finish();
  });
  function tick(){
   const seconds=Math.max(0,Math.ceil((attempt.deadline-Date.now())/1000));
   root.querySelector('#mock-timer').textContent=Math.floor(seconds/60)+':'+String(seconds%60).padStart(2,'0');
   if(!seconds)finish();
  }
  mark();timer=setInterval(tick,250);tick();
 }
 function result(){
  clearInterval(timer);
  const questions=make(attempt.version),scores=grade(questions,attempt.answers);
  const total=scores.reduce((sum,p)=>sum+p,0);
  const root=frame(`<header class="page-title"><h1>Kết quả đề ${attempt.version}</h1><p>Điểm toàn bài · <strong id="mock-score">${format(total/100)}/10</strong></p></header><div class="stats">${parts.map((name,p)=>`<div class="stat"><strong>${format(scores.reduce((sum,score,j)=>sum+(questions[j].part===p?score:0),0)/100)}/${[3,4,3][p]}</strong><span>${name}</span></div>`).join('')}</div><section class="panel"><h2>Đáp án và lời giải</h2>${questions.map((q,i)=>`<details class="mock-review"><summary>${parts[q.part]} · Câu ${questions.slice(0,i+1).filter(x=>x.part===q.part).length} · ${format(scores[i]/100)} điểm</summary><p><strong>${escape(q.prompt)}</strong></p>${q.part===1?q.statements.map(([statement,correct,solution],j)=>`<p>${'abcd'[j]}) ${escape(statement)}<br>Em chọn: ${choice(attempt.answers[i]?.[j])} · Đáp án: <strong>${choice(String(correct))}</strong><br>${escape(solution)}</p>`).join(''):`<p>Em trả lời: ${escape(attempt.answers[i]||'Bỏ trống')} · Đáp án: <strong>${escape(q.part===2?format(q.answer):q.answer)}</strong></p><p>${escape(q.solution)}</p>`}</details>`).join('')}</section><button class="button secondary" id="mock-room">Về phòng thi</button>`);
  root.querySelector('#mock-room').addEventListener('click',room);
  root.querySelector('h1').setAttribute('tabindex','-1');root.querySelector('h1').focus();
 }
 const choice=value=>value==='true'?'Đúng':value==='false'?'Sai':'Bỏ trống';
 function render(target){host=target;room();}
 if(typeof localStorage!=='undefined')load();
 return {render,detach,make,grade,versions};
})();
if(typeof module!=='undefined')module.exports=mockExam;
