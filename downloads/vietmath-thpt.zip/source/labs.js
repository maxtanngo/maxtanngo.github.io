const mathLabs=(()=>{
 const configs={
  quadratic10:{name:'Dịch chuyển đỉnh parabol',symbol:'h',min:-3,max:3,value:1,fn:(x,k)=>(x-k)**2-2,
   note:k=>'y = (x − h)² − 2. Đỉnh ('+k+'; −2), trục đối xứng x = '+k+'.'},
  exp11:{name:'Thay đổi cơ số hàm mũ',symbol:'a',min:.5,max:3,step:.1,value:2,fn:(x,k)=>k**x,
   note:k=>'y = aˣ với a = '+k.toLocaleString('vi-VN')+'. Đồ thị đi qua (0; 1) và '+(k===1?'nằm ngang khi a = 1.':k<1?'nghịch biến.':'đồng biến.')},
  derivative11:{name:'Tìm hệ số góc tiếp tuyến',symbol:'x₀',min:-2,max:2,step:.25,value:1,fn:x=>x*x,
   tangent:(x,k)=>2*k*(x-k)+k*k,note:k=>'y = x². Tại x₀ = '+k+', tiếp tuyến có hệ số góc '+2*k+'.'},
  variation12:{name:'Đọc khoảng đồng biến và nghịch biến',symbol:'a',min:1,max:4,step:1,value:2,fn:(x,k)=>(x**3-3*k*k*x)/12,
   note:k=>'y = (x³ − 3a²x)/12. Hàm giảm giữa −'+k+' và '+k+', tăng ở hai khoảng ngoài.'}
 };
 function markup(id){
  const t=configs[id];
  return t?`<section class="panel"><h2>${t.name}</h2><label for="lab-parameter">Kéo để đổi ${t.symbol}</label><input id="lab-parameter" type="range" min="${t.min}" max="${t.max}" step="${t.step||1}" value="${t.value}"><p id="lab-note" aria-live="polite"></p><canvas id="lab-canvas" width="600" height="250" aria-hidden="true"></canvas></section>`:'';
 }
 function bind(id){
  const t=configs[id], slider=document.getElementById('lab-parameter');
  if(!t||!slider)return;
  const canvas=document.getElementById('lab-canvas'),ctx=canvas.getContext('2d'),note=document.getElementById('lab-note');
  function draw(){
   const k=Number(slider.value), scale=29;
   note.textContent=t.note(k);
   ctx.clearRect(0,0,600,250);
   ctx.save();
   ctx.translate(300,125);
   for(let i=-10;i<=10;i++){
    const v=i*scale;
    ctx.strokeStyle=i===0?'#766b8f':'#e5dfef';
    ctx.beginPath();ctx.moveTo(v,-125);ctx.lineTo(v,125);
    ctx.moveTo(-300,v);ctx.lineTo(300,v);ctx.stroke();
   }
   for(const [fn,color] of [[t.fn,'#6544ae'],[t.tangent,'#a13e28']]){
    if(!fn)continue;
    ctx.strokeStyle=color;ctx.lineWidth=3;ctx.beginPath();
    for(let px=-300;px<=300;px++){
     const y=-scale*fn(px/scale,k);
     if(px===-300)ctx.moveTo(px,y);else ctx.lineTo(px,y);
    }
    ctx.stroke();
   }
   ctx.restore();
  }
  slider.addEventListener('input',draw);draw();
 }
 return {byGrade:{10:'quadratic10',11:'exp11',12:'variation12'},markup,bind};
})();
