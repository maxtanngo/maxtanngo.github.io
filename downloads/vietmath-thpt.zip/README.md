# VietMath THPT · MaxNgo

Giải nén và mở VietMath-THPT-MaxNgo.html bằng trình duyệt. Có thể mở tệp HTML trực tiếp, không cần cài đặt hoặc kết nối mạng. Mục nguồn tham khảo và liên kết website cần Internet.

- Lớp 10, 11, 12 có bài theo chủ đề, gợi ý, lời giải, đồ thị tương tác và mục ôn câu sai.
- Chọn **Luyện đề → Mở phòng thi** để làm đề Toán tốt nghiệp THPT mô phỏng 90 phút. Chín mã đề chia ba mức Cơ bản, Vận dụng và Nâng cao. Ba mã trong mỗi mức thay đổi số liệu theo khung bài của mức đó.
- Phần I 12 câu (3 điểm), phần II 4 câu với 4 ý mỗi câu (4 điểm), phần III 6 câu (3 điểm). Mỗi câu phần II có 0, 1, 2, 3, 4 ý đúng nhận tương ứng 0, 0,10, 0,25, 0,50, 1 điểm.
- Tiến độ bài học và lượt thi thử gần nhất lưu trên trình duyệt nếu bộ nhớ trình duyệt được cho phép. Đề thi tiếp tục tính giờ khi rời trang. Bắt đầu đề mới thay thế lượt thi gần nhất.
- Bản này có các chủ đề trọng tâm và đề mô phỏng tự biên soạn. Đường dẫn tới tài liệu và đề tham khảo của Bộ GDĐT nằm trong mục **Nguồn nội dung**.
- Thư mục source có bản chia tệp để chỉnh sửa hoặc phục vụ bằng web tĩnh.
