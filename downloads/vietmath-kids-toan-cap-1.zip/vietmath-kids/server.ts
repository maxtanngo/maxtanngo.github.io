import { solvePrimaryMathProblem } from './src/utils/tutorSolution.js';
import { appendFile, mkdir } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { generateWithFallback, modelList } from './src/services/geminiFallback.js';
import { generateDynamicQuestions } from './src/utils/questionBanks/dynamicAiGenerator.js';
import { validateQuestions } from './src/utils/validateQuestions.js';
import express, { Request, Response } from 'express';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { extractMathExpression, solveMathExpression } from './src/utils/mathExpressionSolver.js';

dotenv.config();
dotenv.config({ path: '.env.local' });

const textModels = modelList(process.env.GEMINI_TEXT_MODELS, ['gemini-3.8-flash', 'gemini-3.1-flash-lite', 'gemini-flash-latest']);
const ttsModels = modelList(process.env.GEMINI_TTS_MODELS, ['gemini-2.5-flash-preview-tts', 'gemini-3.8-flash-tts']);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '48kb' }));
const requestWindows = new Map<string, { expires: number; count: number }>();
app.use('/api', (req, res, next) => {
  if (req.method !== 'POST') return next();
  const now = Date.now();
  const key = req.ip || 'local';
  let window = requestWindows.get(key);
  if (!window || window.expires <= now) {
    for (const [ip, entry] of requestWindows) if (entry.expires <= now) requestWindows.delete(ip);
    if (requestWindows.size >= 10000) return res.status(503).json({ error: 'Máy chủ đang bận, vui lòng thử lại.' });
    window = { expires: now + 60000, count: 0 };
    requestWindows.set(key, window);
  }
  if (++window.count > 40) {
    res.setHeader('Retry-After', String(Math.ceil((window.expires - now) / 1000)));
    return res.status(429).json({ error: 'Quá nhiều yêu cầu, vui lòng thử lại sau.' });
  }
  next();
});

// Initialize server-side Gemini client
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

// Route 1: Health check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    hasApiKey: !!apiKey,
    model: textModels[0],
  });
});

// Route: Receive, log and persist user feedback for MaxNgo (tannt4@gmail.com)
interface FeedbackItem {
  id: string;
  fullName: string;
  contactInfo: string;
  topicType: string;
  message: string;
  grade?: number;
  timestamp: string;
}

const feedbackFile = path.resolve(process.env.FEEDBACK_FILE || path.join(__dirname, 'private-data', 'feedback.jsonl'));
for (const folder of ['public', 'dist']) {
  const relative = path.relative(path.join(__dirname, folder), feedbackFile);
  if (!relative || (!relative.startsWith('..' + path.sep) && relative !== '..' && !path.isAbsolute(relative))) {
    throw new Error('FEEDBACK_FILE phải nằm ngoài public và dist.');
  }
}

app.post('/api/feedback', async (req: Request, res: Response) => {
  const { fullName, contactInfo, topicType, message, grade } = req.body ?? {};
  if (typeof message !== 'string' || !message.trim() || message.length > 4000) {
    return res.status(400).json({ error: 'Nhập nội dung góp ý từ 1 đến 4.000 ký tự.' });
  }
  const clean = (value: unknown, limit: number) => typeof value === 'string' ? value.trim().slice(0, limit) : '';
  const item: FeedbackItem = {
    id: randomUUID(), fullName: clean(fullName, 100), contactInfo: clean(contactInfo, 200),
    topicType: clean(topicType, 100) || 'Góp ý', message: message.trim(),
    grade: Number.isInteger(grade) && grade >= 1 && grade <= 5 ? grade : undefined,
    timestamp: new Date().toISOString(),
  };
  try {
    await mkdir(path.dirname(feedbackFile), { recursive: true, mode: 0o700 });
    await appendFile(feedbackFile, JSON.stringify(item) + '\n', { encoding: 'utf8', mode: 0o600 });
    return res.json({ success: true, message: 'Góp ý đã được lưu trên máy chủ.', feedbackId: item.id });
  } catch {
    console.error('Không thể lưu góp ý vào kho dữ liệu máy chủ.');
    return res.status(500).json({ error: 'Không thể lưu góp ý lúc này.' });
  }
});

// Route: Gemini Native TTS Audio Generation
interface ServerVoiceConfig {
  geminiVoiceName: 'Kore' | 'Aoede' | 'Charon' | 'Puck' | 'Fenrir' | 'Zephyr';
  stylePrompt: string;
}

const SERVER_VOICE_CONFIGS: Record<string, ServerVoiceConfig> = {
  'co-hoai-my-bac': {
    geminiVoiceName: 'Kore',
    stylePrompt: 'Đọc bằng giọng cô giáo tiểu học miền Bắc Việt Nam thật dịu dàng, ấm áp, phát âm chuẩn, ngắt nghỉ tự nhiên và giàu cảm xúc yêu thương trẻ nhỏ',
  },
  'co-lan-nhi-nam': {
    geminiVoiceName: 'Aoede',
    stylePrompt: 'Đọc bằng giọng cô giáo miền Nam (Sài Gòn) ngọt ngào, tươi vui, thân thiện, gần gũi và khích lệ học sinh tiểu học',
  },
  'thay-nam-minh-bac': {
    geminiVoiceName: 'Charon',
    stylePrompt: 'Đọc bằng giọng thầy giáo miền Bắc trầm ấm, đĩnh đạc, rõ ràng từng con số, truyền cảm hứng học toán',
  },
  'thay-minh-quang-nam': {
    geminiVoiceName: 'Puck',
    stylePrompt: 'Đọc bằng giọng thầy giáo trẻ miền Nam sôi nổi, hào hứng, tràn đầy năng lượng tích cực như người dẫn chương trình thiếu nhi',
  },
  'cu-meo-thong-thai': {
    geminiVoiceName: 'Fenrir',
    stylePrompt: 'Đọc với ngữ điệu nhân vật hoạt hình đáng yêu, hóm hỉnh, nhấn nhá sinh động như đang kể chuyện cổ tích cho bé',
  },
  'fpt-custom': {
    geminiVoiceName: 'Kore',
    stylePrompt: 'Đọc bằng giọng phát thanh viên chuẩn giáo dục, phát âm tròn vành rõ chữ, ngữ điệu truyền cảm, ân cần',
  },
};

// Server-side Audio Cache & Quota Circuit Breaker
const serverTtsCache = new Map<string, string>();
let ttsQuotaExceededUntil = 0;

function wavAudio(base64: string, mimeType = ''): string {
  const pcm = Buffer.from(base64, 'base64');
  if (pcm.toString('ascii', 0, 4) === 'RIFF') return base64;
  if (!/audio\/(?:l16|pcm)/i.test(mimeType) || !pcm.length || pcm.length % 2) return '';
  const rate = Number(mimeType.match(/rate=(\d+)/i)?.[1] || 24000);
  const header = Buffer.alloc(44);
  header.write('RIFF', 0);
  header.writeUInt32LE(36 + pcm.length, 4);
  header.write('WAVEfmt ', 8);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(1, 22);
  header.writeUInt32LE(rate, 24);
  header.writeUInt32LE(rate * 2, 28);
  header.writeUInt16LE(2, 32);
  header.writeUInt16LE(16, 34);
  header.write('data', 36);
  header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]).toString('base64');
}

app.post('/api/tts/generate', async (req: Request, res: Response) => {
  try {
    const { text, voiceId = 'co-hoai-my-bac' } = req.body ?? {};

    if (!text || typeof text !== 'string' || text.trim() === '' || text.length > 2000) {
      return res.status(400).json({ error: 'Nội dung đọc không được để trống' });
    }

    const sanitizedText = text
      .trim()
      .replace(/\s*:\s*/g, '. ')
      .replace(/:+/g, '. ');
    const cacheKey = `v3_${voiceId}::${sanitizedText}`;

    // 1. Serve immediately from Server Audio Cache if available
    if (serverTtsCache.has(cacheKey)) {
      return res.json({
        success: true,
        audioBase64: serverTtsCache.get(cacheKey),
        mimeType: 'audio/wav',
        voiceId,
        cached: true,
      });
    }

    // 2. Circuit breaker check: If quota recently exceeded, immediately fallback to Web Speech
    if (Date.now() < ttsQuotaExceededUntil) {
      return res.json({
        success: false,
        fallback: true,
        message: 'Hạn mức TTS tạm thời bảo vệ quota, kích hoạt Web Speech API tức thì.',
      });
    }

    if (!ai) {
      return res.json({
        success: false,
        fallback: true,
        message: 'Chưa cấu hình GEMINI_API_KEY trên server. Kích hoạt Web Speech API.',
      });
    }

    const voiceConfig = Object.hasOwn(SERVER_VOICE_CONFIGS, voiceId) ? SERVER_VOICE_CONFIGS[voiceId] : SERVER_VOICE_CONFIGS['co-hoai-my-bac'];

    try {
      const { response, model } = await generateWithFallback(ai, ttsModels, {
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: voiceConfig.stylePrompt + '\n\n' + sanitizedText,
              },
            ],
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: voiceConfig.geminiVoiceName },
            },
          },
        },
      }, 20000);

      const audioPart = response.candidates?.[0]?.content?.parts?.find(part => part.inlineData?.data)?.inlineData;
      const base64Audio = audioPart?.data && wavAudio(audioPart.data, audioPart.mimeType);
      if (base64Audio) {
        if (serverTtsCache.size < 1000) {
          serverTtsCache.set(cacheKey, base64Audio);
        }
        return res.json({
          success: true,
          audioBase64: base64Audio,
          mimeType: 'audio/wav',
          voiceId,
          model,
        });
      }
    } catch (err: any) {
      console.warn('[TTS Fallback]', err?.status || '', err?.message || err);
      const errMsg = String(err?.message || err).toLowerCase();

      // Trip circuit breaker on rate limit, quota exhaustion or temporary server issues
      if (errMsg.includes('429') || errMsg.includes('quota') || errMsg.includes('resource_exhausted')) {
        ttsQuotaExceededUntil = Date.now() + 10 * 60 * 1000;
      } else if (errMsg.includes('500') || errMsg.includes('internal') || errMsg.includes('unavailable')) {
        // Cooldown for 2 minutes on remote service internal errors
        ttsQuotaExceededUntil = Date.now() + 2 * 60 * 1000;
      }

      // Gracefully switch to browser Web Speech API
      return res.json({
        success: false,
        fallback: true,
        message: 'Kích hoạt giọng đọc Web Speech dự phòng mượt mà.',
      });
    }

    return res.json({
      success: false,
      fallback: true,
      message: 'Kích hoạt giọng đọc Web Speech dự phòng.',
    });
  } catch (err: any) {
    return res.json({
      success: false,
      fallback: true,
      error: 'Lỗi sinh âm thanh, kích hoạt Web Speech API.',
    });
  }
});

// Route 2: Generate exam using Gemini AI (Thông tư 27) with FAST thinking & reliable fallback
app.post('/api/ai/generate-exam', async (req: Request, res: Response) => {
  const { grade = 3, topic = 'Tổng hợp', level = 'basic', examType = 'Đề 15 phút', textbook = 'Kết nối tri thức' } = req.body ?? {};
  if (!Number.isInteger(grade) || grade < 1 || grade > 5 || !['basic', 'advanced'].includes(level) ||
      [topic, examType, textbook].some(value => typeof value !== 'string' || !value.trim() || value.length > 180)) {
    return res.status(400).json({ error: 'Lớp hoặc tùy chọn tạo đề không hợp lệ.' });
  }
  const fallbackQuestions = () => generateDynamicQuestions(grade, topic, 5, level);

  if (!ai) {
    // Instantly return high quality procedural questions if AI not initialized
    return res.json({
      success: true,
      grade,
      topic,
      examType,
      textbook,
      questions: fallbackQuestions(),
      fallback: true,
    });
  }

  try {
    const prompt = `Bạn là chuyên gia ra đề thi Toán Tiểu học Việt Nam theo chuẩn Chương trình GDPT 2018 và Thông tư 27 của Bộ GD&ĐT.
Hãy tạo một bộ đề kiểm tra cho học sinh:
- Khối lớp: Lớp ${grade}
- Bộ sách: ${textbook}
- Loại đề: ${examType}
- Chủ đề: ${topic}
- Mức độ: ${level === 'advanced' ? 'Nâng cao (chú trọng Mức 3 Vận dụng & tư duy logic)' : 'Cơ bản (Cân đối Mức 1 Nhận biết và Mức 2 Kết nối)'}

Yêu cầu cấu trúc đề thi gồm 5 câu hỏi chuẩn:
- Câu 1: Mức 1 (Nhận biết - kiểm tra khái niệm hoặc phép tính cơ bản)
- Câu 2: Mức 1 (Nhận biết hoặc tính nhanh)
- Câu 3: Mức 2 (Kết nối/Thông hiểu - đổi đơn vị, hình học hoặc tính 2 bước)
- Câu 4: Mức 2 (Giải toán có lời văn 1-2 bước)
- Câu 5: Mức 3 (Vận dụng / Tư duy nâng cao theo lứa tuổi Lớp ${grade})

Định dạng trả về BẮT BUỘC là một JSON array thuần túy (không markdown, không bọc \`\`\`json) có cấu trúc sau:
[
  {
    "id": "q1",
    "question": "Nội dung câu hỏi ngắn gọn, trong sáng, phù hợp với học sinh Lớp ${grade}?",
    "type": "multiple_choice" hoặc "number_input",
    "options": ["Đáp án A", "Đáp án B", "Đáp án C", "Đáp án D"],
    "correctAnswer": "Đáp án đúng (chuỗi nếu là trắc nghiệm, hoặc số dạng chuỗi nếu là number_input)",
    "hint": "Gợi ý tư duy ngắn gọn, ân cần giúp bé tự làm",
    "explanation": "Lời giải chi tiết, rõ ràng từng bước",
    "level": "Mức 1" hoặc "Mức 2" hoặc "Mức 3",
    "strand": "Số & Phép tính" hoặc "Hình học & Đo lường" hoặc "Giải toán có lời văn"
  }
]`;

    const { response, model } = await generateWithFallback(ai, textModels, {
      contents: prompt, config: { responseMimeType: 'application/json' },
    }, 7000);
    const responseText = response.text || '[]';
    let questions;
    try {
      questions = JSON.parse(responseText);
    } catch {
      const cleaned = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
      questions = JSON.parse(cleaned);
    }

    questions = validateQuestions(questions);
    if (questions.length < 5) throw new Error('Đề Gemini chưa có đủ câu hỏi hợp lệ.');

    return res.json({
      success: true,
      grade,
      topic,
      examType,
      textbook,
      questions,
      model,
    });
  } catch (error: any) {
    console.warn('[AI Exam Notice] Using immediate procedural fallback due to:', error?.message || error);
    // Never fail with 500: return rich procedural questions immediately
    return res.json({
      success: true,
      grade,
      topic,
      examType,
      textbook,
      questions: fallbackQuestions(),
      fallback: true,
    });
  }
});

// Smart Procedural Math Solver Fallback for Primary School
app.post('/api/ai/tutor-chat', async (req: Request, res: Response) => {
  const { message, history = [], grade = 3, mode = 'solution', currentProblem = '' } = req.body ?? {};

  if (!message || typeof message !== 'string' || message.trim() === '' || message.length > 2500 || !Array.isArray(history) || history.length > 60 || typeof currentProblem !== 'string' || currentProblem.length > 2500) {
    return res.status(400).json({ error: 'Nội dung tin nhắn không hợp lệ' });
  }

  const cleanMessage = message.trim();
  const studentGrade = Math.max(1, Math.min(5, Number(grade) || 3));

  const localProblem = extractMathExpression(cleanMessage) || /^(?:tìm x(?: biết)?\s*:?\s*)?x\s*[-+×*:÷/]/i.test(cleanMessage)
    || /^[\d(\s.,+*/÷×:−-]+[=?]?\s*$/.test(cleanMessage);
  if (!ai || localProblem) {
    return res.json({
      success: true,
      reply: solvePrimaryMathProblem(cleanMessage, studentGrade, mode),
      mode,
      fallback: true,
    });
  }

  try {
    const mathGroundTruth = (() => {
      const expr = extractMathExpression(cleanMessage);
      if (expr) {
        return solveMathExpression(expr);
      }
      return null;
    })();

    const systemInstruction = `Bạn là "Thầy Cú Mèo Thông Thái" (VietMath Owl) - Gia sư Toán Tiểu học AI chuyên nghiệp, tâm lý, ân cần và giàu phương pháp sư phạm dành riêng cho học sinh Lớp ${studentGrade} ở Việt Nam theo chuẩn GDPT 2018 và Thông tư 27.

NHIỆM VỤ CỐT LÕI: GIẢI ĐÁP TOÀN DIỆN, RÕ RÀNG, CHÍNH XÁC VÀ DỄ HIỂU MỌI CÂU HỎI TOÁN HỌC CỦA HỌC SINH VÀ PHỤ HUYNH.

QUY TẮC XƯNG HÔ: Luôn xưng "Thầy Cú Mèo" (hoặc "Thầy") và gọi học sinh là "con" trìu mến.

QUY TẮC BẮT BUỘC VỀ THỨ TỰ THỰC HIỆN PHÉP TÍNH (CHUẨN BỘ GIÁO DỤC GDPT 2018):
- Đối với biểu thức toán học có nhiều phép tính hoặc nhiều chữ số:
  1. "Trong ngoặc trước, ngoài ngoặc sau" (nếu có dấu ngoặc).
  2. "NHÂN CHIA TRƯỚC, CỘNG TRỪ SAU": Khi biểu thức chứa đồng thời phép nhân/chia và phép cộng/trừ, BẮT BUỘC thực hiện phép nhân/chia trước, sau đó mới thực hiện phép cộng/trừ!
     • Ví dụ 1: 2 + 2 × 2 = ? -> Bước 1: 2 × 2 = 4 -> Bước 2: 2 + 4 = 6. ĐÁP SỐ CHÍNH XÁC LÀ 6 (Tuyệt đối KHÔNG tính 2 + 2 = 4 rồi 4 × 2 = 8).
     • Ví dụ 2: 2 × 2 + 2 = ? -> Bước 1: 2 × 2 = 4 -> Bước 2: 4 + 2 = 6. ĐÁP SỐ CHÍNH XÁC LÀ 6.
     • Ví dụ 3: 10 - 2 × 3 + 4 = ? -> Bước 1: 2 × 3 = 6 -> Bước 2: 10 - 6 + 4 = 4 + 4 = 8.
  3. Nếu biểu thức chỉ có phép cộng, trừ hoặc chỉ có nhân, chia thì thực hiện lần lượt từ trái sang phải.

CHẾ ĐỘ GIẢI BÀI HIỆN TẠI: "${mode}" (${
      mode === 'hint'
        ? 'Gợi ý phương pháp để con tự tư duy, chưa đưa ngay đáp số'
        : mode === 'check'
        ? 'Chấm bài, kiểm tra bài làm của con, chỉ ra chỗ đúng/chỗ sai và hướng dẫn sửa'
        : mode === 'practice'
        ? 'Tạo một bài tập tương tự cùng dạng kèm lời giải mẫu để con tự luyện tập'
        : 'GIẢI CHI TIẾT TỪNG BƯỚC: Hướng dẫn đầy đủ từ tóm tắt, công thức, các bước tính đến ĐÁP SỐ CHÍNH XÁC'
    }).

CẤU TRÚC TRÌNH BÀY BÀI GIẢI CHUẨN MỰC VỞ TIỂU HỌC:
1. LỜI CHÀO & KHEN NGỢI: Khen ngợi tinh thần học hỏi của con ("Câu hỏi này rất hay!", "Thầy cùng con giải bài toán này nhé!").
2. 📌 TÓM TẮT ĐỀ BÀI:
   - Bài toán cho biết gì?
   - Bài toán hỏi gì?
3. 📖 PHƯƠNG PHÁP & CÔNG THỨC: Nêu rõ quy tắc toán học tiểu học ("Nhân chia trước, cộng trừ sau" hoặc công thức hình học).
4. 📐 CÁC BƯỚC GIẢI CHI TIẾT (Trình bày chuẩn vở bài tập tiểu học):
   - Lời giải bước 1: Phép tính = Kết quả
   - Lời giải bước 2 (nếu có): Phép tính = Kết quả
   - 🎯 ĐÁP SỐ: Kết quả cuối cùng rõ ràng.
5. 💡 MẸO TƯ DUY TỪ THẦY CÚ MÈO: Một lưu ý ngắn gọn giúp con không bao giờ bị nhầm lẫn ở dạng toán này.

LƯU Ý QUAN TRỌNG:
- Trả lời bằng tiếng Việt trong sáng, sư phạm, giàu năng lượng tích cực, dùng biểu tượng sinh động (🦉, ⭐, ✏️, 📐, 🎯).
- Phù hợp với đúng lứa tuổi Lớp ${studentGrade}.
- Tránh dùng dấu hai chấm ':' liên tục bừa bãi để hệ thống phát âm (TTS) đọc trôi chảy không bị ngắt quãng.
${currentProblem ? `Học sinh đang học bài: "${currentProblem}".` : ''}`;

    const formattedContents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

    // Include last 6 message history items for context
    const recentHistory = Array.isArray(history) ? history.slice(-6) : [];
    for (const h of recentHistory) {
      if (h.text && typeof h.text === 'string') {
        formattedContents.push({
          role: h.role === 'model' ? 'model' : 'user',
          parts: [{ text: h.text }],
        });
      }
    }

    let userPromptText = `[Chế độ: ${mode}] Học sinh Lớp ${studentGrade} hỏi: "${cleanMessage}".`;
    if (mathGroundTruth) {
      userPromptText += `\n[Dữ liệu tính toán chuẩn xác GDPT 2018]: Biểu thức = ${mathGroundTruth.cleanExpression}, Quy tắc = ${mathGroundTruth.rulesApplied.join(', ')}, Các bước = ${mathGroundTruth.steps.map(s => s.description).join('; ')}, Kết quả chính xác = ${mathGroundTruth.formattedResult}. Con cần Thầy Cú Mèo giải thích thật ân cần, chuẩn mực, nhấn mạnh quy tắc thứ tự phép tính!`;
    } else {
      userPromptText += ` Hãy giải đáp thật tận tình, chuẩn xác và dễ hiểu nhất cho con!`;
    }

    formattedContents.push({
      role: 'user',
      parts: [
        {
          text: userPromptText,
        },
      ],
    });

    const { response } = await generateWithFallback(ai, textModels, {
      contents: formattedContents,
      config: { systemInstruction },
    }, 6800);

    const reply = response.text || solvePrimaryMathProblem(cleanMessage, studentGrade, mode);

    return res.json({
      success: true,
      reply,
      mode,
    });
  } catch (error: any) {
    console.warn('[AI Tutor Notice] Using smart procedural solver fallback:', error?.message || error);
    // Never fail with 500 error: always provide a warm, accurate, complete answer
    return res.json({
      success: true,
      reply: solvePrimaryMathProblem(cleanMessage, studentGrade, mode),
      mode,
      fallback: true,
    });
  }
});

// Setup Vite middlewares in development or serve static in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        fs: { deny: ['.env', '.env.*', '*.{crt,pem}', '**/.git/**', '**/private-data/**', feedbackFile] },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get(/^\/(?!api(?:\/|$)).*/, (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  const host = process.env.HOST || '0.0.0.0';
  app.listen(PORT, host, () => {
    console.log(`VietMath Kids đang chạy tại http://${host === '0.0.0.0' ? 'localhost' : host}:${PORT}`);
  });
}

startServer();
