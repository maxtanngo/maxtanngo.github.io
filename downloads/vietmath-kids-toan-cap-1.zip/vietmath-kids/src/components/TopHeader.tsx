import React from 'react';
import { Grade, Textbook, OwlSkin, StudentProfile } from '../types';
import { GRADE_THEMES } from '../data/curriculumData';
import { MaxNgoLogo } from './MaxNgoLogo';
import {
  Flame,
  Star,
  BookOpen,
  Volume2,
  User,
  Coffee,
  Calendar,
  Cloud,
} from 'lucide-react';
import { playClickSound, REGIONAL_VOICES } from '../utils/soundAndSpeech';

interface Props {
  currentGrade: Grade;
  onGradeChange: (grade: Grade) => void;
  currentTextbook: Textbook;
  onTextbookChange: (textbook: Textbook) => void;
  streak: number;
  stars: number;
  currentSkin: OwlSkin;
  studentProfile?: StudentProfile;
  currentVoiceId: string;
  onOpenVoiceModal: () => void;
  onOpenProfileModal: () => void;
  onOpenAuthorTab: () => void;
  onOpenDriveTab?: () => void;
}

export const TopHeader: React.FC<Props> = ({
  currentGrade,
  onGradeChange,
  currentTextbook,
  onTextbookChange,
  streak,
  stars,
  currentSkin,
  studentProfile,
  currentVoiceId,
  onOpenVoiceModal,
  onOpenProfileModal,
  onOpenAuthorTab,
  onOpenDriveTab,
}) => {
  const currentTheme = GRADE_THEMES[currentGrade];
  const activeVoice =
    REGIONAL_VOICES.find((v) => v.id === currentVoiceId) || REGIONAL_VOICES[0];

  const studentDisplayName = studentProfile?.name || 'Học sinh';
  const studentGenderEmoji = studentProfile?.gender === 'female' ? '👧' : '👦';
  
  // Concise voice label according to user specification: Cô (Nữ), Thầy (Nam), Cú Mèo
  const voiceCompactLabel =
    activeVoice.gender === 'female'
      ? 'Cô (Nữ)'
      : activeVoice.gender === 'male'
      ? 'Thầy (Nam)'
      : 'Cú Mèo';

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b-2 border-slate-200 px-2 sm:px-4 py-2 shadow-xs">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-2 sm:gap-2.5">
        {/* Brand Logo & Grade Switcher */}
        <div className="flex items-center justify-between w-full lg:w-auto gap-2 sm:gap-3 shrink-0">
          {/* Brand Squircle Logo: VietMath Kids */}
          <MaxNgoLogo size="md" showText={true} />

          <select aria-label="Chọn lớp" value={currentGrade}
            onChange={event => onGradeChange(Number(event.target.value) as Grade)}
            className="sm:hidden min-h-10 rounded-xl border border-slate-200 px-3 text-sm font-bold">
            {[1, 2, 3, 4, 5].map(grade => <option key={grade} value={grade}>Lớp {grade}</option>)}
          </select>

          {/* Grade selection pills (1, 2, 3, 4, 5) */}
          <div className="hidden sm:flex items-center gap-1 p-1 bg-slate-100 rounded-2xl shrink-0">
            {([1, 2, 3, 4, 5] as Grade[]).map((g) => {
              const isSelected = g === currentGrade;
              const gTheme = GRADE_THEMES[g];
              return (
                <button
                  key={g}
                  type="button"
                  onClick={() => {
                    playClickSound();
                    onGradeChange(g);
                  }}
                  className={`px-2 py-1 sm:px-2.5 sm:py-1 rounded-xl text-xs font-black transition-all ${
                    isSelected
                      ? `${gTheme.primaryBg} text-white shadow-sm scale-105`
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  Lớp {g}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Section: Student Profile (Guaranteed 100% full display), Voice (Compact), Textbook (Compact), Streak, Stars, Author */}
        <div className="flex items-center gap-1.5 sm:gap-2 w-full min-w-0 lg:w-auto lg:ml-auto justify-start flex-wrap py-1 px-1 scrollbar-none">
          {/* 1. Student Profile & Grade Chip (Prominent, zero clipping, fully visible) */}
          <button
            type="button"
            onClick={() => {
              playClickSound();
              onOpenProfileModal();
            }}
            title="Chạm để xem và chỉnh sửa Tên, Giới tính, Lớp học và Thời khóa biểu"
            className="inline-flex items-center gap-1.5 sm:gap-2 bg-gradient-to-r from-amber-50 via-yellow-50 to-amber-100 hover:from-amber-100 hover:to-yellow-100 border-2 border-amber-300 text-amber-950 px-3 py-1.5 rounded-2xl font-bold transition-all shrink-0 active:scale-95 shadow-2xs group max-w-full"
          >
            <span className="text-base group-hover:scale-110 transition-transform shrink-0">
              {studentGenderEmoji}
            </span>
            <span className="font-black text-slate-900 text-xs sm:text-sm truncate max-w-32 tracking-tight">
              {studentDisplayName}
            </span>
            <span className="text-[11px] font-black px-1.5 py-0.5 rounded-lg bg-amber-200 text-amber-900 border border-amber-300/80 whitespace-nowrap shadow-2xs">
              Lớp {currentGrade}
            </span>
          </button>

          {/* 2. Compact Voice Selector Button (Cô Nữ / Thầy Nam) */}
          <button
            type="button"
            onClick={() => {
              playClickSound();
              onOpenVoiceModal();
            }}
            title={`Đổi giọng đọc đồng hành: ${activeVoice.name}`}
            className="inline-flex items-center gap-1 bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-900 px-2 sm:px-2.5 py-1.5 rounded-2xl text-xs font-bold transition-all shrink-0 active:scale-95 shadow-2xs"
          >
            <span className="text-sm shrink-0">{activeVoice.avatar}</span>
            <span className="font-extrabold whitespace-nowrap text-xs text-sky-800">
              {voiceCompactLabel}
            </span>
            <Volume2 className="w-3.5 h-3.5 text-sky-600 shrink-0" />
          </button>

          {/* 3. Full Textbook Select (Kết Nối Tri Thức, Chân Trời Sáng Tạo, Cánh Diều) */}
          <div className="inline-flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200/70 border border-slate-200 px-2.5 py-1.5 rounded-2xl text-xs text-slate-700 font-semibold shrink-0 transition-colors shadow-2xs">
            <BookOpen className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <select
              value={currentTextbook}
              onChange={(e) => {
                playClickSound();
                onTextbookChange(e.target.value as Textbook);
              }}
              aria-label="Bộ sách dùng để tạo đề AI"
              title="Bộ sách dùng để tạo đề AI"
              className="bg-transparent text-xs font-bold text-slate-800 outline-none cursor-pointer pr-1"
            >
              <option value="ket-noi-tri-thuc">Kết Nối Tri Thức</option>
              <option value="chan-troi-sang-tao">Chân Trời Sáng Tạo</option>
              <option value="canh-dieu">Cánh Diều</option>
            </select>
          </div>

          {/* 4. Streak Badge */}
          <div
            title={`Chuỗi ${streak} ngày học liên tiếp`}
            className="flex items-center gap-1 bg-amber-50 border border-amber-200 px-2 py-1.5 rounded-2xl shrink-0"
          >
            <Flame className="w-3.5 h-3.5 text-amber-500 fill-amber-500 animate-pulse" />
            <span className="text-xs font-black text-amber-900">{streak}</span>
          </div>

          {/* 5. Stars Badge */}
          <div
            title={`Số Sao Vàng tích lũy: ${stars} ⭐`}
            className="flex items-center gap-1 bg-yellow-50 border border-yellow-300 px-2 py-1.5 rounded-2xl shrink-0"
          >
            <Star className="w-3.5 h-3.5 text-yellow-500 fill-yellow-400" />
            <span className="text-xs font-black text-yellow-900">{stars}</span>
          </div>

          {/* 6. Equipped Owl Skin (Compact) */}
          <div
            title={`Trang phục hiện tại: ${currentSkin.name}`}
            className="flex items-center gap-1 bg-slate-100 border border-slate-200 px-1.5 py-1 rounded-2xl shrink-0"
          >
            <span className="text-sm">{currentSkin.emoji.slice(0, 2)}</span>
          </div>

          {/* 7. Google Drive Cloud Sync Trigger */}
          {onOpenDriveTab && (
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onOpenDriveTab();
              }}
              title="Đồng bộ & Lưu trữ Google Drive"
              className="hidden sm:inline-flex p-1.5 bg-blue-50 hover:bg-blue-100 border border-blue-200 hover:border-blue-300 text-blue-700 hover:text-blue-900 rounded-2xl text-xs font-bold transition-all shrink-0 active:scale-95 shadow-2xs"
            >
              <Cloud className="w-3.5 h-3.5 text-blue-600" />
            </button>
          )}

          {/* 8. Author Tab trigger */}
          <button
            type="button"
            onClick={() => {
              playClickSound();
              onOpenAuthorTab();
            }}
            title="Góc Tác Giả & Góp Ý (Ngô Thanh Tân - MaxNgo Studio)"
            className="hidden sm:inline-flex p-1.5 bg-slate-100 hover:bg-amber-100 border border-slate-200 hover:border-amber-300 text-slate-700 hover:text-amber-900 rounded-2xl text-xs font-bold transition-all shrink-0 active:scale-95 shadow-2xs"
          >
            <Coffee className="w-3.5 h-3.5 text-amber-600" />
          </button>
        </div>
      </div>
    </header>
  );
};
