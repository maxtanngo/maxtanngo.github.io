import { readProgressBackup } from '../utils/storage';
import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import { UserProgress, Grade } from '../types';
import { CURRICULUM_2026 } from '../data/curriculum2026';
import { getQuestionsForLesson } from '../utils/questionGenerator';
import {
  initAuth,
  googleSignIn,
  logoutGoogle,
  getAccessToken,
  getCurrentUser,
} from '../services/googleAuthService';
import {
  listDriveFiles,
  backupProgressToDrive,
  downloadDriveFileContent,
  exportReportToDrive,
  exportWorksheetToDrive,
  deleteDriveFile,
  fetchDriveAbout,
  DriveFileItem,
  DriveStorageQuota,
  DriveUserInfo,
  getOrCreateAppFolder,
} from '../services/googleDriveService';
import { GoogleSignInButton } from './GoogleSignInButton';
import { ConfirmModal } from './ConfirmModal';
import { playClickSound, playCorrectSound, playWrongSound } from '../utils/soundAndSpeech';
import {
  HardDrive,
  Cloud,
  CloudUpload,
  CloudDownload,
  FileText,
  FileCheck2,
  Trash2,
  ExternalLink,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  FolderOpen,
  Search,
  BookOpen,
  Award,
  Sparkles,
  ShieldCheck,
  LogOut,
  Info,
} from 'lucide-react';

interface Props {
  grade: Grade;
  progress: UserProgress;
  onRestoreProgress: (restoredProgress: UserProgress) => void;
}

export const GoogleDriveView: React.FC<Props> = ({
  grade,
  progress,
  onRestoreProgress,
}) => {
  // Auth state
  const [user, setUser] = useState<User | null>(getCurrentUser());
  const [token, setToken] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Drive state
  const [restorePreview, setRestorePreview] = useState<{ fileId: string; data: UserProgress } | null>(null);
  const [files, setFiles] = useState<DriveFileItem[]>([]);
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);
  const [driveUserInfo, setDriveUserInfo] = useState<DriveUserInfo | null>(null);
  const [quota, setQuota] = useState<DriveStorageQuota | null>(null);
  const [appFolderId, setAppFolderId] = useState<string | null>(null);

  // Actions state
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [isExportingReport, setIsExportingReport] = useState(false);
  const [isExportingWorksheet, setIsExportingWorksheet] = useState(false);
  const [selectedChapterIndex, setSelectedChapterIndex] = useState<number>(0);
  const [notification, setNotification] = useState<{
    type: 'success' | 'error' | 'info';
    message: string;
    link?: string;
  } | null>(null);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'backup' | 'report' | 'worksheet'>('all');

  // Confirmation modal states for destructive/mutating actions
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    actionType: 'delete' | 'restore';
    targetFile?: DriveFileItem;
    itemDetails?: { label: string; value: string }[];
  }>({
    isOpen: false,
    title: '',
    message: '',
    actionType: 'delete',
  });
  const [isExecutingConfirm, setIsExecutingConfirm] = useState(false);

  // Active sub-tab
  const [activeSubTab, setActiveSubTab] = useState<'backup' | 'export' | 'explorer'>('backup');

  // Listen to auth state
  useEffect(() => {
    const unsubscribe = initAuth(
      (currentUser, accessToken) => {
        setUser(currentUser);
        setToken(accessToken);
        setAuthError(null);
      },
      () => {
        setUser(getCurrentUser());
        setToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  // When token is available, load Drive data
  useEffect(() => {
    if (token) {
      loadDriveData(token);
    } else {
      setFiles([]);
      setQuota(null);
    }
  }, [token]);

  const loadDriveData = async (currentToken: string) => {
    setIsLoadingFiles(true);
    try {
      // 1. Get or create VietMath folder
      const folderId = await getOrCreateAppFolder(currentToken);
      setAppFolderId(folderId);

      // 2. Fetch files in folder and root
      const fileList = await listDriveFiles(currentToken, { folderId });
      setFiles(fileList);

      // 3. Fetch user & quota
      const about = await fetchDriveAbout(currentToken);
      if (about) {
        if (about.user) setDriveUserInfo(about.user);
        if (about.quota) setQuota(about.quota);
      }
    } catch (err: any) {
      console.error('Error loading drive data:', err);
      setNotification({
        type: 'error',
        message: err.message || 'Không thể đồng bộ dữ liệu từ Google Drive.',
      });
    } finally {
      setIsLoadingFiles(false);
    }
  };

  const handleSignIn = async () => {
    setIsLoggingIn(true);
    setAuthError(null);
    try {
      playClickSound();
      const res = await googleSignIn();
      if (res) {
        setUser(res.user);
        setToken(res.accessToken);
        playCorrectSound();
        setNotification({
          type: 'success',
          message: `Chào mừng ${res.user.displayName || 'bạn'} đã kết nối Google Drive thành công!`,
        });
      }
    } catch (err: any) {
      console.error('Sign-in failed:', err);
      playWrongSound();
      setAuthError(err.message || 'Đăng nhập Google không thành công. Vui lòng thử lại!');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    playClickSound();
    await logoutGoogle();
    setUser(null);
    setToken(null);
    setFiles([]);
    setNotification({
      type: 'info',
      message: 'Đã ngắt kết nối tài khoản Google Drive.',
    });
  };

  // 1. BACKUP TO DRIVE
  const handleBackupNow = async () => {
    if (!token) return;
    setIsBackingUp(true);
    try {
      playClickSound();
      const studentName = progress.studentProfile?.name || 'HocSinh';
      const createdFile = await backupProgressToDrive(token, progress, studentName, appFolderId || undefined);
      playCorrectSound();
      setNotification({
        type: 'success',
        message: `Đã sao lưu thành công bản ghi học tập của ${studentName} lên Google Drive!`,
        link: createdFile.webViewLink,
      });
      // Refresh file list
      loadDriveData(token);
    } catch (err: any) {
      console.error('Backup error:', err);
      playWrongSound();
      setNotification({
        type: 'error',
        message: err.message || 'Sao lưu lên Google Drive thất bại.',
      });
    } finally {
      setIsBackingUp(false);
    }
  };

  // 2. RESTORE CONFIRMATION DIALOG (Mandatory confirmation before overwriting local progress)
  const handleRequestRestore = async (file: DriveFileItem) => {
    if (!token) return;
    playClickSound();
    try {
      const data = readProgressBackup(await downloadDriveFileContent(token, file.id));
      if (!data) throw new Error('Định dạng tệp sao lưu không hợp lệ.');
      setRestorePreview({ fileId: file.id, data });
      setConfirmModal({
        isOpen: true,
        title: 'Khôi phục tiến trình học từ Google Drive?',
        message: 'Tiến trình trong tệp sẽ thay tiến trình hiện tại. App giữ một bản lưu trước khi khôi phục trên thiết bị này.',
        actionType: 'restore',
        targetFile: file,
        itemDetails: [
          { label: 'Tệp sao lưu', value: file.name },
          { label: 'Ngày lưu', value: new Date(file.modifiedTime).toLocaleString('vi-VN') },
          { label: 'Khối lớp', value: data.studentProfile ? `Lớp ${data.studentProfile.grade}` : 'Chưa đặt' },
          { label: 'Tiến trình', value: `${data.totalAnswered} câu đã trả lời · ${data.stars} sao` },
        ],
      });
    } catch (error) {
      setNotification({ type: 'error', message: error instanceof Error ? error.message : 'Không thể đọc tệp sao lưu.' });
    }
  };

  // 3. DELETE CONFIRMATION DIALOG (Mandatory confirmation before deleting from Drive)
  const handleRequestDelete = (file: DriveFileItem) => {
    playClickSound();
    setConfirmModal({
      isOpen: true,
      title: 'Xóa tệp khỏi Google Drive vĩnh viễn?',
      message: `Bạn có chắc chắn muốn xóa tệp "${file.name}" khỏi tài khoản Google Drive? Thao tác này không thể hoàn tác.`,
      actionType: 'delete',
      targetFile: file,
      itemDetails: [
        { label: 'Tệp cần xóa', value: file.name },
        {
          label: 'Ngày sửa đổi',
          value: new Date(file.modifiedTime).toLocaleString('vi-VN'),
        },
      ],
    });
  };

  // Execute confirmed action
  const handleExecuteConfirm = async () => {
    if (!token || !confirmModal.targetFile) return;
    setIsExecutingConfirm(true);
    try {
      if (confirmModal.actionType === 'delete') {
        await deleteDriveFile(token, confirmModal.targetFile.id);
        playCorrectSound();
        setNotification({
          type: 'success',
          message: `Đã xóa tệp "${confirmModal.targetFile.name}" khỏi Google Drive thành công.`,
        });
        setFiles((prev) => prev.filter((f) => f.id !== confirmModal.targetFile!.id));
      } else if (confirmModal.actionType === 'restore') {
        const restoredData = restorePreview?.fileId === confirmModal.targetFile.id ? restorePreview.data : null;
        if (restoredData) {
          const current = JSON.stringify(progress);
          localStorage.setItem('vietmath_before_drive_restore', current);
          onRestoreProgress(restoredData);
          setRestorePreview(null);
          playCorrectSound();
          setNotification({
            type: 'success',
            message: `Đã khôi phục thành công tiến trình học: ${restoredData.stars || 0} ⭐ và ${restoredData.streak || 0} ngày chăm chỉ!`,
          });
        } else {
          throw new Error('Định dạng tệp sao lưu không hợp lệ.');
        }
      }
      setConfirmModal((prev) => ({ ...prev, isOpen: false }));
    } catch (err: any) {
      console.error('Action failed:', err);
      playWrongSound();
      setNotification({
        type: 'error',
        message: err.message || 'Thao tác không thành công.',
      });
    } finally {
      setIsExecutingConfirm(false);
    }
  };

  // 4. EXPORT REPORT
  const handleExportReport = async () => {
    if (!token) return;
    setIsExportingReport(true);
    try {
      playClickSound();
      const resFile = await exportReportToDrive(token, progress, grade, appFolderId || undefined);
      playCorrectSound();
      setNotification({
        type: 'success',
        message: 'Đã xuất Báo Cáo Học Tập (Thông tư 27) lên Google Drive thành công!',
        link: resFile.webViewLink,
      });
      loadDriveData(token);
    } catch (err: any) {
      console.error('Export report error:', err);
      playWrongSound();
      setNotification({
        type: 'error',
        message: err.message || 'Xuất báo cáo lên Google Drive thất bại.',
      });
    } finally {
      setIsExportingReport(false);
    }
  };

  // 5. EXPORT WORKSHEET
  const handleExportWorksheet = async () => {
    if (!token) return;
    setIsExportingWorksheet(true);
    try {
      playClickSound();
      const currentChapters = CURRICULUM_2026[grade] || [];
      const selectedChapter = currentChapters[selectedChapterIndex] || currentChapters[0];
      if (!selectedChapter) {
        throw new Error('Không tìm thấy chương bài học để tạo phiếu bài tập.');
      }

      // Collect questions from lessons in chapter
      const allQuestions: any[] = [];
      selectedChapter.lessons.forEach((l) => {
        const qs = getQuestionsForLesson(l);
        allQuestions.push(...qs);
      });

      // Take first 10 questions for a neat weekend worksheet
      const worksheetQuestions = allQuestions.slice(0, 10);

      const resFile = await exportWorksheetToDrive(
        token,
        selectedChapter.title,
        grade,
        worksheetQuestions,
        appFolderId || undefined
      );

      playCorrectSound();
      setNotification({
        type: 'success',
        message: `Đã xuất Phiếu bài tập "${selectedChapter.title}" lên Google Drive thành công!`,
        link: resFile.webViewLink,
      });
      loadDriveData(token);
    } catch (err: any) {
      console.error('Export worksheet error:', err);
      playWrongSound();
      setNotification({
        type: 'error',
        message: err.message || 'Xuất phiếu bài tập thất bại.',
      });
    } finally {
      setIsExportingWorksheet(false);
    }
  };

  // Filter files
  const filteredFiles = files.filter((f) => {
    if (searchQuery.trim()) {
      if (!f.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    }
    if (filterType === 'backup') return f.name.includes('VietMath_SaoLuu') || f.name.endsWith('.json');
    if (filterType === 'report') return f.name.includes('BaoCao_KetQua');
    if (filterType === 'worksheet') return f.name.includes('Phieu_BaiTap');
    return true;
  });

  const chaptersForGrade = CURRICULUM_2026[grade] || [];

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Top Banner with Google Drive Styling */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-600 via-indigo-600 to-sky-600 p-6 sm:p-8 text-white shadow-lg border-2 border-blue-400/40">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur text-xs font-black tracking-wide uppercase">
              <Cloud className="w-3.5 h-3.5" />
              <span>Google Drive Cloud Workspace</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black font-display tracking-tight">
              Đồng Bộ & Lưu Trữ Google Drive
            </h1>
            <p className="text-blue-100 text-xs sm:text-sm max-w-xl leading-relaxed">
              Phụ huynh có thể chủ động sao lưu tiến trình, xuất báo cáo và lưu phiếu bài tập vào Google Drive. App chỉ truy cập các tệp được cấp quyền.
            </p>
          </div>

          {/* User Sign In / Profile Box */}
          <div className="w-full md:w-auto shrink-0 bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 flex flex-col sm:flex-row items-center gap-3">
            {user && token ? (
              <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-start">
                <div className="flex items-center gap-2.5">
                  {user.photoURL ? (
                    <img
                      src={user.photoURL}
                      alt={user.displayName || 'Google Avatar'}
                      className="w-10 h-10 rounded-full border-2 border-white/80 shadow-xs"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-white/20 text-white flex items-center justify-center font-black">
                      {(user.displayName || 'G')[0]}
                    </div>
                  )}
                  <div className="text-left">
                    <p className="text-xs font-black truncate max-w-[140px] text-white">
                      {user.displayName || 'Tài khoản Google'}
                    </p>
                    <p className="text-[10px] text-blue-200 truncate max-w-[140px]">
                      {user.email}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleLogout}
                  title="Đăng xuất khỏi Google Drive"
                  className="p-2 rounded-xl bg-white/15 hover:bg-rose-500/80 text-white transition-colors text-xs font-bold flex items-center gap-1 shrink-0 ml-2"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Thoát</span>
                </button>
              </div>
            ) : (
              <div className="w-full sm:w-auto text-center space-y-2">
                <GoogleSignInButton
                  onClick={handleSignIn}
                  isLoading={isLoggingIn}
                  label="Đăng nhập Google Drive"
                />
                <p className="text-[10px] text-blue-100 flex items-center justify-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-300" />
                  Bảo mật bằng Firebase Auth & Google OAuth
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Decorative Drive shapes */}
        <div className="absolute -right-8 -bottom-8 w-44 h-44 bg-white/10 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* Auth Error Banner if any */}
      {authError && (
        <div className="p-4 rounded-2xl bg-rose-50 border-2 border-rose-200 text-rose-800 text-xs font-bold flex items-center gap-2.5">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{authError}</span>
        </div>
      )}

      {/* Notification Toast Banner */}
      {notification && (
        <div
          className={`p-4 rounded-2xl border-2 flex items-center justify-between gap-3 text-xs font-bold transition-all ${
            notification.type === 'success'
              ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
              : notification.type === 'error'
              ? 'bg-rose-50 border-rose-300 text-rose-900'
              : 'bg-sky-50 border-sky-300 text-sky-900'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {notification.type === 'success' ? (
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : notification.type === 'error' ? (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            ) : (
              <Info className="w-4 h-4 text-sky-600 shrink-0" />
            )}
            <span>{notification.message}</span>
          </div>
          {notification.link && (
            <a
              href={notification.link}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-blue-600 hover:text-blue-800 hover:bg-slate-50 transition-colors shrink-0 shadow-2xs font-extrabold"
            >
              <span>Xem tệp trên Drive</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          )}
        </div>
      )}

      {/* Quick Summary Cards (When signed in) */}
      {token && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-white rounded-2xl border-2 border-slate-200 p-4 shadow-2xs flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-black shrink-0">
              <FolderOpen className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <p className="text-[11px] text-slate-500 font-bold uppercase tracking-wider">Thư mục VietMath</p>
              <p className="text-xs font-black text-slate-800 truncate" title="Toán Tiểu Học 2026 - VietMath Kids">
                Toán Tiểu Học 2026
              </p>
            </div>
          </div>

          <div className="bg-white rounded-2xl border-2 border-slate-200 p-4 shadow-2xs flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-black shrink-0">
              <FileCheck2 className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <p className="text-[11px] text-slate-500 font-bold uppercase tracking-wider">Tệp trong thư mục</p>
              <p className="text-xs font-black text-slate-800">
                {isLoadingFiles ? 'Đang tải...' : `${files.length} tệp tài liệu`}
              </p>
            </div>
          </div>

          <div className="bg-white rounded-2xl border-2 border-slate-200 p-4 shadow-2xs flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-black shrink-0">
              <HardDrive className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <p className="text-[11px] text-slate-500 font-bold uppercase tracking-wider">Dung lượng Drive</p>
              <p className="text-xs font-black text-slate-800">
                {quota?.usage
                  ? `${(Number(quota.usage) / (1024 * 1024 * 1024)).toFixed(2)} GB đã dùng`
                  : 'Sẵn sàng lưu trữ'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Sub Tabs Navigation */}
      <div className="flex items-center gap-2 border-b-2 border-slate-200 pb-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => {
            playClickSound();
            setActiveSubTab('backup');
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-2xl font-black text-xs transition-all shrink-0 ${
            activeSubTab === 'backup'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <CloudUpload className="w-4 h-4" />
          <span>Sao Lưu & Khôi Phục Tiến Trình</span>
        </button>

        <button
          type="button"
          onClick={() => {
            playClickSound();
            setActiveSubTab('export');
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-2xl font-black text-xs transition-all shrink-0 ${
            activeSubTab === 'export'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Xuất Báo Cáo & Phiếu Bài Tập</span>
        </button>

        <button
          type="button"
          onClick={() => {
            playClickSound();
            setActiveSubTab('explorer');
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-2xl font-black text-xs transition-all shrink-0 ${
            activeSubTab === 'explorer'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <FolderOpen className="w-4 h-4" />
          <span>Trình Khám Phá Tệp Drive ({files.length})</span>
        </button>
      </div>

      {/* TAB 1: SAO LƯU & KHÔI PHỤC TIẾN TRÌNH */}
      {activeSubTab === 'backup' && (
        <div className="space-y-6">
          {/* Backup Action Card */}
          <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 md:p-8 shadow-xs">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="space-y-1.5">
                <span className="px-2.5 py-0.5 rounded-lg bg-blue-100 text-blue-800 text-[10px] font-black uppercase tracking-wider">
                  Bản Ghi Học Tập Hiện Tại
                </span>
                <h3 className="text-xl font-black text-slate-800">
                  Học sinh: {progress.studentProfile?.name || 'Bảo Nam'} · Lớp {grade}
                </h3>
                <div className="flex flex-wrap items-center gap-3 text-xs font-bold text-slate-600 pt-1">
                  <span className="flex items-center gap-1 text-amber-600">
                    ⭐ {progress.stars} sao vàng
                  </span>
                  <span>·</span>
                  <span className="text-orange-600">🔥 Chuỗi {progress.streak} ngày</span>
                  <span>·</span>
                  <span>🎯 {progress.correctCount}/{progress.totalAnswered} câu đúng</span>
                  <span>·</span>
                  <span>📚 {Object.keys(progress.completedLessons).length} bài đã hoàn thành</span>
                </div>
              </div>

              <div className="shrink-0 w-full md:w-auto">
                {token ? (
                  <button
                    type="button"
                    disabled={isBackingUp}
                    onClick={handleBackupNow}
                    className="w-full md:w-auto px-6 py-3.5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black text-sm shadow-md flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
                  >
                    {isBackingUp ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <CloudUpload className="w-4 h-4" />
                    )}
                    <span>{isBackingUp ? 'Đang tải lên Drive...' : 'Sao Lưu Lên Google Drive Ngay'}</span>
                  </button>
                ) : (
                  <GoogleSignInButton
                    onClick={handleSignIn}
                    isLoading={isLoggingIn}
                    label="Đăng nhập để Sao lưu"
                  />
                )}
              </div>
            </div>
          </div>

          {/* List of Previous Backups on Drive */}
          <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-black text-slate-800">
                  Các Bản Sao Lưu Có Sẵn Trên Google Drive
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Chọn một bản sao lưu để khôi phục lại máy tính, điện thoại hoặc máy tính bảng bất kỳ lúc nào.
                </p>
              </div>
              {token && (
                <button
                  type="button"
                  onClick={() => loadDriveData(token)}
                  disabled={isLoadingFiles}
                  className="p-2 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-600 text-xs font-bold flex items-center gap-1"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoadingFiles ? 'animate-spin' : ''}`} />
                  <span className="hidden sm:inline">Làm mới</span>
                </button>
              )}
            </div>

            {!token ? (
              <div className="py-10 text-center space-y-3 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
                <Cloud className="w-10 h-10 text-slate-400 mx-auto" />
                <p className="text-xs text-slate-600 font-bold max-w-sm mx-auto">
                  Vui lòng đăng nhập Google Drive để xem và khôi phục các bản sao lưu đã lưu trữ.
                </p>
                <GoogleSignInButton onClick={handleSignIn} isLoading={isLoggingIn} />
              </div>
            ) : isLoadingFiles ? (
              <div className="py-12 text-center text-xs text-slate-500 font-bold flex flex-col items-center gap-2">
                <RefreshCw className="w-6 h-6 animate-spin text-blue-600" />
                <span>Đang quét các bản sao lưu trên Google Drive...</span>
              </div>
            ) : files.filter((f) => f.name.includes('VietMath_SaoLuu') || f.name.endsWith('.json')).length === 0 ? (
              <div className="py-10 text-center space-y-2 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
                <FileCheck2 className="w-8 h-8 text-slate-400 mx-auto" />
                <p className="text-xs font-bold text-slate-600">
                  Chưa có bản sao lưu nào trong thư mục Google Drive.
                </p>
                <p className="text-[11px] text-slate-400">
                  Nhấn "Sao Lưu Lên Google Drive Ngay" ở trên để tạo bản lưu đầu tiên!
                </p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {files
                  .filter((f) => f.name.includes('VietMath_SaoLuu') || f.name.endsWith('.json'))
                  .map((file) => (
                    <div
                      key={file.id}
                      className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/80 px-2 rounded-xl transition-colors"
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-black shrink-0 mt-0.5">
                          ⭐
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-black text-slate-800 truncate">{file.name}</p>
                          <p className="text-[11px] text-slate-500 font-medium">
                            Lưu ngày: {new Date(file.modifiedTime).toLocaleString('vi-VN')} ·{' '}
                            {Math.round(Number(file.size || 0) / 1024)} KB
                          </p>
                          {file.description && (
                            <p className="text-[10px] text-slate-600 mt-0.5 line-clamp-1 italic">
                              {file.description}
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                        {file.webViewLink && (
                          <a
                            href={file.webViewLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-2 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-bold"
                            title="Mở trên Google Drive"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        )}
                        <button
                          type="button"
                          onClick={() => handleRequestRestore(file)}
                          className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black flex items-center gap-1 shadow-2xs active:scale-95"
                          title="Khôi phục dữ liệu từ bản sao lưu này"
                        >
                          <CloudDownload className="w-3.5 h-3.5" />
                          <span>Khôi phục</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRequestDelete(file)}
                          className="p-2 rounded-xl hover:bg-rose-100 text-rose-600 transition-colors"
                          title="Xóa tệp này khỏi Google Drive"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: XUẤT BÁO CÁO & PHIẾU BÀI TẬP */}
      {activeSubTab === 'export' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Card 1: Báo cáo Thông tư 27 */}
          <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 shadow-xs flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-700 flex items-center justify-center font-black">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-black text-slate-800">
                  Báo Cáo Đánh Giá Học Tập (Thông Tư 27)
                </h3>
                <p className="text-xs text-slate-500 font-medium mt-1 leading-relaxed">
                  Xuất bảng tổng hợp kết quả học tập, độ chính xác các mạch kiến thức (Số học, Hình học, Giải toán) theo chuẩn Thông tư 27 Bộ GD&ĐT trực tiếp lên Google Drive.
                </p>
              </div>

              <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-200 text-xs space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Học sinh:</span>
                  <span className="font-bold text-slate-800">{progress.studentProfile?.name} (Lớp {grade})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Trường học:</span>
                  <span className="font-bold text-slate-800">{progress.studentProfile?.schoolName || 'Chưa cập nhật'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Tổng điểm tích lũy:</span>
                  <span className="font-bold text-amber-600">{progress.stars} ⭐ ({progress.totalAnswered} câu đã làm)</span>
                </div>
              </div>
            </div>

            <div className="pt-2">
              {token ? (
                <button
                  type="button"
                  disabled={isExportingReport}
                  onClick={handleExportReport}
                  className="w-full py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs shadow-sm flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
                >
                  {isExportingReport ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <FileText className="w-4 h-4" />
                  )}
                  <span>{isExportingReport ? 'Đang xuất báo cáo...' : 'Xuất Báo Cáo Lên Google Drive'}</span>
                </button>
              ) : (
                <GoogleSignInButton
                  onClick={handleSignIn}
                  isLoading={isLoggingIn}
                  label="Đăng nhập để Xuất Báo Cáo"
                  className="w-full"
                />
              )}
            </div>
          </div>

          {/* Card 2: Phiếu bài tập cuối tuần / ôn tập */}
          <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 shadow-xs flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-black">
                <BookOpen className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-black text-slate-800">
                  Tạo & Xuất Phiếu Bài Tập Cuối Tuần
                </h3>
                <p className="text-xs text-slate-500 font-medium mt-1 leading-relaxed">
                  Tạo phiếu bài tập in ấn chuẩn có phần họ tên, lời phê của thầy cô và đáp án chi tiết, tải thẳng lên Google Drive để bố mẹ dễ dàng in ra giấy cho con làm bài.
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">
                  Chọn Chủ đề / Chương bài học Lớp {grade}:
                </label>
                <select
                  value={selectedChapterIndex}
                  onChange={(e) => setSelectedChapterIndex(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 bg-white outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  {chaptersForGrade.map((chap, idx) => (
                    <option key={chap.id} value={idx}>
                      {chap.title}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="pt-2">
              {token ? (
                <button
                  type="button"
                  disabled={isExportingWorksheet}
                  onClick={handleExportWorksheet}
                  className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-sm flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
                >
                  {isExportingWorksheet ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <CloudUpload className="w-4 h-4" />
                  )}
                  <span>{isExportingWorksheet ? 'Đang tạo & tải lên...' : 'Xuất Phiếu Bài Tập Lên Drive'}</span>
                </button>
              ) : (
                <GoogleSignInButton
                  onClick={handleSignIn}
                  isLoading={isLoggingIn}
                  label="Đăng nhập để Xuất Phiếu Bài"
                  className="w-full"
                />
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: TRÌNH KHÁM PHÁ TỆP GOOGLE DRIVE */}
      {activeSubTab === 'explorer' && (
        <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-black text-slate-800">
                Tất Cả Tệp Trong Thư Mục "Toán Tiểu Học 2026 - VietMath Kids"
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Quản lý các tài liệu toán, báo cáo đánh giá và bản sao lưu đồng bộ của bạn.
              </p>
            </div>

            {token && (
              <button
                type="button"
                onClick={() => loadDriveData(token)}
                disabled={isLoadingFiles}
                className="px-3 py-2 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-600 text-xs font-bold flex items-center gap-1 shrink-0"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoadingFiles ? 'animate-spin' : ''}`} />
                <span>Làm mới danh sách</span>
              </button>
            )}
          </div>

          {/* Search & Filter Toolbar */}
          <div className="flex flex-col sm:flex-row items-center gap-2.5 pt-2">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Tìm kiếm theo tên tệp..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto shrink-0">
              {(
                [
                  { id: 'all', label: 'Tất cả' },
                  { id: 'backup', label: 'Sao lưu' },
                  { id: 'report', label: 'Báo cáo' },
                  { id: 'worksheet', label: 'Phiếu bài tập' },
                ] as const
              ).map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setFilterType(f.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
                    filterType === f.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {!token ? (
            <div className="py-12 text-center space-y-3 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
              <Cloud className="w-10 h-10 text-slate-400 mx-auto" />
              <p className="text-xs text-slate-600 font-bold max-w-sm mx-auto">
                Vui lòng đăng nhập Google Drive để xem danh sách tài liệu.
              </p>
              <GoogleSignInButton onClick={handleSignIn} isLoading={isLoggingIn} />
            </div>
          ) : isLoadingFiles ? (
            <div className="py-16 text-center text-xs text-slate-500 font-bold flex flex-col items-center gap-2">
              <RefreshCw className="w-6 h-6 animate-spin text-blue-600" />
              <span>Đang tải danh sách tệp từ Google Drive...</span>
            </div>
          ) : filteredFiles.length === 0 ? (
            <div className="py-12 text-center space-y-2 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
              <FolderOpen className="w-8 h-8 text-slate-400 mx-auto" />
              <p className="text-xs font-bold text-slate-600">
                {searchQuery ? 'Không tìm thấy tệp phù hợp với từ khóa.' : 'Thư mục hiện tại chưa có tệp.'}
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden">
              {filteredFiles.map((file) => {
                const isJson = file.name.endsWith('.json');
                const isHtml = file.name.endsWith('.html');
                return (
                  <div
                    key={file.id}
                    className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                          isJson
                            ? 'bg-amber-100 text-amber-700'
                            : isHtml
                            ? 'bg-blue-100 text-blue-700'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {isJson ? 'JSON' : isHtml ? 'HTML' : 'FILE'}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-black text-slate-800 truncate">{file.name}</p>
                        <p className="text-[11px] text-slate-500">
                          {new Date(file.modifiedTime).toLocaleString('vi-VN')} ·{' '}
                          {file.size ? `${Math.round(Number(file.size) / 1024)} KB` : 'Tài liệu'}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                      {isJson && (
                        <button
                          type="button"
                          onClick={() => handleRequestRestore(file)}
                          className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1 shadow-2xs"
                        >
                          <CloudDownload className="w-3.5 h-3.5" />
                          <span>Khôi phục</span>
                        </button>
                      )}
                      {file.webViewLink && (
                        <a
                          href={file.webViewLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2.5 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-bold flex items-center gap-1"
                        >
                          <span>Mở Drive</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}
                      <button
                        type="button"
                        onClick={() => handleRequestDelete(file)}
                        className="p-1.5 rounded-xl text-rose-500 hover:bg-rose-50 transition-colors"
                        title="Xóa tệp này khỏi Google Drive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Mandatory User Confirmation Dialog */}
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.actionType === 'delete' ? 'danger' : 'warning'}
        confirmLabel={
          confirmModal.actionType === 'delete' ? 'Xác nhận xóa tệp' : 'Đồng ý khôi phục'
        }
        cancelLabel="Hủy bỏ"
        itemDetails={confirmModal.itemDetails}
        isProcessing={isExecutingConfirm}
        onConfirm={handleExecuteConfirm}
        onCancel={() => setConfirmModal((prev) => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};
