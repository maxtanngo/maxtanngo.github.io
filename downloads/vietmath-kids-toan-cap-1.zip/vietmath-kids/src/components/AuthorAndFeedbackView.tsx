import { staticRelease } from '../utils/releaseMode';
import React, { useState } from 'react';
import { MaxNgoLogo } from './MaxNgoLogo';
import {
  Send,
  Mail,
  Phone,
  Globe,
  Coffee,
  Copy,
  Check,
  Sparkles,
  Heart,
  ShieldCheck,
  QrCode,
  Building2,
  ExternalLink,
  MessageSquare,
} from 'lucide-react';
import { playClickSound, playCorrectSound } from '../utils/soundAndSpeech';

export const AuthorAndFeedbackView: React.FC = () => {
  const [fullName, setFullName] = useState('');
  const [contactInfo, setContactInfo] = useState('');
  const [topicType, setTopicType] = useState('Góp ý & Báo lỗi nội dung');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSent, setIsSent] = useState(false);
  const [isCopiedBody, setIsCopiedBody] = useState(false);
  const [serverStatus, setServerStatus] = useState<string | null>(null);

  const AUTHOR_INFO = {
    name: 'Ngô Thanh Tân',
    brand: 'MaxNgo Studio',
    email: 'tannt4@gmail.com',
    website: 'https://maxngo.io.vn',
  };

  const fullEmailBody = `Kính gửi Tác giả Ngô Thanh Tân - MaxNgo Studio (tannt4@gmail.com),

Tôi xin gửi thông tin đóng góp cho ứng dụng VietMath Kids 2026:
- Họ và tên: ${fullName.trim() || 'Người dùng'}
- Thông tin liên hệ (Email/SĐT): ${contactInfo.trim() || 'Chưa cung cấp'}
- Chủ đề: ${topicType}
- Thời gian: ${new Date().toLocaleString('vi-VN')}

Nội dung chi tiết:
${message.trim()}

--------------------------------------------------
Gửi từ ứng dụng Toán Tiểu Học Thông Minh 2026 (VietMath Kids)
Website: maxngo.io.vn | Tác giả: Ngô Thanh Tân`;

  const emailSubject = `[MaxNgo Studio - VietMath Kids] ${topicType} từ ${fullName.trim() || 'Người dùng'}`;

  // Direct Gmail Web Compose link
  const gmailComposeUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(AUTHOR_INFO.email)}&su=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(fullEmailBody)}`;

  // Standard mailto link
  const mailtoUrl = `mailto:${AUTHOR_INFO.email}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(fullEmailBody)}`;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    if (staticRelease) {
      window.open(gmailComposeUrl, '_blank', 'noopener,noreferrer');
      return;
    }
    setIsSubmitting(true);
    playClickSound();

    // 1. Copy content to clipboard automatically
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      try {
        await navigator.clipboard.writeText(fullEmailBody);
        setIsCopiedBody(true);
        setTimeout(() => setIsCopiedBody(false), 3000);
      } catch (err) {
        console.debug('Clipboard write error', err);
      }
    }

    // 2. Submit to server-side logging and storage API
    try {
      const res = await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName,
          contactInfo,
          topicType,
          message,
        }),
      });

      if (res.ok) {
        setServerStatus('success');
      } else {
        setServerStatus('error');
      }
    } catch {
      setServerStatus('error');
    }

    playCorrectSound();
    setIsSent(true);
    setIsSubmitting(false);


  };

  const handleCopyBodyOnly = () => {
    playClickSound();
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(fullEmailBody);
      setIsCopiedBody(true);
      setTimeout(() => setIsCopiedBody(false), 2500);
    }
  };


  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white rounded-3xl p-6 md:p-8 shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur border border-white/20 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            Đồng hành cùng EdTech Việt Nam 2026
          </div>
          <h1 className="text-2xl md:text-3xl font-black font-display mb-2">
            Góc Tác Giả & Đóng Góp Ý Kiến
          </h1>
          <p className="text-slate-300 text-sm md:text-base leading-relaxed">
            Ứng dụng được sáng tạo và phát triển bởi <strong className="text-white">Ngô Thanh Tân (MaxNgo Studio)</strong>. Mọi góp ý, báo lỗi hoặc nhu cầu đặt hàng phần mềm giáo dục vui lòng kết nối trực tiếp tại đây!
          </p>
        </div>

        <div className="absolute -right-8 -bottom-8 w-60 h-60 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Main 2-Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* ==================================================== */}
        {/* CỘT BÊN TRÁI: FORM GỬI Ý KIẾN / BÁO LỖI / ĐẶT LÀM APP */}
        {/* ==================================================== */}
        <div className="lg:col-span-7 bg-white rounded-3xl border-2 border-slate-200 p-6 md:p-8 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-200 pb-4 mb-6">
              <div>
                <h2 className="text-xl font-black text-slate-900 font-display flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-sky-600" />
                  Gửi Ý Kiến & Đặt Hàng Phần Mềm
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Phản hồi trực tiếp tới Email: <strong>{AUTHOR_INFO.email}</strong>
                </p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Họ và tên của bạn / Phụ huynh / Thầy cô *
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Ví dụ: Nguyễn Văn An"
                  className="w-full text-sm font-semibold px-4 py-3 rounded-2xl border-2 border-slate-200 focus:border-sky-500 focus:ring-4 focus:ring-sky-100 outline-none transition-all"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Email hoặc Số điện thoại *
                  </label>
                  <input
                    type="text"
                    required
                    value={contactInfo}
                    onChange={(e) => setContactInfo(e.target.value)}
                    placeholder="098... hoặc email@..."
                    className="w-full text-sm font-semibold px-4 py-3 rounded-2xl border-2 border-slate-200 focus:border-sky-500 focus:ring-4 focus:ring-sky-100 outline-none transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Chủ đề phản hồi
                  </label>
                  <select
                    value={topicType}
                    onChange={(e) => setTopicType(e.target.value)}
                    className="w-full text-xs font-bold px-3 py-3 rounded-2xl border-2 border-slate-200 focus:border-sky-500 focus:ring-4 focus:ring-sky-100 outline-none bg-white transition-all cursor-pointer"
                  >
                    <option value="Góp ý & Báo lỗi nội dung bài học">Góp ý & Báo lỗi bài học</option>
                    <option value="Đóng góp ý tưởng tính năng mới">Đóng góp ý tưởng mới</option>
                    <option value="Đặt hàng phát triển app giáo dục (EdTech)">Đặt làm app khác (EdTech)</option>
                    <option value="Hợp tác giáo dục & bản quyền">Hợp tác giáo dục</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Nội dung chi tiết *
                </label>
                <textarea
                  rows={5}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Mô tả cụ thể câu hỏi bị lỗi, tính năng con yêu thích hoặc yêu cầu thiết kế ứng dụng giáo dục..."
                  className="w-full text-sm font-medium p-4 rounded-2xl border-2 border-slate-200 focus:border-sky-500 focus:ring-4 focus:ring-sky-100 outline-none resize-none transition-all"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full py-4 rounded-2xl border-b-4 text-white font-black text-base shadow-lg btn-tactile flex items-center justify-center gap-2 transition-all ${
                  isSubmitting
                    ? 'bg-slate-400 border-slate-600 cursor-wait'
                    : 'bg-gradient-to-r from-blue-600 via-sky-600 to-teal-500 hover:from-blue-700 hover:to-teal-600 border-blue-800'
                }`}
              >
                {isSubmitting ? (
                  <>
                    <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Đang lưu góp ý...
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    {staticRelease ? "Mở email góp ý" : "Lưu góp ý"}
                  </>
                )}
              </button>
            </form>

            {isSent && (
              <div className="mt-5 p-5 rounded-3xl bg-gradient-to-br from-emerald-50 to-teal-50 border-3 border-emerald-300 text-slate-800 shadow-md animate-fade-in space-y-3">
                <div className="flex items-center gap-2.5 text-emerald-800">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500 text-white flex items-center justify-center shadow-xs">
                    <Check className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-black text-sm font-display text-emerald-950">
                      {serverStatus === "success" ? "Đã lưu góp ý trên máy chủ" : "Chưa lưu được góp ý"}
                    </h4>
                    <p className="text-[11px] text-emerald-800">
                      Bạn có thể dùng nút mở email để liên hệ trực tiếp với tác giả.
                    </p>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed bg-white/70 p-3 rounded-2xl border border-emerald-200">
                  Cảm ơn sự đồng hành quý báu của bạn! Để đảm bảo tác giả nhận được phản hồi ngay tức thì, bạn có thể chọn thêm một trong các kênh liên hệ nhanh bên dưới:
                </p>

                {/* Multi-channel Action Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  <a
                    href={gmailComposeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-2.5 px-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                  >
                    <Mail className="w-4 h-4" />
                    Mở Hộp Thư Gmail (Gửi 1 chạm)
                  </a>

                  <a
                    href={mailtoUrl}
                    className="py-2.5 px-3 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Mở Ứng Dụng Mail Trên Máy
                  </a>

                  <button
                    type="button"
                    onClick={handleCopyBodyOnly}
                    className="py-2 px-3 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    {isCopiedBody ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        Đã sao chép nội dung thư!
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-500" />
                        Sao chép nội dung thư
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      setMessage('');
                      setIsSent(false);
                    }}
                    className="py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <span>✏️ Soạn đóng góp khác</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Quick contact strip */}
          <div className="mt-6 pt-4 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
            <a
              href={`mailto:${AUTHOR_INFO.email}`}
              className="p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 flex items-center gap-2 font-semibold transition-colors"
            >
              <Mail className="w-4 h-4 text-rose-500 shrink-0" />
              <span className="truncate">{AUTHOR_INFO.email}</span>
            </a>
            <a
              href={AUTHOR_INFO.website}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 flex items-center gap-2 font-semibold transition-colors"
            >
              <Globe className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>maxngo.io.vn</span>
            </a>
          </div>
        </div>

        {/* ==================================================== */}
        {/* CỘT BÊN PHẢI: THẺ TÁC GIẢ & MÃ VIETQR MỜI CÀ PHÊ ☕ */}
        {/* ==================================================== */}
        <div className="lg:col-span-5 space-y-6">
          {/* Author Bio Card */}
          <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 md:p-7 shadow-xs">
            <div className="flex items-start gap-4">
              <MaxNgoLogo size="lg" showText={false} />
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-xl font-black text-slate-900 font-display">
                    {AUTHOR_INFO.name}
                  </h3>
                  <span className="text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                    Founder
                  </span>
                </div>
                <p className="text-xs font-bold text-sky-700">MaxNgo Studio · EdTech Architect</p>
                <a
                  href={AUTHOR_INFO.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-slate-500 hover:text-sky-600 inline-flex items-center gap-1 mt-0.5"
                >
                  Website chính thức: <span className="font-semibold text-slate-800">maxngo.io.vn</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </a>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-100 text-xs text-slate-600 leading-relaxed space-y-2">
              <p>
                <strong>Sứ mệnh:</strong> Kiến tạo các giải pháp công nghệ giáo dục hiện đại, ứng dụng Trí tuệ Nhân tạo (Gemini AI) và phương pháp sư phạm gợi mở (Socratic) chuẩn GDPT 2018.
              </p>
              <p className="text-[11px] text-slate-500 italic">
                "Mỗi bạn nhỏ đều xứng đáng được tiếp cận với một người thầy kiên nhẫn, vui vẻ và khơi dậy niềm đam mê khám phá toán học mỗi ngày."
              </p>
            </div>
          </div>


        </div>
      </div>
    </div>
  );
};
