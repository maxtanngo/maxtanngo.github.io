import React from 'react';
import { OwlSkin, UserProgress, Grade } from '../types';
import { INITIAL_SKINS } from '../utils/storage';
import { GRADE_THEMES } from '../data/curriculumData';
import {
  Star,
  Check,
  Lock,
  Sparkles,
  ShoppingBag,
  Award,
  Crown,
} from 'lucide-react';
import { playClickSound, playWinFanfare } from '../utils/soundAndSpeech';

interface Props {
  grade: Grade;
  progress: UserProgress;
  onEquipSkin: (skinId: string) => void;
  onUnlockSkin: (skinId: string, cost: number) => void;
}

export const StoreView: React.FC<Props> = ({
  grade,
  progress,
  onEquipSkin,
  onUnlockSkin,
}) => {
  const currentTheme = GRADE_THEMES[grade];

  const BADGES = [
    {
      id: 'b1',
      title: 'Chiến Binh Bảng Cửu Chương',
      description: 'Luyện tập thuộc lòng các bảng nhân chia căn bản',
      icon: '⚡',
      achieved: progress.totalAnswered >= 5,
    },
    {
      id: 'b2',
      title: 'Bậc Thầy Hình Học',
      description: 'Chinh phục các bài toán đo lường và góc',
      icon: '📐',
      achieved: progress.strandStats['Hình học & Đo lường']?.correct >= 2,
    },
    {
      id: 'b3',
      title: 'Thám Tử Lời Văn',
      description: 'Giải xuất sắc các bài toán có lời văn thực tế',
      icon: '🔍',
      achieved: progress.strandStats['Giải toán có lời văn']?.correct >= 2,
    },
    {
      id: 'b4',
      title: 'Ngôi Sao Chăm Chỉ',
      description: 'Duy trì chuỗi học tập liên tục ít nhất 3 ngày',
      icon: '🔥',
      achieved: progress.streak >= 3,
    },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      {/* Header Banner */}
      <div className={`p-6 md:p-8 rounded-3xl bg-gradient-to-r ${currentTheme.gradient} text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden`}>
        <div className="relative z-10 max-w-xl text-center md:text-left">
          <div className="inline-flex items-center gap-1.5 bg-white/20 backdrop-blur px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            Phần thưởng xứng đáng
          </div>
          <h1 className="text-2xl md:text-3xl font-black font-display mb-2">
            Cửa Hàng Sao Vàng & Bộ Sưu Tập
          </h1>
          <p className="text-white/90 text-sm leading-relaxed">
            Mỗi bài toán con giải đúng là thêm một bước tích lũy Sao Vàng để đổi những trang phục siêu ngầu cho Cú Mèo Thông Thái!
          </p>
        </div>

        {/* Current Stars Balance Display */}
        <div className="relative z-10 bg-white/15 backdrop-blur-md border-2 border-white/30 rounded-3xl p-5 text-center shrink-0 min-w-[200px] shadow-lg">
          <span className="text-xs font-black uppercase tracking-wider text-amber-200">
            Số Sao Hiện Có
          </span>
          <div className="flex items-center justify-center gap-2 mt-1">
            <Star className="w-8 h-8 text-amber-300 fill-amber-300 animate-pulse" />
            <span className="text-4xl font-black text-white">{progress.stars}</span>
          </div>
          <p className="text-[11px] text-white/80 mt-1">Giải thêm bài để nhận thêm sao</p>
        </div>
      </div>

      {/* Owl Skins Grid */}
      <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 md:p-8 shadow-xs">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-black text-slate-900 font-display flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-amber-500" />
              Tủ Đồ Thời Trang Cú Mèo
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Chọn trang phục yêu thích để Thầy Cú Mèo đồng hành cùng con
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {INITIAL_SKINS.map((skin) => {
            const isUnlocked = progress.unlockedSkins.includes(skin.id);
            const isEquipped = progress.equippedSkin === skin.id;
            const canAfford = progress.stars >= skin.costStars;

            return (
              <div
                key={skin.id}
                className={`p-5 rounded-3xl border-3 transition-all duration-200 flex flex-col justify-between ${
                  isEquipped
                    ? 'bg-amber-50/70 border-amber-400 ring-4 ring-amber-100 shadow-md'
                    : isUnlocked
                    ? 'bg-white border-slate-200 hover:border-slate-300 shadow-2xs'
                    : 'bg-slate-50/80 border-slate-200 opacity-90'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-3xl p-2 bg-white rounded-2xl border border-slate-200 shadow-xs">
                      {skin.emoji}
                    </span>

                    {isEquipped ? (
                      <span className="text-xs font-black text-amber-800 bg-amber-100 border border-amber-300 px-2.5 py-1 rounded-xl flex items-center gap-1">
                        <Crown className="w-3.5 h-3.5 text-amber-600" /> Đang dùng
                      </span>
                    ) : isUnlocked ? (
                      <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-lg flex items-center gap-1">
                        <Check className="w-3 h-3" /> Đã sở hữu
                      </span>
                    ) : (
                      <div className="flex items-center gap-1 text-xs font-black text-amber-700 bg-amber-100 px-2.5 py-1 rounded-xl">
                        <Star className="w-3.5 h-3.5 text-amber-600 fill-amber-500" />
                        {skin.costStars}
                      </div>
                    )}
                  </div>

                  <h3 className="font-extrabold text-base text-slate-900">{skin.name}</h3>
                  <span className="text-xs font-bold text-slate-500 block mb-1">
                    {skin.title}
                  </span>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {skin.description}
                  </p>
                </div>

                {/* Card Action Button */}
                <div className="mt-5 pt-3 border-t border-slate-200">
                  {isEquipped ? (
                    <button
                      type="button"
                      disabled
                      className="w-full py-2.5 rounded-xl text-xs font-black bg-amber-200 text-amber-900 cursor-default"
                    >
                      ✓ Trang phục đang chọn
                    </button>
                  ) : isUnlocked ? (
                    <button
                      type="button"
                      onClick={() => {
                        playClickSound();
                        onEquipSkin(skin.id);
                      }}
                      className="w-full py-2.5 rounded-xl border-b-3 border-slate-700 bg-slate-900 hover:bg-slate-800 text-white text-xs font-black btn-tactile shadow-xs"
                    >
                      Chọn trang phục này
                    </button>
                  ) : (
                    <button
                      type="button"
                      disabled={!canAfford}
                      onClick={() => {
                        playWinFanfare();
                        onUnlockSkin(skin.id, skin.costStars);
                      }}
                      className={`w-full py-2.5 rounded-xl border-b-3 text-xs font-black btn-tactile shadow-xs flex items-center justify-center gap-1.5 ${
                        canAfford
                          ? 'bg-amber-500 hover:bg-amber-600 border-amber-700 text-white'
                          : 'bg-slate-200 border-slate-300 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      <Lock className="w-3.5 h-3.5" />
                      {canAfford ? `Mở khóa bằng ${skin.costStars} ⭐` : `Cần thêm ${skin.costStars - progress.stars} ⭐`}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Badges Collection */}
      <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 md:p-8 shadow-xs">
        <h2 className="text-xl font-black text-slate-900 font-display mb-2 flex items-center gap-2">
          <Award className="w-5 h-5 text-purple-600" />
          Huy Hiệu Danh Dự VietMath
        </h2>
        <p className="text-xs text-slate-500 mb-6">
          Thành tích nổi bật ghi nhận sự nỗ lực kiên trì của con trong quá trình rèn luyện toán
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {BADGES.map((b) => (
            <div
              key={b.id}
              className={`p-4 rounded-2xl border-2 flex items-start gap-3 transition-all ${
                b.achieved
                  ? 'bg-purple-50/60 border-purple-200'
                  : 'bg-slate-50 border-slate-200 opacity-60'
              }`}
            >
              <div
                className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shrink-0 shadow-inner ${
                  b.achieved ? 'bg-purple-100 border border-purple-300' : 'bg-slate-200'
                }`}
              >
                {b.icon}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-1">
                  <h4 className="text-xs font-black text-slate-800">{b.title}</h4>
                  {b.achieved && (
                    <span className="text-[10px] text-purple-700 font-bold bg-purple-100 px-1 rounded">
                      ✓ Đạt
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                  {b.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
