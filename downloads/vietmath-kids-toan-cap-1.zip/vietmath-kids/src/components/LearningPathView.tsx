import React, { useState, useMemo } from 'react';
import { Chapter, Grade, Lesson, UserProgress } from '../types';
import { GRADE_THEMES } from '../data/curriculumData';
import {
  Star,
  Play,
  CheckCircle2,
  Sparkles,
  BookMarked,
  Calendar,
  Compass,
  Search,
  BookOpen,
  Filter,
} from 'lucide-react';
import { playClickSound } from '../utils/soundAndSpeech';

interface Props {
  grade: Grade;
  chapters: Chapter[];
  progress: UserProgress;
  onSelectLesson: (lesson: Lesson) => void;
  onOpenProfileModal?: (tab?: 'profile' | 'timetable') => void;
}

export const LearningPathView: React.FC<Props> = ({
  grade,
  chapters,
  progress,
  onSelectLesson,
  onOpenProfileModal,
}) => {
  const currentTheme = GRADE_THEMES[grade];
  const [semesterFilter, setSemesterFilter] = useState<'all' | 'sem1' | 'sem2'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const studentName = progress.studentProfile?.name;
  const lessons = chapters.flatMap(chapter => chapter.lessons);
  const nextLesson = lessons.find(lesson => !progress.completedLessons[lesson.id]);

  // Filter chapters and lessons according to semester and search query
  const filteredChapters = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();

    return chapters
      .map((ch) => {
        const filteredLessons = ch.lessons.filter((l) => {
          // Semester filter
          if (semesterFilter === 'sem1' && l.semester === 2) return false;
          if (semesterFilter === 'sem2' && l.semester === 1) return false;

          // Search query
          if (!query) return true;
          const matchTitle = l.title.toLowerCase().includes(query);
          const matchDesc = l.description.toLowerCase().includes(query);
          const matchStrand = l.strand.toLowerCase().includes(query);
          const matchWeek = l.week && `tuần ${l.week}`.includes(query);
          const matchWeekNum = l.week && l.week.toString() === query;

          return matchTitle || matchDesc || matchStrand || matchWeek || matchWeekNum;
        });

        return {
          ...ch,
          lessons: filteredLessons,
        };
      })
      .filter((ch) => ch.lessons.length > 0);
  }, [chapters, semesterFilter, searchQuery]);

  const totalLessonsInGrade = useMemo(() => {
    return chapters.reduce((acc, ch) => acc + ch.lessons.length, 0);
  }, [chapters]);

  const completedCount = useMemo(() => {
    return chapters.flatMap(chapter => chapter.lessons).filter(lesson => progress.completedLessons[lesson.id]).length;
  }, [progress.completedLessons, chapters]);

  return (
    <div className="space-y-6 md:space-y-8 pb-12">
      {/* Hero Banner for Grade */}
      <div
        className={`rounded-3xl p-5 md:p-8 bg-gradient-to-r ${currentTheme.gradient} text-white shadow-xl relative overflow-hidden`}
      >
        <div className="relative z-10 max-w-2xl">
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <div className="inline-flex items-center gap-1.5 bg-white/20 backdrop-blur px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              Bài học theo chủ đề
            </div>
            <div className="inline-flex items-center gap-2 bg-black/25 backdrop-blur border border-white/20 px-3 py-1 rounded-full text-xs font-black">
              <span>{progress.studentProfile?.gender === 'female' ? '👧' : '👦'}</span>
              {studentName && <span className="text-white">{studentName}</span>}
              <span className="text-amber-300 bg-white/15 px-2 py-0.2 rounded-md text-[11px]">
                Lớp {grade}
              </span>
            </div>
          </div>

          <h1 className="text-2xl md:text-3xl font-black font-display leading-tight mb-2">
            Bản Đồ Kho Báu Toán Học {currentTheme.badge}
          </h1>
          <p className="text-white/90 text-sm md:text-base leading-relaxed">
            Chọn một bài để học hoặc ôn tập và nhận Sao Vàng ⭐!
          </p>

          {nextLesson && (
            <button type="button" onClick={() => onSelectLesson(nextLesson)}
              className="mt-4 rounded-xl bg-white px-4 py-2.5 font-bold text-slate-900 hover:bg-emerald-50">
              {completedCount ? 'Tiếp tục học' : 'Học bài đầu tiên'} · {nextLesson.title}
            </button>
          )}
          <div className="flex flex-wrap items-center gap-3 mt-5 text-xs font-bold">
            <div className="bg-black/20 backdrop-blur px-3 py-1.5 rounded-xl flex items-center gap-1.5">
              <span>Đã hoàn thành:</span>
              <span className="text-amber-300 font-black">
                {completedCount} / {totalLessonsInGrade} bài
              </span>
            </div>
            <div className="bg-black/20 backdrop-blur px-3 py-1.5 rounded-xl flex items-center gap-1.5">
              <span>Sao Vàng:</span>
              <span className="text-amber-300 font-black">⭐ {progress.stars}</span>
            </div>
            {onOpenProfileModal && (
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  onOpenProfileModal('timetable');
                }}
                className="bg-white/25 hover:bg-white/35 active:scale-95 backdrop-blur px-3.5 py-1.5 rounded-xl flex items-center gap-1.5 text-white transition-all cursor-pointer font-bold shadow-xs border border-white/30"
              >
                <Calendar className="w-3.5 h-3.5 text-amber-300" />
                <span>Xem TKB tuần của bé</span>
              </button>
            )}
          </div>
        </div>

        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* Control Bar: Search Input & Semester Filters */}
      <div className="bg-white p-4 rounded-3xl border-2 border-slate-200 shadow-2xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="🔍 Tìm nhanh bài học, chủ đề, tuần học (ví dụ: tuần 5, phân số, chu vi...)"
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:bg-white transition-all"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400 hover:text-slate-600 bg-slate-200 hover:bg-slate-300 rounded-full w-5 h-5 flex items-center justify-center"
            >
              ×
            </button>
          )}
        </div>

        {/* Semester Filter Tabs */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl shrink-0 text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setSemesterFilter('all');
            }}
            className={`px-3 py-2 rounded-xl transition-all ${
              semesterFilter === 'all'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Tất cả bài học
          </button>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setSemesterFilter('sem1');
            }}
            className={`px-3 py-2 rounded-xl transition-all ${
              semesterFilter === 'sem1'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Học Kỳ 1 (T.1 - 18)
          </button>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setSemesterFilter('sem2');
            }}
            className={`px-3 py-2 rounded-xl transition-all ${
              semesterFilter === 'sem2'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Học Kỳ 2 (T.19 - 35)
          </button>
        </div>
      </div>

      {/* Chapters & Lessons Path */}
      {filteredChapters.length === 0 ? (
        <div className="bg-white rounded-3xl border-2 border-slate-200 p-8 text-center my-6">
          <Filter className="w-10 h-10 text-slate-300 mx-auto mb-2" />
          <h3 className="text-base font-bold text-slate-800">Không tìm thấy bài học phù hợp</h3>
          <p className="text-xs text-slate-500 mt-1">
            Thử tìm với từ khóa khác hoặc bấm nút "Tất cả bài học" ở phía trên.
          </p>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setSemesterFilter('all');
            }}
            className="mt-4 px-4 py-2 bg-sky-500 text-white rounded-xl text-xs font-bold hover:bg-sky-600"
          >
            Hiện lại toàn bộ bài học
          </button>
        </div>
      ) : (
        <div className="space-y-8">
          {filteredChapters.map((chapter, cIdx) => (
            <div
              key={chapter.id}
              className="bg-white rounded-3xl border-2 border-slate-200 p-5 md:p-7 shadow-xs"
            >
              {/* Chapter Header */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-slate-200 pb-3 mb-5">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[11px] font-black uppercase tracking-wider text-sky-700 bg-sky-50 border border-sky-200 px-2.5 py-0.5 rounded-lg">
                      Chương {cIdx + 1}
                    </span>
                    <span className="text-[11px] font-bold text-slate-500">
                      GDPT 2018 · Lớp {grade}
                    </span>
                  </div>
                  <h2 className="text-lg md:text-xl font-black text-slate-900 font-display">
                    {chapter.title}
                  </h2>
                  <p className="text-xs md:text-sm text-slate-600 mt-0.5">{chapter.description}</p>
                </div>

                <div className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-600 bg-slate-100 px-3 py-1.5 rounded-xl self-start md:self-auto shrink-0">
                  <BookMarked className="w-3.5 h-3.5 text-slate-500" />
                  {chapter.lessons.length} bài học
                </div>
              </div>

              {/* Lesson Cards in Treasure Path */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {chapter.lessons.map((lesson) => {
                  const lessonProgress = progress.completedLessons[lesson.id];
                  const isCompleted = !!lessonProgress;
                  const starsCount = lessonProgress?.stars || 0;
                  const weekNum = lesson.week || 1;

                  return (
                    <div
                      key={lesson.id}
                      className={`relative p-5 rounded-2xl border-2 transition-all duration-200 flex flex-col justify-between ${
                        isCompleted
                          ? 'bg-emerald-50/50 border-emerald-300 hover:border-emerald-400'
                          : 'bg-white border-slate-200 hover:border-sky-300 hover:shadow-md'
                      }`}
                    >
                      <div>
                        {/* Tags Header */}
                        <div className="flex items-center justify-between gap-2 mb-2">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-[10px] font-black uppercase tracking-wider text-sky-800 bg-sky-100 px-2 py-0.5 rounded-md">
                              Tuần {weekNum}
                            </span>
                            <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md">
                              {lesson.strand}
                            </span>
                            {lesson.semester && (
                              <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded-md">
                                HK{lesson.semester}
                              </span>
                            )}
                          </div>

                          {/* Stars badge */}
                          <div className="flex items-center gap-0.5 bg-white border border-slate-200 px-2 py-0.5 rounded-xl shadow-2xs shrink-0">
                            {[1, 2, 3].map((s) => (
                              <Star
                                key={s}
                                className={`w-3.5 h-3.5 ${
                                  s <= starsCount
                                    ? 'text-amber-500 fill-amber-400'
                                    : 'text-slate-200'
                                }`}
                              />
                            ))}
                          </div>
                        </div>

                        {/* Lesson Title */}
                        <h3 className="text-base font-bold text-slate-900 group-hover:text-sky-600 transition-colors">
                          {lesson.title}
                        </h3>

                        {/* Description */}
                        <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                          {lesson.description}
                        </p>

                        {/* Theory snippet if present */}
                        {lesson.theory && (
                          <div className="mt-2.5 bg-amber-50/70 border border-amber-200/80 rounded-xl p-2.5 text-[11px] text-amber-900 flex items-start gap-1.5">
                            <BookOpen className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                            <span className="line-clamp-2 font-medium">
                              <strong>Lý thuyết:</strong> {lesson.theory.summary}
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Action Bar */}
                      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                        <span className="text-[11px] font-medium text-slate-500">
                          {isCompleted ? (
                            <span className="inline-flex items-center gap-1 text-emerald-700 font-bold">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Đã hoàn thành ({starsCount}⭐)
                            </span>
                          ) : (
                            '10 câu hỏi thử thách'
                          )}
                        </span>

                        <button
                          type="button"
                          onClick={() => {
                            playClickSound();
                            onSelectLesson(lesson);
                          }}
                          className={`py-2 px-4 rounded-xl border-b-3 font-bold text-xs flex items-center gap-1.5 btn-tactile shadow-xs cursor-pointer ${
                            isCompleted
                              ? 'bg-emerald-600 hover:bg-emerald-700 border-emerald-800 text-white'
                              : `${currentTheme.primaryBg} ${currentTheme.primaryHover} ${currentTheme.primaryBorder} text-white`
                          }`}
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                          {isCompleted ? 'Ôn tập lại' : 'Bắt đầu học'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
