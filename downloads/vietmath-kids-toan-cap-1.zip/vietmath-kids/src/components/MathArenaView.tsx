import { addAnswer, type AttemptResult, type StrandTotals } from '../utils/assessment';
import React, { useState, useEffect, useRef } from 'react';
import { Grade } from '../types';
import { GRADE_THEMES } from '../data/curriculumData';
import {
  Trophy,
  Zap,
  Timer,
  Flame,
  Star,
  RotateCcw,
  Play,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  playCorrectSound,
  playWrongSound,
  playClickSound,
  playWinFanfare,
  playStreakSound,
} from '../utils/soundAndSpeech';

interface Props {
  grade: Grade;
  studentName?: string;
  highScore: number;
  onUpdateHighScore: (score: number, result: AttemptResult) => void;
}

interface ArenaQuestion {
  question: string;
  correctAnswer: number;
  options: number[];
}

export const MathArenaView: React.FC<Props> = ({
  grade,
  studentName = 'Bé',
  highScore,
  onUpdateHighScore,
}) => {
  const currentTheme = GRADE_THEMES[grade];

  const [gameState, setGameState] = useState<'idle' | 'playing' | 'gameover'>('idle');
  const run = useRef({ answered: 0, correct: 0, started: 0, saved: false, strands: {} as StrandTotals });
  const [timeLeft, setTimeLeft] = useState(60);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [currentQ, setCurrentQ] = useState<ArenaQuestion | null>(null);

  // Generate dynamic grade-appropriate mental math question
  const generateArenaQuestion = (): ArenaQuestion => {
    let q = '';
    let ans = 0;

    if (grade === 1) {
      // Numbers up to 10 or 20
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 9) + 1;
      const isPlus = Math.random() > 0.4;
      if (isPlus) {
        q = `${a} + ${b} = ?`;
        ans = a + b;
      } else {
        const big = Math.max(a, b);
        const small = Math.min(a, b);
        q = `${big} - ${small} = ?`;
        ans = big - small;
      }
    } else if (grade === 2) {
      // 2-digit addition or times 2, 5
      const type = Math.random();
      if (type < 0.4) {
        const a = Math.floor(Math.random() * 40) + 10;
        const b = Math.floor(Math.random() * 30) + 5;
        q = `${a} + ${b} = ?`;
        ans = a + b;
      } else if (type < 0.7) {
        const factor = Math.random() > 0.5 ? 2 : 5;
        const n = Math.floor(Math.random() * 9) + 1;
        q = `${factor} × ${n} = ?`;
        ans = factor * n;
      } else {
        const factor = Math.random() > 0.5 ? 2 : 5;
        const n = Math.floor(Math.random() * 9) + 1;
        const prod = factor * n;
        q = `${prod} : ${factor} = ?`;
        ans = n;
      }
    } else if (grade === 3) {
      // Tables 3, 4, 6, 7, 8, 9
      const table = [3, 4, 6, 7, 8, 9][Math.floor(Math.random() * 6)];
      const n = Math.floor(Math.random() * 9) + 1;
      const isMult = Math.random() > 0.35;
      if (isMult) {
        q = `${table} × ${n} = ?`;
        ans = table * n;
      } else {
        const prod = table * n;
        q = `${prod} : ${table} = ?`;
        ans = n;
      }
    } else if (grade === 4) {
      // Multiplication / Division / Average
      const type = Math.random();
      if (type < 0.5) {
        const a = Math.floor(Math.random() * 15) + 10;
        const b = Math.floor(Math.random() * 8) + 2;
        q = `${a} × ${b} = ?`;
        ans = a * b;
      } else {
        const a = Math.floor(Math.random() * 80) + 20;
        const b = Math.floor(Math.random() * 50) + 10;
        q = `${a} + ${b} = ?`;
        ans = a + b;
      }
    } else {
      // Grade 5: Decimals or percentages
      const type = Math.random();
      if (type < 0.5) {
        const a = (Math.floor(Math.random() * 20) + 5) / 10; // 0.5 to 2.5
        const b = Math.floor(Math.random() * 8) + 2;
        ans = Math.round(a * b * 10) / 10;
        q = `${a.toString().replace('.', ',')} × ${b} = ?`;
      } else {
        const a = Math.floor(Math.random() * 90) + 10;
        const b = Math.floor(Math.random() * 60) + 15;
        ans = a + b;
        q = `${a} + ${b} = ?`;
      }
    }

    // 4 Distinct options
    const optionsSet = new Set<number>();
    optionsSet.add(ans);
    while (optionsSet.size < 4) {
      const delta = [1, -1, 2, -2, 5, -5, 10, -10][Math.floor(Math.random() * 8)];
      const fake = Math.max(0, ans + delta);
      optionsSet.add(fake);
    }

    const options = Array.from(optionsSet).sort(() => Math.random() - 0.5);

    return { question: q, correctAnswer: ans, options };
  };

  const handleStartGame = () => {
    playClickSound();
    run.current = { answered: 0, correct: 0, started: Date.now(), saved: false, strands: {} };
    setScore(0);
    setCombo(0);
    setTimeLeft(60);
    setCurrentQ(generateArenaQuestion());
    setGameState('playing');
  };

  // Timer countdown
  useEffect(() => {
    if (gameState !== 'playing') return;

    if (timeLeft <= 0 && !run.current.saved) {
      run.current.saved = true;
      setGameState('gameover');
      playWinFanfare();

      const stars = score > 0 ? Math.max(3, Math.floor(score / 20)) : 0;
      const { answered, correct, strands } = run.current;
      onUpdateHighScore(score, { title: `Đấu trường tính nhẩm lớp ${grade}`, answered, correct, seconds: 60, stars, strands });

      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {}
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(Math.max(0, 60 - Math.floor((Date.now() - run.current.started) / 1000)));
    }, 200);

    return () => clearInterval(timer);
  }, [gameState, timeLeft, score]);

  const handleAnswer = (selected: number) => {
    if (!currentQ || gameState !== 'playing' || Date.now() - run.current.started >= 60000) return;
    run.current.answered++;
    run.current.correct += Number(selected === currentQ.correctAnswer);
    addAnswer(run.current.strands, 'Số & Phép tính', selected === currentQ.correctAnswer);

    if (selected === currentQ.correctAnswer) {
      playCorrectSound();
      const points = 10 + combo * 2;
      setScore((prev) => prev + points);
      const newCombo = combo + 1;
      setCombo(newCombo);
      if (newCombo % 3 === 0) playStreakSound();
    } else {
      playWrongSound();
      setCombo(0);
    }

    setCurrentQ(generateArenaQuestion());
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* Arena Header */}
      <div className={`p-6 md:p-8 rounded-3xl bg-gradient-to-r ${currentTheme.gradient} text-white shadow-xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6`}>
        <div className="relative z-10 max-w-xl text-center md:text-left">
          <div className="inline-flex items-center gap-1.5 bg-white/20 backdrop-blur px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-3">
            <Trophy className="w-3.5 h-3.5 text-amber-300" />
            Đấu trường tốc độ 60 giây
          </div>
          <h1 className="text-2xl md:text-3xl font-black font-display mb-2">
            Đấu Trường Tính Nhẩm Lớp {grade} 🏆
          </h1>
          <p className="text-white/90 text-sm leading-relaxed">
            Thử thách phản xạ tính nhanh không giới hạn! Giải đúng liên tiếp để kích hoạt Combo điểm x2, x3 và nhận thêm Sao Vàng tích lũy!
          </p>
        </div>

        {/* High score box */}
        <div className="relative z-10 bg-white/15 backdrop-blur border-2 border-white/30 rounded-3xl p-5 text-center min-w-[180px] shadow-lg">
          <span className="text-[11px] font-black uppercase tracking-wider text-amber-200">
            Kỷ Lục Của {studentName}
          </span>
          <div className="text-4xl font-black text-white mt-1">
            {highScore} <span className="text-xs text-amber-200">Điểm</span>
          </div>
        </div>
      </div>

      {/* Game Playing Stage */}
      {gameState === 'idle' && (
        <div className="bg-white rounded-3xl border-2 border-slate-200 p-8 md:p-12 text-center shadow-xs">
          <div className="w-24 h-24 bg-amber-100 rounded-full border-4 border-amber-300 flex items-center justify-center mx-auto mb-5 text-4xl shadow-inner animate-bounce">
            ⚡
          </div>
          <h2 className="text-2xl font-black text-slate-800 font-display mb-2">
            Sẵn sàng thi đấu chưa nào, {studentName}?
          </h2>
          <p className="text-sm text-slate-600 max-w-md mx-auto mb-8 leading-relaxed">
            Con có <strong>60 giây</strong> để giải càng nhiều phép tính nhẩm càng tốt. Mỗi câu đúng được cộng điểm và Sao Vàng!
          </p>

          <button
            type="button"
            onClick={handleStartGame}
            className={`py-4 px-10 rounded-2xl border-b-4 text-white font-black text-lg ${currentTheme.primaryBg} ${currentTheme.primaryBorder} btn-tactile shadow-lg inline-flex items-center gap-2`}
          >
            <Play className="w-6 h-6 fill-current" />
            Bắt đầu đếm ngược 60s ngay!
          </button>
        </div>
      )}

      {gameState === 'playing' && currentQ && (
        <div className="bg-white rounded-3xl border-4 border-slate-200 p-6 md:p-8 shadow-2xl animate-fade-in max-w-xl mx-auto">
          {/* Top Info Bar */}
          <div className="flex items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <Timer className={`w-6 h-6 ${timeLeft <= 10 ? 'text-rose-500 animate-spin' : 'text-slate-600'}`} />
              <span className={`text-2xl font-black tabular-nums ${timeLeft <= 10 ? 'text-rose-600 font-mono' : 'text-slate-800'}`}>
                {timeLeft}s
              </span>
            </div>

            <div className="text-center">
              <span className="text-xs font-bold text-slate-500 block">Điểm số</span>
              <span className="text-3xl font-black text-sky-600 tabular-nums">{score}</span>
            </div>

            <div className="flex items-center gap-1.5">
              {combo >= 2 && (
                <div className="flex items-center gap-1 bg-amber-100 border border-amber-300 text-amber-800 px-3 py-1 rounded-xl text-xs font-black animate-pulse">
                  <Flame className="w-4 h-4 text-amber-600 fill-amber-500" />
                  x{combo}
                </div>
              )}
            </div>
          </div>

          {/* Big Math Question */}
          <div className="bg-slate-50 border-2 border-slate-200 rounded-3xl p-8 text-center my-6 shadow-inner">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-widest block mb-2">
              Tính nhanh kết quả
            </span>
            <div className="text-4xl md:text-5xl font-black text-slate-900 font-mono tracking-wider">
              {currentQ.question}
            </div>
          </div>

          {/* 4 Choices */}
          <div className="grid grid-cols-2 gap-3.5">
            {currentQ.options.map((opt, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleAnswer(opt)}
                className="py-5 px-4 rounded-2xl border-3 border-slate-200 bg-white hover:bg-sky-50 hover:border-sky-400 active:border-b-0 active:translate-y-1 text-2xl font-black text-slate-800 transition-all shadow-sm font-mono"
              >
                {opt}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Game Over Screen */}
      {gameState === 'gameover' && (
        <div className="bg-white rounded-3xl border-4 border-slate-200 p-8 md:p-10 text-center shadow-2xl animate-fade-in max-w-xl mx-auto">
          <div className="w-20 h-20 bg-amber-100 rounded-full border-4 border-amber-400 flex items-center justify-center mx-auto mb-4 text-3xl animate-bounce">
            🏆
          </div>

          <h2 className="text-2xl font-black text-slate-800 font-display mb-1">
            Hết Giờ! Đấu Trường Hoàn Tất 🎉
          </h2>
          <p className="text-xs text-slate-500 mb-6">
            Thầy Cú Mèo khen {studentName} phản xạ tính toán cực kỳ nhanh nhẹn!
          </p>

          <div className="grid grid-cols-2 gap-4 bg-slate-50 rounded-2xl p-4 border border-slate-200 mb-6">
            <div>
              <span className="text-xs font-bold text-slate-500">Điểm số đợt này</span>
              <p className="text-3xl font-black text-sky-600 tabular-nums">{score}</p>
            </div>
            <div>
              <span className="text-xs font-bold text-slate-500">Kỷ lục cao nhất</span>
              <p className="text-3xl font-black text-amber-600 tabular-nums">
                {Math.max(score, highScore)}
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <button
              type="button"
              onClick={handleStartGame}
              className={`flex-1 py-3.5 px-4 rounded-2xl border-b-4 text-white font-black text-base ${currentTheme.primaryBg} ${currentTheme.primaryBorder} btn-tactile shadow-md flex items-center justify-center gap-2`}
            >
              <RotateCcw className="w-5 h-5" /> Chơi Lại 60s
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
