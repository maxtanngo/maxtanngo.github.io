import React from 'react';

interface Props {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  brandTitle?: string;
  subtitle?: string;
  className?: string;
}

export const MaxNgoLogo: React.FC<Props> = ({
  size = 'md',
  showText = true,
  brandTitle = 'VietMath Kids',
  subtitle = 'maxngo.io.vn',
  className = '',
}) => {
  const sizeMap = {
    sm: { box: 'w-8 h-8', svg: 'w-8 h-8', text: 'text-sm', sub: 'text-[9px]' },
    md: { box: 'w-10 h-10', svg: 'w-10 h-10', text: 'text-base', sub: 'text-[10px]' },
    lg: { box: 'w-12 h-12', svg: 'w-12 h-12', text: 'text-lg', sub: 'text-xs' },
  };

  const currentSize = sizeMap[size];

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      {/* Brand Squircle Logo with Deep Navy Base, Stylized M & Green Corner Dot */}
      <div className={`relative ${currentSize.box} shrink-0 drop-shadow-sm`}>
        <svg
          viewBox="0 0 100 100"
          className={`${currentSize.svg} rounded-[22px] overflow-hidden`}
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Deep Navy Gradient Background */}
          <defs>
            <linearGradient id="maxngoBg" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#0B2356" />
              <stop offset="50%" stopColor="#091A42" />
              <stop offset="100%" stopColor="#06122E" />
            </linearGradient>
            <linearGradient id="mGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#E0F2FE" />
            </linearGradient>
            <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Squircle Base */}
          <rect width="100" height="100" rx="26" fill="url(#maxngoBg)" />

          {/* Subtle inner border glow */}
          <rect
            x="2"
            y="2"
            width="96"
            height="96"
            rx="24"
            stroke="rgba(255,255,255,0.18)"
            strokeWidth="2"
          />

          {/* Stylized Modern "M" */}
          <path
            d="M26 72V30L50 52L74 30V72H62V46L50 57L38 46V72H26Z"
            fill="url(#mGradient)"
          />

          {/* Signature Lime-Green Dot at corner of M */}
          <circle
            cx="76"
            cy="24"
            r="7"
            fill="#22C55E"
            filter="url(#glow)"
          />
          <circle
            cx="76"
            cy="24"
            r="6.5"
            fill="#4ADE80"
          />
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col leading-tight">
          <div className="flex items-center gap-1.5">
            <span className={`font-black text-slate-900 tracking-tight font-display ${currentSize.text}`}>
              {brandTitle}
            </span>
            <span className="text-[10px] font-black uppercase tracking-wider px-1.5 py-0.2 rounded-md bg-emerald-100 text-emerald-800 border border-emerald-200">
              2026
            </span>
          </div>
          <span className={`text-slate-500 font-semibold tracking-wide ${currentSize.sub}`}>
            {subtitle}
          </span>
        </div>
      )}
    </div>
  );
};
