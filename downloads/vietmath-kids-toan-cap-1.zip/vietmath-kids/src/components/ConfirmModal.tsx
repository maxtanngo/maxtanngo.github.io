import React from 'react';
import { AlertTriangle, Trash2, RefreshCw, X } from 'lucide-react';

interface Props {
  isOpen: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'danger' | 'warning' | 'info';
  itemDetails?: { label: string; value: string }[];
  isProcessing?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmModal: React.FC<Props> = ({
  isOpen,
  title,
  message,
  confirmLabel = 'Xác nhận xóa',
  cancelLabel = 'Hủy bỏ',
  variant = 'danger',
  itemDetails,
  isProcessing = false,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl border-2 border-slate-200 shadow-2xl max-w-md w-full overflow-hidden animate-in zoom-in-95 duration-150">
        {/* Top Header */}
        <div
          className={`p-5 flex items-start gap-4 border-b ${
            variant === 'danger'
              ? 'bg-rose-50 border-rose-100 text-rose-900'
              : variant === 'warning'
              ? 'bg-amber-50 border-amber-100 text-amber-900'
              : 'bg-sky-50 border-sky-100 text-sky-900'
          }`}
        >
          <div
            className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 shadow-xs ${
              variant === 'danger'
                ? 'bg-rose-500 text-white'
                : variant === 'warning'
                ? 'bg-amber-500 text-white'
                : 'bg-sky-500 text-white'
            }`}
          >
            {variant === 'danger' ? (
              <Trash2 className="w-5 h-5" />
            ) : (
              <AlertTriangle className="w-5 h-5" />
            )}
          </div>
          <div className="flex-1 pr-2">
            <h3 className="text-base font-black leading-snug">{title}</h3>
            <p className="text-xs font-semibold mt-1 opacity-90 leading-relaxed">{message}</p>
          </div>
          <button
            type="button"
            disabled={isProcessing}
            onClick={onCancel}
            className="p-1 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Item Details if any */}
        {itemDetails && itemDetails.length > 0 && (
          <div className="p-5 bg-slate-50/70 border-b border-slate-100 space-y-2 text-xs">
            {itemDetails.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between gap-3">
                <span className="text-slate-500 font-medium">{item.label}:</span>
                <span className="text-slate-800 font-bold truncate max-w-[240px] text-right">
                  {item.value}
                </span>
              </div>
            ))}
          </div>
        )}

        {/* Action Buttons */}
        <div className="p-4 bg-white flex items-center justify-end gap-2.5">
          <button
            type="button"
            disabled={isProcessing}
            onClick={onCancel}
            className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 font-bold text-xs transition-colors"
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            disabled={isProcessing}
            onClick={onConfirm}
            className={`px-5 py-2.5 rounded-xl text-white font-black text-xs shadow-sm flex items-center gap-1.5 transition-all active:scale-95 ${
              variant === 'danger'
                ? 'bg-rose-600 hover:bg-rose-700'
                : variant === 'warning'
                ? 'bg-amber-600 hover:bg-amber-700'
                : 'bg-sky-600 hover:bg-sky-700'
            } disabled:opacity-50`}
          >
            {isProcessing && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
};
