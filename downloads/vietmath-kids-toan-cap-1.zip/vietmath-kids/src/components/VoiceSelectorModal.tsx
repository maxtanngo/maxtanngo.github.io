import React, { useState } from 'react';
import {
  VOICE_PROFILES,
  getVoiceProfile,
  previewVoice,
  stopSpeaking,
} from '../services/ttsService';
import { playClickSound, playCorrectSound } from '../utils/soundAndSpeech';
import {
  Volume2,
  VolumeX,
  Check,
  Sparkles,
  X,
  Settings,
  Key,
  Radio,
  Sliders,
  CheckCircle2,
} from 'lucide-react';

interface Props {
  currentVoiceId: string;
  onSelectVoice: (voiceId: string) => void;
  onClose: () => void;
}

export const VoiceSelectorModal: React.FC<Props> = ({
  currentVoiceId,
  onSelectVoice,
  onClose,
}) => {
  const [testingVoiceId, setTestingVoiceId] = useState<string | null>(null);
  const [showFptSettings, setShowFptSettings] = useState(false);
  const [fptApiKey, setFptApiKey] = useState(
    () => (typeof window !== 'undefined' ? localStorage.getItem('vietmath_fpt_key') || '' : '')
  );
  const [fptSavedMsg, setFptSavedMsg] = useState(false);

  const handleTestVoice = (voiceId: string) => {
    playClickSound();
    if (testingVoiceId === voiceId) {
      stopSpeaking();
      setTestingVoiceId(null);
      return;
    }

    setTestingVoiceId(voiceId);
    previewVoice(
      voiceId,
      () => setTestingVoiceId(voiceId),
      () => setTestingVoiceId(null)
    );
  };

  const handleSaveFptKey = () => {
    playClickSound();
    if (typeof window !== 'undefined') {
      localStorage.setItem('vietmath_fpt_key', fptApiKey.trim());
      setFptSavedMsg(true);
      playCorrectSound();
      setTimeout(() => setFptSavedMsg(false), 3000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fade-in">
      <div className="bg-white rounded-3xl border-4 border-slate-200 shadow-2xl max-w-xl w-full p-5 sm:p-7 relative flex flex-col max-h-[92vh]">
        {/* Close Button */}
        <button
          type="button"
          onClick={() => {
            playClickSound();
            stopSpeaking();
            onClose();
          }}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-2 shrink-0">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-sky-400 to-indigo-600 text-white flex items-center justify-center text-xl shadow-md shrink-0">
            🎙️
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xl font-black text-slate-900 font-display">
                Chọn Giọng Đọc Đồng Hành
              </h3>
              <span className="text-[10px] font-black uppercase tracking-wider bg-indigo-100 text-indigo-700 border border-indigo-200 px-2 py-0.5 rounded-full">
                Gemini Native TTS
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Giọng đọc cảm xúc, ngắt nghỉ tự nhiên như giáo viên thật & phân biệt rõ vùng miền
            </p>
          </div>
        </div>

        {/* Subtitle Banner */}
        <div className="bg-sky-50/80 border border-sky-200 p-2.5 rounded-2xl text-xs text-sky-900 flex items-center justify-between gap-2 mb-4 shrink-0">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-sky-600 shrink-0" />
            <span>
              Tích hợp <strong>Audio Cache</strong> giúp đọc tức thì, không giật lag!
            </span>
          </div>
          <span className="text-[10px] font-bold bg-white px-2 py-0.5 rounded-lg border border-sky-200 text-sky-700 shrink-0">
            6 Giọng đa dạng
          </span>
        </div>

        {/* Voice Cards List */}
        <div className="space-y-3 overflow-y-auto pr-1 flex-1 scrollbar-thin">
          {VOICE_PROFILES.map((v) => {
            const isSelected = currentVoiceId === v.id;
            const isPlaying = testingVoiceId === v.id;

            return (
              <div
                key={v.id}
                className={`p-3.5 sm:p-4 rounded-2xl border-2 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  isSelected
                    ? 'bg-sky-50/80 border-sky-400 ring-2 ring-sky-200 shadow-sm'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Voice info */}
                <div className="flex items-start gap-3 flex-1">
                  <span className="text-2xl p-2 bg-white rounded-xl border border-slate-200 shadow-2xs shrink-0 mt-0.5">
                    {v.avatar}
                  </span>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="font-extrabold text-sm text-slate-900">{v.name}</h4>
                    </div>

                    <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                      <span className="text-[11px] font-bold text-sky-700 bg-sky-100/70 px-2 py-0.5 rounded-md">
                        {v.tag}
                      </span>
                      <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded-md">
                        {v.region}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      {v.description}
                    </p>

                    {v.id === 'fpt-custom' && (
                      <button
                        type="button"
                        onClick={() => setShowFptSettings(!showFptSettings)}
                        className="mt-1 text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                      >
                        <Settings className="w-3 h-3" />
                        {showFptSettings ? 'Ẩn cấu hình API' : 'Cấu hình API Key FPT.AI / ElevenLabs'}
                      </button>
                    )}
                  </div>
                </div>

                {/* Buttons */}
                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                  <button
                    type="button"
                    onClick={() => handleTestVoice(v.id)}
                    title={`Nghe thử giọng: ${v.shortName}`}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                      isPlaying
                        ? 'bg-rose-100 border-rose-300 text-rose-700 animate-pulse'
                        : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
                    }`}
                  >
                    {isPlaying ? (
                      <VolumeX className="w-3.5 h-3.5" />
                    ) : (
                      <Volume2 className="w-3.5 h-3.5 text-sky-600" />
                    )}
                    <span>{isPlaying ? 'Dừng' : 'Nghe thử'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      stopSpeaking();
                      onSelectVoice(v.id);
                    }}
                    className={`py-2 px-3.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-sky-600 text-white cursor-default shadow-xs'
                        : 'bg-slate-900 hover:bg-slate-800 text-white shadow-xs'
                    }`}
                  >
                    {isSelected ? (
                      <span className="flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> Đang dùng
                      </span>
                    ) : (
                      'Chọn giọng'
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* FPT / ElevenLabs Settings Drawer */}
        {showFptSettings && (
          <div className="mt-3 p-3 bg-indigo-50 border border-indigo-200 rounded-2xl animate-fade-in shrink-0">
            <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-900 mb-1.5">
              <Key className="w-3.5 h-3.5 text-indigo-600" />
              <span>Cài đặt API Key FPT.AI / ElevenLabs (Tùy chọn)</span>
            </div>
            <p className="text-[11px] text-slate-600 mb-2">
              Nếu bạn có API Key từ FPT.AI hoặc ElevenLabs, nhập vào đây để ứng dụng ưu tiên sử dụng.
            </p>
            <div className="flex items-center gap-2">
              <input
                type="password"
                value={fptApiKey}
                onChange={(e) => setFptApiKey(e.target.value)}
                placeholder="Nhập API Key FPT.AI hoặc ElevenLabs..."
                className="flex-1 bg-white border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
              <button
                type="button"
                onClick={handleSaveFptKey}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                Lưu
              </button>
            </div>
            {fptSavedMsg && (
              <span className="text-[11px] text-emerald-700 font-bold mt-1 inline-flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Đã lưu API key thành công!
              </span>
            )}
          </div>
        )}

        {/* Footer */}
        <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-slate-500 font-medium">
            Giọng đọc hiện tại:{' '}
            <strong className="text-slate-800">
              {getVoiceProfile(currentVoiceId).name}
            </strong>
          </span>

          <button
            type="button"
            onClick={() => {
              playClickSound();
              stopSpeaking();
              onClose();
            }}
            className="py-2.5 px-6 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-black shadow-xs cursor-pointer"
          >
            Hoàn tất
          </button>
        </div>
      </div>
    </div>
  );
};
