import { staticRelease } from '../utils/releaseMode';
import React from 'react';
import { Grade } from '../types';
import { GRADE_THEMES } from '../data/curriculumData';
import {
  Map,
  Gamepad2,
  Trophy,
  Bot,
  Gift,
  BarChart3,
  PenTool,
  Sparkles,
  ExternalLink,
  Bug,
  User,
  Cloud,
} from 'lucide-react';
import { playClickSound } from '../utils/soundAndSpeech';

export type TabKey = 'path' | 'exam' | 'arena' | 'tutor' | 'store' | 'parent' | 'drive' | 'author';

interface Props {
  activeTab: TabKey;
  onTabChange: (tab: TabKey) => void;
  grade: Grade;
  onOpenFeedbackModal: () => void;
}

export const Navigation: React.FC<Props> = ({
  activeTab,
  onTabChange,
  grade,
  onOpenFeedbackModal,
}) => {
  const currentTheme = GRADE_THEMES[grade];
  const NAV_ITEMS: { id: TabKey; label: string; shortLabel: string; icon: React.FC<{ className?: string }>; badge?: string }[] = [
    { id: 'path', shortLabel: 'Học tập', label: 'Bản Đồ Học Tập', icon: Map },
    { id: 'exam', shortLabel: staticRelease ? 'Luyện đề' : 'Đề AI', label: staticRelease ? 'Luyện đề' : 'Luyện Tập AI', icon: Gamepad2, badge: 'TT27' },
    { id: 'arena', shortLabel: 'Đấu 60s', label: 'Đấu Trường', icon: Trophy, badge: '60s' },
    { id: 'tutor', shortLabel: 'Gia sư', label: staticRelease ? 'Hỏi Gia Sư' : 'Hỏi Gia Sư AI', icon: Bot, badge: 'AI' },
    { id: 'store', shortLabel: 'Cửa hàng', label: 'Cửa Hàng Sao', icon: Gift },
    { id: 'parent', shortLabel: 'Báo cáo', label: 'Báo Cáo', icon: BarChart3 },
    { id: 'drive', shortLabel: 'Drive', label: 'Google Drive', icon: Cloud, badge: 'Đồng bộ' },
    { id: 'author', shortLabel: 'Tác giả', label: 'Góc Tác Giả & Góp Ý', icon: PenTool, badge: 'MaxNgo' },
  ];

  const visibleItems = NAV_ITEMS.filter(item => !staticRelease || item.id !== 'drive');

  return (
    <>
      {/* Desktop Sidebar (Left side) */}
      <aside className="hidden lg:flex flex-col w-64 bg-white border-r-2 border-slate-200 p-4 shrink-0 min-h-[calc(100vh-65px)]">
        {/* Grade info badge */}
        <div className="mb-3 px-1">
          <div className={`p-2.5 rounded-2xl ${currentTheme.lightBg} border-2 ${currentTheme.ringColor} flex items-center gap-2.5 shadow-2xs`}>
            <div className={`w-8 h-8 rounded-xl ${currentTheme.primaryBg} text-white flex items-center justify-center font-black text-xs shadow-xs shrink-0`}>
              L{grade}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-black text-slate-800 truncate">{currentTheme.badge}</p>
              <p className="text-[10px] text-slate-500 font-medium truncate">{currentTheme.name.split('-')[1]?.trim()}</p>
            </div>
          </div>
        </div>

        <nav className="space-y-1.5 flex-1">
          {visibleItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  playClickSound();
                  onTabChange(item.id);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold text-xs md:text-sm transition-all text-left ${
                  isActive
                    ? `${currentTheme.primaryBg} text-white shadow-md border-b-3 ${currentTheme.primaryBorder} btn-tactile`
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[10px] font-black px-1.5 py-0.5 rounded-md shrink-0 ${
                      isActive
                        ? 'bg-white/25 text-white'
                        : item.badge === 'MaxNgo'
                        ? 'bg-blue-100 text-blue-900 font-extrabold'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Author / Studio Corner */}
        <div className="pt-3 border-t border-slate-200 text-xs mt-auto">
          <div className="flex items-center justify-between gap-1 text-[11px] text-slate-600 mb-1.5">
            <span>Tác giả: <strong className="text-slate-800 font-bold">Ngô Thanh Tân</strong></span>
            <a
              href="https://maxngo.io.vn"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sky-600 hover:text-sky-700 font-bold inline-flex items-center gap-0.5 hover:underline"
            >
              maxngo.io.vn <ExternalLink className="w-2.5 h-2.5" />
            </a>
          </div>

          <button
            type="button"
            onClick={() => {
              playClickSound();
              onTabChange('author');
            }}
            className="w-full py-2 px-2.5 rounded-xl bg-slate-50 hover:bg-amber-50 border border-slate-200 hover:border-amber-300 text-slate-700 hover:text-amber-900 text-[11px] font-bold flex items-center justify-center gap-1.5 transition-colors shadow-2xs"
          >
            <span>Góp ý về VietMath Kids</span>
          </button>
        </div>
      </aside>

      {/* Mobile Bottom Navigation Bar */}
      <nav aria-label="Điều hướng học tập" className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur border-t-2 border-slate-200 px-1 py-1 shadow-lg grid grid-cols-4 sm:grid-cols-8">
        {visibleItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                playClickSound();
                onTabChange(item.id);
              }}
              className={`flex flex-col items-center justify-center py-1 px-1.5 rounded-xl transition-all relative shrink-0 min-w-0 min-h-10 ${
                isActive
                  ? `${currentTheme.textColor} font-black`
                  : 'text-slate-500 font-semibold hover:text-slate-800'
              }`}
            >
              <div
                className={`p-1 rounded-xl transition-all ${
                  isActive ? `${currentTheme.lightBg}` : ''
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? currentTheme.textColor : 'text-slate-500'}`} />
              </div>
              <span className="text-[10px] mt-0.5 whitespace-nowrap">{item.shortLabel}</span>
              {item.badge && (
                <span className="absolute top-0.5 right-1.5 w-1.5 h-1.5 rounded-full bg-amber-500" />
              )}
            </button>
          );
        })}
      </nav>
    </>
  );
};
