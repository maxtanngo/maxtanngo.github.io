import React, { useState } from 'react';
import { VisualData } from '../types';
import { Apple, Star, Candy, Fish, Flower2, Pencil, Car, Clock as ClockIcon } from 'lucide-react';

interface Props {
  type: string;
  data?: VisualData;
}

export const VisualMathWidget: React.FC<Props> = ({ type, data }) => {
  const [clickedItems, setClickedItems] = useState<number[]>([]);

  if (!data) return null;

  // 1. VISUAL COUNTING (Lớp 1-2)
  if (type === 'visual_count') {
    const count = data.countNumber ?? 4;
    const items = Array.from({ length: count }, (_, i) => i + 1);

    const Icon = { apple: Apple, star: Star, candy: Candy, fish: Fish, flower: Flower2, pencil: Pencil }[data.countItem ?? 'apple'] ?? Apple;
    const toggleItem = (idx: number) => {
      setClickedItems(previous => previous.includes(idx) ? previous.filter(i => i !== idx) : [...previous, idx]);
    };

    return (
      <div className="bg-amber-50/70 border-2 border-amber-200 rounded-3xl p-6 text-center my-4 shadow-inner">
        <p className="text-xs font-semibold text-amber-800 uppercase tracking-wider mb-3">
          Chạm vào từng hình để đếm (Đã đếm: {clickedItems.length}/{count})
        </p>
        <div className="flex flex-wrap items-center justify-center gap-4 py-2">
          {items.map((num) => {
            const isCounted = clickedItems.includes(num);
            return (
              <button
                key={num}
                type="button"
                aria-label={`Hình ${num}`}
                aria-pressed={isCounted}
                onClick={() => toggleItem(num)}
                className={`relative group p-4 rounded-2xl transition-all duration-150 transform hover:scale-110 active:scale-95 ${
                  isCounted
                    ? 'bg-emerald-100 border-2 border-emerald-400 shadow-md ring-2 ring-emerald-300'
                    : 'bg-white border-2 border-amber-200 shadow hover:shadow-lg'
                }`}
              >
                <Icon aria-hidden="true" className={`w-9 h-9 sm:w-12 sm:h-12 ${isCounted ? 'text-emerald-600' : 'text-rose-500'}`} />
                {isCounted && (
                  <span className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-emerald-500 text-white text-xs font-bold flex items-center justify-center shadow">
                    {clickedItems.indexOf(num) + 1}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  // 2. VISUAL CLOCK (Lớp 1-3)
  if (type === 'visual_clock') {
    const hour = data.clockHour || 8;
    const minute = data.clockMinute || 0;

    // Calculate rotation angles
    // Minute hand: 360 deg for 60 min -> 6 deg per minute
    const minuteAngle = minute * 6;
    // Hour hand: 360 deg for 12 hours -> 30 deg per hour + 0.5 deg per minute
    const hourAngle = (hour % 12) * 30 + minute * 0.5;

    return (
      <div className="bg-sky-50/60 border-2 border-sky-200 rounded-3xl p-5 my-4 flex flex-col items-center justify-center">
        <div className="flex items-center gap-2 text-sky-800 text-xs font-bold uppercase tracking-wider mb-2">
          <ClockIcon className="w-4 h-4 text-sky-600" />
          Đồng hồ kim trực quan
        </div>
        <div className="relative w-48 h-48 bg-white rounded-full border-4 border-slate-700 shadow-lg flex items-center justify-center">
          {/* Hour markers 1 to 12 */}
          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((n) => {
            const angle = (n * 30 - 90) * (Math.PI / 180);
            const radius = 72; // Distance from center
            const x = 96 + radius * Math.cos(angle);
            const y = 96 + radius * Math.sin(angle);
            return (
              <span
                key={n}
                className="absolute text-sm font-extrabold text-slate-800"
                style={{
                  left: `${x}px`,
                  top: `${y}px`,
                  transform: 'translate(-50%, -50%)',
                }}
              >
                {n}
              </span>
            );
          })}

          {/* Minute Hand (Blue, Long) */}
          <div
            className="absolute origin-bottom bg-sky-600 rounded-full w-1.5 shadow"
            style={{
              height: '62px',
              bottom: '50%',
              left: 'calc(50% - 3px)',
              transform: `rotate(${minuteAngle}deg)`,
              transition: 'transform 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
            }}
          />

          {/* Hour Hand (Red, Short & Thicker) */}
          <div
            className="absolute origin-bottom bg-rose-500 rounded-full w-2.5 shadow"
            style={{
              height: '44px',
              bottom: '50%',
              left: 'calc(50% - 5px)',
              transform: `rotate(${hourAngle}deg)`,
              transition: 'transform 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
            }}
          />

          {/* Center Pin */}
          <div className="absolute w-4 h-4 bg-amber-400 border-2 border-slate-800 rounded-full z-10 shadow" />
        </div>
        <div className="flex items-center gap-4 mt-3 text-xs font-semibold text-slate-600">
          <span className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-rose-500 inline-block" /> Kim ngắn: Giờ
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-sky-600 inline-block" /> Kim dài: Phút
          </span>
        </div>
      </div>
    );
  }

  // 3. VISUAL FRACTION (Lớp 4)
  if (type === 'visual_fraction') {
    const num = data.fractionNumerator || 3;
    const den = data.fractionDenominator || 5;
    const parts = Array.from({ length: den }, (_, i) => i);

    return (
      <div className="bg-purple-50/80 border-2 border-purple-200 rounded-3xl p-6 my-4">
        <p className="text-xs font-semibold text-purple-800 uppercase tracking-wider text-center mb-3">
          Mô hình phân số trực quan ({num}/{den})
        </p>
        <div className="max-w-md mx-auto">
          {/* Fraction bar */}
          <div className="grid grid-flow-col auto-cols-fr h-16 bg-white border-3 border-purple-800 rounded-2xl overflow-hidden shadow-md">
            {parts.map((p) => {
              const isFilled = p < num;
              return (
                <div
                  key={p}
                  className={`h-full border-r-2 last:border-r-0 border-purple-800 flex items-center justify-center transition-colors ${
                    isFilled ? 'bg-purple-500 text-white font-bold' : 'bg-purple-50 text-purple-300'
                  }`}
                >
                  <span className="text-sm font-semibold">1/{den}</span>
                </div>
              );
            })}
          </div>
          <div className="flex justify-between items-center mt-3 text-xs font-bold text-purple-900 px-1">
            <span>Đã tô màu: {num} phần</span>
            <span>Tổng cộng: {den} phần bằng nhau</span>
          </div>
        </div>
      </div>
    );
  }

  // 4. VISUAL DISTANCE / SPEED (Lớp 5)
  if (type === 'visual_distance') {
    const distance = data.distanceKm || 180;
    const v1 = data.speedV1 || 40;
    const v2 = data.speedV2 || 50;

    return (
      <div className="bg-rose-50/80 border-2 border-rose-200 rounded-3xl p-6 my-4">
        <p className="text-xs font-semibold text-rose-800 uppercase tracking-wider text-center mb-4">
          Sơ đồ chuyển động ngược chiều (Hai xe đi về phía nhau)
        </p>
        <div className="relative pt-6 pb-4 px-4 max-w-lg mx-auto">
          {/* Highway line */}
          <div className="relative h-4 bg-slate-300 rounded-full border border-slate-400 overflow-hidden">
            <div className="absolute inset-y-1 left-2 right-2 border-t-2 border-dashed border-white" />
          </div>

          {/* Points A & B */}
          <div className="flex justify-between items-center text-xs font-bold text-slate-800 mt-2">
            <div className="flex items-center gap-1">
              <span className="w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center text-[10px]">A</span>
              <span>Điểm A (Xe 1)</span>
            </div>
            <div className="text-center font-extrabold text-rose-700 bg-rose-100 px-2.5 py-0.5 rounded-full text-xs">
              Quãng đường s = {distance} km
            </div>
            <div className="flex items-center gap-1">
              <span>Điểm B (Xe 2)</span>
              <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px]">B</span>
            </div>
          </div>

          {/* Vehicles and Velocities */}
          <div className="flex justify-between items-center mt-3">
            <div className="flex items-center gap-1.5 bg-white border border-rose-200 px-3 py-1.5 rounded-xl shadow-sm">
              <Car className="w-4 h-4 text-rose-600" />
              <div className="text-xs">
                <p className="font-bold text-slate-800">Xe đỏ →</p>
                <p className="text-rose-600 font-semibold">{v1} km/h</p>
              </div>
            </div>

            <div className="text-xs font-medium text-slate-500 italic">
              gặp nhau tại điểm C
            </div>

            <div className="flex items-center gap-1.5 bg-white border border-blue-200 px-3 py-1.5 rounded-xl shadow-sm">
              <div className="text-xs text-right">
                <p className="font-bold text-slate-800">← Xe xanh</p>
                <p className="text-blue-600 font-semibold">{v2} km/h</p>
              </div>
              <Car className="w-4 h-4 text-blue-600 transform scale-x-[-1]" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
};
