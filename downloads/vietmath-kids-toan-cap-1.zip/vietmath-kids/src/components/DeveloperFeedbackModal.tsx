import React, { useState } from 'react';
import {
  X,
  Mail,
  ExternalLink,
  Bug,
  Send,
  Check,
  Copy,
  Sparkles,
  ShieldCheck,
  Heart,
} from 'lucide-react';
import { playClickSound } from '../utils/soundAndSpeech';
import { Grade } from '../types';

interface Props {
  currentGrade: Grade;
  onClose: () => void;
}

export const DeveloperFeedbackModal: React.FC<Props> = ({
  currentGrade,
  onClose,
}) => {
  const [feedbackType, setFeedbackType] = useState('Báo lỗi bài tập / đáp án');
  const [feedbackText, setFeedbackText] = useState('');
  const [isCopied, setIsCopied] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const developerEmail = 'tannt4@gmail.com';
  const developerSite = 'https://maxngo.io.vn';

  const fullEmailBody = `Kính gửi Nhà phát triển Ngô Thanh Tân - MaxNgo Studio (tannt4@gmail.com),

Tôi xin gửi đóng góp / báo lỗi cho ứng dụng VietMath Kids 2026:
- Loại phản hồi: ${feedbackType}
- Khối lớp: Lớp ${currentGrade}
- Thiết bị: ${typeof navigator !== 'undefined' ? navigator.userAgent : 'Trình duyệt Web'}
- Thời gian: ${new Date().toLocaleString('vi-VN')}

Nội dung chi tiết:
${feedbackText || '(Chưa nhập nội dung)'}

--------------------------------------------------
VietMath Kids 2026 - MaxNgo Studio`;

  const subject = `[VietMath Kids] ${feedbackType} - Lớp ${currentGrade}`;
  const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(developerEmail)}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(fullEmailBody)}`;
  const mailtoLink = `mailto:${developerEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(fullEmailBody)}`;

  const handleCopy = () => {
    playClickSound();
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(fullEmailBody);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2500);
    }
  };

  const handleSendEmail = () => {
    playClickSound();
    setIsSubmitted(true);
    window.open(gmailUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white rounded-3xl border-4 border-slate-200 shadow-2xl max-w-lg w-full p-6 md:p-8 relative">
        {/* Close Button */}
        <button
          type="button"
          onClick={() => {
            playClickSound();
            onClose();
          }}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Developer Info Card */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-2xl p-5 mb-6 shadow-md relative overflow-hidden">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center text-xl font-black text-amber-300">
              MN
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Tác giả phát triển
                </span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
                  Verified EdTech
                </span>
              </div>
              <h3 className="text-xl font-black text-white font-display">
                MaxNgo
              </h3>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
            <a
              href={developerSite}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-sky-300 hover:text-sky-200 font-bold transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Website: Maxngo.io.vn
            </a>

            <div className="inline-flex items-center gap-1.5 text-amber-200 font-medium">
              <Mail className="w-3.5 h-3.5" />
              Email: Tannt4@gmail.com
            </div>
          </div>
        </div>

        {/* Feedback & Bug Reporting Header */}
        <div className="mb-4">
          <h4 className="text-base font-black text-slate-900 font-display flex items-center gap-2">
            <Bug className="w-4 h-4 text-rose-500" />
            Báo lỗi ứng dụng & Đóng góp ý kiến
          </h4>
          <p className="text-xs text-slate-500 mt-0.5">
            Mọi phản hồi của Quý phụ huynh, thầy cô và học sinh sẽ được xử lý trực tiếp qua email:{' '}
            <span className="font-bold text-slate-800">{developerEmail}</span>
          </p>
        </div>

        {/* Form */}
        <div className="space-y-3">
          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1.5">
              Loại phản hồi
            </label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {[
                'Báo lỗi bài tập / đáp án',
                'Gợi ý tính năng mới',
                'Lỗi âm thanh / giọng đọc',
                'Góp ý nội dung chương trình',
              ].map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setFeedbackType(type);
                  }}
                  className={`py-2 px-3 rounded-xl border text-left font-bold transition-all text-[11px] ${
                    feedbackType === type
                      ? 'bg-sky-50 border-sky-400 text-sky-900 shadow-2xs'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1.5">
              Nội dung góp ý / Mô tả lỗi chi tiết
            </label>
            <textarea
              rows={3}
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
              placeholder="VD: Câu 3 Bài 1 Lớp 3 bị nhầm số, hoặc con muốn thêm tính năng thi đấu toán học..."
              className="w-full text-xs font-medium p-3 rounded-2xl border-2 border-slate-200 focus:border-sky-400 focus:ring-2 focus:ring-sky-100 outline-none resize-none text-slate-800 bg-white"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-5 pt-3 border-t border-slate-200 flex flex-col sm:flex-row gap-2">
          <button
            type="button"
            onClick={handleCopy}
            className="flex-1 py-2.5 px-3 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
          >
            {isCopied ? (
              <>
                <Check className="w-4 h-4 text-emerald-600" />
                Đã sao chép nội dung!
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-slate-500" />
                Sao chép nội dung
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleSendEmail}
            className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-sky-600 to-blue-700 hover:from-sky-700 hover:to-blue-800 text-white text-xs font-black shadow-xs flex items-center justify-center gap-1.5 transition-all active:scale-95"
          >
            <Send className="w-4 h-4" />
            Mở email góp ý
          </button>
        </div>

        {isSubmitted && (
          <div className="mt-4 p-3 rounded-2xl bg-emerald-50 border-2 border-emerald-200 text-emerald-900 text-xs space-y-2">
            <p className="font-bold flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              Góp ý sẽ được gửi khi bạn bấm Gửi trong email.
            </p>
            <div className="flex gap-2 pt-1 text-[11px]">
              <a
                href={gmailUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-1.5 px-2 rounded-lg bg-rose-600 text-white font-bold text-center hover:bg-rose-700 transition-colors"
              >
                Mở Gmail (1 chạm)
              </a>
              <a
                href={mailtoLink}
                className="flex-1 py-1.5 px-2 rounded-lg bg-sky-600 text-white font-bold text-center hover:bg-sky-700 transition-colors"
              >
                Mở App Mail
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
