import { CURRICULUM_2026 } from '../data/curriculum2026';
const lessonTitles = new Map(Object.values(CURRICULUM_2026).flatMap(chapters => chapters.flatMap(chapter => chapter.lessons.map(lesson => [lesson.id, lesson.title] as const))));
import React, { useState } from 'react';
import { UserProgress, Grade } from '../types';
import { GRADE_THEMES } from '../data/curriculumData';
import {
  BarChart3,
  CheckCircle2,
  Clock,
  Flame,
  Award,
  Sparkles,
  BookOpen,
  RotateCcw,
  Printer,
  ChevronRight,
  TrendingUp,
  Calendar,
  Sun,
  Zap,
  Cloud,
} from 'lucide-react';
import { playClickSound } from '../utils/soundAndSpeech';

interface Props {
  grade: Grade;
  progress: UserProgress;
  onResetProgress: () => void;
  onOpenDriveTab?: () => void;
}

export const ParentDashboardView: React.FC<Props> = ({
  grade,
  progress,
  onResetProgress,
  onOpenDriveTab,
}) => {
  const currentTheme = GRADE_THEMES[grade];
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const accuracyRate =
    progress.totalAnswered > 0
      ? Math.round((progress.correctCount / progress.totalAnswered) * 100)
      : null;

  const STRANDS = [
    {
      name: 'Số & Phép tính',
      stats: progress.strandStats['Số & Phép tính'] || { correct: 0, total: 0 },
      icon: '🔢',
      color: 'bg-emerald-500',
      advice: 'Kỹ năng tính nhẩm và quy tắc cộng trừ nhân chia của con rất tích cực. Hãy cho bé làm quen thêm các phép tính có nhớ.',
    },
    {
      name: 'Hình học & Đo lường',
      stats: progress.strandStats['Hình học & Đo lường'] || { correct: 0, total: 0 },
      icon: '📐',
      color: 'bg-sky-500',
      advice: 'Khả năng quan sát không gian, đọc đồng hồ và nhận diện hình học cơ bản phát triển tốt.',
    },
    {
      name: 'Giải toán có lời văn',
      stats: progress.strandStats['Giải toán có lời văn'] || { correct: 0, total: 0 },
      icon: '📖',
      color: 'bg-amber-500',
      advice: 'Phụ huynh có thể cùng con đọc to đề bài, gạch chân từ khóa "tất cả", "còn lại", "nhiều hơn", "ít hơn" để tăng tốc độ phân tích.',
    },
    {
      name: 'Dữ liệu & Xác suất',
      stats: progress.strandStats['Dữ liệu & Xác suất'],
      icon: '📊',
      color: 'bg-violet-500',
      advice: 'Cùng con đọc tên các cột và so sánh số liệu trong bảng hoặc biểu đồ.',
    },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 md:p-8 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-slate-500 bg-slate-100 px-3 py-1 rounded-full mb-2">
            <BarChart3 className="w-3.5 h-3.5 text-sky-600" />
            Báo cáo tiến độ học tập của con
          </div>
          <h1 className="text-2xl md:text-3xl font-black text-slate-900 font-display">
            Góc Phụ Huynh & Phân Tích Năng Lực
          </h1>
          <div className="flex flex-wrap items-center gap-2 mt-2">
            <span className="text-xs text-slate-500">
              Dữ liệu ghi nhận tự động theo chuẩn Thông tư 27 - Bộ GD&ĐT
            </span>
            <div className="inline-flex items-center gap-1.5 bg-amber-50 border border-amber-300 px-3 py-1 rounded-full text-xs font-black text-amber-950 shadow-2xs">
              <span>{progress.studentProfile?.gender === 'female' ? '👧' : '👦'}</span>
              <span>{progress.studentProfile?.name || 'Học sinh'}</span>
              <span className="bg-amber-200 text-amber-900 px-1.5 py-0.2 rounded font-black text-[11px]">
                Lớp {progress.studentProfile?.grade || grade}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 self-stretch md:self-auto">
          {onOpenDriveTab && (
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onOpenDriveTab();
              }}
              className="flex-1 md:flex-none py-2.5 px-4 rounded-xl bg-blue-50 border border-blue-200 hover:bg-blue-100 text-xs font-bold text-blue-700 flex items-center justify-center gap-2 transition-colors shadow-2xs"
            >
              <Cloud className="w-4 h-4 text-blue-600" />
              Lưu lên Google Drive
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              playClickSound();
              window.print();
            }}
            className="flex-1 md:flex-none py-2.5 px-4 rounded-xl border border-slate-300 hover:bg-slate-100 text-xs font-bold text-slate-700 flex items-center justify-center gap-2 transition-colors shadow-2xs"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            In phiếu học tập
          </button>
        </div>
      </div>

      {/* 4 KPIs Summary Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* KPI 1 */}
        <div className="bg-white rounded-3xl border-2 border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold">Tổng câu đã giải</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-3xl font-black text-slate-900 tabular-nums">
            {progress.totalAnswered}
          </p>
          <span className="text-[11px] text-emerald-600 font-semibold mt-1 block">
            {progress.correctCount} câu đúng
          </span>
        </div>

        {/* KPI 2 */}
        <div className="bg-white rounded-3xl border-2 border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold">Tỉ lệ chính xác</span>
            <TrendingUp className="w-4 h-4 text-sky-500" />
          </div>
          <p className="text-3xl font-black text-slate-900 tabular-nums">
            {accuracyRate === null ? "—" : `${accuracyRate}%`}
          </p>
          <span className="text-[11px] text-sky-600 font-semibold mt-1 block">
            {accuracyRate === null ? 'Chưa có câu trả lời' : accuracyRate >= 80 ? '🌟 Thành thạo tốt' : '👍 Đang rèn luyện'}
          </span>
        </div>

        {/* KPI 3 */}
        <div className="bg-white rounded-3xl border-2 border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold">Thời gian học tập</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-3xl font-black text-slate-900 tabular-nums">
            {Number(progress.timeSpentMinutes.toFixed(1))} phút
          </p>
          <span className="text-[11px] text-slate-500 font-semibold mt-1 block">
            ~15 phút mỗi ngày
          </span>
        </div>

        {/* KPI 4 */}
        <div className="bg-white rounded-3xl border-2 border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold">Chuỗi học tập</span>
            <Flame className="w-4 h-4 text-rose-500" />
          </div>
          <p className="text-3xl font-black text-slate-900 tabular-nums">
            {progress.streak} ngày
          </p>
          <span className="text-[11px] text-rose-600 font-semibold mt-1 block">
            Duy trì thói quen tốt 🔥
          </span>
        </div>
      </div>

      {/* 3 Core Strands Breakdown */}
      <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 md:p-8 shadow-xs">
        <h2 className="text-xl font-black text-slate-900 font-display mb-1">
          Kết quả theo mạch kiến thức
        </h2>
        <p className="text-xs text-slate-500 mb-6">
          Tổng hợp câu trả lời đã lưu trên thiết bị để phụ huynh chọn nội dung ôn tập.
        </p>

        <div className="space-y-6">
          {STRANDS.map((strand) => {
            const total = strand.stats.total || 0;
            const correct = strand.stats.correct || 0;
            const percent = total > 0 ? Math.round((correct / total) * 100) : 0;

            return (
              <div
                key={strand.name}
                className="bg-slate-50 rounded-2xl border border-slate-200 p-5"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="text-2xl p-2 bg-white rounded-xl border border-slate-200 shadow-2xs">
                      {strand.icon}
                    </span>
                    <div>
                      <h3 className="font-extrabold text-sm md:text-base text-slate-900">
                        {strand.name}
                      </h3>
                      <span className="text-xs text-slate-500 font-medium">
                        Đã làm {total} câu · Đúng {correct} câu
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xl font-black text-slate-900 tabular-nums">
                      {total ? `${percent}%` : "—"}
                    </span>
                    <span className="text-[11px] block text-slate-500 font-medium">
                      {total ? "Tỷ lệ đúng" : "Chưa làm câu nào"}
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="h-3 bg-white rounded-full border border-slate-200 overflow-hidden mb-3">
                  <div
                    className={`h-full ${strand.color} rounded-full transition-all duration-500`}
                    style={{ width: `${Math.max(percent, 5)}%` }}
                  />
                </div>

                {/* Pedagogy note */}
                <div className="bg-white rounded-xl p-3 border border-slate-200 text-xs text-slate-600 leading-relaxed">
                  <span className="font-bold text-slate-800">Lời khuyên cho Ba Mẹ: </span>
                  {strand.advice}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Student Timetable with Main & Extra Classes */}
      {progress.studentProfile?.timetable && (
        <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 md:p-8 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center text-xl shadow-inner">
                {progress.studentProfile.gender === 'female' ? '👧' : '👦'}
              </div>
              <div>
                <h2 className="text-xl font-black text-slate-900 font-display flex items-center gap-2">
                  <span>Thời Khóa Biểu Của Bé: {progress.studentProfile.name}</span>
                  <span className="text-xs bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full font-extrabold">
                    Lớp {progress.studentProfile.grade}
                  </span>
                </h2>
                <p className="text-xs text-slate-500">
                  {progress.studentProfile.schoolName ? `${progress.studentProfile.schoolName} · ` : ''}
                  Lịch học chính khóa và lịch tăng tiết bổ trợ
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-black px-2.5 py-1 rounded-xl bg-purple-100 text-purple-900 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-purple-600" />
                {progress.studentProfile.timetable.filter((d) => d.extraSlots && d.extraSlots.length > 0).length} ngày tăng tiết/tuần
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {progress.studentProfile.timetable.map((dayItem) => {
              const hasExtras = dayItem.extraSlots && dayItem.extraSlots.length > 0;
              return (
                <div
                  key={dayItem.day}
                  className="rounded-2xl border-2 border-slate-200 p-3 bg-slate-50/60 flex flex-col justify-between space-y-2.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-slate-900 font-display">
                      {dayItem.day}
                    </span>
                    {hasExtras ? (
                      <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-md bg-purple-200 text-purple-900">
                        ⚡ {dayItem.extraSlots?.length} tiết tăng
                      </span>
                    ) : (
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-200 text-slate-500">
                        Nghỉ chiều
                      </span>
                    )}
                  </div>

                  {/* Sáng: Lịch chính */}
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold text-amber-800 flex items-center gap-1 uppercase tracking-wider">
                      <Sun className="w-3 h-3 text-amber-500" />
                      Sáng (Chính khóa):
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {dayItem.slots.map((s, idx) => (
                        <span
                          key={idx}
                          className="text-[11px] font-semibold bg-white border border-slate-200 text-slate-700 px-2 py-0.5 rounded-md"
                        >
                          {s || `T${idx + 1}`}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Chiều: Lịch tăng tiết */}
                  <div className="space-y-1 pt-1.5 border-t border-slate-200/80">
                    <span className="text-[10px] font-bold text-purple-800 flex items-center gap-1 uppercase tracking-wider">
                      <Zap className="w-3 h-3 text-purple-600" />
                      Chiều (Tăng tiết):
                    </span>
                    {hasExtras ? (
                      <div className="flex flex-wrap gap-1">
                        {dayItem.extraSlots?.map((ex, idx) => (
                          <span
                            key={idx}
                            className="text-[11px] font-bold bg-purple-50 border border-purple-200 text-purple-900 px-2 py-0.5 rounded-md"
                          >
                            {ex}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-[11px] text-slate-400 italic">
                        Không có lịch tăng tiết
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Completed Lessons Registry */}
      <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 md:p-8 shadow-xs">
        <h2 className="text-xl font-black text-slate-900 font-display mb-1">
          Lịch Sử Bài Học & Đề Kiểm Tra Đã Hoàn Thành
        </h2>
        <p className="text-xs text-slate-500 mb-4">
          Toàn bộ kết quả được lưu trữ an toàn trong máy (localStorage)
        </p>

        <div className="divide-y divide-slate-100">
          {Object.entries(progress.completedLessons).length === 0 ? (
            <p className="text-xs text-slate-400 py-4 text-center">
              Chưa có bài học nào được hoàn thành. Hãy cùng con bắt đầu bài học đầu tiên nhé!
            </p>
          ) : (
            Object.entries(progress.completedLessons).sort(([, a], [, b]) => b.completedAt.localeCompare(a.completedAt)).map(([lessonId, data]) => (
              <div
                key={lessonId}
                className="py-3 flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-bold text-slate-800">{data.title || lessonTitles.get(lessonId) || (lessonId.startsWith('exam_') ? 'Đề luyện đã làm' : 'Bài học đã lưu')}</span>
                  <span className="text-slate-400 block text-[10px]">
                    Ngày hoàn thành: {new Date(data.completedAt).toLocaleDateString('vi-VN')}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-extrabold text-emerald-600">
                    {data.score}%{data.answered !== undefined && ` · ${data.correct}/${data.answered}`}
                  </span>
                  <span className="font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200">
                    ⭐ {data.stars} sao
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Reset progress area */}
        <div className="mt-8 pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <span className="text-xs text-slate-500">
            Đặt lại số sao, kỷ lục và lịch sử học. Hồ sơ và thời khóa biểu vẫn được lưu.
          </span>

          {!showResetConfirm ? (
            <button
              type="button"
              onClick={() => {
                playClickSound();
                setShowResetConfirm(true);
              }}
              className="text-xs font-bold text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 py-2 px-3.5 rounded-xl transition-colors"
            >
              Đặt lại tiến trình học tập
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <span className="text-xs text-rose-700 font-bold">Xóa tiến trình học?</span>
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  onResetProgress();
                  setShowResetConfirm(false);
                }}
                className="text-xs font-black bg-rose-600 text-white px-3 py-1.5 rounded-xl hover:bg-rose-700 shadow-xs"
              >
                Đồng ý
              </button>
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setShowResetConfirm(false);
                }}
                className="text-xs font-bold bg-slate-100 text-slate-700 px-3 py-1.5 rounded-xl hover:bg-slate-200"
              >
                Hủy
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
