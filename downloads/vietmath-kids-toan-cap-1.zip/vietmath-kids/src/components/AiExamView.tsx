import { fetchAppApi } from '../utils/releaseMode';
import { classifyTopic, generateDynamicQuestions } from '../utils/questionBanks/dynamicAiGenerator';
import { validateQuestions } from '../utils/validateQuestions';
import type { AttemptResult } from '../utils/assessment';
import React, { useState } from 'react';
import { Grade, Question, Textbook } from '../types';
import { GRADE_THEMES } from '../data/curriculumData';
import { QuizEngine } from './QuizEngine';
import {
  FileCheck2,
  Sparkles,
  Timer,
  BookOpen,
  Award,
  Loader2,
  AlertCircle,
  HelpCircle,
  CheckCircle,
} from 'lucide-react';
import { playClickSound } from '../utils/soundAndSpeech';

interface Props {
  grade: Grade;
  textbook: Textbook;
  currentVoiceId?: string;
  onOpenVoiceModal?: () => void;
  onExamComplete: (result: AttemptResult) => void;
}

export const AiExamView: React.FC<Props> = ({
  grade,
  textbook,
  currentVoiceId,
  onOpenVoiceModal,
  onExamComplete,
}) => {
  const currentTheme = GRADE_THEMES[grade];

  const [examType, setExamType] = useState('Đề 15 phút');
  const [level, setLevel] = useState<'basic' | 'advanced'>('basic');
  const [topic, setTopic] = useState('Tổng hợp kiến thức học kỳ');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Active exam session
  const [activeExam, setActiveExam] = useState<{
    title: string;
    questions: Question[];
  } | null>(null);

  const TOPIC_PRESETS: Record<Grade, string[]> = {
    1: [
      'Tổng hợp kiến thức học kỳ',
      'Phép cộng và trừ trong phạm vi 10, 100',
      'Hình phẳng và Đo độ dài xăng-ti-mét',
      'Xem đồng hồ giờ đúng và Giải toán',
    ],
    2: [
      'Tổng hợp kiến thức học kỳ',
      'Cộng trừ có nhớ trong phạm vi 100',
      'Bảng nhân 2, 5 và Bảng chia 2, 5',
      'Đo lường: Đề-xi-mét, Lít, Ki-lô-gam',
    ],
    3: [
      'Tổng hợp kiến thức học kỳ',
      'Bảng nhân chia từ 3 đến 9',
      'Một phần mấy & Tính giá trị biểu thức',
      'Chu vi và diện tích hình chữ nhật, hình vuông',
      'Chữ số La Mã và Tiền Việt Nam',
    ],
    4: [
      'Tổng hợp kiến thức học kỳ',
      'Số tự nhiên và 4 phép tính lớn',
      'Toán Tìm hai số khi biết Tổng và Hiệu',
      'Trung bình cộng & Hình học (góc, song song)',
      'Phân số và 4 phép tính với phân số',
    ],
    5: [
      'Tổng hợp kiến thức học kỳ',
      'Số thập phân và 4 phép tính số thập phân',
      'Tỉ số phần trăm (%) và ứng dụng thực tế',
      'Diện tích tam giác, hình thang, hình tròn',
      'Toán chuyển động đều (Vận tốc, Quãng đường, Thời gian)',
    ],
  };

  const handleCreateExam = async () => {
    playClickSound();
    setIsLoading(true);
    setErrorMessage(null);

    const textbookMap: Record<Textbook, string> = {
      'ket-noi-tri-thuc': 'Kết nối tri thức với cuộc sống',
      'chan-troi-sang-tao': 'Chân trời sáng tạo',
      'canh-dieu': 'Cánh diều',
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);
    const openFallback = () => {
      const label = classifyTopic(topic) === 'mixed' ? 'Tổng hợp' : topic;
      setActiveExam({ title: `${examType} - Lớp ${grade} (${label}) · Bộ câu hỏi dự phòng`,
        questions: generateDynamicQuestions(grade, topic, 5, level) });
    };
    try {
      const response = await fetchAppApi('/api/ai/generate-exam', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({ grade, topic, level, examType, textbook: textbookMap[textbook] }),
      });
      const data = await response.json();
      const questions = validateQuestions(data.questions);
      if (response.ok && data.success && questions.length) {
        const label = data.fallback && classifyTopic(topic) === 'mixed' ? 'Tổng hợp' : topic;
        setActiveExam({ title: `${examType} - Lớp ${grade} (${label}) · ${data.fallback ? 'Bộ câu hỏi dự phòng' : 'Gemini'}`, questions });
      } else {
        openFallback();
      }
    } catch {
      openFallback();
    } finally {
      clearTimeout(timeoutId);
      setIsLoading(false);
    }
  };

  if (activeExam) {
    return (
      <QuizEngine
        title={activeExam.title}
        showTitle
        grade={grade}
        questions={activeExam.questions}
        currentVoiceId={currentVoiceId}
        onOpenVoiceModal={onOpenVoiceModal}
        onComplete={onExamComplete}
        onExit={() => setActiveExam(null)}
      />
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* Header Card */}
      <div className={`p-6 md:p-8 rounded-3xl bg-gradient-to-r ${currentTheme.gradient} text-white shadow-xl relative overflow-hidden`}>
        <div className="relative z-10 max-w-xl">
          <div className="inline-flex items-center gap-1.5 bg-white/20 backdrop-blur px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            Luyện đề theo lớp
          </div>
          <h1 className="text-2xl md:text-3xl font-black font-display mb-2">
            Luyện Đề Kiểm Tra Thông Minh AI
          </h1>
          <p className="text-white/90 text-sm md:text-base leading-relaxed">
            Hệ thống tự động thiết kế đề kiểm tra bám sát 3 mức độ đánh giá chuẩn:
            <span className="font-bold text-amber-200"> Mức 1 (Nhận biết)</span>,
            <span className="font-bold text-amber-200"> Mức 2 (Kết nối)</span>,
            <span className="font-bold text-amber-200"> Mức 3 (Vận dụng)</span>.
          </p>
        </div>
      </div>

      {/* Exam Configuration Form */}
      <div className="bg-white rounded-3xl border-2 border-slate-200 p-6 md:p-8 shadow-xs">
        <h2 className="text-lg font-black text-slate-800 font-display mb-6 flex items-center gap-2">
          <FileCheck2 className="w-5 h-5 text-sky-600" />
          Thiết lập đề kiểm tra cho con
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Exam Type Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
              Loại đề kiểm tra
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {[
                'Đề 15 phút',
                'Giữa Học Kỳ 1',
                'Cuối Học Kỳ 1',
                'Giữa Học Kỳ 2',
                'Cuối Học Kỳ 2',
              ].map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setExamType(type);
                  }}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold text-left border-2 transition-all ${
                    examType === type
                      ? `${currentTheme.primaryBg} text-white ${currentTheme.primaryBorder} shadow-sm`
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* Level: Basic or Advanced */}
          <div>
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
              Mức độ thử thách
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setLevel('basic');
                }}
                className={`p-4 rounded-2xl border-2 text-left transition-all ${
                  level === 'basic'
                    ? 'bg-emerald-50 border-emerald-400 text-emerald-900 ring-2 ring-emerald-300'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-extrabold text-sm">Cơ Bản</span>
                  <CheckCircle className={`w-4 h-4 ${level === 'basic' ? 'text-emerald-600' : 'text-slate-300'}`} />
                </div>
                <p className="text-[11px] text-slate-500">
                  Củng cố Mức 1 & Mức 2 vững chắc, tự tin đạt 8-9 điểm.
                </p>
              </button>

              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setLevel('advanced');
                }}
                className={`p-4 rounded-2xl border-2 text-left transition-all ${
                  level === 'advanced'
                    ? 'bg-purple-50 border-purple-400 text-purple-900 ring-2 ring-purple-300'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-extrabold text-sm">Nâng Cao</span>
                  <Award className={`w-4 h-4 ${level === 'advanced' ? 'text-purple-600' : 'text-slate-300'}`} />
                </div>
                <p className="text-[11px] text-slate-500">
                  Thêm câu hỏi Mức 3 Vận dụng tư duy sắc bén, săn điểm 10!
                </p>
              </button>
            </div>
          </div>

          {/* Topic presets */}
          <div className="md:col-span-2">
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
              Chủ đề trọng tâm (Lớp {grade})
            </label>
            <div className="flex flex-wrap gap-2">
              {TOPIC_PRESETS[grade].map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setTopic(t);
                  }}
                  className={`py-2 px-3.5 rounded-xl text-xs font-bold border transition-all ${
                    topic === t
                      ? 'bg-slate-900 border-slate-900 text-white shadow-xs'
                      : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>

        {errorMessage && (
          <div className="mt-4 p-3 bg-amber-50 border border-amber-300 rounded-2xl text-xs text-amber-900 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            {errorMessage}
          </div>
        )}

        {/* Action Button */}
        <div className="mt-8 pt-4 border-t border-slate-200">
          <button
            type="button"
            disabled={isLoading}
            onClick={handleCreateExam}
            className={`w-full py-4 rounded-2xl border-b-4 text-white font-black text-base md:text-lg ${currentTheme.primaryBg} ${currentTheme.primaryBorder} btn-tactile shadow-lg flex items-center justify-center gap-2 disabled:opacity-50`}
          >
            {isLoading ? (
              <>
                <Loader2 className="w-6 h-6 animate-spin" />
                Đang chuẩn bị đề luyện...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-amber-200" />
                Bắt đầu làm đề kiểm tra ngay ✍️
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
