import { fetchAppApi } from '../utils/releaseMode';
import { validateQuestions } from '../utils/validateQuestions';
import { addAnswer, matchesAnswer, type AttemptResult, type StrandTotals } from '../utils/assessment';
import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { Question, Grade, Lesson } from '../types';
import {
  playCorrectSound,
  playWrongSound,
  playClickSound,
  playWinFanfare,
  playStreakSound,
  speakVietnamese,
  stopSpeaking,
  REGIONAL_VOICES,
} from '../utils/soundAndSpeech';
import { VisualMathWidget } from './VisualMathWidget';
import { speakEncouragement } from '../services/ttsService';
import { generateDynamicQuestions } from '../utils/questionGenerator';
import {
  Volume2,
  VolumeX,
  Lightbulb,
  CheckCircle2,
  XCircle,
  Sparkles,
  ArrowRight,
  Flame,
  Star,
  RotateCcw,
  Trophy,
  BookOpen,
  Check,
  BrainCircuit,
  Loader2,
  PlusCircle,
  Heart,
  MessageCircle,
} from 'lucide-react';

interface Props {
  title: string;
  showTitle?: boolean;
  grade: Grade;
  lesson?: Lesson | null;
  questions: Question[];
  currentVoiceId?: string;
  onOpenVoiceModal?: () => void;
  onComplete: (result: AttemptResult) => void;
  onExit: () => void;
}

export const QuizEngine: React.FC<Props> = ({
  title,
  showTitle,
  grade,
  lesson,
  questions: initialQuestions,
  currentVoiceId,
  onOpenVoiceModal,
  onComplete,
  onExit,
}) => {
  // Mode: Theory view or Quiz practice
  const [activeMode, setActiveMode] = useState<'theory' | 'quiz'>(
    lesson?.theory ? 'theory' : 'quiz'
  );

  const mistakes = useRef<Question[]>([]);
  const [isReview, setIsReview] = useState(false);
  const attempt = useRef({ answered: 0, correct: 0, strands: {} as StrandTotals, started: Date.now(), saved: false, index: -1 });
  const resetAttempt = () => {
    mistakes.current = [];
    attempt.current = { answered: 0, correct: 0, strands: {}, started: Date.now(), saved: false, index: -1 };
    setIsSubmitted(false);
    setSelectedOption(null);
    setNumberInputValue('');
    setShowHint(false);
    setCurrentEncouragementText('');
  };
  const [questions, setQuestions] = useState<Question[]>(initialQuestions);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [numberInputValue, setNumberInputValue] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Automatic Emotional Praise/Encouragement on Right/Wrong Answers
  const [enableVoiceEncouragement, setEnableVoiceEncouragement] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    return localStorage.getItem('vietmath_voice_encouragement') !== 'false';
  });
  const [currentEncouragementText, setCurrentEncouragementText] = useState<string>('');

  // AI Question Generation state
  const [isGeneratingAiQuestions, setIsGeneratingAiQuestions] = useState(false);
  const [aiSuccessToast, setAiSuccessToast] = useState('');

  // Gamification stats
  const [combo, setCombo] = useState(0);
  const [maxCombo, setMaxCombo] = useState(0);
  const [correctAnswersCount, setCorrectAnswersCount] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  // Reset when initialQuestions change
  useEffect(() => {
    resetAttempt();
    setIsReview(false);
    setQuestions(initialQuestions);
    setCurrentIndex(0);
    setCorrectAnswersCount(0);
    setCombo(0);
    setMaxCombo(0);
    setIsFinished(false);
    if (lesson?.theory) {
      setActiveMode('theory');
    } else {
      setActiveMode('quiz');
    }
  }, [initialQuestions, lesson]);

  const currentQ = questions[currentIndex] || questions[0];
  useEffect(() => () => stopSpeaking(), []);

  useEffect(() => {
    // Reset state for new question
    setSelectedOption(null);
    setNumberInputValue('');
    setIsSubmitted(false);
    setIsCorrect(false);
    setShowHint(false);
    setCurrentEncouragementText('');
    stopSpeaking();
    setIsSpeaking(false);
  }, [currentIndex]);

  const handleSpeakQuestion = () => {
    playClickSound();
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    if (!currentQ) return;

    const sanitizedQuestion = currentQ.question.replace(/\s*:\s*/g, '. ').replace(/:+/g, '. ');
    const textToSpeak = `${sanitizedQuestion}. ${
      currentQ.options && currentQ.options.length > 0
        ? 'Các lựa chọn là. ' + currentQ.options.join(', ')
        : ''
    }`;

    speakVietnamese(
      textToSpeak,
      currentVoiceId,
      grade,
      () => setIsSpeaking(true),
      () => setIsSpeaking(false)
    );
  };

  const handleSpeakTheory = () => {
    playClickSound();
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    if (!lesson?.theory) return;

    const parts: string[] = [];
    parts.push(`${title}.`);
    if (lesson.theory.summary) {
      parts.push(`Tóm tắt lý thuyết. ${lesson.theory.summary}`);
    }
    if (lesson.theory.rules && lesson.theory.rules.length > 0) {
      parts.push(`Kiến thức cần nhớ. ${lesson.theory.rules.join('. ')}`);
    }
    if (lesson.theory.example) {
      parts.push(`Ví dụ. ${lesson.theory.example.problem}. Lời giải. ${lesson.theory.example.solution}`);
    }

    // Khi đọc lý thuyết và đề bài, dấu ":" không đọc là "chia" mà xem như dấu chấm dừng câu
    const theorySpeechText = parts
      .join('. ')
      .replace(/\s*:\s*/g, '. ')
      .replace(/:+/g, '. ')
      .replace(/\s*\.\s*\./g, '.');

    speakVietnamese(
      theorySpeechText,
      currentVoiceId,
      grade,
      () => setIsSpeaking(true),
      () => setIsSpeaking(false)
    );
  };

  const handleSelectOption = (opt: string) => {
    if (isSubmitted) return;
    playClickSound();
    setSelectedOption(opt);
  };

  const handleCheckAnswer = () => {
    if (isSubmitted || !currentQ) return;
    stopSpeaking();
    setIsSpeaking(false);

    let answerToCheck = '';
    if (currentQ.type === 'number_input') {
      answerToCheck = numberInputValue.trim();
    } else {
      answerToCheck = selectedOption || '';
    }

    if (!answerToCheck) return;

    const run = attempt.current;
    if (run.index === currentIndex) return;
    run.index = currentIndex;
    const correct = matchesAnswer(currentQ, answerToCheck);
    run.answered++;
    run.correct += Number(correct);
    if (!correct) mistakes.current.push(currentQ);
    addAnswer(run.strands, currentQ.strand, correct);
    if (currentIndex === questions.length - 1 && !run.saved) {
      run.saved = true;
      const score = Math.round(100 * run.correct / run.answered);
      if (!isReview) onComplete({ title, answered: run.answered, correct: run.correct,
        seconds: (Date.now() - run.started) / 1000, stars: score >= 90 ? 3 : score >= 60 ? 2 : 1, strands: run.strands });
    }

    setIsSubmitted(true);
    setIsCorrect(correct);

    if (correct) {
      playCorrectSound();
      const newCombo = combo + 1;
      setCombo(newCombo);
      if (newCombo > maxCombo) setMaxCombo(newCombo);
      if (newCombo >= 2) playStreakSound();
      setCorrectAnswersCount((prev) => prev + 1);

      if (enableVoiceEncouragement) {
        const text = speakEncouragement(true, newCombo, currentVoiceId);
        setCurrentEncouragementText(text);
      }
    } else {
      playWrongSound();
      setCombo(0);

      if (enableVoiceEncouragement) {
        const text = speakEncouragement(false, 0, currentVoiceId);
        setCurrentEncouragementText(text);
      }
    }
  };

  const exitQuiz = () => {
    if (!attempt.current.saved && attempt.current.answered > 0 && !window.confirm('Bài đang làm chưa được lưu. Con có muốn thoát không?')) return;
    stopSpeaking();
    onExit();
  };

  const handleNext = () => {
    playClickSound();
    if (currentIndex < questions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      finishQuiz();
    }
  };

  const finishQuiz = () => {
    setIsFinished(true);
    playWinFanfare();

    try {
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 },
        colors: ['#10B981', '#F59E0B', '#3B82F6', '#EC4899', '#8B5CF6'],
      });
    } catch {
      // safe fallback
    }
  };

  // Generate 5 additional questions via Gemini API with guaranteed client-side fallback
  const handleGenerateAiQuestions = async () => {
    if (isGeneratingAiQuestions || attempt.current.saved || isReview) return;
    const run = attempt.current;
    setIsGeneratingAiQuestions(true);
    playClickSound();

    let newQuestions: Question[] = [];
    let source = "Bộ câu hỏi dự phòng";

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 7500);

      const res = await fetchAppApi('/api/ai/generate-exam', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          grade,
          topic: title,
          level: 'basic',
          examType: 'Bài tập mở rộng',
          textbook: 'Kết nối tri thức',
        }),
      });

      clearTimeout(timeoutId);

      if (res.ok) {
        const data = await res.json();
        if (data.questions && Array.isArray(data.questions) && data.questions.length > 0) {
          newQuestions = validateQuestions(data.questions);
          if (!data.fallback && newQuestions.length) source = "Gemini";
        }
      }
    } catch (err: any) {
      console.warn('AI fetch timed out or offline, deploying procedural fallback:', err?.message || err);
    }

    // Guarantee: If server didn't return questions, generate 5 dynamic questions immediately!
    if (!newQuestions || newQuestions.length === 0) {
      newQuestions = generateDynamicQuestions(grade, title, 5);
    }

    if (newQuestions.length > 0 && attempt.current === run && !run.saved) {
      setQuestions((prev) => [...prev, ...newQuestions]);
      playCorrectSound();
      setAiSuccessToast(`✨ Đã bổ sung ${newQuestions.length} câu hỏi mới · ${source}`);
      setTimeout(() => setAiSuccessToast(''), 4000);
    }

    setIsGeneratingAiQuestions(false);
  };

  const finalScore = Math.round((correctAnswersCount / (questions.length || 1)) * 100);
  let starsEarned = 1;
  if (finalScore >= 90) starsEarned = 3;
  else if (finalScore >= 60) starsEarned = 2;

  // Grade color accents
  const gradeBorderColor =
    grade === 1
      ? 'border-emerald-500'
      : grade === 2
      ? 'border-sky-500'
      : grade === 3
      ? 'border-amber-500'
      : grade === 4
      ? 'border-purple-500'
      : 'border-rose-500';

  const gradeBadgeBg =
    grade === 1
      ? 'bg-emerald-500'
      : grade === 2
      ? 'bg-sky-500'
      : grade === 3
      ? 'bg-amber-500'
      : grade === 4
      ? 'bg-purple-600'
      : 'bg-rose-500';

  // Completion Screen
  if (isFinished) {
    return (
      <div className="bg-white rounded-3xl border-4 border-slate-200 shadow-2xl p-8 max-w-xl mx-auto my-6 text-center animate-fade-in">
        <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-amber-300 animate-bounce">
          <Trophy className="w-10 h-10 text-amber-500" />
        </div>

        <h2 className="text-2xl font-black text-slate-800 font-display">
          Chúc mừng con đã hoàn thành! 🎉
        </h2>
        <p className="text-sm text-slate-600 mt-1">{title}</p>

        {/* Stars earned */}
        <div className="flex justify-center items-center gap-3 my-6">
          {[1, 2, 3].map((starIdx) => (
            <div
              key={starIdx}
              className={`p-3 rounded-2xl transition-all duration-300 transform ${
                starIdx <= starsEarned
                  ? 'bg-amber-100 border-3 border-amber-400 scale-110'
                  : 'bg-slate-100 border-2 border-slate-200 opacity-40'
              }`}
            >
              <Star
                className={`w-10 h-10 ${
                  starIdx <= starsEarned
                    ? 'text-amber-500 fill-amber-400'
                    : 'text-slate-400'
                }`}
              />
            </div>
          ))}
        </div>

        {/* Score & Combo details */}
        <div className="grid grid-cols-3 gap-3 bg-slate-50 rounded-2xl p-4 border border-slate-200 mb-6 text-left">
          <div className="text-center">
            <span className="text-xs text-slate-500 font-medium">Điểm số</span>
            <p className="text-2xl font-black text-slate-800">{finalScore}%</p>
          </div>
          <div className="text-center border-x border-slate-200">
            <span className="text-xs text-slate-500 font-medium">Đúng</span>
            <p className="text-2xl font-black text-emerald-600">
              {correctAnswersCount}/{questions.length}
            </p>
          </div>
          <div className="text-center">
            <span className="text-xs text-slate-500 font-medium">Combo cao nhất</span>
            <p className="text-2xl font-black text-amber-600">🔥 {maxCombo}</p>
          </div>
        </div>

        {mistakes.current.length > 0 && (
          <button type="button" className="mb-3 rounded-xl border border-sky-300 px-4 py-2 font-bold text-sky-900"
            onClick={() => {
              const retryQuestions = [...mistakes.current];
              resetAttempt();
              setIsReview(true);
              setQuestions(retryQuestions);
              setCurrentIndex(0);
              setCorrectAnswersCount(0);
              setCombo(0);
              setMaxCombo(0);
              setIsFinished(false);
            }}>
            Làm lại {mistakes.current.length} câu sai
          </button>
        )}
        <div className="flex gap-3">
          <button
            type="button"
            onClick={() => {
              playClickSound();
              resetAttempt();
              setIsReview(false);
              setQuestions(initialQuestions);
              setCurrentIndex(0);
              setCombo(0);
              setMaxCombo(0);
              setCorrectAnswersCount(0);
              setIsFinished(false);
            }}
            className="flex-1 py-3 px-4 rounded-2xl border-2 border-slate-300 text-slate-700 font-bold hover:bg-slate-100 transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-5 h-5" /> Làm lại
          </button>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              exitQuiz();
            }}
            className={`flex-1 py-3 px-4 rounded-2xl border-b-4 text-white font-extrabold ${gradeBadgeBg} ${gradeBorderColor} btn-tactile shadow-lg flex items-center justify-center gap-2 cursor-pointer`}
          >
            Tiếp tục <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    );
  }

  const progressPercent = ((currentIndex + 1) / (questions.length || 1)) * 100;

  return (
    <div className="bg-white rounded-3xl border-4 border-slate-200 shadow-2xl p-5 md:p-8 max-w-2xl mx-auto my-4 transition-all">
      {/* Toast Alert for AI Question Generation */}
      {aiSuccessToast && (
        <div className="mb-4 p-3 bg-sky-50 border-2 border-sky-300 rounded-2xl text-xs font-bold text-sky-900 flex items-center gap-2 animate-fade-in shadow-xs">
          <Sparkles className="w-4 h-4 text-sky-600 shrink-0" />
          <span>{aiSuccessToast}</span>
        </div>
      )}

      {/* Mode Switcher Tabs: Lý thuyết vs Luyện tập */}
      {lesson?.theory && (
        <div className="flex items-center justify-between border-b-2 border-slate-100 pb-3 mb-5 gap-2">
          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-2xl">
            <button
              type="button"
              onClick={() => {
                playClickSound();
                stopSpeaking();
                setIsSpeaking(false);
                setActiveMode('theory');
              }}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                activeMode === 'theory'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 text-amber-500" />
              <span>1. Lý thuyết trọng tâm</span>
            </button>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                stopSpeaking();
                setIsSpeaking(false);
                setActiveMode('quiz');
              }}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                activeMode === 'quiz'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BrainCircuit className="w-3.5 h-3.5 text-sky-500" />
              <span>2. Thực hành ({questions.length} câu)</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => {
              playClickSound();
              stopSpeaking();
              exitQuiz();
            }}
            className="text-xs font-bold text-slate-400 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-xl transition-colors cursor-pointer"
          >
            ✕ Thoát
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODE 1: THEORY VIEW */}
      {/* ========================================================================= */}
      {activeMode === 'theory' && lesson?.theory && (
        <div className="space-y-5 animate-fade-in">
          {/* Header */}
          <div className="flex items-start justify-between gap-3">
            <div>
              <span className="text-[11px] font-black uppercase tracking-wider text-sky-700 bg-sky-50 border border-sky-200 px-2.5 py-0.5 rounded-lg">
                Tuần {lesson.week || 1} · {lesson.strand}
              </span>
              <h2 className="text-xl md:text-2xl font-black text-slate-900 font-display mt-1.5">
                {title}
              </h2>
            </div>

            {/* Listen to Theory Teacher Voice */}
            <button
              type="button"
              onClick={handleSpeakTheory}
              title={isSpeaking ? 'Dừng giảng bài' : 'Nghe Giảng Bài lý thuyết trọng tâm'}
              className={`p-2.5 rounded-2xl border-2 transition-all flex items-center gap-1.5 shrink-0 cursor-pointer ${
                isSpeaking
                  ? 'bg-rose-100 border-rose-400 text-rose-600 animate-pulse'
                  : 'bg-amber-50 hover:bg-amber-100 border-amber-300 text-amber-900 shadow-2xs'
              }`}
            >
              {isSpeaking ? (
                <VolumeX className="w-4 h-4" />
              ) : (
                <Volume2 className="w-4 h-4 text-amber-600" />
              )}
              <span className="text-xs font-bold hidden sm:inline">
                {isSpeaking ? 'Dừng giảng bài' : 'Nghe Giảng Bài'}
              </span>
            </button>
          </div>

          {/* Theory Summary */}
          <div className="bg-amber-50/70 border-2 border-amber-200 rounded-3xl p-5 shadow-inner">
            <h4 className="text-xs font-black uppercase tracking-wider text-amber-800 flex items-center gap-1.5 mb-2">
              <Sparkles className="w-4 h-4 text-amber-600" /> Tóm tắt kiến thức cốt lõi
            </h4>
            <p className="text-sm md:text-base font-medium text-slate-800 leading-relaxed">
              {lesson.theory.summary}
            </p>
          </div>

          {/* Rules & Formulas */}
          {lesson.theory.rules && lesson.theory.rules.length > 0 && (
            <div className="bg-slate-50 border-2 border-slate-200 rounded-3xl p-5">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-3">
                <Check className="w-4 h-4 text-emerald-600" /> Quy tắc & Ghi nhớ
              </h4>
              <ul className="space-y-2">
                {lesson.theory.rules.map((rule, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-xs md:text-sm text-slate-700">
                    <span className="w-5 h-5 rounded-full bg-sky-100 text-sky-800 font-bold flex items-center justify-center shrink-0 text-xs mt-0.5">
                      {idx + 1}
                    </span>
                    <span className="leading-relaxed">{rule}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Worked Example */}
          {lesson.theory.example && (
            <div className="bg-emerald-50/70 border-2 border-emerald-200 rounded-3xl p-5">
              <h4 className="text-xs font-black uppercase tracking-wider text-emerald-800 flex items-center gap-1.5 mb-2">
                <Lightbulb className="w-4 h-4 text-emerald-600" /> Ví dụ giải mẫu
              </h4>
              <div className="text-xs md:text-sm text-slate-800 space-y-1.5">
                <p>
                  <strong className="text-emerald-900">Bài toán:</strong> {lesson.theory.example.problem}
                </p>
                <div className="p-3 bg-white rounded-2xl border border-emerald-200 text-slate-700 font-medium">
                  <strong className="text-emerald-700">Hướng dẫn giải:</strong> {lesson.theory.example.solution}
                </div>
              </div>
            </div>
          )}

          {/* Actions: Start Quiz & AI Extra Questions */}
          <div className="pt-3 flex flex-col sm:flex-row items-center gap-3">
            <button
              type="button"
              onClick={() => {
                playClickSound();
                stopSpeaking();
                setIsSpeaking(false);
                setActiveMode('quiz');
              }}
              className={`w-full sm:flex-1 py-3 px-6 rounded-2xl border-b-4 text-white font-extrabold ${gradeBadgeBg} ${gradeBorderColor} btn-tactile shadow-lg flex items-center justify-center gap-2 cursor-pointer`}
            >
              <span>Vào luyện tập 10 câu hỏi</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODE 2: INTERACTIVE PRACTICE QUIZ */}
      {/* ========================================================================= */}
      {(activeMode === 'quiz' || !lesson?.theory) && currentQ && (
        <div>
          {/* Top Header: Progress Bar, Combos, Exit (if no theory tabs) */}
          {!lesson?.theory && (
            <div className="flex items-center justify-between gap-4 mb-6">
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  stopSpeaking();
                  exitQuiz();
                }}
                className="text-xs font-bold text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-xl transition-colors cursor-pointer"
              >
                ✕ Rời khỏi
              </button>

              <div className="flex-1 mx-2">
                <div className="h-4 bg-slate-100 rounded-full border border-slate-200 overflow-hidden relative">
                  <div
                    className={`h-full ${gradeBadgeBg} rounded-full transition-all duration-300`}
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {/* Voice Encouragement Toggle Button */}
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    const nextVal = !enableVoiceEncouragement;
                    setEnableVoiceEncouragement(nextVal);
                    localStorage.setItem('vietmath_voice_encouragement', String(nextVal));
                  }}
                  title="Bật/Tắt giọng đọc khen ngợi & khích lệ cảm xúc khi làm bài"
                  className={`px-2.5 py-1 rounded-xl border text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
                    enableVoiceEncouragement
                      ? 'bg-rose-50 border-rose-300 text-rose-800 shadow-2xs'
                      : 'bg-slate-100 border-slate-200 text-slate-500 hover:text-slate-700'
                  }`}
                >
                  <Heart className={`w-3.5 h-3.5 ${enableVoiceEncouragement ? 'text-rose-500 fill-rose-500 animate-pulse' : 'text-slate-400'}`} />
                  <span className="hidden sm:inline">Khích lệ:</span>
                  <span>{enableVoiceEncouragement ? 'Bật' : 'Tắt'}</span>
                </button>

                {combo >= 2 && (
                  <div className="flex items-center gap-1 bg-amber-100 border border-amber-300 text-amber-800 px-2.5 py-1 rounded-xl text-xs font-black animate-pulse">
                    <Flame className="w-4 h-4 text-amber-600 fill-amber-500" />
                    Combo x{combo}
                  </div>
                )}
                <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-xl">
                  {currentIndex + 1} / {questions.length}
                </span>
              </div>
            </div>
          )}

          {showTitle && <h1 className="mb-4 text-sm font-bold text-slate-700">{title}</h1>}

          {/* If theory tabs exist, show mini progress strip */}
          {lesson?.theory && (
            <div className="flex items-center justify-between gap-3 mb-5">
              <div className="flex-1">
                <div className="h-3.5 bg-slate-100 rounded-full border border-slate-200 overflow-hidden relative">
                  <div
                    className={`h-full ${gradeBadgeBg} rounded-full transition-all duration-300`}
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {/* Voice Encouragement Toggle Button */}
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    const nextVal = !enableVoiceEncouragement;
                    setEnableVoiceEncouragement(nextVal);
                    localStorage.setItem('vietmath_voice_encouragement', String(nextVal));
                  }}
                  title="Bật/Tắt giọng đọc khen ngợi & khích lệ cảm xúc khi làm bài"
                  className={`px-2.5 py-1 rounded-xl border text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
                    enableVoiceEncouragement
                      ? 'bg-rose-50 border-rose-300 text-rose-800 shadow-2xs'
                      : 'bg-slate-100 border-slate-200 text-slate-500 hover:text-slate-700'
                  }`}
                >
                  <Heart className={`w-3.5 h-3.5 ${enableVoiceEncouragement ? 'text-rose-500 fill-rose-500 animate-pulse' : 'text-slate-400'}`} />
                  <span className="hidden sm:inline">Khích lệ:</span>
                  <span>{enableVoiceEncouragement ? 'Bật' : 'Tắt'}</span>
                </button>

                {combo >= 2 && (
                  <div className="flex items-center gap-1 bg-amber-100 border border-amber-300 text-amber-800 px-2.5 py-1 rounded-xl text-xs font-black animate-pulse">
                    <Flame className="w-3.5 h-3.5 text-amber-600 fill-amber-500" />
                    Combo x{combo}
                  </div>
                )}
                <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-xl">
                  Câu {currentIndex + 1}/{questions.length}
                </span>
              </div>
            </div>
          )}

          {/* Question Header & Speech Button */}
          <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 mb-5 relative">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                {currentQ.level && (
                  <span className="inline-block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    {currentQ.level} · {currentQ.strand}
                  </span>
                )}
                <h3 className="text-lg md:text-xl font-bold text-slate-900 leading-relaxed">
                  {currentQ.question}
                </h3>
              </div>

              <div className="flex flex-col items-end gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={handleSpeakQuestion}
                  title={`Đọc đề bài bằng tiếng Việt (${REGIONAL_VOICES.find((v) => v.id === currentVoiceId)?.name || 'Cô Hoài My'})`}
                  className={`p-2.5 md:p-3 rounded-2xl border-2 transition-all flex items-center gap-1.5 cursor-pointer ${
                    isSpeaking
                      ? 'bg-rose-100 border-rose-400 text-rose-600 animate-pulse'
                      : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-100 shadow-xs'
                  }`}
                >
                  {isSpeaking ? (
                    <VolumeX className="w-5 h-5" />
                  ) : (
                    <Volume2 className="w-5 h-5 text-sky-600" />
                  )}
                  <span className="text-xs font-bold hidden sm:inline">
                    {isSpeaking ? 'Dừng đọc' : 'Đọc đề'}
                  </span>
                </button>
              </div>
            </div>

            {/* Visual Widget if applicable */}
            {currentQ.visualData && (
              <VisualMathWidget key={currentQ.id + currentIndex} type={currentQ.type} data={currentQ.visualData} />
            )}
          </div>

          {/* Options: Multiple Choice or Number Input */}
          <div className="space-y-3 mb-6">
            {currentQ.type === 'number_input' ? (
              <div className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-5">
                <label className="block text-xs font-bold text-slate-600 mb-2 uppercase tracking-wider">
                  Nhập kết quả con tính được:
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    inputMode={/[\/]/.test(currentQ.correctAnswer) ? "text" : "decimal"}
                    disabled={isSubmitted}
                    value={numberInputValue}
                    onChange={(e) => setNumberInputValue(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !isSubmitted && numberInputValue.trim()) {
                        handleCheckAnswer();
                      }
                    }}
                    placeholder="Nhập số vào đây..."
                    className="min-w-0 flex-1 text-xl font-bold px-3 py-3 bg-white border-2 border-slate-300 rounded-2xl focus:border-sky-500 focus:outline-none"
                  />
                  {!isSubmitted && (
                    <button
                      type="button"
                      onClick={handleCheckAnswer}
                      disabled={!numberInputValue.trim()}
                      className="px-6 py-3 bg-sky-500 text-white font-bold rounded-2xl border-b-4 border-sky-700 disabled:opacity-50 btn-tactile cursor-pointer"
                    >
                      Kiểm tra
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {currentQ.options?.map((opt, idx) => {
                  const isSelected = selectedOption === opt;
                  let btnStyle = 'bg-white border-slate-200 hover:border-sky-300 hover:bg-sky-50/50';

                  if (isSubmitted) {
                    const isAnsCorrect = matchesAnswer(currentQ, opt);
                    if (isAnsCorrect) {
                      btnStyle = 'bg-emerald-100 border-emerald-500 text-emerald-900 font-bold';
                    } else if (isSelected) {
                      btnStyle = 'bg-rose-100 border-rose-400 text-rose-900';
                    } else {
                      btnStyle = 'bg-slate-50 border-slate-200 opacity-50';
                    }
                  } else if (isSelected) {
                    btnStyle = 'bg-sky-100 border-sky-500 text-sky-900 shadow-md ring-2 ring-sky-300';
                  }

                  return (
                    <button
                      key={idx}
                      type="button"
                      disabled={isSubmitted}
                      onClick={() => handleSelectOption(opt)}
                      className={`p-4 rounded-2xl border-2 text-left transition-all duration-150 flex items-center justify-between font-semibold text-sm cursor-pointer ${btnStyle}`}
                    >
                      <span>{opt}</span>
                      {isSubmitted && matchesAnswer(currentQ, opt) && (
                        <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                      )}
                      {isSubmitted && isSelected && !matchesAnswer(currentQ, opt) && (
                        <XCircle className="w-5 h-5 text-rose-500 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Hint & AI Tutor Drawer */}
          {!isSubmitted && (
            <div className="flex items-center justify-between mb-4">
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setShowHint(!showHint);
                }}
                className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1.5 cursor-pointer"
              >
                <Lightbulb className="w-4 h-4 text-amber-500" />
                {showHint ? 'Ẩn gợi ý' : 'Con cần một gợi ý nhỏ?'}
              </button>
            </div>
          )}

          {showHint && !isSubmitted && (
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-4 text-xs text-amber-900 animate-fade-in flex items-start gap-2">
              <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <strong className="font-bold">Gợi ý từ Thầy Cú Mèo:</strong>
                <p className="mt-0.5">{currentQ.hint}</p>
              </div>
            </div>
          )}

          {/* Explanation Banner when answered */}
          {isSubmitted && (
            <div
              className={`p-4 rounded-2xl border-2 mb-6 animate-fade-in ${
                isCorrect
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                  : 'bg-rose-50 border-rose-300 text-rose-950'
              }`}
            >
              <div className="flex items-center gap-2 mb-1">
                {isCorrect ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    <span className="font-black text-sm">Chính xác tuyệt vời! 🎉</span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-5 h-5 text-rose-600" />
                    <span className="font-black text-sm">Chưa đúng rồi con ơi, cố lên nhé! 💪</span>
                  </>
                )}
              </div>

              {/* Spoken Encouragement Quote Card */}
              {currentEncouragementText && (
                <div className="my-2 p-2.5 bg-white/95 border border-slate-200 rounded-xl flex items-center justify-between gap-2 shadow-2xs animate-fade-in">
                  <div className="flex items-center gap-2">
                    <span className="text-base shrink-0">🗣️</span>
                    <span className="text-xs font-bold text-slate-800 italic">
                      "{currentEncouragementText}"
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      speakVietnamese(currentEncouragementText, currentVoiceId);
                    }}
                    title="Nghe lại lời khích lệ"
                    className="p-1 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-800 cursor-pointer shrink-0"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-sky-600" />
                  </button>
                </div>
              )}

              <p className="text-xs leading-relaxed mt-1">
                <strong className="font-bold">Lời giải:</strong> {currentQ.explanation}
              </p>
            </div>
          )}

          {/* Bottom Actions: Check answer or Go next + AI Question Generator button */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-100">
            {/* AI Generator button */}
            <button
              type="button"
              disabled={isGeneratingAiQuestions || attempt.current.saved || isReview}
              onClick={handleGenerateAiQuestions}
              className="w-full sm:w-auto px-3.5 py-2.5 rounded-xl border border-sky-200 bg-sky-50 hover:bg-sky-100 text-sky-800 text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-2xs"
            >
              {isGeneratingAiQuestions ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-sky-600" />
                  <span>Gemini đang tạo 5 câu hỏi...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-sky-600" />
                  <span>Sinh thêm 5 câu hỏi AI</span>
                </>
              )}
            </button>

            {/* Check / Next Button */}
            <div className="w-full sm:w-auto">
              {!isSubmitted ? (
                currentQ.type !== 'number_input' && (
                  <button
                    type="button"
                    disabled={!selectedOption}
                    onClick={handleCheckAnswer}
                    className={`w-full sm:w-auto px-8 py-3 rounded-2xl border-b-4 text-white font-extrabold ${gradeBadgeBg} ${gradeBorderColor} disabled:opacity-40 btn-tactile shadow-md cursor-pointer`}
                  >
                    Kiểm tra đáp án
                  </button>
                )
              ) : (
                <button
                  type="button"
                  onClick={handleNext}
                  className="w-full sm:w-auto px-8 py-3 rounded-2xl border-b-4 bg-emerald-500 border-emerald-700 text-white font-extrabold btn-tactile shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  {currentIndex < questions.length - 1 ? 'Câu tiếp theo' : 'Xem kết quả'}
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
