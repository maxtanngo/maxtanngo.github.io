import React, { useState } from 'react';
import { Grade, StudentProfile, TimetableDay } from '../types';
import {
  User,
  Calendar,
  Save,
  X,
  Sparkles,
  Check,
  Plus,
  Trash2,
  Sun,
  Zap,
  RotateCcw,
  BookOpen,
} from 'lucide-react';
import { playClickSound, playCorrectSound } from '../utils/soundAndSpeech';

interface Props {
  initialProfile: StudentProfile;
  currentGrade: Grade;
  initialTab?: 'profile' | 'timetable';
  onSaveProfile: (profile: StudentProfile) => void;
  onClose: () => void;
}

const COMMON_MAIN_SUBJECTS = [
  'Toán',
  'Tiếng Việt',
  'Tiếng Anh',
  'Tự nhiên & XH',
  'Tin học',
  'Đạo đức',
  'Mỹ thuật',
  'Âm nhạc',
  'Thể dục',
  'Hoạt động TN',
];

const COMMON_EXTRA_SUBJECTS = [
  'Toán tăng cường',
  'Toán tư duy VietMath',
  'Ôn tập Tiếng Việt',
  'Tiếng Anh giao tiếp',
  'Tin học & STEM',
  'Kỹ năng sống',
  'Luyện chữ đẹp',
  'CLB Cờ vua & Thể thao',
];

export const StudentProfileModal: React.FC<Props> = ({
  initialProfile,
  currentGrade,
  initialTab = 'profile',
  onSaveProfile,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'timetable'>(initialTab);
  const [name, setName] = useState(initialProfile.name || '');
  const [gender, setGender] = useState<'male' | 'female'>(initialProfile.gender || 'male');
  const [grade, setGrade] = useState<Grade>(initialProfile.grade || currentGrade);
  const [schoolName, setSchoolName] = useState(initialProfile.schoolName || '');

  const [timetable, setTimetable] = useState<TimetableDay[]>(() => {
    const raw = initialProfile.timetable || [];
    const baseDays = ['Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7'];

    return baseDays.map((dayName, idx) => {
      const existing = raw.find((d) => d.day === dayName);
      if (existing) {
        return {
          day: existing.day,
          slots: existing.slots && existing.slots.length > 0
            ? [...existing.slots]
            : ['Toán', 'Tiếng Việt', 'Tiếng Anh', 'Tự nhiên & XH'],
          extraSlots: Array.isArray(existing.extraSlots)
            ? [...existing.extraSlots]
            : (idx === 0 || idx === 2 || idx === 4)
            ? ['Toán tăng cường', 'Ôn tập Tiếng Việt']
            : [],
        };
      }

      // Default schedule
      const defaultExtras = (idx === 0 || idx === 2 || idx === 4)
        ? ['Toán tăng cường', 'Ôn tập Tiếng Việt']
        : [];

      return {
        day: dayName,
        slots: ['Toán', 'Tiếng Việt', 'Tiếng Anh', 'Mỹ thuật'],
        extraSlots: defaultExtras,
      };
    });
  });

  const [isSaved, setIsSaved] = useState(false);

  // Update a main morning slot
  const handleSlotChange = (dayIdx: number, slotIdx: number, value: string) => {
    const updated = [...timetable];
    updated[dayIdx].slots[slotIdx] = value;
    setTimetable(updated);
  };

  // Update an extra afternoon slot
  const handleExtraSlotChange = (dayIdx: number, slotIdx: number, value: string) => {
    const updated = [...timetable];
    const extras = updated[dayIdx].extraSlots ? [...updated[dayIdx].extraSlots!] : [];
    extras[slotIdx] = value;
    updated[dayIdx].extraSlots = extras;
    setTimetable(updated);
  };

  // Add extra slot to a specific day
  const handleAddExtraSlot = (dayIdx: number, defaultVal: string = 'Toán tăng cường') => {
    playClickSound();
    const updated = [...timetable];
    const extras = updated[dayIdx].extraSlots ? [...updated[dayIdx].extraSlots!] : [];
    if (extras.length < 4) {
      extras.push(defaultVal);
      updated[dayIdx].extraSlots = extras;
      setTimetable(updated);
    }
  };

  // Remove an extra slot
  const handleRemoveExtraSlot = (dayIdx: number, slotIdx: number) => {
    playClickSound();
    const updated = [...timetable];
    const extras = updated[dayIdx].extraSlots ? [...updated[dayIdx].extraSlots!] : [];
    extras.splice(slotIdx, 1);
    updated[dayIdx].extraSlots = extras;
    setTimetable(updated);
  };

  // Toggle whether a day has extra classes
  const handleToggleExtraDay = (dayIdx: number) => {
    playClickSound();
    const updated = [...timetable];
    const current = updated[dayIdx].extraSlots || [];
    if (current.length > 0) {
      // Turn off
      updated[dayIdx].extraSlots = [];
    } else {
      // Turn on with 2 standard primary school extra periods
      updated[dayIdx].extraSlots = ['Toán tăng cường', 'Ôn tập Tiếng Việt'];
    }
    setTimetable(updated);
  };

  // Preset 1: 3 extra days (Thứ 2, Thứ 4, Thứ 6)
  const applyPreset3Days = () => {
    playClickSound();
    const updated = timetable.map((dayItem, idx) => {
      if (idx === 0) {
        return { ...dayItem, extraSlots: ['Toán tăng cường', 'Ôn tập Tiếng Việt'] };
      }
      if (idx === 2) {
        return { ...dayItem, extraSlots: ['Toán tư duy VietMath', 'Kỹ năng sống'] };
      }
      if (idx === 4) {
        return { ...dayItem, extraSlots: ['Tiếng Anh tăng cường', 'Sinh hoạt lớp'] };
      }
      return { ...dayItem, extraSlots: [] };
    });
    setTimetable(updated);
  };

  // Preset 2: 2 extra days (Thứ 3, Thứ 5)
  const applyPreset2Days = () => {
    playClickSound();
    const updated = timetable.map((dayItem, idx) => {
      if (idx === 1) {
        return { ...dayItem, extraSlots: ['Toán tăng cường', 'Tiếng Anh giao tiếp'] };
      }
      if (idx === 3) {
        return { ...dayItem, extraSlots: ['Toán tư duy VietMath', 'Tin học & STEM'] };
      }
      return { ...dayItem, extraSlots: [] };
    });
    setTimetable(updated);
  };

  // Clear all extra days
  const applyClearAllExtra = () => {
    playClickSound();
    const updated = timetable.map((dayItem) => ({
      ...dayItem,
      extraSlots: [],
    }));
    setTimetable(updated);
  };

  const handleSave = () => {
    playCorrectSound();
    const updatedProfile: StudentProfile = {
      name: name.trim(),
      gender,
      grade,
      schoolName: schoolName.trim(),
      timetable,
    };
    onSaveProfile(updatedProfile);
    setIsSaved(true);
    setTimeout(() => {
      onClose();
    }, 1100);
  };

  // Count active extra days per week
  const activeExtraDayCount = timetable.filter(
    (d) => d.extraSlots && d.extraSlots.length > 0
  ).length;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-3 md:p-4 animate-fade-in">
      <div className="bg-white rounded-3xl border-4 border-slate-200 shadow-2xl max-w-3xl w-full p-5 md:p-7 relative max-h-[92vh] flex flex-col">
        {/* Close Button */}
        <button
          type="button"
          onClick={() => {
            playClickSound();
            onClose();
          }}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 border border-amber-300 flex items-center justify-center text-2xl shadow-inner shrink-0">
            {gender === 'male' ? '👦' : '👧'}
          </div>
          <div>
            <h3 className="text-xl font-black text-slate-900 font-display">
              Hồ Sơ Học Sinh & Thời Khóa Biểu
            </h3>
            <p className="text-xs text-slate-500 font-medium">
              Lịch học chính khóa và lịch tăng tiết 2 - 3 ngày/tuần theo chuẩn tiểu học
            </p>
          </div>
        </div>

        {/* Sub-Tabs: Thông tin học sinh / Thời khóa biểu */}
        <div className="flex items-center gap-2 p-1 bg-slate-100 rounded-2xl mb-4 shrink-0">
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setActiveTab('profile');
            }}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 ${
              activeTab === 'profile'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <User className="w-4 h-4 text-sky-600" />
            Thông Tin Cá Nhân
          </button>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setActiveTab('timetable');
            }}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 ${
              activeTab === 'timetable'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Calendar className="w-4 h-4 text-amber-600" />
            <span>Thời Khóa Biểu Tuần</span>
            {activeExtraDayCount > 0 && (
              <span className="text-[10px] bg-purple-100 text-purple-800 font-bold px-1.5 py-0.2 rounded-md">
                {activeExtraDayCount} ngày tăng tiết
              </span>
            )}
          </button>
        </div>

        {/* Tab 1: Profile Details */}
        {activeTab === 'profile' && (
          <div className="space-y-4 overflow-y-auto pr-1 flex-1">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Tên của bé (Biệt danh hoặc Họ tên) *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ví dụ: Bảo Nam, Khánh Vy, Bé Bắp..."
                className="w-full text-base font-bold px-4 py-3 rounded-2xl border-2 border-slate-200 focus:border-sky-500 focus:ring-4 focus:ring-sky-100 outline-none text-slate-800"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Giới tính của bé *
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setGender('male');
                  }}
                  className={`p-3.5 rounded-2xl border-2 font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                    gender === 'male'
                      ? 'bg-sky-50 border-sky-500 text-sky-900 ring-4 ring-sky-100'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <span className="text-xl">👦</span>
                  <span>Bé Trai (Nam)</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setGender('female');
                  }}
                  className={`p-3.5 rounded-2xl border-2 font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                    gender === 'female'
                      ? 'bg-rose-50 border-rose-500 text-rose-900 ring-4 ring-rose-100'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <span className="text-xl">👧</span>
                  <span>Bé Gái (Nữ)</span>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Lớp đang học (1, 2, 3, 4, 5) *
              </label>
              <div className="grid grid-cols-5 gap-2">
                {([1, 2, 3, 4, 5] as Grade[]).map((g) => (
                  <button
                    key={g}
                    type="button"
                    onClick={() => {
                      playClickSound();
                      setGrade(g);
                    }}
                    className={`py-3 rounded-2xl border-2 font-black text-sm flex flex-col items-center justify-center transition-all ${
                      grade === g
                        ? 'bg-amber-50 border-amber-500 text-amber-900 ring-4 ring-amber-100 shadow-sm'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>Lớp {g}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Tên trường tiểu học (Không bắt buộc)
              </label>
              <input
                type="text"
                value={schoolName}
                onChange={(e) => setSchoolName(e.target.value)}
                placeholder="Ví dụ: Trường Tiểu học Thăng Long, Kim Đồng..."
                className="w-full text-sm font-semibold px-4 py-2.5 rounded-2xl border-2 border-slate-200 focus:border-sky-500 focus:ring-4 focus:ring-sky-100 outline-none text-slate-800"
              />
            </div>
          </div>
        )}

        {/* Tab 2: Timetable (Thời Khóa Biểu: Lịch Chính & Lịch Tăng Tiết) */}
        {activeTab === 'timetable' && (
          <div className="space-y-6 overflow-y-auto pr-1 flex-1">
            {/* Context Note */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs text-slate-600 bg-amber-50/80 p-3 rounded-2xl border border-amber-200">
              <div className="flex items-center gap-2">
                <span className="text-base">📅</span>
                <span className="font-bold text-amber-950">
                  Thời khóa biểu Tiểu học: Lịch học chính (sáng) & Lịch tăng tiết (chiều)
                </span>
              </div>
              <span className="text-[11px] font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-lg shrink-0">
                Lưu tự động vào máy
              </span>
            </div>

            {/* ========================================================= */}
            {/* 1. LỊCH HỌC CHÍNH KHÓA (BUỔI SÁNG)                        */}
            {/* ========================================================= */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center text-xs">
                    <Sun className="w-3.5 h-3.5 text-amber-600" />
                  </div>
                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 font-display">
                    1. Lịch Học Chính Khóa (Buổi Sáng)
                  </h4>
                </div>
                <span className="text-[10px] text-slate-400 font-semibold">
                  4 tiết học tiêu chuẩn mỗi ngày
                </span>
              </div>

              {/* Main Subjects quick palette */}
              <div className="flex flex-wrap items-center gap-1.5 p-2 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mr-1">
                  Môn chính:
                </span>
                {COMMON_MAIN_SUBJECTS.map((subj) => (
                  <span
                    key={subj}
                    className="text-[10px] font-semibold bg-white text-slate-700 px-2 py-0.5 rounded-md border border-slate-200 shadow-2xs"
                  >
                    {subj}
                  </span>
                ))}
              </div>

              {/* Main Timetable Grid */}
              <div className="space-y-2">
                {timetable.map((dayItem, dIdx) => (
                  <div
                    key={dayItem.day}
                    className="bg-white border-2 border-slate-200 rounded-2xl p-2.5 sm:p-3 hover:border-amber-300 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-amber-500" />
                        {dayItem.day}
                      </span>
                      <span className="text-[10px] font-semibold text-slate-400">
                        Buổi sáng
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {dayItem.slots.map((slot, sIdx) => (
                        <div key={sIdx} className="relative">
                          <input
                            type="text"
                            value={slot}
                            onChange={(e) => handleSlotChange(dIdx, sIdx, e.target.value)}
                            placeholder={`Tiết ${sIdx + 1}`}
                            className="w-full text-xs font-bold px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50/60 text-slate-800 focus:bg-white focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none transition-all"
                          />
                          <span className="absolute right-2 top-2 text-[9px] font-bold text-slate-300 pointer-events-none">
                            T{sIdx + 1}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* ========================================================= */}
            {/* 2. LỊCH TĂNG TIẾT PHÍA DƯỚI LỊCH HỌC CHÍNH (BUỔI CHIỀU)  */}
            {/* ========================================================= */}
            <div className="mt-8 pt-6 border-t-2 border-dashed border-purple-200 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-purple-100 text-purple-800 flex items-center justify-center text-xs">
                    <Zap className="w-3.5 h-3.5 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-wider text-purple-900 font-display">
                      2. Lịch Tăng Tiết / Bổ Trợ (Buổi Chiều)
                    </h4>
                    <p className="text-[11px] text-purple-700">
                      Bậc tiểu học thường tăng tiết 2 - 3 ngày/tuần (ôn tập Toán, Tiếng Việt, CLB)
                    </p>
                  </div>
                </div>

                {/* Quick Presets */}
                <div className="flex flex-wrap items-center gap-1.5 self-start sm:self-auto">
                  <button
                    type="button"
                    onClick={applyPreset3Days}
                    className="py-1 px-2.5 rounded-lg bg-purple-100 hover:bg-purple-200 text-purple-900 text-[10px] font-bold transition-colors"
                  >
                    ⚡ Mẫu 3 ngày (Thứ 2-4-6)
                  </button>
                  <button
                    type="button"
                    onClick={applyPreset2Days}
                    className="py-1 px-2.5 rounded-lg bg-sky-100 hover:bg-sky-200 text-sky-900 text-[10px] font-bold transition-colors"
                  >
                    ⚡ Mẫu 2 ngày (Thứ 3-5)
                  </button>
                  <button
                    type="button"
                    onClick={applyClearAllExtra}
                    className="py-1 px-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 text-[10px] font-bold transition-colors"
                    title="Xóa hết lịch tăng tiết"
                  >
                    <RotateCcw className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Extra Subjects quick palette */}
              <div className="flex flex-wrap items-center gap-1.5 p-2 bg-purple-50/60 rounded-xl border border-purple-200">
                <span className="text-[10px] font-bold text-purple-600 uppercase tracking-wider mr-1">
                  Môn tăng cường:
                </span>
                {COMMON_EXTRA_SUBJECTS.map((subj) => (
                  <span
                    key={subj}
                    className="text-[10px] font-semibold bg-white text-purple-900 px-2 py-0.5 rounded-md border border-purple-200 shadow-2xs"
                  >
                    {subj}
                  </span>
                ))}
              </div>

              {/* Extra Timetable Days Rows */}
              <div className="space-y-2.5">
                {timetable.map((dayItem, dIdx) => {
                  const hasExtra = dayItem.extraSlots && dayItem.extraSlots.length > 0;

                  return (
                    <div
                      key={dayItem.day}
                      className={`rounded-2xl p-3 border-2 transition-all ${
                        hasExtra
                          ? 'bg-gradient-to-r from-purple-50/70 to-indigo-50/40 border-purple-300 shadow-xs'
                          : 'bg-slate-50/80 border-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black text-slate-800">
                            {dayItem.day}
                          </span>
                          {hasExtra ? (
                            <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-purple-200 text-purple-900">
                              Có tăng tiết ({dayItem.extraSlots?.length} tiết)
                            </span>
                          ) : (
                            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-200/80 text-slate-500">
                              Không có tăng tiết
                            </span>
                          )}
                        </div>

                        {/* Toggle button */}
                        <div className="flex items-center gap-1.5">
                          {hasExtra && (dayItem.extraSlots?.length || 0) < 3 && (
                            <button
                              type="button"
                              onClick={() => handleAddExtraSlot(dIdx)}
                              className="text-[10px] font-bold text-purple-700 hover:text-purple-900 bg-white border border-purple-200 hover:bg-purple-100 px-2 py-1 rounded-lg flex items-center gap-1 transition-colors"
                            >
                              <Plus className="w-3 h-3" />
                              Thêm tiết
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleToggleExtraDay(dIdx)}
                            className={`text-[10px] font-bold px-2.5 py-1 rounded-lg transition-colors ${
                              hasExtra
                                ? 'bg-rose-100 hover:bg-rose-200 text-rose-700'
                                : 'bg-purple-600 hover:bg-purple-700 text-white'
                            }`}
                          >
                            {hasExtra ? 'Tắt tăng tiết' : '+ Bật tăng tiết'}
                          </button>
                        </div>
                      </div>

                      {hasExtra ? (
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                          {dayItem.extraSlots?.map((extraSlot, eIdx) => (
                            <div key={eIdx} className="relative flex items-center">
                              <input
                                type="text"
                                value={extraSlot}
                                onChange={(e) => handleExtraSlotChange(dIdx, eIdx, e.target.value)}
                                placeholder={`Tiết tăng ${eIdx + 1}`}
                                className="w-full text-xs font-bold px-2.5 py-1.5 pr-7 rounded-xl border border-purple-300 bg-white text-purple-950 focus:border-purple-500 focus:ring-2 focus:ring-purple-200 outline-none"
                              />
                              <button
                                type="button"
                                onClick={() => handleRemoveExtraSlot(dIdx, eIdx)}
                                title="Xóa tiết này"
                                className="absolute right-2 p-1 text-slate-300 hover:text-rose-500 transition-colors"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-[11px] text-slate-400 italic">
                          Buổi chiều bé nghỉ ngơi hoặc tự học tại nhà.
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Save Success Banner */}
        {isSaved && (
          <div className="mt-3 p-3 rounded-2xl bg-emerald-500 text-white flex items-center justify-between gap-2 shadow-lg animate-bounce shrink-0">
            <div className="flex items-center gap-2 text-xs font-black">
              <Check className="w-5 h-5 bg-white text-emerald-600 rounded-full p-0.5" />
              <span>✓ Đã lưu thành công Thời khóa biểu và Hồ sơ của bé {name || 'học sinh'}!</span>
            </div>
            <span className="text-[11px] font-bold bg-white/20 px-2 py-0.5 rounded-lg">
              Đang áp dụng...
            </span>
          </div>
        )}

        {/* Footer actions */}
        <div className="mt-4 pt-3 border-t border-slate-200 flex justify-between items-center gap-3 shrink-0">
          <span className="text-xs text-slate-500 hidden sm:inline">
            Dữ liệu được lưu trữ an toàn trong máy
          </span>

          <div className="flex gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onClose();
              }}
              className="py-2.5 px-4 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100"
            >
              Hủy
            </button>

            <button
              type="button"
              onClick={handleSave}
              className="flex-1 sm:flex-none py-2.5 px-6 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 border-b-3 border-emerald-800 text-white text-xs font-black btn-tactile shadow-md flex items-center justify-center gap-1.5"
            >
              <Save className="w-4 h-4" />
              {isSaved ? 'Đã Lưu!' : 'Lưu Hồ Sơ & Thời Khóa Biểu'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
