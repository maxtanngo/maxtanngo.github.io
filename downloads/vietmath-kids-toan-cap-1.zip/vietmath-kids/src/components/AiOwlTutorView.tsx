import { fetchAppApi } from '../utils/releaseMode';
import { solvePrimaryMathProblem } from '../utils/tutorSolution';
import React, { useState, useRef, useEffect } from 'react';
import { Grade } from '../types';
import { GRADE_THEMES } from '../data/curriculumData';
import {
  Send,
  Sparkles,
  Volume2,
  VolumeX,
  Lightbulb,
  CheckCircle2,
  BookOpen,
  Target,
  Copy,
  Check,
  RotateCcw,
  Loader2,
  Heart,
  HelpCircle,
  FileText,
  Calculator,
} from 'lucide-react';
import {
  playClickSound,
  playCorrectSound,
  speakVietnamese,
  stopSpeaking,
} from '../utils/soundAndSpeech';
import {
  extractMathExpression,
  solveMathExpression,
} from '../utils/mathExpressionSolver';

interface Props {
  grade: Grade;
  currentVoiceId?: string;
  onOpenVoiceModal?: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'owl';
  text: string;
  time: string;
  mode?: 'solution' | 'hint' | 'check' | 'practice';
}

type TutorMode = 'solution' | 'hint' | 'check' | 'practice';

export const AiOwlTutorView: React.FC<Props> = ({
  grade,
  currentVoiceId,
  onOpenVoiceModal,
}) => {
  const currentTheme = GRADE_THEMES[grade];

  const [tutorMode, setTutorMode] = useState<TutorMode>('solution');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'owl',
      text: `Chào con yêu! Thầy là Thầy Cú Mèo Thông Thái 🦉✨ - Gia sư Toán Lớp ${grade} của con!

Thầy đã sẵn sàng giải đáp và hướng dẫn con mọi bài toán khó. Con có thể:
1. Gõ đề bài toán hoặc phép tính con đang thắc mắc vào khung bên dưới.
2. Chọn các chế độ hỗ trợ: 📘 Giải chi tiết, 💡 Gợi ý tự làm, ✍️ Chấm bài của con, hoặc 🎯 Ra bài tập tương tự.
3. Bấm vào các câu hỏi gợi ý nhanh để xem Thầy hướng dẫn mẫu nhé! ⭐🎒`,
      time: 'Vừa xong',
      mode: 'solution',
    },
  ]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Curated topic questions for each grade
  const GRADE_TOPIC_QUESTIONS: Record<Grade, { topic: string; questions: string[] }[]> = {
    1: [
      {
        topic: 'Số & Phép tính 0-20',
        questions: [
          'Thầy ơi, tính 8 + 5 và 14 - 6 thế nào nhanh nhất ạ?',
          'Làm sao để cộng nhẩm trong phạm vi 10 không bị nhầm hả Thầy?',
          'Tách số 9 gồm 4 và mấy hả Thầy?',
        ],
      },
      {
        topic: 'Hình học & Đo lường',
        questions: [
          'Làm sao phân biệt hình vuông và hình chữ nhật hả Thầy?',
          'Thầy chỉ con cách nhìn đồng hồ khi kim ngắn chỉ số 8, kim dài chỉ số 12!',
          'Cần bao nhiêu que tính để xếp thành 1 hình tam giác ạ?',
        ],
      },
      {
        topic: 'Toán có lời văn',
        questions: [
          'Bạn An có 5 quả cam, mẹ cho thêm 3 quả cam. Hỏi có tất cả mấy quả cam?',
          'Trên cành có 8 con chim, 3 con bay đi. Hỏi còn lại mấy con chim?',
        ],
      },
    ],
    2: [
      {
        topic: 'Cộng trừ có nhớ & Bảng nhân chia',
        questions: [
          'Thầy ơi, phép tính 38 + 25 đặt tính và nhớ thế nào ạ?',
          'Làm sao nhớ nhanh bảng nhân 2 và bảng nhân 5 hả Thầy?',
          'Thầy giải giúp con phép chia: 20 : 5 = ?',
        ],
      },
      {
        topic: 'Đo lường & Đại lượng',
        questions: [
          'Đổi: 3 dm = bao nhiêu cm hả Thầy?',
          '1 mét bằng bao nhiêu xăng-ti-mét?',
          'Can to có 15 lít dầu, can nhỏ có 8 lít. Cả hai can có mấy lít dầu?',
        ],
      },
      {
        topic: 'Toán nhiều hơn, ít hơn',
        questions: [
          'Lan có 20 cái kẹo, Mai có nhiều hơn Lan 6 cái kẹo. Hỏi Mai có bao nhiêu cái kẹo?',
          'Đoạn thẳng AB dài 12 cm, đoạn BC dài 18 cm. Tính độ dài đường gấp khúc ABC?',
        ],
      },
    ],
    3: [
      {
        topic: 'Thứ tự phép tính & Biểu thức',
        questions: [
          '2 + 2 × 2 = ? (Nhân chia trước, cộng trừ sau)',
          '2 × 2 + 2 = ? (Thực hiện từ trái sang phải)',
          '10 - 2 × 3 + 4 = ?',
          '(15 + 5) : 4 = ?',
        ],
      },
      {
        topic: 'Bảng nhân chia 6, 7, 8, 9 & Phân số',
        questions: [
          'Thầy ơi, tính nhẩm 7 × 8 và 9 × 6 bằng bao nhiêu ạ?',
          'Tìm 1/4 của 24 quả cam làm thế nào hả Thầy?',
          'Thầy hướng dẫn con đọc số La Mã IX, XIV, XIX với!',
        ],
      },
      {
        topic: 'Chu vi & Diện tích',
        questions: [
          'Một hình chữ nhật dài 8 cm, rộng 5 cm. Tính chu vi và diện tích?',
          'Một hình vuông có chu vi 36 cm. Tính độ dài cạnh của hình vuông?',
        ],
      },
      {
        topic: 'Toán giải bằng hai bước',
        questions: [
          'Thùng 1 có 15 l dầu, thùng 2 gấp đôi thùng 1. Hỏi cả hai thùng có mấy lít dầu?',
          'Mua 4 quyển vở hết 32 000 đồng. Mua 7 quyển vở như thế hết bao nhiêu tiền?',
        ],
      },
    ],
    4: [
      {
        topic: 'Biểu thức nhiều phép tính & Lớp triệu',
        questions: [
          '2 + 2 × 2 = ?',
          'Tính giá trị biểu thức: 120 + a × 5 với a = 8',
          'Tính: 45 - 15 : 3 + 8 × 2 = ?',
          'Thầy chỉ con cách đọc số 5 234 000 theo từng lớp với ạ!',
        ],
      },
      {
        topic: 'Phân số & 4 phép tính',
        questions: [
          'Thầy ơi, tính phép cộng hai phân số: 2/5 + 1/3 = ?',
          'Rút gọn phân số 18/24 về phân số tối giản thế nào ạ?',
          'Tìm 3/4 của 60 kg gạo là bao nhiêu kg?',
        ],
      },
      {
        topic: 'Toán Tổng - Hiệu & Trung bình cộng',
        questions: [
          'Hai thùng có tất cả 120 lít dầu. Thùng 1 nhiều hơn thùng 2 là 20 lít. Tìm số dầu mỗi thùng?',
          'Tìm số trung bình cộng của 15, 25, 35 và 45?',
        ],
      },
    ],
    5: [
      {
        topic: 'Hỗn số & Toán Tổng - Tỉ, Hiệu - Tỉ',
        questions: [
          'Tổng hai số là 72, tỉ số là 1/3. Tìm hai số đó giúp con với!',
          'Hiệu hai số là 24, tỉ số là 2/5. Tìm số bé và số lớn?',
          'Chuyển hỗn số 3 và 2/5 thành phân số thế nào hả Thầy?',
        ],
      },
      {
        topic: 'Số thập phân & Tỉ số %',
        questions: [
          'Tính: 15,6 + 8,75 và 7,2 × 4,5 = ?',
          'Tìm tỉ số phần trăm của 24 và 40 làm thế nào ạ?',
          'Một chiếc áo giá 200 000 đồng được giảm giá 15%. Tính số tiền được giảm?',
        ],
      },
      {
        topic: 'Hình học & Toán Chuyển động đều',
        questions: [
          'Một hình tam giác có đáy 12 cm, chiều cao 8 cm. Tính diện tích tam giác?',
          'Tính diện tích hình thang có đáy lớn 10 cm, đáy bé 6 cm, chiều cao 5 cm?',
          'Hai xe đi ngược chiều từ A và B cách nhau 180 km: xe 1 chạy 50 km/h, xe 2 chạy 40 km/h. Sau mấy giờ gặp nhau?',
        ],
      },
    ],
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputPrompt).trim();
    if (!text || isLoading) return;

    playClickSound();

    const userMsg: ChatMessage = {
      id: `u_${Date.now()}`,
      sender: 'user',
      text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      mode: tutorMode,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputPrompt('');
    setIsLoading(true);

    try {
      const history = messages.slice(-6).map((m) => ({
        role: m.sender === 'user' ? ('user' as const) : ('model' as const),
        text: m.text,
      }));

      const res = await fetchAppApi('/api/ai/tutor-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history,
          grade,
          mode: tutorMode,
        }),
      });

      if (!res.ok) throw new Error('Không thể kết nối máy chủ gia sư');
      const data = await res.json();

      const replyText =
        data.reply ||
        `Chào con yêu! 🦉✨ Thầy Cú Mèo rất khen ngợi tinh thần học toán của con! Với câu hỏi này, con hãy xem lại công thức và thực hiện từng bước cẩn thận nhé!`;

      const owlMsg: ChatMessage = {
        id: `o_${Date.now()}`,
        sender: 'owl',
        text: replyText,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        mode: tutorMode,
      };

      setMessages((prev) => [...prev, owlMsg]);
      playCorrectSound();
    } catch (err: any) {
      console.warn('Tutor API unavailable, deploying smart client solver:', err);
      // Client-side instant solver fallback
      const fallbackReply = solvePrimaryMathProblem(text, grade, tutorMode);
      const owlMsg: ChatMessage = {
        id: `o_${Date.now()}`,
        sender: 'owl',
        text: fallbackReply,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        mode: tutorMode,
      };
      setMessages((prev) => [...prev, owlMsg]);
      playCorrectSound();
    } finally {
      setIsLoading(false);
    }
  };

  const handleSpeakMessage = (msgId: string, text: string) => {
    playClickSound();
    if (speakingMessageId === msgId) {
      stopSpeaking();
      setSpeakingMessageId(null);
      return;
    }

    setSpeakingMessageId(msgId);
    speakVietnamese(
      text,
      currentVoiceId,
      grade,
      () => setSpeakingMessageId(msgId),
      () => setSpeakingMessageId(null)
    );
  };

  const handleCopyMessage = (msgId: string, text: string) => {
    playClickSound();
    navigator.clipboard.writeText(text);
    setCopiedMessageId(msgId);
    setTimeout(() => setCopiedMessageId(null), 2500);
  };

  const handleClearChat = () => {
    playClickSound();
    stopSpeaking();
    setSpeakingMessageId(null);
    setMessages([
      {
        id: `m_${Date.now()}`,
        sender: 'owl',
        text: `Thầy đã làm mới bảng học rồi! Con hãy gửi bài toán tiếp theo để Thầy hướng dẫn nhé! 🦉🎒✨`,
        time: 'Vừa xong',
        mode: tutorMode,
      },
    ]);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4 pb-12">
      {/* Header Profile Card for Owl */}
      <div className="bg-white rounded-3xl border-2 border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="relative">
            <div className="w-16 h-16 rounded-3xl bg-amber-100 border-2 border-amber-300 flex items-center justify-center text-3xl shadow-inner animate-float">
              🦉
            </div>
            <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 rounded-full border-2 border-white flex items-center justify-center">
              <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black text-slate-900 font-display">
                Thầy Cú Mèo Thông Thái
              </h1>
              <span className="text-[10px] font-black uppercase tracking-wider bg-amber-100 text-amber-800 px-2.5 py-0.5 rounded-full border border-amber-200">
                Gia Sư Toán AI Chuyên Nghiệp
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Giải đáp chi tiết từng bước · Phù hợp chuẩn GDPT 2018 Lớp {grade}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onOpenVoiceModal && (
            <button
              type="button"
              onClick={onOpenVoiceModal}
              className="flex items-center gap-1.5 text-xs font-bold text-sky-800 bg-sky-50 hover:bg-sky-100 border border-sky-200 py-1.5 px-3 rounded-2xl transition-colors shadow-2xs"
            >
              <Volume2 className="w-3.5 h-3.5 text-sky-600" />
              <span>Đổi giọng giảng</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleClearChat}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 py-1.5 px-3 rounded-2xl transition-colors"
            title="Làm mới bảng học để hỏi bài mới"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
            <span>Hỏi bài mới</span>
          </button>

          <div className="flex items-center gap-1 text-xs font-black text-rose-700 bg-rose-50 border border-rose-200 py-1.5 px-3 rounded-2xl">
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
            <span>Lớp {grade}</span>
          </div>
        </div>
      </div>

      {/* 4 Professional Tutor Modes */}
      <div className="bg-white rounded-2xl border-2 border-slate-200 p-2 shadow-2xs flex flex-wrap items-center gap-1.5">
        <span className="text-[11px] font-black text-slate-500 uppercase tracking-wider px-2 py-1">
          Chế độ hỗ trợ:
        </span>

        <button
          type="button"
          onClick={() => {
            playClickSound();
            setTutorMode('solution');
          }}
          className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-xl transition-all ${
            tutorMode === 'solution'
              ? 'bg-amber-500 text-white shadow-xs'
              : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>Giải chi tiết (A-Z)</span>
        </button>

        <button
          type="button"
          onClick={() => {
            playClickSound();
            setTutorMode('hint');
          }}
          className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-xl transition-all ${
            tutorMode === 'hint'
              ? 'bg-amber-500 text-white shadow-xs'
              : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Lightbulb className="w-3.5 h-3.5" />
          <span>Gợi ý tự giải</span>
        </button>

        <button
          type="button"
          onClick={() => {
            playClickSound();
            setTutorMode('check');
          }}
          className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-xl transition-all ${
            tutorMode === 'check'
              ? 'bg-amber-500 text-white shadow-xs'
              : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Chấm bài của con</span>
        </button>

        <button
          type="button"
          onClick={() => {
            playClickSound();
            setTutorMode('practice');
          }}
          className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-xl transition-all ${
            tutorMode === 'practice'
              ? 'bg-amber-500 text-white shadow-xs'
              : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Target className="w-3.5 h-3.5" />
          <span>Bài tập tương tự</span>
        </button>
      </div>

      {/* Quick Suggestion Chips by Category */}
      <div className="bg-amber-50/60 rounded-3xl border border-amber-200/80 p-3.5 space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-black text-amber-900 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            Chọn nhanh bài toán mẫu Lớp {grade} để Thầy giải đáp:
          </span>
          <span className="text-[10px] text-amber-700 font-semibold">Chạm vào để hỏi</span>
        </div>

        <div className="space-y-2">
          {GRADE_TOPIC_QUESTIONS[grade].map((topicGroup, gIdx) => (
            <div key={gIdx} className="space-y-1">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">
                • {topicGroup.topic}:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {topicGroup.questions.map((q, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSendMessage(q)}
                    className="text-xs font-semibold bg-white border border-amber-200/80 hover:border-amber-400 hover:bg-amber-100/50 text-slate-800 py-1.5 px-3 rounded-xl transition-all shadow-2xs text-left"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat Messages Log */}
      <div className="bg-slate-50 rounded-3xl border-2 border-slate-200 p-4 md:p-6 min-h-[460px] max-h-[580px] overflow-y-auto space-y-4 shadow-inner">
        {messages.map((m) => {
          const isOwl = m.sender === 'owl';
          const isSpeakingThis = speakingMessageId === m.id;
          const isCopiedThis = copiedMessageId === m.id;

          return (
            <div
              key={m.id}
              className={`flex items-start gap-3 ${
                isOwl ? 'justify-start' : 'justify-end'
              }`}
            >
              {isOwl && (
                <div className="w-10 h-10 rounded-2xl bg-amber-100 border border-amber-300 flex items-center justify-center text-xl shrink-0 shadow-xs">
                  🦉
                </div>
              )}

              <div
                className={`max-w-[90%] md:max-w-[80%] rounded-3xl p-4 md:p-5 text-sm leading-relaxed relative shadow-xs ${
                  isOwl
                    ? 'bg-white border-2 border-slate-200 text-slate-800 rounded-tl-sm'
                    : `${currentTheme.primaryBg} text-white font-medium rounded-tr-sm`
                }`}
              >
                {/* Header indicator for Owl response mode */}
                {isOwl && (
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 text-[11px] font-bold text-amber-800">
                    <span className="flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                      {m.mode === 'hint'
                        ? '💡 Gợi ý tư duy từng bước'
                        : m.mode === 'check'
                        ? '✍️ Chấm & Sửa bài làm'
                        : m.mode === 'practice'
                        ? '🎯 Bài tập tương tự rèn luyện'
                        : '📘 Lời giải chi tiết từ Thầy Cú Mèo'}
                    </span>
                    <span className="text-slate-400 font-normal">{m.time}</span>
                  </div>
                )}

                <div className="whitespace-pre-line font-normal leading-relaxed text-slate-800">
                  {m.text}
                </div>

                {isOwl && (
                  <div className="flex items-center justify-between gap-3 mt-3 pt-2.5 border-t border-slate-100 text-[11px]">
                    <span className="text-slate-400 text-[10px]">VietMath Kids AI Tutor</span>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleCopyMessage(m.id, m.text)}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
                        title="Sao chép bài giải"
                      >
                        {isCopiedThis ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                            <span className="text-emerald-700 font-bold">Đã chép!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Sao chép</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSpeakMessage(m.id, m.text)}
                        className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-colors font-bold ${
                          isSpeakingThis
                            ? 'bg-rose-100 text-rose-700'
                            : 'bg-amber-100/70 hover:bg-amber-200 text-amber-900'
                        }`}
                        title="Nghe Thầy giảng bài"
                      >
                        {isSpeakingThis ? (
                          <>
                            <VolumeX className="w-3.5 h-3.5 text-rose-600" />
                            <span>Dừng đọc</span>
                          </>
                        ) : (
                          <>
                            <Volume2 className="w-3.5 h-3.5 text-amber-600" />
                            <span>Nghe giảng bài</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                )}

                {!isOwl && (
                  <div className="flex justify-end mt-1 text-[10px] text-white/80">
                    <span>{m.time}</span>
                  </div>
                )}
              </div>

              {!isOwl && (
                <div className="w-10 h-10 rounded-2xl bg-slate-200 border border-slate-300 flex items-center justify-center text-xs font-black text-slate-700 shrink-0 shadow-xs">
                  Con
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 border border-amber-300 flex items-center justify-center text-xl shrink-0 animate-bounce">
              🦉
            </div>
            <div className="bg-white border-2 border-slate-200 rounded-3xl py-3.5 px-5 shadow-xs text-xs font-semibold text-slate-600 flex items-center gap-2.5">
              <Loader2 className="w-4 h-4 animate-spin text-amber-500" />
              <span>Thầy Cú Mèo đang phân tích đề bài và soạn lời giải chi tiết cho con...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Message Input Box */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="flex items-center gap-2 bg-white rounded-3xl border-2 border-slate-300 p-2 shadow-sm focus-within:border-amber-400 focus-within:ring-4 focus-within:ring-amber-100 transition-all"
      >
        <div className="pl-3 text-slate-400">
          <Calculator className="w-5 h-5 text-amber-500" />
        </div>

        <input
          type="text"
          value={inputPrompt}
          onChange={(e) => setInputPrompt(e.target.value)}
          placeholder={`Hỏi Thầy Cú Mèo bài toán khó Lớp ${grade} (ví dụ: Tính diện tích hình thang, 15 + 28, tìm x...)...`}
          className="flex-1 px-2 py-2.5 bg-transparent text-sm font-semibold text-slate-900 outline-none placeholder:text-slate-400"
        />

        <button
          type="submit"
          disabled={!inputPrompt.trim() || isLoading}
          className={`py-2.5 px-5 rounded-2xl border-b-3 font-bold text-xs md:text-sm text-white ${currentTheme.primaryBg} ${currentTheme.primaryBorder} btn-tactile shadow-xs flex items-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed`}
        >
          <span>Gửi Thầy giải</span>
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
