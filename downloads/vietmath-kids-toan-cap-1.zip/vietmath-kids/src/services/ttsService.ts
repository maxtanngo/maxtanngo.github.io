import { staticRelease } from '../utils/releaseMode';
/**
 * Expressive Text-to-Speech (TTS) Service for VietMath Kids
 * Supports Gemini Native TTS (gemini-2.5-flash-preview-tts / gemini-3.8-flash-lite-tts),
 * custom FPT.AI / ElevenLabs configs, Audio Cache, and Web Speech API fallback.
 */

import { VoiceProfile } from '../types';

export const VOICE_PROFILES: VoiceProfile[] = [
  {
    id: 'co-hoai-my-bac',
    name: '👩‍🏫 Cô Hoài My (Nữ Miền Bắc - Dịu dàng, truyền cảm)',
    shortName: 'Cô Hoài My (Bắc)',
    region: 'Nữ Miền Bắc · Dịu dàng, chuẩn phát âm',
    tag: 'Dịu dàng · Ấm áp · Yêu thương',
    gender: 'female',
    avatar: '👩‍🏫',
    description: 'Giọng cô giáo tiểu học miền Bắc truyền cảm, ấm áp, phát âm chuẩn Hà Nội, ngắt nghỉ tự nhiên.',
    sampleText: 'Chào con yêu! Hôm nay cô sẽ đồng hành cùng con vượt qua các bài toán thật xuất sắc nhé!',
    geminiVoiceName: 'Kore',
    stylePrompt: 'Đọc bằng giọng cô giáo tiểu học miền Bắc Việt Nam thật dịu dàng, ấm áp, phát âm chuẩn, ngắt nghỉ tự nhiên và giàu cảm xúc yêu thương trẻ nhỏ',
    rate: 0.95,
    pitch: 1.15,
    provider: 'gemini',
    preferredVoiceNames: ['hoaimy', 'hoai my', 'vi-vn-hoaimyneural', 'female', 'mai', 'lan', 'linh', 'nu'],
  },
  {
    id: 'co-lan-nhi-nam',
    name: '👩‍🏫 Cô Lan Nhi (Nữ Miền Nam - Ngọt ngào, vui tươi)',
    shortName: 'Cô Lan Nhi (Nam)',
    region: 'Nữ Miền Nam · Ngọt ngào, gần gũi',
    tag: 'Ngọt ngào · Vui tươi · Khích lệ',
    gender: 'female',
    avatar: '🌸',
    description: 'Giọng cô giáo miền Nam ngọt ngào, tươi vui, mang lại cảm giác thân thiện và tràn đầy hứng khởi.',
    sampleText: 'Cô chào con nha! Chúng mình cùng nhau làm bài tập toán thật vui và rinh thật nhiều Sao Vàng nhen!',
    geminiVoiceName: 'Aoede',
    stylePrompt: 'Đọc bằng giọng cô giáo miền Nam (Sài Gòn) ngọt ngào, tươi vui, thân thiện, gần gũi và khích lệ học sinh tiểu học',
    rate: 0.93,
    pitch: 1.18,
    provider: 'gemini',
    preferredVoiceNames: ['lannhi', 'lan nhi', 'female', 'south', 'my', 'dung'],
  },
  {
    id: 'thay-nam-minh-bac',
    name: '👨‍🏫 Thầy Nam Minh (Nam Miền Bắc - Trầm ấm, rõ ràng)',
    shortName: 'Thầy Nam Minh (Bắc)',
    region: 'Nam Miền Bắc · Trầm ấm, đĩnh đạc',
    tag: 'Trầm ấm · Đĩnh đạc · Rõ ràng',
    gender: 'male',
    avatar: '👨‍🏫',
    description: 'Giọng thầy giáo miền Bắc trầm ấm, dõng dạc, giải thích từng con số khúc chiết, khơi gợi tư duy.',
    sampleText: 'Thầy chào con! Hãy cùng thầy quan sát kỹ đề bài, tư duy từng bước để tìm ra đáp án chính xác nhất nhé!',
    geminiVoiceName: 'Charon',
    stylePrompt: 'Đọc bằng giọng thầy giáo miền Bắc trầm ấm, đĩnh đạc, rõ ràng từng con số, truyền cảm hứng học toán',
    rate: 0.90,
    pitch: 0.85,
    provider: 'gemini',
    preferredVoiceNames: ['namminh', 'nam minh', 'vi-vn-namminhneural', 'male', 'nam', 'an'],
  },
  {
    id: 'thay-minh-quang-nam',
    name: '👨‍🏫 Thầy Minh Quang (Nam Miền Nam - Sôi nổi, hào hứng)',
    shortName: 'Thầy Minh Quang (Nam)',
    region: 'Nam Miền Nam · Sôi nổi, năng lượng',
    tag: 'Sôi nổi · Hào hứng · Năng động',
    gender: 'male',
    avatar: '⚡',
    description: 'Giọng thầy giáo trẻ miền Nam tràn đầy năng lượng tích cực, hài hước và lôi cuốn như dẫn chương trình.',
    sampleText: 'Alo các bạn nhỏ ơi! Thầy Minh Quang đã sẵn sàng cùng con chinh phục các thử thách toán học siêu đỉnh hôm nay rồi nè!',
    geminiVoiceName: 'Puck',
    stylePrompt: 'Đọc bằng giọng thầy giáo trẻ miền Nam sôi nổi, hào hứng, tràn đầy năng lượng tích cực như người dẫn chương trình thiếu nhi',
    rate: 0.95,
    pitch: 0.95,
    provider: 'gemini',
    preferredVoiceNames: ['minhquang', 'minh quang', 'male', 'quang', 'dung'],
  },
  {
    id: 'cu-meo-thong-thai',
    name: '🦉 Cú Mèo Thông Thái (Giọng Kể Chuyện Hoạt Hình)',
    shortName: 'Cú Mèo Thông Thái',
    region: 'Nhân vật Hoạt Hình · Hóm hỉnh, kỳ thú',
    tag: 'Hóm hỉnh · Kỳ thú · Bí ẩn',
    gender: 'owl',
    avatar: '🦉',
    description: 'Ngữ điệu nhân vật hoạt hình ngộ nghĩnh, nhấn nhá sinh động như bước ra từ truyện cổ tích.',
    sampleText: 'Hú hú! Ta là Cú Mèo Thông Thái đây! Con có câu hỏi toán nào hóc búa cần giải mã cùng ta không nào?',
    geminiVoiceName: 'Fenrir',
    stylePrompt: 'Đọc với ngữ điệu nhân vật hoạt hình đáng yêu, hóm hỉnh, nhấn nhá sinh động như đang kể chuyện cổ tích cho bé',
    rate: 0.92,
    pitch: 0.90,
    provider: 'gemini',
    preferredVoiceNames: ['cartoon', 'owl', 'male'],
  },
  {
    id: 'fpt-custom',
    name: '✨ Giọng FPT.AI / ElevenLabs (Tùy chọn API riêng)',
    shortName: 'FPT / ElevenLabs',
    region: 'Chuyên nghiệp · Phòng thu Studio',
    tag: 'Tùy chọn API · Chất lượng cao',
    gender: 'female',
    avatar: '✨',
    description: 'Chế độ giọng đọc chuẩn phòng thu phát thanh viên, hỗ trợ kết nối API Key riêng từ FPT.AI hoặc ElevenLabs.',
    sampleText: 'Xin chào quý phụ huynh và các em học sinh. Chức năng âm thanh giáo dục chất lượng cao đã sẵn sàng phục vụ.',
    geminiVoiceName: 'Kore',
    stylePrompt: 'Đọc bằng giọng phát thanh viên chuẩn giáo dục, phát âm tròn vành rõ chữ, ngữ điệu truyền cảm, ân cần',
    rate: 0.95,
    pitch: 1.05,
    provider: 'fpt',
    preferredVoiceNames: ['fpt', 'female', 'neural'],
  },
];

export const VOICE_PROFILES_MAP: Record<string, VoiceProfile> = VOICE_PROFILES.reduce(
  (acc, v) => ({ ...acc, [v.id]: v }),
  {}
);

// Map old IDs to new ones
export function normalizeVoiceId(voiceId: string): string {
  if (voiceId === 'voice_co') return 'co-hoai-my-bac';
  if (voiceId === 'voice_thay' || voiceId === 'voice_nam_minh') return 'thay-nam-minh-bac';
  if (voiceId === 'voice_minh_quang') return 'thay-minh-quang-nam';
  if (voiceId === 'voice_lan_nhi') return 'co-lan-nhi-nam';
  if (voiceId === 'voice_owl') return 'cu-meo-thong-thai';
  if (VOICE_PROFILES_MAP[voiceId]) return voiceId;
  return 'co-hoai-my-bac';
}

export function getVoiceProfile(voiceId?: string): VoiceProfile {
  const normalized = normalizeVoiceId(voiceId || 'co-hoai-my-bac');
  return VOICE_PROFILES_MAP[normalized] || VOICE_PROFILES[0];
}

const VOICE_STORAGE_KEY = 'vietmath_kids_voice';

export function getSavedVoiceId(): string {
  if (typeof window === 'undefined') return 'co-hoai-my-bac';
  const saved = localStorage.getItem(VOICE_STORAGE_KEY);
  if (!saved) return 'co-hoai-my-bac';
  return normalizeVoiceId(saved);
}

export function setSavedVoiceId(voiceId: string) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(VOICE_STORAGE_KEY, normalizeVoiceId(voiceId));
}

// -------------------------------------------------------------
// AUDIO CACHE (Memory + Session Storage)
// -------------------------------------------------------------
class AudioCacheManager {
  private cache = new Map<string, string>();
  private readonly STORAGE_PREFIX = 'vm_tts_v2_';

  private hashKey(voiceId: string, text: string): string {
    let hash = 0;
    const str = `v2::${voiceId}::${text.trim()}`;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    return `tts_v2_${voiceId}_${Math.abs(hash)}`;
  }

  get(voiceId: string, text: string): string | null {
    const key = this.hashKey(voiceId, text);
    if (this.cache.has(key)) {
      return this.cache.get(key)!;
    }
    if (typeof window !== 'undefined' && window.sessionStorage) {
      try {
        const item = sessionStorage.getItem(this.STORAGE_PREFIX + key);
        if (item) {
          this.cache.set(key, item);
          return item;
        }
      } catch {
        // quota exceeded or storage disabled
      }
    }
    return null;
  }

  set(voiceId: string, text: string, base64Audio: string) {
    const key = this.hashKey(voiceId, text);
    this.cache.set(key, base64Audio);
    if (typeof window !== 'undefined' && window.sessionStorage && base64Audio.length < 500000) {
      try {
        sessionStorage.setItem(this.STORAGE_PREFIX + key, base64Audio);
      } catch {
        // Safe fallback if sessionStorage is full
      }
    }
  }

  clear() {
    this.cache.clear();
  }
}

export const audioCache = new AudioCacheManager();

// -------------------------------------------------------------
// TEXT ENHANCEMENT FOR NATURAL VIETNAMESE MATH SPEECH
// -------------------------------------------------------------
export function enhanceTextForSpeech(text: string): string {
  let cleaned = text
    // Replace squared and cubed units
    .replace(/\bcm[2²]\b/gi, ' xen ti mét vuông ')
    .replace(/\bm[2²]\b/gi, ' mét vuông ')
    .replace(/\bdm[2²]\b/gi, ' đề xi mét vuông ')
    .replace(/\bkm[2²]\b/gi, ' ki lô mét vuông ')
    .replace(/\bmm[2²]\b/gi, ' mi li mét vuông ')
    .replace(/\bcm[3³]\b/gi, ' xen ti mét khối ')
    .replace(/\bm[3³]\b/gi, ' mét khối ')
    .replace(/\bdm[3³]\b/gi, ' đề xi mét khối ')
    // Speed units
    .replace(/\bkm\/h\b/gi, ' ki lô mét trên giờ ')
    .replace(/\bm\/s\b/gi, ' mét trên giây ')
    .replace(/\bm\/giây\b/gi, ' mét trên giây ')
    // Common measurement units
    .replace(/(\d+)\s*kg\b/gi, '$1 ki lô gam ')
    .replace(/(\d+)\s*g\b/gi, '$1 gam ')
    .replace(/(\d+)\s*dm\b/gi, '$1 đề xi mét ')
    .replace(/(\d+)\s*cm\b/gi, '$1 xen ti mét ')
    .replace(/(\d+)\s*mm\b/gi, '$1 mi li mét ')
    .replace(/(\d+)\s*m\b/gi, '$1 mét ')
    .replace(/(\d+)\s*l\b/gi, '$1 lít ')
    // Standardize loan words to spaces instead of hyphens so they are never converted to "trừ"
    .replace(/xen-ti-mét/gi, 'xen ti mét')
    .replace(/đề-xi-mét/gi, 'đề xi mét')
    .replace(/ki-lô-mét/gi, 'ki lô mét')
    .replace(/mi-li-mét/gi, 'mi li mét')
    .replace(/ki-lô-gam/gi, 'ki lô gam')
    // Percent
    .replace(/(\d+(?:[.,]\d+)?)\s*%/g, '$1 phần trăm')
    // Common fractions
    .replace(/\b1\/2\b/g, ' một phần hai ')
    .replace(/\b1\/3\b/g, ' một phần ba ')
    .replace(/\b2\/3\b/g, ' hai phần ba ')
    .replace(/\b1\/4\b/g, ' một phần tư ')
    .replace(/\b3\/4\b/g, ' ba phần tư ')
    .replace(/\b1\/5\b/g, ' một phần năm ')
    .replace(/\b2\/5\b/g, ' hai phần năm ')
    .replace(/\b3\/5\b/g, ' ba phần năm ')
    .replace(/\b4\/5\b/g, ' bốn phần năm ')
    // Decimal comma to spoken
    .replace(/(\d+),(\d+)/g, '$1 phẩy $2')
    // Bảo vệ tiêu đề mục/bài học: "Bài 1:", "Câu 2:", "Ví dụ 1:", "Chương 3:", "Tuần 4:"
    .replace(/\b(Bài|Câu|Ví dụ|Chương|Tuần|Phần|Mục)\s*(\d+)\s*[:.]/gi, '$1 $2. ')
    .replace(/\b(Tóm tắt lý thuyết|Lý thuyết trọng tâm|Ghi nhớ|Ví dụ minh họa|Bài toán|Hướng dẫn giải|Lời giải|Chú ý|Nhận xét|Đáp số|Đáp án|Tính nhẩm|Đặt tính rồi tính)\s*[:.]/gi, '$1. ')
    // Math operations
    .replace(/\s*\+\s*/g, ' cộng ')
    .replace(/\s*[×*]\s*/g, ' nhân ')
    .replace(/(\d+)\s*÷\s*(\d+)/g, '$1 chia $2')
    .replace(/([a-zA-Z])\s*÷\s*([a-zA-Z0-9])/g, '$1 chia $2')
    .replace(/\s*÷\s*/g, ' chia ')
    // Phép trừ: CHỈ thay thế khi dấu trừ nằm giữa hai số hoặc toán hạng có khoảng cách
    .replace(/(\d+)\s*[-–—]\s*(\d+)/g, '$1 trừ $2')
    .replace(/([a-zA-Z])\s*[-–—]\s*([a-zA-Z0-9])/g, '$1 trừ $2')
    .replace(/\s+[-–—]\s+/g, ' trừ ')
    // QUY TẮC TRỌNG TÂM: Mọi dấu hai chấm ":" trong phần lý thuyết và đề bài TUYỆT ĐỐI KHÔNG đọc là "chia" hay "hai chấm",
    // mà được xem như dấu chấm cuối câu (. ) để ngắt nhịp tự nhiên mà không phát âm thành tiếng
    .replace(/\s*:\s*/g, '. ')
    .replace(/:+/g, '. ')
    .replace(/\s*=\s*/g, ' bằng ')
    .replace(/\s*<\s*/g, ' bé hơn ')
    .replace(/\s*>\s*/g, ' lớn hơn ')
    // Dấu hỏi chấm giữ khoảng trắng tự nhiên
    .replace(/\?+/g, '? ')
    // Dọn dẹp khoảng trắng thừa và dấu chấm trùng
    .replace(/\s*\.\s*\./g, '.')
    .replace(/\s+/g, ' ')
    .trim();

  return cleaned;
}

// -------------------------------------------------------------
// EMOTIONAL PRAISE & ENCOURAGEMENT VOICE SYSTEM
// -------------------------------------------------------------
export const PRAISE_PHRASES = [
  'Giỏi quá! Con tính chính xác rồi, thưởng cho con 10 sao vàng nhé! 🎉',
  'Tuyệt vời lắm con yêu! Trả lời xuất sắc, tiếp tục phát huy nhé!',
  'Hoan hô! Con thông minh quá, câu trả lời hoàn toàn chính xác nè!',
  'Chính xác tuyệt đối! Con làm Thầy Cô rất tự hào đấy!',
  'Xuất sắc luôn con ơi! Con nắm bài rất vững vàng!',
];

export const STREAK_PRAISE_PHRASES = [
  'Đỉnh quá con ơi! Chuỗi đúng liên tiếp rồi, phong độ siêu đẳng! 🔥',
  'Tuyệt đỉnh! Chuỗi trả lời đúng siêu tốc, con giỏi như thần đồng vậy!',
  'Xuất sắc không tì vết! Thêm một câu đúng vào chuỗi combo siêu đẳng rồi!',
];

export const ENCOURAGEMENT_PHRASES = [
  'Chưa đúng rồi con ơi, không sao cả, con bình tĩnh nhẩm lại một chút nhé! 💪',
  'Tiếc một chút thôi, đừng nản lòng nhé con yêu, câu sau mình làm lại nào!',
  'Cố lên con nha! Thầy Cô tin chắc là câu tiếp theo con sẽ vượt qua dễ dàng!',
  'Sai một chút để nhớ lâu hơn nè, con đọc kỹ lại gợi ý và nhẩm lại nha!',
];

export function getRandomPraise(combo: number = 0): string {
  if (combo >= 2) {
    const idx = Math.floor(Math.random() * STREAK_PRAISE_PHRASES.length);
    return STREAK_PRAISE_PHRASES[idx];
  }
  const idx = Math.floor(Math.random() * PRAISE_PHRASES.length);
  return PRAISE_PHRASES[idx];
}

export function getRandomEncouragement(): string {
  const idx = Math.floor(Math.random() * ENCOURAGEMENT_PHRASES.length);
  return ENCOURAGEMENT_PHRASES[idx];
}

export function speakEncouragement(
  isCorrect: boolean,
  combo: number = 0,
  voiceId?: string,
  onStart?: () => void,
  onEnd?: () => void
): string {
  const phrase = isCorrect ? getRandomPraise(combo) : getRandomEncouragement();
  speakText(phrase, voiceId, onStart, onEnd);
  return phrase;
}

// -------------------------------------------------------------
// PLAYBACK ENGINE (HTML5 Audio + Web Speech API Fallback)
// -------------------------------------------------------------
let pendingSpeech: AbortController | null = null;
let currentAudio: HTMLAudioElement | null = null;
let currentUtterance: SpeechSynthesisUtterance | null = null;

export function stopSpeaking() {
  pendingSpeech?.abort();
  pendingSpeech = null;
  if (currentAudio) {
    try {
      currentAudio.pause();
      currentAudio.currentTime = 0;
      currentAudio.src = '';
    } catch {
      // ignore
    }
    currentAudio = null;
  }

  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch {
      // ignore
    }
    currentUtterance = null;
  }
}

export function isSpeaking(): boolean {
  if (currentAudio && !currentAudio.paused && !currentAudio.ended) return true;
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    return window.speechSynthesis.speaking;
  }
  return false;
}

/**
 * Web Speech API Fallback with custom voice matching, rate, and pitch
 */
function speakWithWebSpeech(
  cleanedText: string,
  profile: VoiceProfile,
  onStart?: () => void,
  onEnd?: () => void,
  onError?: (err: any) => void
) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    onEnd?.();
    return;
  }

  stopSpeaking();

  const utterance = new SpeechSynthesisUtterance(cleanedText);
  utterance.lang = 'vi-VN';
  utterance.rate = profile.rate;
  utterance.pitch = profile.pitch;

  const voices = window.speechSynthesis.getVoices();
  const viVoices = voices.filter((v) => v.lang.includes('vi') || v.lang.includes('VI'));

  let matchedVoice = viVoices[0] || null;

  if (profile.preferredVoiceNames && viVoices.length > 0) {
    for (const pref of profile.preferredVoiceNames) {
      const found = viVoices.find(
        (v) =>
          v.name.toLowerCase().includes(pref) ||
          (profile.gender === 'female' && v.name.toLowerCase().includes('female')) ||
          (profile.gender === 'male' && v.name.toLowerCase().includes('male'))
      );
      if (found) {
        matchedVoice = found;
        break;
      }
    }
  }

  if (matchedVoice) {
    utterance.voice = matchedVoice;
  }

  utterance.onstart = () => {
    onStart?.();
  };

  utterance.onend = () => {
    currentUtterance = null;
    onEnd?.();
  };

  utterance.onerror = (e) => {
    currentUtterance = null;
    onError?.(e);
    onEnd?.();
  };

  currentUtterance = utterance;
  window.speechSynthesis.speak(utterance);
}

/**
 * Main Speak Function:
 * 1. Checks Audio Cache
 * 2. Tries Gemini Native TTS (/api/tts/generate)
 * 3. Falls back to Web Speech API seamlessly
 */
export async function speakText(
  text: string,
  voiceId?: string,
  onStart?: () => void,
  onEnd?: () => void,
  onError?: (err: any) => void
): Promise<void> {
  const selectedVoiceId = normalizeVoiceId(voiceId || getSavedVoiceId());
  const profile = getVoiceProfile(selectedVoiceId);
  const cleanedText = enhanceTextForSpeech(text);

  if (!cleanedText) {
    onEnd?.();
    return;
  }

  stopSpeaking();

  if (staticRelease) {
    speakWithWebSpeech(cleanedText, profile, onStart, onEnd, onError);
    return;
  }

  // 1. Check Audio Cache
  const cachedAudioBase64 = audioCache.get(selectedVoiceId, cleanedText);
  if (cachedAudioBase64) {
    playBase64Audio(cachedAudioBase64, onStart, onEnd, onError);
    return;
  }

  // 2. Fetch from Gemini Native TTS endpoint
  const controller = new AbortController();
  pendingSpeech = controller;
  const timeout = setTimeout(() => controller.abort('timeout'), 9000);
  try {
    const res = await fetch('/api/tts/generate', {
      signal: controller.signal,
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: cleanedText,
        voiceId: selectedVoiceId,
      }),
    });

    if (!res.ok) {
      throw new Error(`TTS server response ${res.status}`);
    }

    const data = await res.json();
    if (pendingSpeech !== controller) return;
    if (data.success && data.audioBase64) {
      // Save in cache
      audioCache.set(selectedVoiceId, cleanedText, data.audioBase64);
      playBase64Audio(data.audioBase64, onStart, onEnd, onError);
      return;
    }

    // Graceful fallback to browser's natural Web Speech API
    speakWithWebSpeech(cleanedText, profile, onStart, onEnd, onError);
  } catch (_err) {
    if (pendingSpeech === controller) speakWithWebSpeech(cleanedText, profile, onStart, onEnd, onError);
  } finally {
    clearTimeout(timeout);
    if (pendingSpeech === controller) pendingSpeech = null;
  }
}

/**
 * Play WAV base64 audio via HTML5 Audio element
 */
function playBase64Audio(
  base64Audio: string,
  onStart?: () => void,
  onEnd?: () => void,
  onError?: (err: any) => void
) {
  try {
    const audio = new Audio(`data:audio/wav;base64,${base64Audio}`);
    currentAudio = audio;

    audio.onplay = () => {
      onStart?.();
    };

    audio.onended = () => {
      currentAudio = null;
      onEnd?.();
    };

    audio.onerror = (e) => {
      console.warn('Error playing base64 audio, falling back:', e);
      currentAudio = null;
      onError?.(e);
      onEnd?.();
    };

    audio.play().catch((playErr) => {
      console.warn('Audio play() error:', playErr);
      onError?.(playErr);
      onEnd?.();
    });
  } catch (e) {
    onError?.(e);
    onEnd?.();
  }
}

/**
 * Preview a Voice Profile with its built-in sample text
 */
export function previewVoice(
  voiceId: string,
  onStart?: () => void,
  onEnd?: () => void
): void {
  const profile = getVoiceProfile(voiceId);
  speakText(profile.sampleText, voiceId, onStart, onEnd);
}
