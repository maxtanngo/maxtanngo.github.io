function escapeHtml(text: string): string {
  return text.replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char] ?? char);
}

import { UserProgress, Grade } from '../types';

export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  modifiedTime: string;
  webViewLink?: string;
  iconLink?: string;
  thumbnailLink?: string;
  parents?: string[];
  description?: string;
}

export interface DriveStorageQuota {
  limit?: string;
  usage?: string;
  usageInDrive?: string;
  usageInDriveTrash?: string;
}

export interface DriveUserInfo {
  displayName?: string;
  emailAddress?: string;
  photoLink?: string;
}

const APP_FOLDER_NAME = 'Toán Tiểu Học 2026 - VietMath Kids';

/**
 * Get or create the dedicated folder in Google Drive
 */
export async function getOrCreateAppFolder(token: string): Promise<string> {
  try {
    // 1. Search for existing folder
    const searchUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
      `name = '${APP_FOLDER_NAME}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`
    )}&fields=files(id,name)`;

    const searchRes = await fetch(searchUrl, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (searchRes.ok) {
      const data = await searchRes.json();
      if (data.files && data.files.length > 0) {
        return data.files[0].id;
      }
    }

    // 2. Create folder if not found
    const createRes = await fetch('https://www.googleapis.com/drive/v3/files', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: APP_FOLDER_NAME,
        mimeType: 'application/vnd.google-apps.folder',
        description: 'Thư mục lưu trữ sao lưu học tập, phiếu đề thi và báo cáo toán tiểu học VietMath Kids 2026',
      }),
    });

    if (createRes.ok) {
      const newFolder = await createRes.json();
      return newFolder.id;
    }
  } catch (err) {
    console.warn('Could not get/create VietMath folder, using root:', err);
  }
  return 'root';
}

/**
 * Fetch storage quota & drive user info
 */
export async function fetchDriveAbout(
  token: string
): Promise<{ user?: DriveUserInfo; quota?: DriveStorageQuota } | null> {
  try {
    const res = await fetch(
      'https://www.googleapis.com/drive/v3/about?fields=user,storageQuota',
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    if (!res.ok) return null;
    const data = await res.json();
    return {
      user: data.user,
      quota: data.storageQuota,
    };
  } catch (err) {
    console.error('Failed to fetch Drive about info:', err);
    return null;
  }
}

/**
 * List files in Google Drive (by default lists files within the app folder or relevant math files)
 */
export async function listDriveFiles(
  token: string,
  options?: { folderId?: string; search?: string; onlyAppFiles?: boolean }
): Promise<DriveFileItem[]> {
  try {
    let qParts: string[] = ['trashed = false'];

    if (options?.folderId && options.folderId !== 'all') {
      qParts.push(`'${options.folderId}' in parents`);
    }

    if (options?.search && options.search.trim()) {
      const escaped = options.search.trim().replace(/'/g, "\\'");
      qParts.push(`name contains '${escaped}'`);
    }

    const q = qParts.join(' and ');
    const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
      q
    )}&fields=files(id,name,mimeType,size,modifiedTime,webViewLink,iconLink,thumbnailLink,parents,description)&orderBy=modifiedTime desc&pageSize=50`;

    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      const errJson = await res.json().catch(() => ({}));
      throw new Error(errJson?.error?.message || `Lỗi tải tệp: ${res.statusText}`);
    }

    const data = await res.json();
    return (data.files as DriveFileItem[]) || [];
  } catch (err: any) {
    console.error('listDriveFiles error:', err);
    throw err;
  }
}

/**
 * Backup student progress to Google Drive as a JSON file
 */
export async function backupProgressToDrive(
  token: string,
  progress: UserProgress,
  studentName: string,
  folderId?: string
): Promise<DriveFileItem> {
  const targetFolderId = folderId || (await getOrCreateAppFolder(token));
  const sanitizedName = (studentName || 'HocSinh').replace(/[^a-zA-Z0-9\u00C0-\u024F\u1EA0-\u1EF9]/g, '_');
  const now = new Date();
  const dateStr = now.toISOString().split('T')[0];
  const timeStr = `${String(now.getHours()).padStart(2, '0')}h${String(now.getMinutes()).padStart(2, '0')}`;
  const fileName = `VietMath_SaoLuu_${sanitizedName}_Lop${progress.studentProfile?.grade || 1}_${dateStr}_${timeStr}.json`;

  const backupPayload = {
    app: 'Toán Tiểu Học Thông Minh 2026 (VietMath Kids)',
    version: '2026.2',
    createdAt: now.toISOString(),
    studentName: progress.studentProfile?.name,
    grade: progress.studentProfile?.grade,
    stars: progress.stars,
    streak: progress.streak,
    totalAnswered: progress.totalAnswered,
    correctCount: progress.correctCount,
    progressData: progress,
  };

  const fileContent = JSON.stringify(backupPayload, null, 2);

  // Use multipart upload for Drive API v3
  const boundary = '-------314159265358979323846';
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const metadata = {
    name: fileName,
    mimeType: 'application/json',
    description: `Bản sao lưu học tập của ${studentName || 'Học sinh'} (Lớp ${progress.studentProfile?.grade || 1}) lưu lúc ${dateStr} ${timeStr}. Có ${progress.stars} sao vàng và ${progress.correctCount}/${progress.totalAnswered} câu đúng.`,
    parents: targetFolderId !== 'root' ? [targetFolderId] : undefined,
  };

  const multipartRequestBody =
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    JSON.stringify(metadata) +
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    fileContent +
    closeDelimiter;

  const res = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,size,modifiedTime,webViewLink',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: multipartRequestBody,
    }
  );

  if (!res.ok) {
    const errJson = await res.json().catch(() => ({}));
    throw new Error(errJson?.error?.message || 'Không thể tải bản sao lưu lên Google Drive');
  }

  return await res.json();
}

/**
 * Restore progress by reading JSON content from Google Drive
 */
export async function downloadDriveFileContent<T = any>(token: string, fileId: string): Promise<T> {
  const url = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    throw new Error(`Không thể đọc nội dung tệp từ Google Drive (mã lỗi: ${res.status})`);
  }

  const maxBytes = 2 * 1024 * 1024;
  if (Number(res.headers.get('content-length')) > maxBytes) throw new Error('Tệp sao lưu quá lớn.');
  const blob = await res.blob();
  if (blob.size > maxBytes) throw new Error('Tệp sao lưu quá lớn.');
  const text = await blob.text();
  try {
    return JSON.parse(text) as T;
  } catch {
    return text as unknown as T;
  }
}

/**
 * Export Study Report (Thông tư 27) as an HTML document to Google Drive
 */
export async function exportReportToDrive(
  token: string,
  progress: UserProgress,
  grade: Grade,
  folderId?: string
): Promise<DriveFileItem> {
  const targetFolderId = folderId || (await getOrCreateAppFolder(token));
  const student = progress.studentProfile;
  const studentName = student?.name || 'Học sinh';
  const now = new Date();
  const dateStr = now.toLocaleDateString('vi-VN');
  const fileName = `BaoCao_KetQua_Toan_Lop${grade}_${studentName.replace(/\s+/g, '_')}_${now.toISOString().split('T')[0]}.html`;

  const accuracyRate =
    progress.totalAnswered > 0
      ? Math.round((progress.correctCount / progress.totalAnswered) * 100)
      : null;

  const htmlContent = `<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Báo Cáo Học Tập Môn Toán - ${escapeHtml(studentName)}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; margin: 40px; color: #1e293b; background: #f8fafc; }
    .card { background: white; border-radius: 16px; padding: 32px; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); max-width: 800px; margin: 0 auto; }
    h1 { color: #0f172a; margin-top: 0; font-size: 24px; border-bottom: 2px solid #3b82f6; padding-bottom: 12px; }
    .meta { display: flex; justify-content: space-between; margin-bottom: 24px; font-size: 14px; color: #64748b; }
    .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin: 24px 0; }
    .stat-box { background: #f1f5f9; padding: 16px; border-radius: 12px; text-align: center; }
    .stat-val { font-size: 24px; font-weight: 800; color: #2563eb; }
    .stat-label { font-size: 12px; color: #64748b; margin-top: 4px; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e2e8f0; }
    th { background: #f8fafc; color: #475569; font-weight: 700; }
    .footer { margin-top: 32px; text-align: center; font-size: 12px; color: #94a3b8; }
    .badge { display: inline-block; padding: 4px 8px; border-radius: 6px; font-weight: 700; font-size: 12px; }
    .badge-success { background: #dcfce7; color: #166534; }
  </style>
</head>
<body>
  <div class="card">
    <h1>🦉 VIETMATH KIDS 2026 - BÁO CÁO KẾT QUẢ HỌC TẬP</h1>
    <div class="meta">
      <div><strong>Học sinh:</strong> ${escapeHtml(studentName)} (${student?.gender === 'female' ? 'Nữ' : 'Nam'}) - Lớp ${grade}</div>
      <div><strong>Ngày xuất:</strong> ${dateStr}</div>
    </div>
    <div class="meta">
      <div><strong>Trường:</strong> ${escapeHtml(student?.schoolName || 'Chưa cập nhật')}</div>
      <div><strong>Đánh giá Thông tư 27:</strong> <span class="badge badge-success">Hoàn thành tốt (T)</span></div>
    </div>

    <div class="stats-grid">
      <div class="stat-box">
        <div class="stat-val">${progress.stars} ⭐</div>
        <div class="stat-label">Sao Vàng Tích Lũy</div>
      </div>
      <div class="stat-box">
        <div class="stat-val">${progress.streak} ngày 🔥</div>
        <div class="stat-label">Chuỗi Ngày Học</div>
      </div>
      <div class="stat-box">
        <div class="stat-val">${accuracyRate === null ? "Chưa có dữ liệu" : `${accuracyRate}%`}</div>
        <div class="stat-label">Tỷ Lệ Chính Xác</div>
      </div>
      <div class="stat-box">
        <div class="stat-val">${progress.totalAnswered} câu</div>
        <div class="stat-label">Tổng Câu Hỏi Đã Làm</div>
      </div>
    </div>

    <h3>Đánh Giá Năng Lực Theo Mạch Kiến Thức</h3>
    <table>
      <thead>
        <tr>
          <th>Mạch Kiến Thức</th>
          <th>Câu Đúng / Tổng</th>
          <th>Độ Chính Xác</th>
          <th>Đánh Giá Theo TT27</th>
        </tr>
      </thead>
      <tbody>
        ${Object.entries(progress.strandStats)
          .map(([strand, stats]) => {
            const strandAcc = stats.total > 0 ? Math.round((stats.correct / stats.total) * 100) : null;
            return `<tr>
              <td><strong>${escapeHtml(strand)}</strong></td>
              <td>${stats.correct} / ${stats.total}</td>
              <td>${strandAcc === null ? "—" : `${strandAcc}%`}</td>
              <td>${strandAcc === null ? 'Chưa có dữ liệu' : strandAcc >= 80 ? 'Hoàn thành tốt' : strandAcc >= 60 ? 'Hoàn thành' : 'Cần cố gắng'}</td>
            </tr>`;
          })
          .join('')}
      </tbody>
    </table>

    <div class="footer">
      Xuất từ ứng dụng <strong>Toán Tiểu Học Thông Minh 2026 (VietMath Kids)</strong> · Tác giả: Ngô Thanh Tân (MaxNgo Studio)<br>
      Tệp được đồng bộ an toàn trên Google Drive của phụ huynh.
    </div>
  </div>
</body>
</html>`;

  const boundary = '-------314159265358979323846';
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const metadata = {
    name: fileName,
    mimeType: 'text/html',
    description: `Báo cáo đánh giá học tập môn Toán Lớp ${grade} của học sinh ${studentName} (Thông tư 27) xuất ngày ${dateStr}`,
    parents: targetFolderId !== 'root' ? [targetFolderId] : undefined,
  };

  const multipartRequestBody =
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    JSON.stringify(metadata) +
    delimiter +
    'Content-Type: text/html; charset=UTF-8\r\n\r\n' +
    htmlContent +
    closeDelimiter;

  const res = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,size,modifiedTime,webViewLink',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: multipartRequestBody,
    }
  );

  if (!res.ok) {
    const errJson = await res.json().catch(() => ({}));
    throw new Error(errJson?.error?.message || 'Không thể tải báo cáo lên Google Drive');
  }

  return await res.json();
}

/**
 * Export Printable Exercise Worksheet (Phiếu bài tập) to Google Drive
 */
export async function exportWorksheetToDrive(
  token: string,
  title: string,
  grade: Grade,
  questions: { question: string; options?: string[]; correctAnswer: string; hint?: string }[],
  folderId?: string
): Promise<DriveFileItem> {
  const targetFolderId = folderId || (await getOrCreateAppFolder(token));
  const dateStr = new Date().toLocaleDateString('vi-VN');
  const fileName = `Phieu_BaiTap_Toan_Lop${grade}_${title.replace(/[^a-zA-Z0-9\u00C0-\u024F\u1EA0-\u1EF9]/g, '_')}.html`;

  const htmlContent = `<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Phiếu Bài Tập Toán Lớp ${grade} - ${escapeHtml(title)}</title>
  <style>
    body { font-family: 'Times New Roman', Times, serif; margin: 30px; font-size: 16px; color: #000; line-height: 1.5; }
    .header { text-align: center; margin-bottom: 25px; border-bottom: 1.5px solid #333; padding-bottom: 15px; }
    .school-info { display: flex; justify-content: space-between; margin-bottom: 15px; font-size: 15px; }
    h1 { font-size: 20px; text-transform: uppercase; margin: 5px 0; }
    .sub { font-style: italic; }
    .question-box { margin-bottom: 18px; page-break-inside: avoid; }
    .q-title { font-weight: bold; margin-bottom: 6px; }
    .options-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; margin-left: 20px; margin-top: 4px; }
    .line-writing { border-bottom: 1px dotted #888; height: 26px; margin-top: 6px; }
    .answer-key { margin-top: 40px; border-top: 2px dashed #999; padding-top: 20px; page-break-before: always; }
  </style>
</head>
<body>
  <div class="school-info">
    <div>
      <div>TRƯỜNG TIỂU HỌC: ................................................</div>
      <div>HỌ VÀ TÊN HỌC SINH: .......................................</div>
    </div>
    <div>
      <div>LỚP: ............. NĂM HỌC 2025 - 2026</div>
      <div>NGÀY LÀM BÀI: ..... / ..... / 202...</div>
    </div>
  </div>

  <div class="header">
    <h1>PHIẾU BÀI TẬP CUỐI TUẦN - TOÁN LỚP ${grade}</h1>
    <div class="sub">Chủ đề: ${escapeHtml(title)} · Chương trình GDPT 2018</div>
  </div>

  <div class="questions-list">
    ${questions
      .map((q, idx) => {
        return `
      <div class="question-box">
        <div class="q-title">Câu ${idx + 1}: ${escapeHtml(q.question)}</div>
        ${
          q.options && q.options.length > 0
            ? `<div class="options-grid">
              ${q.options
                .map((opt, oIdx) => `<div>${String.fromCharCode(65 + oIdx)}. ${escapeHtml(opt)}</div>`)
                .join('')}
            </div>`
            : `<div class="line-writing"></div><div class="line-writing"></div>`
        }
      </div>`;
      })
      .join('')}
  </div>

  <div class="answer-key">
    <h3>ĐÁP ÁN THAM KHẢO & HƯỚNG DẪN GIẢI</h3>
    <ol>
      ${questions
        .map(
          (q) =>
            `<li><strong>Đáp án:</strong> ${escapeHtml(q.correctAnswer)} ${q.hint ? `<em>(${escapeHtml(q.hint)})</em>` : ''}</li>`
        )
        .join('')}
    </ol>
  </div>
</body>
</html>`;

  const boundary = '-------314159265358979323846';
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const metadata = {
    name: fileName,
    mimeType: 'text/html',
    description: `Phiếu bài tập Toán Lớp ${grade}: ${title}. Được tạo bởi VietMath Kids 2026.`,
    parents: targetFolderId !== 'root' ? [targetFolderId] : undefined,
  };

  const multipartRequestBody =
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    JSON.stringify(metadata) +
    delimiter +
    'Content-Type: text/html; charset=UTF-8\r\n\r\n' +
    htmlContent +
    closeDelimiter;

  const res = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,size,modifiedTime,webViewLink',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: multipartRequestBody,
    }
  );

  if (!res.ok) {
    const errJson = await res.json().catch(() => ({}));
    throw new Error(errJson?.error?.message || 'Không thể xuất phiếu bài tập lên Google Drive');
  }

  return await res.json();
}

/**
 * Delete a file in Google Drive
 * CRITICAL REQUIREMENT: UI MUST ALWAYS show explicit confirmation modal before executing this!
 */
export async function deleteDriveFile(token: string, fileId: string): Promise<void> {
  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok && res.status !== 204 && res.status !== 404) {
    const errJson = await res.json().catch(() => ({}));
    throw new Error(errJson?.error?.message || 'Không thể xóa tệp trên Google Drive');
  }
}
