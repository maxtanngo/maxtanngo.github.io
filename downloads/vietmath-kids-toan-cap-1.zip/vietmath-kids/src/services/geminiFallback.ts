import type { GoogleGenAI, GenerateContentParameters } from '@google/genai';

const cooldown = new Map<string, number>();

export function modelList(value: string | undefined, defaults: string[]): string[] {
  const configured = value?.split(',').map(model => model.trim()).filter(Boolean);
  return [...new Set(configured?.length ? configured : defaults)].slice(0, 5);
}

export async function generateWithFallback(client: GoogleGenAI, models: string[], options: Omit<GenerateContentParameters, 'model'>, budget: number) {
  const deadline = Date.now() + budget;
  let failure: unknown = new Error('Các model đang trong thời gian chờ.');
  const available = models.filter(model => (cooldown.get(model) ?? 0) <= Date.now());
  for (const [index, model] of available.entries()) {
    const remaining = deadline - Date.now();
    if (remaining < 200) break;
    const timeout = Math.min(remaining, index < available.length - 1 ? Math.max(1500, Math.floor(budget / 2)) : remaining);
    const signal = AbortSignal.timeout(timeout);
    try {
      const response = await client.models.generateContent({ ...options, model, config: {
        ...options.config, abortSignal: signal, httpOptions: { timeout, retryOptions: { attempts: 1 } },
      } });
      return { response, model };
    } catch (error) {
      failure = error;
      const status = Number((error as { status?: number })?.status);
      if (!signal.aborted && ![404, 408, 429, 500, 502, 503, 504].includes(status)) throw error;
      cooldown.set(model, Date.now() + (status === 429 ? 60000 : status === 404 ? 600000 : 15000));
    }
  }
  throw failure;
}
