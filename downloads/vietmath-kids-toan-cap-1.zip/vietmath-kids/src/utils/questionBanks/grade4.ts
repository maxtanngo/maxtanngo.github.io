import { Question, Lesson } from '../../types';

export function getGrade4Questions(lesson: Lesson): Question[] {
  const id = lesson.id;
  const title = lesson.title.toLowerCase();

  // Bài 11, 12, 13: Phân số & Các phép tính phân số
  if (id === 'g4_l11' || id === 'g4_l12' || id === 'g4_l13' || title.includes('phân số')) {
    return [
      {
        id: `${id}_1`,
        level: 'Mức 1',
        strand: 'Số & Phép tính',
        type: 'visual_fraction',
        visualData: { fractionNumerator: 3, fractionDenominator: 5, fractionType: 'bar' },
        question: 'Phân số chỉ phần đã tô màu trong băng giấy gồm 5 phần bằng nhau, đã tô 3 phần là:',
        options: ['3/5', '5/3', '2/5', '3/8'],
        correctAnswer: '3/5',
        hint: 'Tử số là số phần đã tô (3), mẫu số là tổng số phần bằng nhau (5).',
        explanation: 'Phân số chỉ phần đã tô màu là 3/5.',
      },
      {
        id: `${id}_2`,
        level: 'Mức 1',
        strand: 'Số & Phép tính',
        type: 'multiple_choice',
        question: 'Rút gọn phân số 15/20 về phân số tối giản ta được:',
        options: ['3/4', '5/4', '3/5', '1/4'],
        correctAnswer: '3/4',
        hint: 'Chia cả tử số và mẫu số cho ước chung lớn nhất là 5: (15 : 5)/(20 : 5).',
        explanation: '15/20 = (15 : 5)/(20 : 5) = 3/4.',
      },
      {
        id: `${id}_3`,
        level: 'Mức 2',
        strand: 'Số & Phép tính',
        type: 'multiple_choice',
        question: 'Tính: 2/7 + 3/7 = ?',
        options: ['5/7', '5/14', '6/7', '1/7'],
        correctAnswer: '5/7',
        hint: 'Cùng mẫu số: giữ nguyên mẫu số 7, cộng hai tử số 2 + 3 = 5.',
        explanation: '2/7 + 3/7 = (2 + 3)/7 = 5/7.',
      },
      {
        id: `${id}_4`,
        level: 'Mức 2',
        strand: 'Số & Phép tính',
        type: 'multiple_choice',
        question: 'Tính: 1/2 + 1/3 = ?',
        options: ['5/6', '2/5', '1/6', '5/5'],
        correctAnswer: '5/6',
        hint: 'Quy đồng mẫu số chung là 6: 3/6 + 2/6 = 5/6.',
        explanation: '1/2 + 1/3 = 3/6 + 2/6 = 5/6.',
      },
      {
        id: `${id}_5`,
        level: 'Mức 2',
        strand: 'Số & Phép tính',
        type: 'number_input',
        question: 'Tìm 3/4 của 60 kg là bao nhiêu kg? (Nhập số)',
        correctAnswer: '45',
        hint: 'Muốn tìm phân số của một số: lấy số đó nhân với phân số: 60 × 3/4 = (60 : 4) × 3.',
        explanation: '3/4 của 60 kg là: (60 : 4) × 3 = 15 × 3 = 45 kg.',
      },
      {
        id: `${id}_6`,
        level: 'Mức 3',
        strand: 'Giải toán có lời văn',
        type: 'multiple_choice',
        question: 'Một lớp học có 35 học sinh, trong đó 3/5 số học sinh là nữ. Hỏi lớp đó có bao nhiêu học sinh nam?',
        options: ['14 bạn', '21 bạn', '15 bạn', '12 bạn'],
        correctAnswer: '14 bạn',
        hint: 'Số học sinh nữ = 35 × 3/5 = 21 bạn. Số học sinh nam = 35 - 21.',
        explanation: 'Số học sinh nữ là: 35 × 3/5 = 21 bạn. Số học sinh nam là: 35 - 21 = 14 bạn.',
      },
    ];
  }

  // Bài 7: Tìm hai số khi biết Tổng và Hiệu
  if (id === 'g4_l7' || title.includes('tổng và hiệu')) {
    return [
      {
        id: `${id}_1`,
        level: 'Mức 1',
        strand: 'Giải toán có lời văn',
        type: 'multiple_choice',
        question: 'Công thức tìm số lớn khi biết tổng và hiệu của hai số là:',
        options: ['Số lớn = (Tổng + Hiệu) : 2', 'Số lớn = (Tổng - Hiệu) : 2', 'Số lớn = Tổng : 2 + Hiệu', 'Số lớn = Tổng + Hiệu'],
        correctAnswer: 'Số lớn = (Tổng + Hiệu) : 2',
        hint: 'Số lớn = (Tổng + Hiệu) : 2; Số bé = (Tổng - Hiệu) : 2.',
        explanation: 'Công thức chuẩn: Số lớn = (Tổng + Hiệu) : 2.',
      },
      {
        id: `${id}_2`,
        level: 'Mức 1',
        strand: 'Số & Phép tính',
        type: 'number_input',
        question: 'Hai số có tổng là 50 và hiệu là 10. Tìm số lớn (Nhập số)',
        correctAnswer: '30',
        hint: 'Số lớn = (50 + 10) : 2 = 60 : 2.',
        explanation: 'Số lớn là: (50 + 10) : 2 = 30.',
      },
      {
        id: `${id}_3`,
        level: 'Mức 2',
        strand: 'Số & Phép tính',
        type: 'number_input',
        question: 'Hai số có tổng là 84 và hiệu là 16. Tìm số bé (Nhập số)',
        correctAnswer: '34',
        hint: 'Số bé = (84 - 16) : 2 = 68 : 2.',
        explanation: 'Số bé là: (84 - 16) : 2 = 34.',
      },
      {
        id: `${id}_4`,
        level: 'Mức 2',
        strand: 'Giải toán có lời văn',
        type: 'multiple_choice',
        question: 'Tuổi của mẹ và con cộng lại là 42 tuổi. Mẹ hơn con 28 tuổi. Hỏi năm nay mẹ bao nhiêu tuổi?',
        options: ['35 tuổi', '36 tuổi', '38 tuổi', '32 tuổi'],
        correctAnswer: '35 tuổi',
        hint: 'Tuổi mẹ = (42 + 28) : 2 = 70 : 2.',
        explanation: 'Tuổi mẹ là: (42 + 28) : 2 = 35 tuổi (con 7 tuổi).',
      },
      {
        id: `${id}_5`,
        level: 'Mức 3',
        strand: 'Giải toán có lời văn',
        type: 'number_input',
        question: 'Một thửa ruộng hình chữ nhật có chu vi là 160 m. Chiều dài hơn chiều rộng 20 m. Diện tích thửa ruộng đó là bao nhiêu mét vuông? (Nhập số)',
        correctAnswer: '1500',
        hint: 'Nửa chu vi = 80 m. Dài = (80 + 20) : 2 = 50 m. Rộng = 80 - 50 = 30 m. S = 50 × 30.',
        explanation: 'Nửa chu vi: 160 : 2 = 80 m. Chiều dài: (80 + 20) : 2 = 50 m. Chiều rộng: 80 - 50 = 30 m. Diện tích: 50 × 30 = 1 500 m².',
      },
    ];
  }

  // Bài 9: Tìm số trung bình cộng
  if (id === 'g4_l9' || title.includes('trung bình cộng')) {
    return [
      {
        id: `${id}_1`,
        level: 'Mức 1',
        strand: 'Số & Phép tính',
        type: 'number_input',
        question: 'Tìm số trung bình cộng của hai số 14 và 26 (Nhập số)',
        correctAnswer: '20',
        hint: 'Lấy (14 + 26) : 2.',
        explanation: 'Trung bình cộng: (14 + 26) : 2 = 40 : 2 = 20.',
      },
      {
        id: `${id}_2`,
        level: 'Mức 2',
        strand: 'Số & Phép tính',
        type: 'number_input',
        question: 'Tìm trung bình cộng của 3 số: 15, 25, 50 (Nhập số)',
        correctAnswer: '30',
        hint: 'Tổng 3 số: 15 + 25 + 50 = 90. Chia cho 3.',
        explanation: 'Trung bình cộng: (15 + 25 + 50) : 3 = 90 : 3 = 30.',
      },
      {
        id: `${id}_3`,
        level: 'Mức 3',
        strand: 'Giải toán có lời văn',
        type: 'multiple_choice',
        question: 'Bốn bạn An, Bình, Cường, Dũng cân nặng lần lượt là 32 kg, 34 kg, 36 kg và 38 kg. Hỏi trung bình mỗi bạn cân nặng bao nhiêu ki-lô-gam?',
        options: ['35 kg', '34 kg', '36 kg', '33 kg'],
        correctAnswer: '35 kg',
        hint: 'Tổng số cân nặng = 32 + 34 + 36 + 38 = 140 kg. Chia cho 4.',
        explanation: 'Tổng cân nặng: 140 kg. Trung bình mỗi bạn nặng: 140 : 4 = 35 kg.',
      },
    ];
  }

  // Bài 6: Hình bình hành và Hình thoi
  if (id === 'g4_l6' || title.includes('hình bình hành') || title.includes('hình thoi')) {
    return [
      {
        id: `${id}_1`,
        level: 'Mức 1',
        strand: 'Hình học & Đo lường',
        type: 'multiple_choice',
        question: 'Công thức tính diện tích hình bình hành có đáy a và chiều cao h là:',
        options: ['S = a × h', 'S = (a × h) : 2', 'S = (a + h) × 2', 'S = a × a'],
        correctAnswer: 'S = a × h',
        hint: 'Diện tích hình bình hành bằng độ dài đáy nhân với chiều cao.',
        explanation: 'S = a × h (cùng đơn vị đo).',
      },
      {
        id: `${id}_2`,
        level: 'Mức 2',
        strand: 'Hình học & Đo lường',
        type: 'number_input',
        question: 'Một hình thoi có độ dài hai đường chéo là 8 cm và 15 cm. Diện tích của hình thoi đó là bao nhiêu cm²? (Nhập số)',
        correctAnswer: '60',
        hint: 'Diện tích hình thoi = (m × n) : 2 = (8 × 15) : 2.',
        explanation: 'Diện tích hình thoi: (8 × 15) : 2 = 120 : 2 = 60 cm².',
      },
    ];
  }

  // Bài 3: Đơn vị Yến, Tạ, Tấn & Giây, Thế kỷ
  if (id === 'g4_l3' || title.includes('yến') || title.includes('tấn') || title.includes('thế kỷ')) {
    return [
      {
        id: `${id}_1`,
        level: 'Mức 1',
        strand: 'Hình học & Đo lường',
        type: 'multiple_choice',
        question: '1 tấn bằng bao nhiêu ki-lô-gam?',
        options: ['1 000 kg', '100 kg', '10 kg', '10 000 kg'],
        correctAnswer: '1 000 kg',
        hint: '1 tấn = 10 tạ = 100 yến = 1 000 kg.',
        explanation: '1 tấn = 1 000 kg.',
      },
      {
        id: `${id}_2`,
        level: 'Mức 1',
        strand: 'Hình học & Đo lường',
        type: 'multiple_choice',
        question: 'Năm 2026 thuộc thế kỷ thứ mấy?',
        options: ['Thế kỷ 21 (XXI)', 'Thế kỷ 20 (XX)', 'Thế kỷ 22 (XXII)', 'Thế kỷ 19 (XIX)'],
        correctAnswer: 'Thế kỷ 21 (XXI)',
        hint: 'Từ năm 2001 đến hết năm 2100 là thế kỷ 21.',
        explanation: 'Năm 2026 thuộc thế kỷ XXI (thế kỷ 21).',
      },
      {
        id: `${id}_3`,
        level: 'Mức 2',
        strand: 'Hình học & Đo lường',
        type: 'number_input',
        question: 'Đổi: 3 tấn 5 tạ = ... tạ. (Nhập số)',
        correctAnswer: '35',
        hint: '3 tấn = 30 tạ, 30 + 5 = 35 tạ.',
        explanation: '3 tấn 5 tạ = 35 tạ.',
      },
    ];
  }

  // Tổng hợp kiến thức Lớp 4
  return [
    {
      id: `${id}_1`,
      level: 'Mức 1',
      strand: 'Số & Phép tính',
      type: 'multiple_choice',
      question: 'Số "Bảy mươi lăm triệu sáu trăm linh hai nghìn" được viết là:',
      options: ['75 602 000', '75 620 000', '75 062 000', '75 600 002'],
      correctAnswer: '75 602 000',
      hint: 'Lớp triệu: 75. Lớp nghìn: 602. Lớp đơn vị: 000.',
      explanation: 'Số đó là 75 602 000.',
    },
    {
      id: `${id}_2`,
      level: 'Mức 1',
      strand: 'Hình học & Đo lường',
      type: 'multiple_choice',
      question: 'Góc có số đo lớn hơn góc vuông nhưng nhỏ hơn góc bẹt là góc gì?',
      options: ['Góc tù', 'Góc nhọn', 'Góc vuông', 'Góc bẹt'],
      correctAnswer: 'Góc tù',
      hint: 'Góc nhọn < 90°; Góc vuông = 90°; 90° < Góc tù < 180°.',
      explanation: 'Góc tù lớn hơn góc vuông và nhỏ hơn góc bẹt.',
    },
    {
      id: `${id}_3`,
      level: 'Mức 2',
      strand: 'Số & Phép tính',
      type: 'number_input',
      question: 'Tính giá trị biểu thức: a + b × 2 với a = 30, b = 25 (Nhập số)',
      correctAnswer: '80',
      hint: 'Thay số: 30 + 25 × 2. Thực hiện nhân trước: 25 × 2 = 50, rồi lấy 30 + 50.',
      explanation: '30 + 25 × 2 = 30 + 50 = 80.',
    },
    {
      id: `${id}_4`,
      level: 'Mức 2',
      strand: 'Giải toán có lời văn',
      type: 'number_input',
      question: 'Mua 5 quyển vở hết 40 000 đồng. Hỏi mua 8 quyển vở cùng loại hết bao nhiêu nghìn đồng? (Nhập số đơn vị nghìn, ví dụ: 64)',
      correctAnswer: '64',
      hint: 'Rút về đơn vị: 1 quyển vở = 40 000 : 5 = 8 000 đồng. 8 quyển = 8 000 × 8 = 64 000 đồng.',
      explanation: 'Giá 1 quyển vở: 40 : 5 = 8 nghìn đồng. 8 quyển vở: 8 × 8 = 64 nghìn đồng.',
    },
    {
      id: `${id}_5`,
      level: 'Mức 3',
      strand: 'Giải toán có lời văn',
      type: 'multiple_choice',
      question: 'Một khu vườn hình chữ nhật có nửa chu vi là 90 m. Chiều dài gấp đôi chiều rộng. Diện tích khu vườn đó là:',
      options: ['1 800 m²', '2 700 m²', '3 600 m²', '1 200 m²'],
      correctAnswer: '1 800 m²',
      hint: 'Tổng số phần = 1 + 2 = 3 phần. Chiều rộng = 90 : 3 = 30 m. Chiều dài = 30 × 2 = 60 m. S = 60 × 30.',
      explanation: 'Chiều rộng: 90 : (1 + 2) = 30 m. Chiều dài: 30 × 2 = 60 m. Diện tích: 60 × 30 = 1 800 m².',
    },
  ];
}
