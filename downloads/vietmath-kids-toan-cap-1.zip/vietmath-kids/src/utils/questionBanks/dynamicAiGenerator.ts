import { Question, Grade, VisualData } from '../../types';

/**
 * Bộ tạo câu hỏi thông minh năng động (Dynamic Smart Math Generator)
 * Đảm bảo:
 * 1. Luôn sinh ra ngay lập tức (<10ms), không bao giờ bị nghẽn hay treo.
 * 2. Đa dạng câu hỏi theo đúng Thông tư 27 (Mức 1, Mức 2, Mức 3).
 * 3. Nội dung phong phú, thay đổi số liệu liên tục theo thời gian thực (không trùng lặp).
 * 4. Định dạng thân thiện với TTS: không dùng dấu hai chấm ':' làm ngắt câu để tránh đọc thành 'chia'.
 */

function randInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function shuffle<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export function generateDynamicQuestions(
  grade: Grade | number,
  topic: string,
  count = 5,
  level = 'basic'
): Question[] {
  const g = Math.max(1, Math.min(5, Math.trunc(Number(grade) || 1))) as Grade;
  const questions: Question[] = [];
  const timestamp = Date.now() + '_' + Math.random().toString(36).slice(2, 8);
  const topicKind = classifyTopic(topic);
  const mixedGeometry = topicKind === 'perimeter' && /diện tích/i.test(topic);

  for (let i = 0; i < count; i++) {
    const qIndex = i + 1;
    const qId = `dyn_${timestamp}_${i}`;
    const qLevel = level === 'advanced' ? 'Mức 3' : i < 2 ? 'Mức 1' : i < 4 ? 'Mức 2' : 'Mức 3';
    const targeted = makeTopicQuestion(mixedGeometry && i % 2 ? 'area' : topicKind, g, qId, qIndex, qLevel);
    if (targeted) { questions.push(targeted); continue; }

    if (g === 1) {
      questions.push(generateGrade1Item(qId, qIndex, qLevel, topic));
    } else if (g === 2) {
      questions.push(generateGrade2Item(qId, qIndex, qLevel, topic));
    } else if (g === 3) {
      questions.push(generateGrade3Item(qId, qIndex, qLevel, topic));
    } else if (g === 4) {
      questions.push(generateGrade4Item(qId, qIndex, qLevel, topic));
    } else {
      questions.push(generateGrade5Item(qId, qIndex, qLevel, topic));
    }
  }

  return questions;
}

function generateGrade1Item(id: string, idx: number, level: 'Mức 1' | 'Mức 2' | 'Mức 3', topic: string): Question {
  const subType = idx % 4;

  if (subType === 0) {
    const countVal = randInt(3, 7);
    const items: NonNullable<VisualData['countItem']>[] = ['apple', 'star', 'pencil', 'candy', 'flower', 'fish'];
    const item = items[randInt(0, items.length - 1)];
    const itemName = item === 'apple' ? 'quả táo' : item === 'star' ? 'ngôi sao' : item === 'candy' ? 'viên kẹo' : item === 'pencil' ? 'cây bút' : item === 'flower' ? 'bông hoa' : 'con cá';
    const wrong1 = countVal + 1;
    const wrong2 = Math.max(1, countVal - 1);
    const wrong3 = countVal + 2;
    const options = shuffle([`${countVal} ${itemName}`, `${wrong1} ${itemName}`, `${wrong2} ${itemName}`, `${wrong3} ${itemName}`]);

    return {
      id,
      level,
      strand: 'Số & Phép tính',
      type: 'visual_count',
      visualData: { countItem: item, countNumber: countVal },
      question: `Con hãy đếm xem trong hình có tất cả bao nhiêu ${itemName}?`,
      options,
      correctAnswer: `${countVal} ${itemName}`,
      hint: `Chạm vào từng hình để đếm từ 1 trở đi nhé con.`,
      explanation: `Đếm lần lượt có đúng ${countVal} ${itemName}.`,
    };
  }

  if (subType === 1) {
    const a = randInt(2, 6);
    const b = randInt(1, 4);
    const sum = a + b;
    return {
      id,
      level,
      strand: 'Số & Phép tính',
      type: 'number_input',
      question: `Tính nhẩm. ${a} + ${b} = ? (Nhập kết quả)`,
      correctAnswer: String(sum),
      hint: `Lấy ${a} đếm thêm ${b} đơn vị.`,
      explanation: `${a} + ${b} = ${sum}. Con làm rất chính xác!`,
    };
  }

  if (subType === 2) {
    const a = randInt(5, 9);
    const b = randInt(1, a - 1);
    const diff = a - b;
    const wrongOptions = [diff + 1, Math.max(0, diff - 1), diff + 2].map(String);
    const options = shuffle([String(diff), ...wrongOptions]);

    return {
      id,
      level,
      strand: 'Số & Phép tính',
      type: 'multiple_choice',
      question: `Phép tính ${a} - ${b} có kết quả là:`,
      options,
      correctAnswer: String(diff),
      hint: `Lấy ${a} ngón tay, cụp bớt ${b} ngón lại nhé.`,
      explanation: `${a} - ${b} = ${diff}.`,
    };
  }

  // Word problem
  const nam = randInt(3, 6);
  const nu = randInt(2, 4);
  const total = nam + nu;
  return {
    id,
    level: 'Mức 3',
    strand: 'Giải toán có lời văn',
    type: 'multiple_choice',
    question: `Bạn Lan có ${nam} bông hoa đỏ và ${nu} bông hoa vàng. Hỏi bạn Lan có tất cả bao nhiêu bông hoa?`,
    options: shuffle([`${total} bông hoa`, `${total + 1} bông hoa`, `${total - 1} bông hoa`, `${total + 2} bông hoa`]),
    correctAnswer: `${total} bông hoa`,
    hint: `Muốn biết có tất cả bao nhiêu, ta làm phép tính cộng: ${nam} + ${nu}.`,
    explanation: `Số bông hoa bạn Lan có là: ${nam} + ${nu} = ${total} bông hoa.`,
  };
}

function generateGrade2Item(id: string, idx: number, level: 'Mức 1' | 'Mức 2' | 'Mức 3', topic: string): Question {
  const mode = idx % 4;

  if (mode === 0) {
    // Multiplication 2 or 5
    const factor = [2, 5][randInt(0, 1)];
    const n = randInt(3, 9);
    const prod = factor * n;
    const options = shuffle([String(prod), String(prod + factor), String(prod - factor), String(prod + 1)]);
    return {
      id,
      level,
      strand: 'Số & Phép tính',
      type: 'multiple_choice',
      question: `Tính giá trị của phép nhân. ${factor} × ${n} = ?`,
      options,
      correctAnswer: String(prod),
      hint: `Áp dụng bảng nhân ${factor}: ${factor} được lấy ${n} lần.`,
      explanation: `${factor} × ${n} = ${prod}.`,
    };
  }

  if (mode === 1) {
    // Clock
    const h = randInt(1, 11);
    return {
      id,
      level,
      strand: 'Hình học & Đo lường',
      type: 'visual_clock',
      visualData: { clockHour: h, clockMinute: 0 },
      question: `Đồng hồ bên dưới đang chỉ mấy giờ đúng?`,
      options: shuffle([`${h} giờ đúng`, `${(h % 12) + 1} giờ đúng`, `${((h + 10) % 12) + 1} giờ đúng`, `${((h + 1) % 12) + 1} giờ đúng`]),
      correctAnswer: `${h} giờ đúng`,
      hint: `Kim ngắn màu đỏ chỉ số ${h}, kim dài chỉ số 12.`,
      explanation: `Khi kim dài chỉ số 12 và kim ngắn chỉ số ${h}, lúc đó là ${h} giờ đúng.`,
    };
  }

  if (mode === 2) {
    const a = randInt(25, 60);
    const b = randInt(18, 38);
    const sum = a + b;
    return {
      id,
      level,
      strand: 'Số & Phép tính',
      type: 'number_input',
      question: `Đặt tính rồi tính. ${a} + ${b} = ? (Nhập kết quả)`,
      correctAnswer: String(sum),
      hint: `Cộng từ hàng đơn vị trước rồi nhớ 1 sang hàng chục nếu cần.`,
      explanation: `${a} + ${b} = ${sum}.`,
    };
  }

  // Word problem
  const have = randInt(20, 45);
  const more = randInt(6, 15);
  const total = have + more;
  return {
    id,
    level: 'Mức 3',
    strand: 'Giải toán có lời văn',
    type: 'multiple_choice',
    question: `Bình có ${have} viên bi. An có nhiều hơn Bình ${more} viên bi. Hỏi An có bao nhiêu viên bi?`,
    options: shuffle([`${total} viên bi`, `${total - 2} viên bi`, `${total + 3} viên bi`, `${have - more} viên bi`]),
    correctAnswer: `${total} viên bi`,
    hint: `Dạng toán nhiều hơn, ta lấy số bi của Bình cộng với phần nhiều hơn: ${have} + ${more}.`,
    explanation: `Số bi của An là: ${have} + ${more} = ${total} (viên bi).`,
  };
}

function generateGrade3Item(id: string, idx: number, level: 'Mức 1' | 'Mức 2' | 'Mức 3', topic: string): Question {
  const mode = idx % 4;

  if (mode === 0) {
    const d = randInt(6, 15);
    const r = randInt(3, d - 2);
    const s = d * r;
    return {
      id,
      level,
      strand: 'Hình học & Đo lường',
      type: 'number_input',
      question: `Một hình chữ nhật có chiều dài ${d} cm và chiều rộng ${r} cm. Diện tích của hình chữ nhật là bao nhiêu cm²? (Nhập số)`,
      correctAnswer: String(s),
      hint: `Diện tích hình chữ nhật = Chiều dài × Chiều rộng: ${d} × ${r}.`,
      explanation: `Diện tích là: ${d} × ${r} = ${s} cm².`,
    };
  }

  if (mode === 1) {
    const a = randInt(6, 9);
    const b = randInt(6, 9);
    const prod = a * b;
    return {
      id,
      level,
      strand: 'Số & Phép tính',
      type: 'multiple_choice',
      question: `Tính nhẩm giá trị phép tính. ${a} × ${b} = ?`,
      options: shuffle([String(prod), String(prod + a), String(prod - b), String(prod + 2)]),
      correctAnswer: String(prod),
      hint: `Nhẩm lại bảng nhân ${a}.`,
      explanation: `${a} × ${b} = ${prod}.`,
    };
  }

  if (mode === 2) {
    const total = randInt(20, 60);
    const divisor = [2, 3, 4, 5][randInt(0, 3)];
    const part = Math.floor(total / divisor);
    const realTotal = part * divisor;
    return {
      id,
      level,
      strand: 'Số & Phép tính',
      type: 'multiple_choice',
      question: `Tìm 1/${divisor} của ${realTotal} cái kẹo:`,
      options: shuffle([`${part} cái kẹo`, `${part + 2} cái kẹo`, `${part - 1} cái kẹo`, `${part + 5} cái kẹo`]),
      correctAnswer: `${part} cái kẹo`,
      hint: `Muốn tìm 1/${divisor} của một số, ta lấy số đó chia cho ${divisor}.`,
      explanation: `${realTotal} chia ${divisor} = ${part} cái kẹo.`,
    };
  }

  // Expression
  const x = randInt(10, 30);
  const y = randInt(2, 6);
  const z = randInt(3, 8);
  const res = x + y * z;
  return {
    id,
    level: 'Mức 3',
    strand: 'Số & Phép tính',
    type: 'number_input',
    question: `Tính giá trị của biểu thức. ${x} + ${y} × ${z} = ? (Nhập số)`,
    correctAnswer: String(res),
    hint: `Thực hiện phép nhân trước: ${y} × ${z} = ${y * z}, sau đó lấy ${x} + ${y * z}.`,
    explanation: `${x} + ${y} × ${z} = ${x} + ${y * z} = ${res}.`,
  };
}

function generateGrade4Item(id: string, idx: number, level: 'Mức 1' | 'Mức 2' | 'Mức 3', topic: string): Question {
  const mode = idx % 4;

  if (mode === 0) {
    const denom = [4, 5, 6, 8, 10][randInt(0, 4)];
    const num = randInt(1, denom - 1);
    return {
      id,
      level,
      strand: 'Số & Phép tính',
      type: 'visual_fraction',
      visualData: { fractionNumerator: num, fractionDenominator: denom, fractionType: 'bar' },
      question: `Phân số biểu thị phần tô màu trong hình bên dưới là:`,
      options: shuffle([`${num}/${denom}`, `${denom}/${num}`, `${num === 1 ? denom - 1 : num - 1}/${denom}`, `${num + 1}/${denom}`]),
      correctAnswer: `${num}/${denom}`,
      hint: `Tử số là số phần tô màu (${num}), mẫu số là tổng số phần (${denom}).`,
      explanation: `Phần tô màu chiếm ${num} trên tổng số ${denom} phần bằng nhau, tức là phân số ${num}/${denom}.`,
    };
  }

  if (mode === 1) {
    const ton = randInt(2, 7);
    const kg = ton * 1000;
    return {
      id,
      level,
      strand: 'Hình học & Đo lường',
      type: 'number_input',
      question: `Đổi đơn vị khối lượng. ${ton} tấn = ... kg? (Nhập số)`,
      correctAnswer: String(kg),
      hint: `1 tấn = 1000 kg nên ${ton} tấn = ${ton} × 1000.`,
      explanation: `${ton} tấn = ${kg} kg.`,
    };
  }

  if (mode === 2) {
    const num1 = randInt(1, 3);
    const num2 = randInt(1, 4);
    const den = 7;
    const sum = num1 + num2;
    return {
      id,
      level,
      strand: 'Số & Phép tính',
      type: 'multiple_choice',
      question: `Tính phép cộng phân số cùng mẫu. ${num1}/${den} + ${num2}/${den} = ?`,
      options: shuffle([`${sum}/${den}`, `${sum}/${den * 2}`, `${sum - 1}/${den}`, `${sum + 1}/${den}`]),
      correctAnswer: `${sum}/${den}`,
      hint: `Giữ nguyên mẫu số ${den}, lấy hai tử số cộng lại: ${num1} + ${num2} = ${sum}.`,
      explanation: `${num1}/${den} + ${num2}/${den} = (${num1} + ${num2})/${den} = ${sum}/${den}.`,
    };
  }

  // Two steps word problem
  const n1 = randInt(20, 50);
  const n2 = randInt(2, 3);
  const total2 = n1 * n2;
  const all = n1 + total2;
  return {
    id,
    level: 'Mức 3',
    strand: 'Giải toán có lời văn',
    type: 'multiple_choice',
    question: `Đội Một trồng được ${n1} cây xanh. Đội Hai trồng được gấp ${n2} lần Đội Một. Hỏi cả hai đội trồng được bao nhiêu cây xanh?`,
    options: shuffle([`${all} cây`, `${total2} cây`, `${all + 5} cây`, `${all + n1} cây`]),
    correctAnswer: `${all} cây`,
    hint: `Bước 1 tính số cây Đội Hai: ${n1} × ${n2} = ${total2}. Bước 2 tính cả hai đội: ${n1} + ${total2}.`,
    explanation: `Đội Hai trồng: ${n1} × ${n2} = ${total2} cây. Cả hai đội trồng: ${n1} + ${total2} = ${all} cây.`,
  };
}

function generateGrade5Item(id: string, idx: number, level: 'Mức 1' | 'Mức 2' | 'Mức 3', topic: string): Question {
  const mode = idx % 4;

  if (mode === 0) {
    const val = (randInt(11, 89) / 10).toFixed(1);
    const mul = 10;
    const res = (parseFloat(val) * mul).toFixed(0);
    return {
      id,
      level,
      strand: 'Số & Phép tính',
      type: 'number_input',
      question: `Tính nhẩm. ${val.replace('.', ',')} × ${mul} = ? (Nhập số)`,
      correctAnswer: String(res),
      hint: `Nhân với 10 thì dời dấu phẩy sang bên phải 1 chữ số.`,
      explanation: `${val.replace('.', ',')} × ${mul} = ${res}.`,
    };
  }

  if (mode === 1) {
    const pct = [10, 20, 25, 50][randInt(0, 3)];
    const base = [100, 200, 300, 400][randInt(0, 3)];
    const ans = (base * pct) / 100;
    return {
      id,
      level,
      strand: 'Số & Phép tính',
      type: 'multiple_choice',
      question: `Tìm ${pct}% của ${base} kg:`,
      options: shuffle([`${ans} kg`, `${ans + 10} kg`, `${ans - 5} kg`, `${ans + 15} kg`]),
      correctAnswer: `${ans} kg`,
      hint: `Lấy ${base} chia 100 rồi nhân ${pct}: ${base} × ${pct} / 100.`,
      explanation: `${pct}% của ${base} kg là: ${base} × ${pct} : 100 = ${ans} kg.`,
    };
  }

  if (mode === 2) {
    const v = [30, 40, 50, 60][randInt(0, 3)];
    const t = [2, 3, 4][randInt(0, 2)];
    const s = v * t;
    return {
      id,
      level,
      strand: 'Giải toán có lời văn',
      type: 'number_input',
      question: `Một ô tô chạy với vận tốc ${v} km/h trong thời gian ${t} giờ. Hỏi ô tô đi được quãng đường bao nhiêu ki-lô-mét? (Nhập số)`,
      correctAnswer: String(s),
      hint: `Công thức quãng đường: s = v × t = ${v} × ${t}.`,
      explanation: `Quãng đường đi được là: ${v} × ${t} = ${s} km.`,
    };
  }

  // Geometry or Ratio
  const day = randInt(6, 14);
  const cao = randInt(4, 10);
  const dt = (day * cao) / 2;
  return {
    id,
    level: 'Mức 3',
    strand: 'Hình học & Đo lường',
    type: 'multiple_choice',
    question: `Một hình tam giác có độ dài đáy là ${day} cm và chiều cao tương ứng là ${cao} cm. Diện tích tam giác đó là:`,
    options: shuffle([`${dt} cm²`, `${day * cao} cm²`, `${dt + 4} cm²`, `${dt - 2} cm²`]),
    correctAnswer: `${dt} cm²`,
    hint: `Diện tích tam giác = (Đáy × Chiều cao) chia 2: (${day} × ${cao}) / 2.`,
    explanation: `Diện tích tam giác là: (${day} × ${cao}) : 2 = ${dt} cm².`,
  };
}

export function classifyTopic(topic: string) {
  const name = topic.toLocaleLowerCase('vi');
  if (/chu vi/.test(name)) return 'perimeter';
  if (/diện tích/.test(name)) return 'area';
  if (/đồng hồ|giờ đúng/.test(name)) return 'clock';
  if (/phần trăm|%/.test(name)) return 'percent';
  if (/vận tốc|chuyển động|quãng đường/.test(name)) return 'speed';
  if (/phân số|phần mấy/.test(name)) return 'fraction';
  if (/tam giác/.test(name)) return 'triangle';
  if (/hình phẳng|hình tròn|hình vuông|hình chữ nhật/.test(name)) return 'shape';
  if (/bảng nhân|bảng chia|phép nhân/.test(name)) return 'multiply';
  if (/cộng.*trừ|phép cộng|phép trừ/.test(name)) return 'arithmetic';
  return 'mixed';
}

function makeTopicQuestion(kind: ReturnType<typeof classifyTopic>, grade: Grade, id: string, index: number, level: NonNullable<Question['level']>): Question | undefined {
  if (kind === 'mixed') return;
  if (kind === 'clock') return generateGrade2Item(id, 1, level, '');
  if (kind === 'fraction') return grade <= 3 ? generateGrade3Item(id, 2, level, '') : generateGrade4Item(id, index % 2 === 0 ? 0 : 2, level, '');
  if (kind === 'percent') return generateGrade5Item(id, 1, level, '');
  if (kind === 'speed') return generateGrade5Item(id, 2, level, '');
  if (kind === 'multiply') return grade <= 2 ? generateGrade2Item(id, 0, level, '') : generateGrade3Item(id, 1, level, '');
  if (kind === 'shape' || kind === 'triangle') {
    const options = ['Hình tam giác', 'Hình vuông', 'Hình tròn', 'Hình chữ nhật'];
    const forms = [
      { question: 'Hình nào có đúng 3 cạnh?', answer: 0, explanation: 'Hình tam giác có 3 cạnh.' },
      { question: 'Hình nào có 3 đỉnh và 3 góc?', answer: 0, explanation: 'Hình tam giác có 3 đỉnh và 3 góc.' },
      { question: 'Hình nào không có cạnh thẳng?', answer: 2, explanation: 'Đường bao của hình tròn là một đường cong.' },
      { question: 'Trong các hình sau, hình nào có bốn cạnh bằng nhau và bốn góc vuông?', answer: 1, explanation: 'Hình vuông có bốn cạnh bằng nhau và bốn góc vuông.' },
      { question: 'Hình nào có ít đỉnh hơn hình vuông đúng một đỉnh?', answer: 0, explanation: 'Hình vuông có 4 đỉnh, còn tam giác có 3 đỉnh.' },
      { question: 'Nối 3 điểm không thẳng hàng bằng 3 đoạn thẳng khép kín được hình gì?', answer: 0, explanation: 'Ba đoạn thẳng khép kín đó tạo thành một hình tam giác.' },
      { question: 'Mặt trước của biển cảnh báo có dạng hình ba cạnh. Đó là hình gì?', answer: 0, explanation: 'Hình có ba cạnh là hình tam giác.' },
    ];
    const pool = kind === 'triangle' ? forms.filter(form => form.answer === 0) : forms;
    const form = pool[(index - 1) % pool.length];
    return { id, level, type: 'multiple_choice', strand: 'Hình học & Đo lường',
      question: form.question, options: shuffle(options), correctAnswer: options[form.answer],
      hint: 'Con hãy nghĩ đến số cạnh hoặc số góc của từng hình.', explanation: form.explanation };
  }
  if (kind === 'area' && grade === 5) return generateGrade5Item(id, 3, level, '');
  if (kind === 'area' || kind === 'perimeter') {
    const width = randInt(2, 7);
    const length = width + randInt(1, 9);
    const perimeter = kind === 'perimeter';
    const label = perimeter ? 'chu vi' : 'diện tích';
    const formula = perimeter ? `(${length} + ${width}) × 2` : `${length} × ${width}`;
    const result = perimeter ? (length + width) * 2 : length * width;
    return { id, level, type: 'number_input', strand: 'Hình học & Đo lường',
      question: `Hình chữ nhật dài ${length} cm, rộng ${width} cm. Tính ${label} theo ${perimeter ? 'cm' : 'cm²'} (nhập số).`,
      correctAnswer: String(result), hint: `Con hãy nhớ công thức tính ${label} hình chữ nhật.`, explanation: `${formula} = ${result}.` };
  }
  return grade === 1 ? generateGrade1Item(id, index % 2 + 1, level, '') : generateGrade2Item(id, 2, level, '');
}
