import { localDate } from './assessment';
import { UserProgress, OwlSkin, StudentProfile } from '../types';

const STORAGE_KEY = 'vietmath_kids_progress_2026';

export const INITIAL_SKINS: OwlSkin[] = [
  {
    id: 'skin_default',
    name: 'Cú Mèo Học Sinh',
    title: 'Học Trò Chăm Chỉ',
    description: 'Chiếc khăn quàng đỏ tươi thắm và cặp kính trí tuệ sẵn sàng học tập mỗi ngày!',
    costStars: 0,
    emoji: '🦉🎒',
    colorScheme: {
      bg: 'bg-emerald-50',
      border: 'border-emerald-300',
      text: 'text-emerald-700',
      accent: 'bg-emerald-500',
    },
    features: 'Trang phục khởi đầu',
  },
  {
    id: 'skin_detective',
    name: 'Cú Mèo Thám Tử',
    title: 'Thám Tử Suy Luận',
    description: 'Trang bị kính lúp và nón thám tử, không bài toán hóc búa nào có thể làm khó con!',
    costStars: 20,
    emoji: '🕵️‍♂️🦉',
    colorScheme: {
      bg: 'bg-amber-50',
      border: 'border-amber-300',
      text: 'text-amber-800',
      accent: 'bg-amber-500',
    },
    features: 'Tăng 10% điểm tập trung',
  },
  {
    id: 'skin_astronaut',
    name: 'Cú Mèo Phi Hành Gia',
    title: 'Nhà Du Hành Vũ Trụ',
    description: 'Bộ đồ du hành không gian hiện đại, sẵn sàng bay lên những vì sao tri thức!',
    costStars: 35,
    emoji: '👨‍🚀🚀',
    colorScheme: {
      bg: 'bg-sky-50',
      border: 'border-sky-300',
      text: 'text-sky-800',
      accent: 'bg-sky-500',
    },
    features: 'Khám phá các hành tinh toán',
  },
  {
    id: 'skin_wizard',
    name: 'Cú Mèo Phù Thủy',
    title: 'Phù Thủy Số Học',
    description: 'Cây đũa phép biến hóa những con số phức tạp thành phép màu đơn giản!',
    costStars: 50,
    emoji: '🧙‍♂️✨',
    colorScheme: {
      bg: 'bg-purple-50',
      border: 'border-purple-300',
      text: 'text-purple-800',
      accent: 'bg-purple-600',
    },
    features: 'Biến hình số học',
  },
  {
    id: 'skin_champion',
    name: 'Cú Mèo Trạng Nguyên',
    title: 'Đệ Nhất Trạng Nguyên',
    description: 'Mũ cánh chuồn danh giá và cờ hoa rạng rỡ của bảng vàng ngàn năm văn hiến!',
    costStars: 70,
    emoji: '🎓📜',
    colorScheme: {
      bg: 'bg-rose-50',
      border: 'border-rose-300',
      text: 'text-rose-800',
      accent: 'bg-rose-500',
    },
    features: 'Vinh quy bái tổ toán học',
  },
  {
    id: 'skin_superhero',
    name: 'Cú Mèo Siêu Nhân',
    title: 'Hiệp Sĩ Tính Nhẩm',
    description: 'Áo choàng đỏ uy phong và tốc độ tính nhẩm nhanh như tia chớp!',
    costStars: 90,
    emoji: '🦸‍♂️⚡',
    colorScheme: {
      bg: 'bg-indigo-50',
      border: 'border-indigo-300',
      text: 'text-indigo-800',
      accent: 'bg-indigo-600',
    },
    features: 'Tốc độ tia chớp',
  },
];

export const DEFAULT_STUDENT_PROFILE: StudentProfile = {
  name: '',
  gender: 'male',
  grade: 1,
  schoolName: '',
  timetable: ['Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7'].map(day => ({
    day, slots: ['', '', '', ''], extraSlots: [],
  })),
};

export const DEFAULT_USER_PROGRESS: UserProgress = {
  version: 2,
  stars: 0,
  streak: 0,
  lastActiveDate: '',
  completedLessons: {},
  equippedSkin: 'skin_default',
  unlockedSkins: ['skin_default'],
  totalAnswered: 0,
  correctCount: 0,
  timeSpentMinutes: 0,
  preferredVoiceId: 'voice_co',
  arenaHighScore: 0,
  studentProfile: DEFAULT_STUDENT_PROFILE,
  strandStats: {
    'Số & Phép tính': { correct: 0, total: 0 },
    'Hình học & Đo lường': { correct: 0, total: 0 },
    'Giải toán có lời văn': { correct: 0, total: 0 },
    'Dữ liệu & Xác suất': { correct: 0, total: 0 },
  },
};

export function loadUserProgress(): UserProgress {
  if (typeof window === 'undefined') return DEFAULT_USER_PROGRESS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_USER_PROGRESS;
    const data = readProgressBackup(JSON.parse(raw));
    if (!data) return DEFAULT_USER_PROGRESS;
    const loadedTimetable = (data.studentProfile?.timetable || DEFAULT_STUDENT_PROFILE.timetable).map(
      (dayItem, idx) => ({
        ...dayItem,
        extraSlots: Array.isArray(dayItem.extraSlots)
          ? dayItem.extraSlots
          : (DEFAULT_STUDENT_PROFILE.timetable[idx]?.extraSlots || []),
      })
    );

    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    return {
      ...DEFAULT_USER_PROGRESS,
      ...data,
      version: 2,
      streak: [localDate(), localDate(yesterday)].includes(data.lastActiveDate) ? data.streak : 0,
      studentProfile: {
        ...DEFAULT_STUDENT_PROFILE,
        ...(data.studentProfile || {}),
        timetable: loadedTimetable,
      },
      strandStats: {
        ...DEFAULT_USER_PROGRESS.strandStats,
        ...(data.strandStats || {}),
      },
      completedLessons: {
        ...DEFAULT_USER_PROGRESS.completedLessons,
        ...(data.completedLessons || {}),
      },
    };
  } catch (err) {
    console.error('Failed to load user progress:', err);
    return DEFAULT_USER_PROGRESS;
  }
}

export function saveUserProgress(progress: UserProgress): boolean {
  if (typeof window === 'undefined') return false;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    return true;
  } catch (err) {
    console.error('Failed to save user progress:', err);
    return false;
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}

export function readProgressBackup(file: unknown): UserProgress | null {
  if (!isRecord(file)) return null;
  if ('progressData' in file && !['2026.1', '2026.2'].includes(String(file.version))) return null;
  const data = 'progressData' in file ? file.progressData : file;
  if (!isRecord(data) || (data.version !== undefined && data.version !== 2)) return null;
  const natural = (n: unknown) => typeof n === 'number' && Number.isSafeInteger(n) && n >= 0;
  for (const key of ['stars', 'streak', 'totalAnswered', 'correctCount']) if (!natural(data[key])) return null;
  if (Number(data.correctCount) > Number(data.totalAnswered) || typeof data.timeSpentMinutes !== 'number' || !Number.isFinite(data.timeSpentMinutes) || data.timeSpentMinutes < 0) return null;
  if (typeof data.lastActiveDate !== 'string' || (data.lastActiveDate && !/^\d{4}-\d{2}-\d{2}$/.test(data.lastActiveDate))) return null;
  if (typeof data.equippedSkin !== 'string' || !Array.isArray(data.unlockedSkins) || !data.unlockedSkins.every(id => typeof id === 'string')) return null;
  if (!isRecord(data.completedLessons) || !isRecord(data.strandStats)) return null;
  const validLesson = (lesson: unknown) => isRecord(lesson) && natural(lesson.stars) && natural(lesson.score) &&
    Number(lesson.score) <= 100 && typeof lesson.completedAt === 'string' && (lesson.title === undefined || typeof lesson.title === 'string');
  if (!Object.values(data.completedLessons).every(validLesson)) return null;
  for (const [key, value] of Object.entries(data.strandStats)) {
    if (!Object.hasOwn(DEFAULT_USER_PROGRESS.strandStats, key) || !isRecord(value) ||
        !natural(value.correct) || !natural(value.total) || Number(value.correct) > Number(value.total)) return null;
  }
  if (data.studentProfile !== undefined) {
    const profile = data.studentProfile;
    if (!isRecord(profile) || typeof profile.name !== 'string' || !['male', 'female'].includes(String(profile.gender)) ||
        ![1, 2, 3, 4, 5].includes(Number(profile.grade)) || typeof profile.grade !== 'number' ||
        (profile.schoolName !== undefined && typeof profile.schoolName !== 'string') ||
        !Array.isArray(profile.timetable) || !profile.timetable.every(day => isRecord(day) && typeof day.day === 'string' &&
          Array.isArray(day.slots) && day.slots.every(slot => typeof slot === 'string') &&
          (day.extraSlots === undefined || (Array.isArray(day.extraSlots) && day.extraSlots.every(slot => typeof slot === 'string'))))) return null;
  }
  if (data.arenaHighScore !== undefined && !natural(data.arenaHighScore)) return null;
  if (data.textbook !== undefined && !['ket-noi-tri-thuc', 'chan-troi-sang-tao', 'canh-dieu'].includes(String(data.textbook))) return null;
  return { ...DEFAULT_USER_PROGRESS, ...data, version: 2, strandStats: { ...DEFAULT_USER_PROGRESS.strandStats, ...data.strandStats } } as UserProgress;
}
