import { extractMathExpression, solveMathExpression } from './mathExpressionSolver';

export function solvePrimaryMathProblem(message: string, grade: number, mode = 'solution'): string {
  const g = Math.max(1, Math.min(5, Number(grade) || 3));
  const lower = message.toLowerCase().trim();

  // 1. Check for mathematical expressions (supports multi-term, parentheses, and strict order of operations)
  // e.g. "2+2x2=?", "2x2+2=?", "10 - 2 x 3 + 4", "(15 + 5) : 4", "125 x 4", "72 : 8"
  const extractedExpr = extractMathExpression(message);
  if (extractedExpr) {
    const solved = solveMathExpression(extractedExpr);
    if (!solved) return 'Biểu thức chưa hợp lệ hoặc có phép chia cho 0. Con kiểm tra lại từng phép tính nhé.';
    if (solved) {
      if (mode === 'hint') {
        const hasMulDiv = solved.cleanExpression.includes('×') || solved.cleanExpression.includes(':');
        const hasAddSub = solved.cleanExpression.includes('+') || solved.cleanExpression.includes('-');
        let hintGuide = '';
        if (hasMulDiv && hasAddSub) {
          hintGuide = `Biểu thức của con có cả phép tính cộng/trừ và nhân/chia. Con hãy nhớ Quy tắc Vàng: "Nhân chia trước, cộng trừ sau". Con hãy tìm và thực hiện các phép nhân hoặc phép chia trước nhé!`;
        } else if (solved.rulesApplied.includes('Trong ngoặc trước, ngoài ngoặc sau')) {
          hintGuide = `Biểu thức của con có dấu ngoặc đơn. Con hãy nhớ quy tắc: "Trong ngoặc trước, ngoài ngoặc sau". Hãy tính giá trị trong ngoặc trước nhé!`;
        } else {
          hintGuide = `Con hãy thực hiện lần lượt các phép tính từ trái sang phải, đặt tính cẩn thận từ hàng đơn vị nhé!`;
        }

        return `Chào con yêu! 🦉✨ Thầy Cú Mèo gợi ý con cách thực hiện biểu thức "${solved.cleanExpression}" nhé:
• ${hintGuide}
• Con hãy thử từng bước rồi kiểm tra lại kết quả. Hãy thử tính nhẩm xem bước 1 ra mấy nhé! ⭐`;
      }

      if (mode === 'practice') {
        return `Chào con yêu! 🦉✨ Thầy Cú Mèo hướng dẫn con bài toán này và gửi bài luyện tập tương tự nhé:

${solved.explanation}

📝 BÀI TẬP TỰ LUYỆN TƯƠNG TỰ DÀNH CHO CON:
• Đề bài: Tính giá trị của biểu thức tương tự: ${solved.cleanExpression.replace(/\d+/g, (m) => String(parseInt(m, 10) + 1))} = ?
• Con hãy ghi ra nháp, áp dụng đúng quy tắc "Nhân chia trước, cộng trừ sau" và gửi kết quả lại cho Thầy Cú Mèo chấm nhé! 🦉⭐`;
      }

      // Default or solution mode
      return `Chào con yêu! 🦉✨ Thầy Cú Mèo hướng dẫn con giải chi tiết bài toán này theo chuẩn Bộ GD&ĐT nhé:

${solved.explanation}`;
    }
  }

  // 2. Check for "Tìm x" equation (e.g. "x + 15 = 45", "x * 4 = 36", "x : 5 = 12")
  const findXMatch = lower.match(/^(?:tìm x(?: biết)?\s*:?\s*)?x\s*([\+\-\*xX×:\/÷])\s*(\d+(?:[.,]\d+)?)\s*=\s*(\d+(?:[.,]\d+)?)\s*[.?]?$/);
  if (findXMatch) {
    const op = findXMatch[1];
    const a = parseFloat(findXMatch[2].replace(',', '.'));
    const b = parseFloat(findXMatch[3].replace(',', '.'));
    if (a === 0 && ['*', 'x', '×'].includes(op)) return b === 0
      ? 'Mọi giá trị của x đều thỏa mãn vì số nào nhân với 0 cũng bằng 0.'
      : 'Phương trình vô nghiệm vì số nào nhân với 0 cũng bằng 0.';
    if (a === 0 && [':', '/', '÷'].includes(op)) return 'Phép chia cho 0 không xác định. Con kiểm tra lại đề nhé.';
    let xVal = 0;
    let rule = '';

    if (op === '+') {
      xVal = b - a;
      rule = 'Muốn tìm số hạng chưa biết, ta lấy tổng trừ đi số hạng đã biết.';
    } else if (op === '-' || op === '–') {
      xVal = b + a;
      rule = 'Muốn tìm số bị trừ, ta lấy hiệu cộng với số trừ.';
    } else if (op === '*' || op === 'x' || op === 'X' || op === '×') {
      xVal = b / a;
      rule = 'Muốn tìm thừa số chưa biết, ta lấy tích chia cho thừa số đã biết.';
    } else {
      xVal = b * a;
      rule = 'Muốn tìm số bị chia, ta lấy thương nhân với số chia.';
    }

    const formattedX = Number.isInteger(xVal) ? String(xVal) : xVal.toFixed(2).replace('.', ',');

    return `Chào con yêu! 🦉✨ Thầy Cú Mèo giải bài toán Tìm x này cho con nhé:

📌 ĐỀ BÀI:
Tìm x biết: x ${op} ${a} = ${b}

📖 QUY TẮC CẦN NHỚ:
• ${rule}

📐 CÁC BƯỚC GIẢI CHI TIẾT:
   x ${op} ${a} = ${b}
   x = ${b} ${op === '+' ? '-' : op === '-' ? '+' : op === '*' || op === 'x' || op === '×' ? ':' : '×'} ${a}
   x = ${formattedX}

🎯 ĐÁP SỐ:
• x = ${formattedX}

💡 LỜI KHUYÊN: Con thay lại x = ${formattedX} vào đề bài ban đầu để kiểm tra lại nhé nhé! ⭐`;
  }

  // 3. Check for Geometry (Chu vi, Diện tích hình chữ nhật, hình vuông, tam giác, hình tròn)
  if (lower.includes('chu vi') || lower.includes('diện tích')) {
    if (lower.includes('hình chữ nhật')) {
      return `Chào con yêu! 🦉✨ Thầy Cú Mèo nhắc lại và hướng dẫn công thức Hình chữ nhật cho con nhé:

📐 CÔNG THỨC HÌNH CHỮ NHẬT:
1. Chu vi hình chữ nhật:
   P = (Chiều dài + Chiều rộng) × 2 (cùng đơn vị đo)
   • Nửa chu vi = Chiều dài + Chiều rộng = Chu vi : 2

2. Diện tích hình chữ nhật:
   S = Chiều dài × Chiều rộng (cùng đơn vị đo)

💡 CÁC BƯỚC GIẢI TOÁN CÓ LỜI VĂN:
• Bước 1: Kiểm tra xem Chiều dài và Chiều rộng đã cùng đơn vị đo chưa (nếu chưa phải đổi).
• Bước 2: Tìm chiều dài hoặc chiều rộng nếu đề bài chưa cho trực tiếp.
• Bước 3: Áp dụng công thức tính chu vi hoặc diện tích theo yêu cầu.
• Bước 4: Ghi rõ đáp số kèm đơn vị vuông (cm², m²...). Con hãy gửi số liệu bài toán của con để Thầy giải chi tiết nhé!`;
    }

    if (lower.includes('hình vuông')) {
      return `Chào con yêu! 🦉✨ Thầy Cú Mèo hướng dẫn con công thức Hình vuông nhé:

📐 CÔNG THỨC HÌNH VUÔNG CẠNH a:
1. Chu vi hình vuông:
   P = Cạnh × 4 (a × 4)
   • Muốn tìm cạnh khi biết chu vi: Cạnh = Chu vi : 4

2. Diện tích hình vuông:
   S = Cạnh × Cạnh (a × a)

💡 MẸO GHI NHỚ:
Hình vuông có 4 cạnh dài bằng nhau và 4 góc vuông. Con hãy gửi đề bài chi tiết để Thầy hướng dẫn từng bước nhé! ⭐`;
    }

    if (lower.includes('hình thang') || lower.includes('tam giác')) {
      return `Chào con yêu! 🦉✨ Thầy Cú Mèo hướng dẫn con công thức Diện tích hình tam giác và hình thang nhé:

📐 HÌNH TAM GIÁC (Đáy a, Chiều cao h):
• Diện tích: S = (a × h) : 2
(Muốn tính diện tích tam giác, ta lấy độ dài đáy nhân chiều cao rồi chia cho 2).

📐 HÌNH THANG (Đáy lớn a, Đáy bé b, Chiều cao h):
• Diện tích: S = (a + b) × h : 2
("Muốn tính diện tích hình thang / Đáy lớn đáy bé ta mang cộng vào / Cộng rồi nhân với chiều cao / Chia đôi lấy nửa thế nào cũng ra").

Con hãy gửi kích thước đề bài cho, Thầy sẽ tính ngay kết quả chuẩn xác cho con nhé! 🦉⭐`;
    }
  }

  // 4. Check for Speed / Uniform motion (Vận tốc, quãng đường, thời gian)
  if (lower.includes('vận tốc') || lower.includes('quãng đường') || lower.includes('chuyển động') || lower.includes('km/h')) {
    return `Chào con yêu! 🦉✨ Thầy Cú Mèo hệ thống lại toàn bộ kiến thức Toán Chuyển Động Đều cho con nhé:

🚗 BỘ BA CÔNG THỨC VÀNG:
1. Vận tốc: v = s : t (Quãng đường chia Thời gian)
2. Quãng đường: s = v × t (Vận tốc nhân Thời gian)
3. Thời gian: t = s : v (Quãng đường chia Vận tốc)

🌟 DẠNG TOÁN HAI XE:
• Ngược chiều (Gặp nhau):
  Thời gian gặp nhau = Khoảng cách ban đầu : (v1 + v2)
• Cùng chiều (Đuổi nhau):
  Thời gian đuổi kịp = Khoảng cách ban đầu : (v1 - v2)

⚠️ LƯU Ý SỐ 1: Phải luôn đồng nhất đơn vị đo (ví dụ: km - giờ - km/h; hoặc m - phút - m/phút). Đổi giờ phút ra số thập phân trước khi tính con nhé!`;
  }

  // 5. Default comprehensive pedagogical response
  return `Chào con yêu! 🦉✨ Thầy Cú Mèo rất vui được hỗ trợ bài toán của con!

Để Thầy giải đáp chi tiết và chính xác nhất cho bài tập này:
1. Con hãy gõ đầy đủ đề bài hoặc chép rõ số liệu bài toán vào khung chat.
2. Nếu con cần giải chi tiết từ A-Z: Con cứ nhắn "Thầy giải chi tiết giúp con nhé".
3. Nếu con chỉ cần gợi ý để tự rèn luyện tư duy: Con nhắn "Thầy cho con gợi ý bước 1 thôi".

Thầy Cú Mèo luôn đồng hành cùng con từng bước một để môn Toán trở nên thật dễ dàng và đạt thật nhiều điểm 10 nhé! ⭐🎒`;
}

// Route 3: Professional Primary Math AI Tutor
