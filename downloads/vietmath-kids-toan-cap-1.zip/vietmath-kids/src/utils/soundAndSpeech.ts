/**
 * Web Audio API synthesizer for joyful gamification sound effects ("Ting!", "Bụp")
 * and Web Speech API with expressive Cô (Nữ) & Thầy (Nam) Vietnamese voices.
 */

import { RegionalVoiceOption, Grade } from '../types';

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

// 1. Correct Answer: "Ting!" - Crisp, joyful chime with harmonic sparkle
export function playCorrectSound() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(880, now);
    osc1.frequency.exponentialRampToValueAtTime(1320, now + 0.15);

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(1760, now);
    osc2.frequency.exponentialRampToValueAtTime(2640, now + 0.15);

    gainNode.gain.setValueAtTime(0, now);
    gainNode.gain.linearRampToValueAtTime(0.28, now + 0.015);
    gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

    osc1.connect(gainNode);
    osc2.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.45);
    osc2.stop(now + 0.45);
  } catch (e) {
    console.debug('Audio playback skipped', e);
  }
}

// 2. Incorrect Answer: "Bụp" - Gentle, rounded soft pop (not discouraging)
export function playWrongSound() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(110, now + 0.18);

    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.25, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.005, now + 0.22);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.23);
  } catch (e) {
    console.debug('Audio playback skipped', e);
  }
}

// 3. Button Click: Snappy pop
export function playClickSound() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(650, now);
    osc.frequency.exponentialRampToValueAtTime(850, now + 0.04);

    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.05);
  } catch (e) {
    console.debug('Audio click skipped', e);
  }
}

// 4. Celebration Fanfare for completing a lesson or arena high score
export function playWinFanfare() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const fanfareNotes = [
      { freq: 523.25, time: 0, dur: 0.12 },
      { freq: 659.25, time: 0.13, dur: 0.12 },
      { freq: 783.99, time: 0.26, dur: 0.14 },
      { freq: 1046.5, time: 0.42, dur: 0.35 },
      { freq: 1318.5, time: 0.58, dur: 0.45 },
    ];

    fanfareNotes.forEach((item) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(item.freq, now + item.time);

      gain.gain.setValueAtTime(0, now + item.time);
      gain.gain.linearRampToValueAtTime(0.24, now + item.time + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + item.time + item.dur);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + item.time);
      osc.stop(now + item.time + item.dur + 0.05);
    });
  } catch (e) {
    console.debug('Fanfare skipped', e);
  }
}

// 5. Streak / Combo Sound
export function playStreakSound() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(1040, now + 0.18);

    gain.gain.setValueAtTime(0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.18);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.2);
  } catch (e) {
    console.debug('Streak sound skipped', e);
  }
}

// -------------------------------------------------------------
// 6. Expressive Gemini Native TTS & Web Speech Hybrid System
// -------------------------------------------------------------
import {
  VOICE_PROFILES,
  getSavedVoiceId as getSavedVoiceIdFromService,
  setSavedVoiceId as setSavedVoiceIdFromService,
  speakText,
  stopSpeaking as stopSpeakingService,
  getVoiceProfile,
} from '../services/ttsService';

export const REGIONAL_VOICES: RegionalVoiceOption[] = VOICE_PROFILES;

export function getSavedVoiceId(): string {
  return getSavedVoiceIdFromService();
}

export function setSavedVoiceId(voiceId: string) {
  setSavedVoiceIdFromService(voiceId);
}

export function stopSpeaking() {
  stopSpeakingService();
}

export function speakVietnamese(
  text: string,
  voiceId?: string,
  gradeOrOnStart?: Grade | (() => void),
  onStartOrOnEnd?: () => void,
  onEndParam?: () => void
): boolean {
  let onStart: (() => void) | undefined;
  let onEnd: (() => void) | undefined;

  if (typeof gradeOrOnStart === 'function') {
    onStart = gradeOrOnStart;
    onEnd = onStartOrOnEnd;
  } else {
    onStart = onStartOrOnEnd;
    onEnd = onEndParam;
  }

  const selectedVoiceId = voiceId || getSavedVoiceId();

  speakText(
    text,
    selectedVoiceId,
    onStart,
    onEnd,
    () => {
      onEnd?.();
    }
  );

  return true;
}

