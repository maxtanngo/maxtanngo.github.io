// VietMath Kids - Intelligent Math Expression Solver for Primary School (GDPT 2018)
// Strictly follows Vietnamese elementary school rules:
// 1. "Trong ngoặc trước, ngoài ngoặc sau" (Parentheses first)
// 2. "Nhân chia trước, cộng trừ sau" (Multiplication and division before addition and subtraction)
// 3. "Nếu biểu thức chỉ có phép cộng, trừ hoặc chỉ có phép nhân, chia thì thực hiện lần lượt từ trái sang phải"

export interface MathStep {
  description: string;
  subCalculation?: string;
  resultingExpression: string;
}

export interface SolveResult {
  originalExpression: string;
  cleanExpression: string;
  steps: MathStep[];
  finalResult: number;
  formattedResult: string;
  rulesApplied: string[];
  explanation: string;
}

// Format number nicely: integer or clean decimal with comma (e.g. 4,5)
export function formatVietnameseNumber(n: number): string {
  if (Number.isInteger(n)) return String(n);
  // Round to max 4 decimal places to prevent floating point inaccuracies
  const rounded = Math.round(n * 10000) / 10000;
  return String(rounded).replace('.', ',');
}

type Token = { type: 'num'; val: number } | { type: 'op'; val: '+' | '-' | '×' | ':' } | { type: 'paren'; val: '(' | ')' };

/**
 * Extracts a mathematical expression from free text if present.
 * Examples:
 * - "2+2x2=?" -> "2+2x2"
 * - "tính giúp em 2x2+2" -> "2x2+2"
 * - "(15 + 5) : 4 - 2" -> "(15 + 5) : 4 - 2"
 * - "10 - 2 * 3 + 4 = bao nhiêu" -> "10 - 2 * 3 + 4"
 */
export function extractMathExpression(text: string): string | null {
  if (!text || typeof text !== 'string') return null;

  const cleaned = text.trim()
    .replace(/^(?:hãy\s+)?(?:tính(?: giá trị)?(?: của)?(?: biểu thức)?|kết quả của|biểu thức)\s*(?::\s*|\.\s+)?/i, '')
    .replace(/\s*(?:bằng bao nhiêu|ra bao nhiêu)?\s*=?\s*[?？]?\s*$/, '')
    .trim();
  if (!/^[\d.,+*xX×:÷/()\s−-]+$/.test(cleaned) || !/[+*xX×:÷/−-]/.test(cleaned)) return null;
  return cleaned;
}

/**
 * Tokenize a math expression string into tokens
 */
function tokenize(expr: string): Token[] | null {
  const tokens: Token[] = [];
  let i = 0;
  const grouped = expr.replace(/\b\d{1,3}(?:[ \u00a0\u202f]\d{3})+\b/g, match => match.replace(/\s/g, ''));
  if (/\d\s+\d/.test(grouped)) return null;
  const str = grouped.replace(/\s+/g, '');

  while (i < str.length) {
    const ch = str[i];

    if (ch === '(' || ch === ')') {
      tokens.push({ type: 'paren', val: ch });
      i++;
      continue;
    }

    if (ch === '+' || ch === '-' || ch === '–') {
      tokens.push({ type: 'op', val: ch === '–' ? '-' : ch });
      i++;
      continue;
    }

    if (ch === '*' || ch === 'x' || ch === 'X' || ch === '×') {
      tokens.push({ type: 'op', val: '×' });
      i++;
      continue;
    }

    if (ch === ':' || ch === '/' || ch === '÷') {
      tokens.push({ type: 'op', val: ':' });
      i++;
      continue;
    }

    // Number matching
    if (/\d/.test(ch)) {
      let numStr = '';
      while (i < str.length && /[\d.,]/.test(str[i])) {
        numStr += str[i];
        i++;
      }
      if (!/^\d+(?:[.,]\d+)?$/.test(numStr)) return null;
      const parsed = Number(numStr.replace(',', '.'));
      if (isNaN(parsed)) return null;
      tokens.push({ type: 'num', val: parsed });
      continue;
    }

    // Unrecognized character
    return null;
  }

  return tokens.length > 0 ? tokens : null;
}

function tokensToString(tokens: Token[]): string {
  let s = '';
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    if (t.type === 'num') {
      s += formatVietnameseNumber(t.val);
    } else if (t.type === 'op') {
      s += ` ${t.val} `;
    } else if (t.type === 'paren') {
      s += t.val;
    }
  }
  return s.replace(/\s+/g, ' ').trim();
}

/**
 * Evaluates a sequence of tokens without parentheses using Vietnamese elementary rules:
 * - Pass 1: Multiplication (×) and Division (:) from left to right.
 * - Pass 2: Addition (+) and Subtraction (-) from left to right.
 */
function evaluateFlat(tokens: Token[], steps: MathStep[], rulesApplied: Set<string>): number {
  let current = [...tokens];

  // Helper to check what operations exist
  const hasMulDiv = current.some(t => t.type === 'op' && (t.val === '×' || t.val === ':'));
  const hasAddSub = current.some(t => t.type === 'op' && (t.val === '+' || t.val === '-'));

  if (hasMulDiv && hasAddSub) {
    rulesApplied.add('Nhân chia trước, cộng trừ sau');
  } else if (hasMulDiv) {
    rulesApplied.add('Biểu thức chỉ có nhân và chia, thực hiện từ trái sang phải');
  } else if (hasAddSub) {
    rulesApplied.add('Biểu thức chỉ có cộng và trừ, thực hiện từ trái sang phải');
  }

  // Pass 1: Multiplications & Divisions from left to right
  let changed = true;
  while (changed) {
    changed = false;
    for (let i = 0; i < current.length; i++) {
      const tok = current[i];
      if (tok.type === 'op' && (tok.val === '×' || tok.val === ':')) {
        const leftTok = current[i - 1];
        const rightTok = current[i + 1];

        if (leftTok && leftTok.type === 'num' && rightTok && rightTok.type === 'num') {
          const a = leftTok.val;
          const b = rightTok.val;
          let subRes = 0;
          let opText = '';

          if (tok.val === '×') {
            subRes = a * b;
            opText = `Thực hiện phép nhân: ${formatVietnameseNumber(a)} × ${formatVietnameseNumber(b)} = ${formatVietnameseNumber(subRes)}`;
          } else {
            if (b === 0) return NaN;
            subRes = a / b;
            opText = `Thực hiện phép chia: ${formatVietnameseNumber(a)} : ${formatVietnameseNumber(b)} = ${formatVietnameseNumber(subRes)}`;
          }

          const newTokens: Token[] = [
            ...current.slice(0, i - 1),
            { type: 'num', val: subRes },
            ...current.slice(i + 2),
          ];

          current = newTokens;
          steps.push({
            description: opText,
            subCalculation: `${formatVietnameseNumber(a)} ${tok.val} ${formatVietnameseNumber(b)} = ${formatVietnameseNumber(subRes)}`,
            resultingExpression: tokensToString(current),
          });
          changed = true;
          break; // restart from left to ensure left-to-right order
        }
      }
    }
  }

  // Pass 2: Additions & Subtractions from left to right
  changed = true;
  while (changed) {
    changed = false;
    for (let i = 0; i < current.length; i++) {
      const tok = current[i];
      if (tok.type === 'op' && (tok.val === '+' || tok.val === '-')) {
        const leftTok = current[i - 1];
        const rightTok = current[i + 1];

        if (leftTok && leftTok.type === 'num' && rightTok && rightTok.type === 'num') {
          const a = leftTok.val;
          const b = rightTok.val;
          let subRes = 0;
          let opText = '';

          if (tok.val === '+') {
            subRes = a + b;
            opText = `Thực hiện phép cộng: ${formatVietnameseNumber(a)} + ${formatVietnameseNumber(b)} = ${formatVietnameseNumber(subRes)}`;
          } else {
            subRes = a - b;
            opText = `Thực hiện phép trừ: ${formatVietnameseNumber(a)} - ${formatVietnameseNumber(b)} = ${formatVietnameseNumber(subRes)}`;
          }

          const newTokens: Token[] = [
            ...current.slice(0, i - 1),
            { type: 'num', val: subRes },
            ...current.slice(i + 2),
          ];

          current = newTokens;
          steps.push({
            description: opText,
            subCalculation: `${formatVietnameseNumber(a)} ${tok.val} ${formatVietnameseNumber(b)} = ${formatVietnameseNumber(subRes)}`,
            resultingExpression: tokensToString(current),
          });
          changed = true;
          break; // restart from left
        }
      }
    }
  }

  if (current.length === 1 && current[0].type === 'num') {
    return current[0].val;
  }

  return NaN;
}

/**
 * Solves a complete math expression step-by-step
 */
export function solveMathExpression(rawExpr: string): SolveResult | null {
  const tokens = tokenize(rawExpr);
  if (!tokens || tokens.length === 0) return null;

  const steps: MathStep[] = [];
  const rulesApplied = new Set<string>();
  let currentTokens = [...tokens];

  // Resolve parentheses first: "Trong ngoặc trước, ngoài ngoặc sau"
  let hasParen = true;
  while (hasParen) {
    let lastOpenIndex = -1;
    let matchingCloseIndex = -1;

    for (let i = 0; i < currentTokens.length; i++) {
      if (currentTokens[i].type === 'paren' && (currentTokens[i] as any).val === '(') {
        lastOpenIndex = i;
      } else if (currentTokens[i].type === 'paren' && (currentTokens[i] as any).val === ')') {
        if (lastOpenIndex !== -1) {
          matchingCloseIndex = i;
          break;
        }
      }
    }

    if (lastOpenIndex !== -1 && matchingCloseIndex !== -1) {
      rulesApplied.add('Trong ngoặc trước, ngoài ngoặc sau');
      const innerTokens = currentTokens.slice(lastOpenIndex + 1, matchingCloseIndex);
      const innerSteps: MathStep[] = [];
      const innerRes = evaluateFlat(innerTokens, innerSteps, rulesApplied);

      if (!Number.isFinite(innerRes)) return null;
      steps.push({
        description: `Thực hiện phép tính trong ngoặc (${tokensToString(innerTokens)}) = ${formatVietnameseNumber(innerRes)}`,
        subCalculation: `(${tokensToString(innerTokens)}) = ${formatVietnameseNumber(innerRes)}`,
        resultingExpression: '',
      });

      currentTokens = [
        ...currentTokens.slice(0, lastOpenIndex),
        { type: 'num', val: innerRes },
        ...currentTokens.slice(matchingCloseIndex + 1),
      ];

      steps[steps.length - 1].resultingExpression = tokensToString(currentTokens);
    } else {
      hasParen = false;
    }
  }

  // Now evaluate the remaining flat expression
  const finalResult = evaluateFlat(currentTokens, steps, rulesApplied);
  if (!Number.isFinite(finalResult)) return null;
  const formattedResult = formatVietnameseNumber(finalResult);
  const cleanExpression = tokensToString(tokens);

  // Generate teacher explanation
  let explanation = '';
  explanation += `📌 TÓM TẮT ĐỀ BÀI:\n• Tính giá trị của biểu thức: ${cleanExpression}\n\n`;

  explanation += `📖 QUY TẮC THỨ TỰ THỰC HIỆN PHÉP TÍNH (Chuẩn GDPT 2018):\n`;
  if (rulesApplied.has('Trong ngoặc trước, ngoài ngoặc sau')) {
    explanation += `• Quy tắc 1: Nếu biểu thức có dấu ngoặc, ta thực hiện các phép tính trong ngoặc trước.\n`;
  }
  if (rulesApplied.has('Nhân chia trước, cộng trừ sau')) {
    explanation += `• Quy tắc Vàng: "Nhân chia trước, cộng trừ sau" — Khi biểu thức có cả phép tính (+, -) và (×, :), ta luôn ưu tiên thực hiện phép nhân và phép chia trước, sau đó mới thực hiện phép cộng và phép trừ!\n`;
  }
  if (rulesApplied.has('Biểu thức chỉ có nhân và chia, thực hiện từ trái sang phải') || rulesApplied.has('Biểu thức chỉ có cộng và trừ, thực hiện từ trái sang phải')) {
    explanation += `• Quy tắc thứ tự: Thực hiện các phép tính cùng mức ưu tiên lần lượt từ trái sang phải.\n`;
  }

  explanation += `\n📐 CÁC BƯỚC GIẢI CHI TIẾT:\n`;
  explanation += `Ta có biểu thức:\n   ${cleanExpression}\n`;

  // Filter out redundant steps if any
  let stepCounter = 1;
  for (const step of steps) {
    if (step.subCalculation) {
      explanation += `• Bước ${stepCounter}: ${step.description}\n`;
      explanation += `  -> Biểu thức trở thành: ${step.resultingExpression}\n`;
      stepCounter++;
    }
  }

  explanation += `\n🎯 ĐÁP SỐ:\n• ${cleanExpression} = ${formattedResult}\n\n`;
  explanation += `💡 LỜI KHUYÊN TỪ THẦY CÚ MÈO:\n`;
  if (cleanExpression.includes('+') && cleanExpression.includes('×')) {
    explanation += `Rất nhiều bạn nhỏ hay bị nhầm lẫn tính từ trái qua phải làm phép cộng trước. Con hãy luôn nhớ câu thần chú: "Nhân chia trước, cộng trừ sau" để luôn luôn tính đúng nhé! Chúc con học thật giỏi! ⭐🦉`;
  } else if (cleanExpression.includes(':') || cleanExpression.includes('×')) {
    explanation += `Con làm rất tốt! Luôn kiểm tra lại từng bước nhân chia để bài làm luôn đạt điểm 10 tuyệt đối nhé! ⭐🦉`;
  } else {
    explanation += `Con hãy đặt tính cẩn thận và kiểm tra lại kết quả nhé, Thầy Cú Mèo rất tự hào về con! ⭐🦉`;
  }

  return {
    originalExpression: rawExpr,
    cleanExpression,
    steps,
    finalResult,
    formattedResult,
    rulesApplied: Array.from(rulesApplied),
    explanation,
  };
}
