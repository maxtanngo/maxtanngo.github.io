import { extractMathExpression, solveMathExpression } from './mathExpressionSolver';
import type { Question } from '../types';
import { matchesAnswer, normalizeAnswer, strands } from './assessment';

export function validateQuestions(raw: unknown): Question[] {
  if (!Array.isArray(raw)) return [];
  const ids = new Set<string>();
  return raw.slice(0, 30).flatMap((value, index) => {
    if (!value || typeof value !== 'object') return [];
    const q = value as Question;
    if ([q.question, q.correctAnswer, q.hint, q.explanation].some(text => typeof text !== 'string' || !text.trim() || text.length > 3000)) return [];
    if (!strands.includes(q.strand)) return [];
    if (!['number_input', 'multiple_choice', 'visual_count', 'visual_clock', 'visual_fraction', 'visual_distance'].includes(q.type)) return [];
    if (q.type.startsWith('visual_') && (!q.visualData || typeof q.visualData !== 'object')) return [];
    const plainExpression = q.question.replace(/\s*\(nhập (?:số|kết quả)\)\s*$/i, '');
    const expression = extractMathExpression(plainExpression);
    if (expression) {
      const solution = solveMathExpression(expression);
      if (!solution || !matchesAnswer({ ...q, type: 'number_input', correctAnswer: String(solution.finalResult) }, q.correctAnswer)) return [];
    }
    if (q.type !== 'number_input') {
      if (!Array.isArray(q.options) || q.options.length < 2 || q.options.length > 6 || q.options.some(option => typeof option !== 'string' || !option.trim())) return [];
      if (new Set(q.options.map(normalizeAnswer)).size !== q.options.length || q.options.filter(option => matchesAnswer(q, option)).length !== 1) return [];
    }
    const id = typeof q.id === 'string' && q.id && !ids.has(q.id) ? q.id : `question_${index}`;
    ids.add(id);
    return [{ ...q, id }];
  });
}
