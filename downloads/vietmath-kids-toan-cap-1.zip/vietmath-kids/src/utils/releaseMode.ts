export const offlineRelease = import.meta.env.VITE_STATIC_RELEASE === 'offline';
export const staticRelease = offlineRelease || import.meta.env.VITE_STATIC_RELEASE === '1';

export function fetchAppApi(path: string, init?: RequestInit): Promise<Response> {
  if (staticRelease) return Promise.reject(new Error('Máy chủ AI không được bật trên bản web tĩnh.'));
  return fetch(path, init);
}
