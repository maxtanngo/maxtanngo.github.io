import type { Question, Strand, UserProgress } from '../types';

export type StrandTotals = Partial<Record<Strand, { correct: number; total: number }>>;

export interface AttemptResult {
  title: string;
  answered: number;
  correct: number;
  seconds: number;
  stars: number;
  strands: StrandTotals;
}

export const strands: Strand[] = ['Số & Phép tính', 'Hình học & Đo lường', 'Giải toán có lời văn', 'Dữ liệu & Xác suất'];

export function addAnswer(stats: StrandTotals, strand: Strand, correct: boolean) {
  const previous = stats[strand] ?? { correct: 0, total: 0 };
  stats[strand] = { correct: previous.correct + Number(correct), total: previous.total + 1 };
}

export function recordAttempt(progress: UserProgress, result: AttemptResult, key: string, kind: 'lesson' | 'exam' | 'arena'): UserProgress {
  if (!result.answered) return progress;
  const now = new Date();
  const day = localDate(now);
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  const streak = progress.lastActiveDate === day ? Math.max(1, progress.streak)
    : progress.lastActiveDate === localDate(yesterday) ? progress.streak + 1 : 1;
  const stats = { ...progress.strandStats };
  for (const strand of strands) {
    const count = result.strands[strand];
    if (count) stats[strand] = { correct: stats[strand].correct + count.correct, total: stats[strand].total + count.total };
  }
  const previous = kind === 'lesson' ? progress.completedLessons[key] : undefined;
  const score = Math.round(100 * result.correct / result.answered);
  return {
    ...progress,
    streak,
    lastActiveDate: day,
    stars: progress.stars + Math.max(0, result.stars - (previous?.stars ?? 0)),
    totalAnswered: progress.totalAnswered + result.answered,
    correctCount: progress.correctCount + result.correct,
    timeSpentMinutes: progress.timeSpentMinutes + result.seconds / 60,
    strandStats: stats,
    completedLessons: {
      ...progress.completedLessons,
      [key]: { title: result.title, stars: Math.max(previous?.stars ?? 0, result.stars), score, bestScore: Math.max(previous?.bestScore ?? previous?.score ?? 0, score), completedAt: now.toISOString(), answered: result.answered, correct: result.correct },
    },
  };
}

export function localDate(date = new Date()): string {
  return [date.getFullYear(), String(date.getMonth() + 1).padStart(2, '0'), String(date.getDate()).padStart(2, '0')].join('-');
}

export function normalizeAnswer(value: string): string {
  return value.normalize('NFC').trim().toLocaleLowerCase('vi').replace(/\s+/g, '').replace(/(\d),(?=\d)/g, '$1.');
}

function numericValue(value: string): number | undefined {
  const input = value.trim().replace(/\b\d{1,3}(?:[ \u00a0\u202f]\d{3})+\b/g, group => group.replace(/\s/g, '')).replace(',', '.');
  if (/^[+-]?\d+(?:\.\d+)?$/.test(input)) return Number(input);
  const fraction = input.match(/^([+-]?\d+)\s*\/\s*(\d+)$/);
  if (fraction && Number(fraction[2]) !== 0) return Number(fraction[1]) / Number(fraction[2]);
}

export function matchesAnswer(question: Question, value: string): boolean {
  if (question.type !== 'number_input') return normalizeAnswer(value) === normalizeAnswer(question.correctAnswer);
  const expected = numericValue(question.correctAnswer);
  const actual = numericValue(value);
  if (expected === undefined) return normalizeAnswer(value) === normalizeAnswer(question.correctAnswer);
  if (actual === undefined || !Number.isFinite(actual) || !Number.isFinite(expected)) return false;
  if (/tối giản/i.test(question.question) && normalizeAnswer(value) !== normalizeAnswer(question.correctAnswer)) return false;
  return Math.abs(actual - expected) < 1e-10;
}
