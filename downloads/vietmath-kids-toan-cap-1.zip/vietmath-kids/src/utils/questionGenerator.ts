import { validateQuestions } from './validateQuestions';
import { Question, Lesson } from '../types';
import { getGrade1Questions } from './questionBanks/grade1';
import { getGrade2Questions } from './questionBanks/grade2';
import { getGrade3Questions } from './questionBanks/grade3';
import { getGrade4Questions } from './questionBanks/grade4';
import { getGrade5Questions } from './questionBanks/grade5';
import { generateDynamicQuestions } from './questionBanks/dynamicAiGenerator';

export { generateDynamicQuestions };

/**
 * Bộ tạo câu hỏi thông minh toàn diện chuẩn Thông tư 27 / Bộ GD&ĐT
 * Đảm bảo:
 * 1. Mỗi bài học đều có bộ câu hỏi phong phú, đa dạng, đúng chuẩn sư phạm.
 * 2. Phân tầng rõ ràng 3 mức độ: Mức 1 (Nhận biết), Mức 2 (Kết nối/Thực hành), Mức 3 (Vận dụng/Nâng cao).
 * 3. Hỗ trợ đa dạng các dạng tương tác: trắc nghiệm, điền số, đếm trực quan, phân số trực quan, đồng hồ kim.
 * 4. Không bao giờ để bài học bị rỗng câu hỏi hoặc trùng lặp đơn điệu.
 */
export function getQuestionsForLesson(lesson: Lesson): Question[] {
  if (!lesson) return [];

  // 1. If lesson already has curated questions (>= 5 questions), use them
  const curated = validateQuestions(lesson.questions);
  if (curated.length >= 5) {
    return curated;
  }

  let bankQuestions: Question[] = [];

  switch (lesson.grade) {
    case 1:
      bankQuestions = getGrade1Questions(lesson);
      break;
    case 2:
      bankQuestions = getGrade2Questions(lesson);
      break;
    case 3:
      bankQuestions = getGrade3Questions(lesson);
      break;
    case 4:
      bankQuestions = getGrade4Questions(lesson);
      break;
    case 5:
      bankQuestions = getGrade5Questions(lesson);
      break;
    default:
      bankQuestions = [];
  }

  bankQuestions = validateQuestions(bankQuestions);

  // 2. If specific bank has at least 5 questions, return them or supplement if needed
  if (bankQuestions && bankQuestions.length >= 5) {
    // If less than 10 questions, supplement with dynamic ones to reach 10 questions
    if (bankQuestions.length < 10) {
      const extraNeeded = 10 - bankQuestions.length;
      const extras = generateDynamicQuestions(lesson.grade, lesson.title, extraNeeded);
      return [...bankQuestions, ...extras];
    }
    return bankQuestions;
  }

  // 3. Fallback: Generate 10 rich dynamic questions tailored to the lesson topic & grade
  return generateDynamicQuestions(lesson.grade, lesson.title, 10);
}
