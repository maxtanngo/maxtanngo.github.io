export type Grade = 1 | 2 | 3 | 4 | 5;

export type Textbook = 'ket-noi-tri-thuc' | 'chan-troi-sang-tao' | 'canh-dieu';

export type Strand = 'Số & Phép tính' | 'Hình học & Đo lường' | 'Giải toán có lời văn' | 'Dữ liệu & Xác suất';

export type QuestionType =
  | 'multiple_choice'
  | 'number_input'
  | 'visual_count'
  | 'visual_clock'
  | 'visual_fraction'
  | 'visual_distance';

export interface VisualData {
  countItem?: 'apple' | 'star' | 'candy' | 'fish' | 'flower' | 'pencil';
  countNumber?: number;
  countGroup1?: number;
  countGroup2?: number;
  clockHour?: number;
  clockMinute?: number;
  fractionNumerator?: number;
  fractionDenominator?: number;
  fractionType?: 'bar' | 'circle';
  distanceKm?: number;
  speedV1?: number;
  speedV2?: number;
  vehicleType1?: string;
  vehicleType2?: string;
  direction?: 'opposite' | 'same';
}

export interface Question {
  id: string;
  question: string;
  type: QuestionType;
  options?: string[];
  correctAnswer: string;
  hint: string;
  explanation: string;
  strand: Strand;
  level?: 'Mức 1' | 'Mức 2' | 'Mức 3';
  visualData?: VisualData;
}

export interface LessonTheory {
  summary: string;
  rules?: string[];
  formulas?: string[];
  example?: {
    problem: string;
    solution: string;
  };
}

export interface Lesson {
  id: string;
  title: string;
  chapterId: string;
  grade: Grade;
  week?: number;
  semester?: 1 | 2;
  description: string;
  questions: Question[];
  icon: string;
  strand: Strand;
  theory?: LessonTheory;
}

export interface Chapter {
  id: string;
  title: string;
  grade: Grade;
  description: string;
  lessons: Lesson[];
  color: string;
}

export interface TimetableDay {
  day: string;
  slots: string[]; // Lịch học chính khóa (buổi sáng: Tiết 1, 2, 3, 4)
  extraSlots?: string[]; // Lịch học tăng tiết / bổ trợ (buổi chiều: Tiết tăng 1, 2, 3)
}

export interface StudentProfile {
  name: string;
  gender: 'male' | 'female';
  grade: Grade;
  schoolName?: string;
  timetable: TimetableDay[];
}

export interface UserProgress {
  version?: number;
  textbook?: Textbook;
  stars: number;
  streak: number;
  lastActiveDate: string;
  completedLessons: Record<string, { stars: number; score: number; completedAt: string; title?: string; bestScore?: number; answered?: number; correct?: number }>;
  equippedSkin: string;
  unlockedSkins: string[];
  totalAnswered: number;
  correctCount: number;
  timeSpentMinutes: number;
  preferredVoiceId?: string;
  studentProfile?: StudentProfile;
  arenaHighScore?: number;
  strandStats: {
    'Số & Phép tính': { correct: number; total: number };
    'Hình học & Đo lường': { correct: number; total: number };
    'Giải toán có lời văn': { correct: number; total: number };
    'Dữ liệu & Xác suất': { correct: number; total: number };
  };
}

export interface OwlSkin {
  id: string;
  name: string;
  title: string;
  description: string;
  costStars: number;
  emoji: string;
  colorScheme: {
    bg: string;
    border: string;
    text: string;
    accent: string;
  };
  features: string;
}

export type VoiceRegion = 'north' | 'south' | 'central' | 'cartoon';

export interface VoiceProfile {
  id: string;
  name: string;
  shortName: string;
  region: string;
  tag: string;
  gender: 'female' | 'male' | 'owl';
  avatar: string;
  description: string;
  sampleText: string;
  geminiVoiceName: 'Kore' | 'Aoede' | 'Charon' | 'Puck' | 'Fenrir' | 'Zephyr';
  stylePrompt: string;
  rate: number;
  pitch: number;
  provider: 'gemini' | 'custom' | 'fpt';
  preferredVoiceNames?: string[];
}

export type RegionalVoiceOption = VoiceProfile;

