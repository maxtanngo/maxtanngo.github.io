import { offlineRelease, staticRelease } from './utils/releaseMode';
import { recordAttempt, type AttemptResult } from './utils/assessment';
import React, { useState, useEffect, lazy, Suspense } from 'react';
import { Grade, Textbook, Lesson, UserProgress, StudentProfile } from './types';
import { CURRICULUM_2026 } from './data/curriculum2026';
import { getQuestionsForLesson } from './utils/questionGenerator';
import {
  loadUserProgress,
  saveUserProgress,
  INITIAL_SKINS,
  DEFAULT_USER_PROGRESS,
  DEFAULT_STUDENT_PROFILE,
} from './utils/storage';
import { getSavedVoiceId, setSavedVoiceId } from './utils/soundAndSpeech';
import { TopHeader } from './components/TopHeader';
import { Navigation, TabKey } from './components/Navigation';
import { LearningPathView } from './components/LearningPathView';
import { AiExamView } from './components/AiExamView';
import { MathArenaView } from './components/MathArenaView';
import { StoreView } from './components/StoreView';
import { AuthorAndFeedbackView } from './components/AuthorAndFeedbackView';
import { QuizEngine } from './components/QuizEngine';
import { VoiceSelectorModal } from './components/VoiceSelectorModal';
import { StudentProfileModal } from './components/StudentProfileModal';
import { DeveloperFeedbackModal } from './components/DeveloperFeedbackModal';

const AiOwlTutorView = lazy(() => import('./components/AiOwlTutorView').then(module => ({ default: module.AiOwlTutorView })));

const GoogleDriveView = lazy(() => import('./components/GoogleDriveView').then(module => ({ default: module.GoogleDriveView })));

const ParentDashboardView = lazy(() => import('./components/ParentDashboardView').then(module => ({ default: module.ParentDashboardView })));

export default function App() {
  const [progress, setProgress] = useState<UserProgress>(loadUserProgress);
  const [currentGrade, setCurrentGrade] = useState<Grade>(
    progress.studentProfile?.grade || 1
  );
  const [currentTextbook, setCurrentTextbook] = useState<Textbook>(progress.textbook || 'ket-noi-tri-thuc');
  const [activeTab, setActiveTab] = useState<TabKey>('path');
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);

  // Regional Voice & Modals state
  const [currentVoiceId, setCurrentVoiceId] = useState<string>(getSavedVoiceId);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [profileModalTab, setProfileModalTab] = useState<'profile' | 'timetable'>('profile');
  const [saveFailed, setSaveFailed] = useState(false);
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);

  const handleOpenProfileModal = (tab: 'profile' | 'timetable' = 'profile') => {
    setProfileModalTab(tab);
    setIsProfileModalOpen(true);
  };

  // Sync progress to LocalStorage whenever it changes
  useEffect(() => {
    setSaveFailed(!saveUserProgress(progress));
  }, [progress]);

  const handleSelectVoice = (voiceId: string) => {
    setCurrentVoiceId(voiceId);
    setSavedVoiceId(voiceId);
  };

  // Find currently equipped Owl skin
  const currentSkin =
    INITIAL_SKINS.find((s) => s.id === progress.equippedSkin) || INITIAL_SKINS[0];

  // Current curriculum chapters for active grade (35 weeks, 2026 GDPT 2018)
  const currentChapters = CURRICULUM_2026[currentGrade] || [];

  const handleLessonComplete = (result: AttemptResult) => {
    if (activeLesson) setProgress(previous => recordAttempt(previous, result, activeLesson.id, 'lesson'));
  };

  const handleExamComplete = (result: AttemptResult) => {
    const id = 'exam_' + crypto.randomUUID();
    setProgress(previous => recordAttempt(previous, result, id, 'exam'));
  };

  const handleUpdateArenaScore = (score: number, result: AttemptResult) => {
    const id = 'arena_' + crypto.randomUUID();
    setProgress(previous => ({
      ...recordAttempt(previous, result, id, 'arena'),
      arenaHighScore: Math.max(previous.arenaHighScore ?? 0, score),
    }));
  };

  // Handler for student profile & timetable saving
  const handleSaveProfile = (newProfile: StudentProfile) => {
    setCurrentGrade(newProfile.grade);
    setProgress((prev) => ({
      ...prev,
      studentProfile: newProfile,
    }));
  };

  const handleEquipSkin = (skinId: string) => {
    setProgress((prev) => ({
      ...prev,
      equippedSkin: skinId,
    }));
  };

  const handleUnlockSkin = (skinId: string, cost: number) => {
    setProgress((prev) => {
      if (prev.stars < cost) return prev;
      return {
        ...prev,
        stars: prev.stars - cost,
        unlockedSkins: [...prev.unlockedSkins, skinId],
        equippedSkin: skinId,
      };
    });
  };

  const handleResetProgress = () => {
    setProgress(previous => ({ ...DEFAULT_USER_PROGRESS, studentProfile: previous.studentProfile, textbook: previous.textbook }));
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {saveFailed && <p role="alert" className="bg-amber-100 p-3 text-amber-900">Thiết bị chưa lưu được tiến độ. Kiểm tra dung lượng hoặc quyền lưu của trình duyệt.</p>}
      {staticRelease && <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 bg-emerald-950 px-3 py-2 text-center text-xs text-white">
        <a href={offlineRelease ? "https://maxngo.io.vn/hoc-tap/" : "/hoc-tap/"} className="font-bold underline">← HỌC TẬP</a>
        <span>Học miễn phí · Đề và gia sư theo bộ câu hỏi có sẵn · Tiến độ lưu trên thiết bị</span>
        <a href={offlineRelease ? "https://maxngo.io.vn/downloads/#vietmath-kids" : "/downloads/#vietmath-kids"} className="font-bold underline">Tải về máy</a>
      </div>}
      {/* Top Header */}
      <TopHeader
        currentGrade={currentGrade}
        onGradeChange={(grade) => {
          setCurrentGrade(grade);
          setActiveLesson(null);
        }}
        currentTextbook={currentTextbook}
        onTextbookChange={(textbook) => { setCurrentTextbook(textbook); setProgress(previous => ({ ...previous, textbook })); }}
        streak={progress.streak}
        stars={progress.stars}
        currentSkin={currentSkin}
        studentProfile={progress.studentProfile}
        currentVoiceId={currentVoiceId}
        onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
        onOpenProfileModal={() => handleOpenProfileModal('profile')}
        onOpenAuthorTab={() => {
          setActiveTab('author');
          setActiveLesson(null);
        }}
        onOpenDriveTab={staticRelease ? undefined : () => {
          setActiveTab('drive');
          setActiveLesson(null);
        }}
      />

      {/* Main Layout Container */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex">
        {/* Navigation Sidebar & Mobile Bar */}
        <Navigation
          activeTab={activeTab}
          onTabChange={(tab) => {
            setActiveTab(tab);
            setActiveLesson(null);
          }}
          grade={currentGrade}
          onOpenFeedbackModal={() => setIsFeedbackModalOpen(true)}
        />

        {/* Content Area */}
        <main className="min-w-0 flex-1 p-4 md:p-8 overflow-x-hidden pb-32 lg:pb-8">
          <Suspense fallback={<p role="status" className="p-4">Đang mở mục này…</p>}>
          {activeLesson ? (
            /* Active Interactive Lesson Quiz */
            <QuizEngine
              title={activeLesson.title}
              grade={currentGrade}
              lesson={activeLesson}
              questions={activeLesson.questions}
              currentVoiceId={currentVoiceId}
              onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
              onComplete={handleLessonComplete}
              onExit={() => setActiveLesson(null)}
            />
          ) : (
            <>
              {activeTab === 'path' && (
                <LearningPathView
                  grade={currentGrade}
                  chapters={currentChapters}
                  progress={progress}
                  onSelectLesson={(lesson) => {
                    const populatedQuestions = getQuestionsForLesson(lesson);
                    setActiveLesson({
                      ...lesson,
                      questions: populatedQuestions,
                    });
                  }}
                  onOpenProfileModal={handleOpenProfileModal}
                />
              )}

              {activeTab === 'exam' && (
                <AiExamView key={currentGrade + currentTextbook}
                  grade={currentGrade}
                  textbook={currentTextbook}
                  currentVoiceId={currentVoiceId}
                  onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
                  onExamComplete={handleExamComplete}
                />
              )}

              {activeTab === 'arena' && (
                <MathArenaView key={currentGrade}
                  grade={currentGrade}
                  studentName={progress.studentProfile?.name}
                  highScore={progress.arenaHighScore || 0}
                  onUpdateHighScore={handleUpdateArenaScore}
                />
              )}

              {activeTab === 'tutor' && (
                <AiOwlTutorView
                  grade={currentGrade}
                  currentVoiceId={currentVoiceId}
                  onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
                />
              )}

              {activeTab === 'store' && (
                <StoreView
                  grade={currentGrade}
                  progress={progress}
                  onEquipSkin={handleEquipSkin}
                  onUnlockSkin={handleUnlockSkin}
                />
              )}

              {activeTab === 'parent' && (
                <ParentDashboardView
                  grade={currentGrade}
                  progress={progress}
                  onResetProgress={handleResetProgress}
                  onOpenDriveTab={staticRelease ? undefined : () => {
                    setActiveTab('drive');
                    setActiveLesson(null);
                  }}
                />
              )}

              {!staticRelease && activeTab === 'drive' && (
                <GoogleDriveView
                  grade={currentGrade}
                  progress={progress}
                  onRestoreProgress={(restoredProgress) => {
                    setProgress(restoredProgress);
                    setCurrentTextbook(restoredProgress.textbook || "ket-noi-tri-thuc");
                    if (restoredProgress.studentProfile?.grade) {
                      setCurrentGrade(restoredProgress.studentProfile.grade);
                    }
                  }}
                />
              )}

              {activeTab === 'author' && <AuthorAndFeedbackView />}
            </>
          )}
          </Suspense>
        </main>
      </div>

      {/* Subtle, Professional MaxNgo Studio Footer */}
      <footer className="border-t border-slate-200 bg-white/80 backdrop-blur py-2.5 px-4 text-xs text-slate-500 block mb-16 lg:mb-0">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 font-medium text-[11px]">
            <span>Toán Tiểu Học Thông Minh 2026 · Sáng tạo bởi</span>
            <strong className="text-slate-800 font-bold">Ngô Thanh Tân (MaxNgo Studio)</strong>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span>Hotline hỗ trợ: <strong className="text-slate-700">097.3333.210</strong></span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[11px] text-slate-500 font-medium italic tracking-tight bg-slate-50 border border-slate-200/80 px-3 py-1 rounded-full shadow-2xs">
              Đây là phiên bản đầu còn nhiều thiếu sót mong được Quý phụ huynh góp ý
            </span>
          </div>
        </div>
      </footer>

      {/* Voice Selection Modal */}
      {isVoiceModalOpen && (
        <VoiceSelectorModal
          currentVoiceId={currentVoiceId}
          onSelectVoice={handleSelectVoice}
          onClose={() => setIsVoiceModalOpen(false)}
        />
      )}

      {/* Student Profile & Timetable Modal */}
      {isProfileModalOpen && (
        <StudentProfileModal
          initialProfile={progress.studentProfile || DEFAULT_STUDENT_PROFILE}
          currentGrade={currentGrade}
          initialTab={profileModalTab}
          onSaveProfile={handleSaveProfile}
          onClose={() => setIsProfileModalOpen(false)}
        />
      )}

      {/* Developer Info & Bug Report Modal */}
      {isFeedbackModalOpen && (
        <DeveloperFeedbackModal
          currentGrade={currentGrade}
          onClose={() => setIsFeedbackModalOpen(false)}
        />
      )}
    </div>
  );
}
