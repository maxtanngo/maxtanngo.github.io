import type { GoogleGenAI } from '@google/genai';
import { generateWithFallback } from '../src/services/geminiFallback';
import test from 'node:test';
import assert from 'node:assert/strict';
import { CURRICULUM_2026 } from '../src/data/curriculum2026';
import { addAnswer, matchesAnswer, recordAttempt, type StrandTotals } from '../src/utils/assessment';
import { getQuestionsForLesson, generateDynamicQuestions } from '../src/utils/questionGenerator';
import { validateQuestions } from '../src/utils/validateQuestions';
import { extractMathExpression, solveMathExpression } from '../src/utils/mathExpressionSolver';
import { DEFAULT_USER_PROGRESS, readProgressBackup } from '../src/utils/storage';

test('quiz scores, title, strand totals and streak reflect a completed attempt', () => {
  const strands: StrandTotals = {};
  addAnswer(strands, 'Số & Phép tính', true);
  addAnswer(strands, 'Hình học & Đo lường', false);
  const result = { title: 'Bài thực hành', correct: 1, answered: 2, stars: 1, seconds: 18, strands };
  const first = recordAttempt(DEFAULT_USER_PROGRESS, result, 'lesson', 'lesson');
  assert.equal(first.stars, 1);
  assert.equal(first.streak, 1);
  assert.equal(first.totalAnswered, 2);
  assert.equal(first.correctCount, 1);
  assert.equal(first.completedLessons.lesson.score, 50);
  assert.equal(first.completedLessons.lesson.title, result.title);
  assert.deepEqual(first.strandStats['Hình học & Đo lường'], { total: 1, correct: 0 });
  const repeat = recordAttempt(first, result, 'lesson', 'lesson');
  assert.equal(repeat.streak, 1);
  assert.equal(repeat.stars, 1);
  assert.equal(recordAttempt(first, { ...result, answered: 0 }, 'arena', 'arena'), first);
});

test('decimals and fractions accept equivalent forms and reject malformed input', () => {
  const input = { ...generateDynamicQuestions(3, 'Diện tích', 1)[0], type: 'number_input' as const, correctAnswer: '0,5' };
  assert.ok(matchesAnswer(input, '0.50'));
  assert.ok(matchesAnswer(input, '1/2'));
  assert.ok(!matchesAnswer(input, '0,5,0'));
  assert.ok(!matchesAnswer(input, '1/0'));
  assert.ok(!matchesAnswer({ ...input, question: 'Nhập phân số tối giản', correctAnswer: '1/2' }, '2/4'));
});

test('solver keeps complete expressions and rejects divide-by-zero and malformed numbers', () => {
  const expression = extractMathExpression('Tính giá trị của biểu thức: (15 + 5) : 4 = ?');
  assert.equal(expression, '(15 + 5) : 4');
  assert.equal(solveMathExpression(expression!)?.finalResult, 5);
  assert.equal(solveMathExpression('8 : 0'), null);
  assert.equal(solveMathExpression('1,2,3 + 1'), null);
  assert.equal(solveMathExpression('2 3 + 1'), null);
});

test('generated questions across grades and supported topics have unique valid options', () => {
  for (let iteration = 0; iteration < 25; iteration++) {
    for (const [grade, chapters] of Object.entries(CURRICULUM_2026)) {
      const lessons = chapters.flatMap(chapter => chapter.lessons);
      for (const lesson of lessons) {
        const questions = getQuestionsForLesson(lesson);
        assert.ok(questions.length >= 5, lesson.title);
        assert.equal(validateQuestions(questions).length, questions.length, lesson.title);
      }
      for (const topic of ['Tổng hợp', 'Đồng hồ', 'Hình tam giác', 'Phân số', 'Chu vi', 'Diện tích', 'Phần trăm', 'Chuyển động']) {
        const questions = generateDynamicQuestions(Number(grade), topic, 10);
        assert.equal(validateQuestions(questions).length, 10, topic);
      }
    }
  }
  assert.ok(generateDynamicQuestions(1, 'Hình tam giác', 5).every(question => question.correctAnswer === 'Hình tam giác'));
});

test('Drive backup validates the schema and accepts existing versioned files', () => {
  assert.equal(readProgressBackup({ stars: 10 }), null);
  assert.equal(readProgressBackup({ version: 'invalid', progressData: DEFAULT_USER_PROGRESS }), null);
  assert.equal(readProgressBackup({ version: '2026.1', progressData: { ...DEFAULT_USER_PROGRESS, totalAnswered: 1, correctCount: 2 } }), null);
  assert.deepEqual(readProgressBackup({ version: '2026.2', progressData: DEFAULT_USER_PROGRESS }), DEFAULT_USER_PROGRESS);
});


test('Gemini overload switches model and skips a model still in cooldown', async () => {
  const called: string[] = [];
  const client = { models: { async generateContent({ model }: { model: string }) {
    called.push(model);
    if (model === 'test-primary') throw Object.assign(new Error('Busy'), { status: 503 });
    return { text: 'ok' };
  } } } as unknown as GoogleGenAI;
  const models = ['test-primary', 'test-secondary'];
  assert.equal((await generateWithFallback(client, models, { contents: 'test' }, 5000)).model, 'test-secondary');
  assert.equal((await generateWithFallback(client, models, { contents: 'test' }, 5000)).model, 'test-secondary');
  assert.deepEqual(called, ['test-primary', 'test-secondary', 'test-secondary']);
});
