# VietMath Kids (Toán Cấp 1)

## Mở bản học trên máy

1. Giải nén ZIP và mở Terminal hoặc PowerShell trong thư mục này.
2. Cài Node.js 22.12 trở lên nếu máy chưa có Node.
3. Chạy `npm run offline` và mở http://127.0.0.1:4310/ trong trình duyệt.
4. Nhấn Ctrl+C trong cửa sổ lệnh khi muốn dừng app.

Bản này đã dựng sẵn. Bài học, đề dự phòng, Gia sư theo bộ giải, Đấu trường và tiến độ lưu trên máy chạy với Node mà không cần cài thư viện npm hoặc khóa Gemini. Giọng đọc tiếng Việt tùy vào trình duyệt và giọng cài trên thiết bị. Dùng cùng trình duyệt và địa chỉ để tiếp tục tiến độ. Dữ liệu từ maxngo.io.vn được lưu riêng với bản trên máy.

## Chạy bản đầy đủ có máy chủ

Chạy `npm ci`, `npm run build` rồi `npm run dev`, sau đó mở http://localhost:3000/. Bản này có máy chủ Node cho tạo đề, Gia sư, TTS và lưu góp ý. Có thể chạy chế độ dự phòng mà không cần khóa Gemini.

Muốn bật Gemini, tạo `.env.local` theo `.env.example` và đặt khóa của chính bạn vào `GEMINI_API_KEY`. Giữ khóa trên máy chủ. Drive cần Firebase Google sign-in, Drive API và tên miền được phép của dự án. Điền cấu hình Firebase Web của dự án vào `firebase-applet-config.json`, rồi build lại.

Góp ý trên bản đầy đủ được lưu trong `private-data/feedback.jsonl`. Khi triển khai, đặt `FEEDBACK_FILE` trên ổ lưu riêng, bền vững. Chỉ triển khai thư mục `dist/` cùng máy chủ và cấu hình môi trường thích hợp. Tiến độ, khóa API và dữ liệu góp ý cần giữ ngoài các gói chia sẻ.

## Kiểm tra mã

```sh
npm run lint
npm test
npm run build
```
