# VietMath THCS · Toán cấp 2

Ứng dụng luyện Toán tiếng Việt cho lớp 6, 7, 8 và 9. Mở `VietMath-THCS-MaxNgo.html` trực tiếp trong Chrome, Safari hoặc Firefox để sử dụng. App chạy độc lập và không yêu cầu tài khoản. Thư mục `source/` chứa phiên bản tách riêng HTML, CSS và JavaScript để chỉnh sửa hoặc đưa lên website tĩnh.

## Nội dung và cách dùng

- 44 chủ đề chia theo Số và Đại số, Hình học và Đo lường, Thống kê và Xác suất. Mỗi chủ đề có tóm tắt, ví dụ và ba dạng câu luyện tập. Nhiều dạng sinh biến thể số liệu cho mỗi lượt.
- Đề theo mạch có 6 câu. Đề tổng hợp có 12 câu và đồng hồ 20 phút. Lớp 9 có đề tổng hợp tự luyện trước khi vào 10.
- Học sinh có thể xem gợi ý khi luyện, xem lời giải sau khi chấm và ôn lại câu sai. Tiến độ lưu theo khối lớp trên trình duyệt. Khi chuyển thiết bị hoặc địa chỉ website, mỗi bản có tiến độ riêng.
- Thư viện bao phủ các chủ đề trọng tâm của cả bốn khối. Trước khi dùng như một giáo trình cả năm hoặc nguồn ra đề chính thức, giáo viên cần rà mức bao phủ từng yêu cầu cần đạt và bổ sung bài tự luận, chứng minh, bài thực hành.

## Hoạt động trực quan

- Lớp 6: so sánh hai thanh phân số. Lớp 7: tung xu và so sánh tỉ lệ quan sát với 50%.
- Lớp 8: thay đổi cạnh góc vuông để kiểm tra Pythagore. Lớp 9: đổi hệ số a để quan sát parabol.

## Nguồn đối chiếu

- [Chương trình GDPT môn Toán của Bộ GD&ĐT](https://thcsandong.haiphong.edu.vn/van-ban-bo-gddt/chuong-trinh-giao-duc-pho-thong-mon-toan-ban-hanh-kem-theo-thong-tu-so-322018tt/vbct/20343/91425)
- [OLM Toán 6](https://olm.vn/bg/toan-6-16438?week=0) cho cách tổ chức học và luyện theo chương, bài.
- [VioEdu](https://luyentap.vio.edu.vn/) cho cách tổ chức luyện tương tác và phản hồi.
- [Khan Academy](https://support.khanacademy.org/hc/en-us/articles/360037494231-What-are-Mastery-Challenges) cho ý tưởng ôn các kỹ năng đã học.
- [HOCMAI Học Tốt](https://hoctot.hocmai.vn/) cho việc dành lộ trình ôn riêng cho lớp 9.

- [Mathigon Polypad](https://mathigon.org/teachers), [GeoGebra](https://help.geogebra.org/hc/en-us/articles/10445800380957-GeoGebra-Tools-and-Features-An-Overview) và [Desmos](https://help.desmos.com/hc/en-us/articles/202529069-Sliders-and-Movable-Points-in-a-Graph) cho các hoạt động thao tác trực quan.

Các câu hỏi và lời giải trong bản này được biên soạn riêng cho VietMath THCS.
