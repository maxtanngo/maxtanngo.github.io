/* Nội dung biên soạn cho VietMath THCS. Mỗi hàm tạo câu trả về đề, đáp án và lời giải. */
const A='Số & Đại số', G='Hình học & Đo lường', D='Thống kê & Xác suất';
const topics=[];
const q=(prompt,answer,solution,hint,choices)=>({prompt,answer:String(answer),solution,hint,choices});
const choice=(prompt,answer,others,solution,hint)=>q(prompt,answer,solution,hint,[answer,...others]);
const lesson=(grade,id,strand,title,rule,examples)=>topics.push({grade,id,strand,title,rule,examples});
const signs=(a)=>a<0?'− '+Math.abs(a):'+ '+a;
const f=(n,d)=>n+'/'+d;
const pi=(n)=>n+'π';
const rows=values=>values.join('; ');
lesson(6,'natural',A,'Tập hợp và số tự nhiên','Tập hợp gồm các phần tử phân biệt. Trong biểu thức, tính lũy thừa trước, sau đó nhân chia rồi cộng trừ.',[
 n=>q('Tính '+(n+2)+' + 3 × '+(n+1)+'.',n+2+3*(n+1),'Tính tích trước, rồi cộng '+(n+2)+'.','Nhân trước cộng.'),
 n=>q('Tính 2³ + '+n+'.',8+n,'2³ = 2 × 2 × 2 = 8. Cộng thêm '+n+'.','Viết lũy thừa thành tích.'),
 n=>q('Tập hợp {'+rows(Array.from({length:n+1},(_,i)=>2*i))+'} có bao nhiêu phần tử?',n+1,'Có '+n+' số chẵn dương và thêm số 0.','Đừng bỏ quên số 0.')]);
lesson(6,'divisibility',A,'Chia hết, số nguyên tố, ƯCLN và BCNN','Phân tích thành thừa số nguyên tố. ƯCLN lấy các thừa số chung với số mũ nhỏ nhất. BCNN lấy tất cả thừa số xuất hiện với số mũ lớn nhất.',[
 n=>q('Tìm ƯCLN của '+(6*n)+' và '+(9*n)+'.',3*n,'Chia cả hai số cho '+n+' được 6 và 9, có ƯCLN bằng 3.','Tách nhân tử chung.'),
 n=>q('Tìm BCNN của '+(4*n)+' và '+(6*n)+'.',12*n,'BCNN(4, 6) = 12. Nhân với '+n+' được '+(12*n)+'.','Tìm bội chung nhỏ nhất của 4 và 6 trước.'),
 n=>choice('Số nào chia hết cho 3?',String(30*n+12),[String(30*n+10),String(30*n+11),String(30*n+13)],'Trong bốn số liên tiếp đã cho chỉ có '+(30*n+12)+' là bội của 3.','Dùng tổng các chữ số hoặc chia thử.')]);
lesson(6,'integers',A,'Số nguyên và trục số','Trên trục số, điểm càng về bên trái biểu diễn số càng nhỏ. Trừ một số bằng cách cộng số đối của nó.',[
 n=>q('Tính (−'+(n+5)+') + '+n+'.',-5,'Hai số khác dấu. Lấy hiệu hai giá trị tuyệt đối và giữ dấu âm.','So sánh hai giá trị tuyệt đối.'),
 n=>q('Tính '+n+' − (−'+(n+2)+').',2*n+2,'Trừ một số âm là cộng số đối dương của nó.','Đổi phép trừ thành phép cộng.'),
 n=>q('Nhiệt độ từ −'+n+' °C tăng '+(n+4)+' °C. Nhiệt độ mới là bao nhiêu °C?',4,'Tính −'+n+' + '+(n+4)+' = 4.','Mức tăng mang dấu dương.')]);
lesson(6,'fractions',A,'Phân số và hỗn số','Cộng phân số cần quy đồng mẫu. Nhân tử với tử, mẫu với mẫu. Chia cho phân số khác 0 bằng cách nhân với phân số nghịch đảo.',[
 n=>q('Tính 1/'+(n+2)+' + 2/'+(n+2)+'.',f(3,n+2),'Cùng mẫu nên cộng các tử: 1 + 2 = 3.','Giữ mẫu số.'),
 n=>q('Tính '+n+'/3 × 3/5.',f(n,5),'Rút gọn hai thừa số 3 ở tử và mẫu, được '+n+'/5.','Rút gọn trước khi nhân.'),
 n=>q('Viết hỗn số '+n+' và 2/3 dưới dạng phân số.',f(3*n+2,3),'Nhân phần nguyên với 3 rồi cộng 2, giữ mẫu 3.','Tử mới là phần nguyên × mẫu + tử cũ.')]);
lesson(6,'decimal',A,'Số thập phân, tỉ số và phần trăm','Để tìm p% của một lượng, nhân lượng đó với p/100. Có thể viết số thập phân bằng dấu phẩy hoặc dấu chấm khi nhập đáp án.',[
 n=>q('Tìm 25% của '+(4*n)+' kg (nhập số).',n,'25% = 1/4. Lấy '+(4*n)+' chia 4.','Đổi 25% sang phân số.'),
 n=>q('Tính '+n+',25 + 0,5.',n+.75,'0,25 + 0,50 = 0,75; phần nguyên giữ nguyên.','Đặt các chữ số cùng hàng thẳng cột.'),
 n=>q('Giá '+(10*n)+' nghìn đồng giảm 10%. Giá sau giảm là bao nhiêu nghìn đồng?',9*n,'Giá còn 90%, tức '+(10*n)+' × 0,9 = '+(9*n)+'.','Trừ phần trăm giảm khỏi 100%.')]);
lesson(6,'plane',G,'Điểm, đoạn thẳng và góc','Nếu B nằm giữa A và C thì AB + BC = AC. Góc nhọn nhỏ hơn 90°, góc vuông bằng 90°, góc tù lớn hơn 90° và nhỏ hơn 180°.',[
 n=>q('B nằm giữa A và C, AB = '+n+' cm, BC = '+(n+3)+' cm. Tính AC (cm).',2*n+3,'Cộng độ dài hai đoạn liên tiếp.','Dùng AB + BC = AC.'),
 n=>q('M là trung điểm AB và AB = '+2*n+' cm. Tính AM (cm).',n,'Trung điểm chia đoạn thẳng thành hai phần bằng nhau.','Chia AB cho 2.'),
 n=>choice('Góc '+(95+n)+'° là góc gì?','Góc tù',['Góc nhọn','Góc vuông','Góc bẹt'],'Góc này lớn hơn 90° và nhỏ hơn 180°.','So sánh với 90° và 180°.')]);
lesson(6,'shapes',G,'Hình phẳng, chu vi và diện tích','Hình bình hành có diện tích bằng đáy nhân chiều cao tương ứng. Hình thang có diện tích bằng tổng hai đáy nhân chiều cao rồi chia 2.',[
 n=>q('Hình bình hành có đáy '+(n+4)+' cm, cao 3 cm. Tính diện tích (cm²).',3*(n+4),'Lấy đáy nhân chiều cao tương ứng.','Dùng S = a × h.'),
 n=>q('Hình thang có hai đáy '+n+' cm và '+(n+4)+' cm, cao 2 cm. Tính diện tích (cm²).',2*n+4,'Cộng hai đáy, nhân 2 rồi chia 2.','Dùng S = (a + b) × h / 2.'),
 n=>q('Hình thoi có cạnh '+n+' cm. Tính chu vi (cm).',4*n,'Bốn cạnh của hình thoi bằng nhau.','Nhân độ dài một cạnh với 4.')]);
lesson(6,'symmetry',G,'Đối xứng trục và đối xứng tâm','Đối xứng trục có thể kiểm tra bằng cách gấp hình theo đường thẳng. Đối xứng tâm có thể kiểm tra bằng cách quay hình 180° quanh tâm.',[
 ()=>q('Hình vuông có bao nhiêu trục đối xứng?',4,'Hai đường chéo và hai đường qua trung điểm các cặp cạnh đối diện.','Thử đường chéo và đường đi qua trung điểm.'),
 ()=>q('Hình chữ nhật không phải hình vuông có bao nhiêu trục đối xứng?',2,'Hai đường qua trung điểm các cặp cạnh đối diện.','Đường chéo không chia hình thành hai nửa gấp khít.'),
 ()=>choice('Tâm đối xứng của hình bình hành ở đâu?','Giao điểm hai đường chéo',['Một đỉnh bất kỳ','Trung điểm của một cạnh','Hình bình hành không có tâm'],'Hai đường chéo cắt nhau tại trung điểm mỗi đường. Quay 180° đổi chỗ các đỉnh đối diện.','Tìm một điểm cách đều mỗi cặp đỉnh đối diện.')]);
lesson(6,'data',D,'Thu thập dữ liệu và đọc biểu đồ','Bảng tần số đếm số lần xuất hiện. Biểu đồ cột biểu diễn số liệu bằng chiều cao cột. Khi so sánh cần đọc đơn vị và thang đo.',[
 n=>q('Ba tổ trồng được lần lượt '+rows([n,n+3,n+1])+' cây. Tổng số cây là bao nhiêu?',3*n+4,'Cộng số cây của ba tổ.','Tổng gồm cả ba giá trị.'),
 n=>q('Trong dãy '+rows([n,n+1,n,n+2,n])+' số '+n+' xuất hiện bao nhiêu lần?',3,'Đếm các vị trí 1, 3 và 5.','Chỉ đếm đúng giá trị được hỏi.'),
 n=>q('Cột A biểu diễn '+(n+8)+' bạn, cột B biểu diễn '+n+' bạn. A hơn B bao nhiêu bạn?',8,'Lấy số bạn của A trừ số bạn của B.','So sánh bằng hiệu.')]);
lesson(6,'chance',D,'Kết quả có thể và xác suất thực nghiệm','Xác suất thực nghiệm của một sự kiện bằng số lần sự kiện xảy ra chia cho tổng số lần thực hiện phép thử.',[
 n=>q('Tung đồng xu '+(5*n)+' lần, có '+(2*n)+' lần mặt ngửa. Xác suất thực nghiệm mặt ngửa là bao nhiêu?',f(2,5),'Lấy '+(2*n)+' chia '+(5*n)+' rồi rút gọn.','Tử số là số lần mặt ngửa.'),
 n=>q('Lắc xúc xắc '+(6*n)+' lần, mặt 6 xuất hiện '+n+' lần. Tìm xác suất thực nghiệm.',f(1,6),'Tỉ số '+n+'/'+(6*n)+' rút gọn được 1/6.','Dùng số lần quan sát được.'),
 ()=>q('Khi tung một xúc xắc 6 mặt, có bao nhiêu kết quả có thể?',6,'Các kết quả là 1, 2, 3, 4, 5 và 6 chấm.','Liệt kê từng mặt.')]);

lesson(7,'rational',A,'Số hữu tỉ và phép tính','Số hữu tỉ viết được dưới dạng a/b với a, b nguyên và b khác 0. Tôn trọng thứ tự phép tính và quy tắc dấu.',[
 n=>q('Tính −'+n+'/5 + '+(n+2)+'/5.',f(2,5),'Cộng tử: −'+n+' + '+(n+2)+' = 2.','Hai phân số cùng mẫu.'),
 n=>q('Tính (−'+n+'/3) × 3/2.',f(-n,2),'Rút gọn 3. Tích một số âm với số dương mang dấu âm.','Rút gọn trước khi tính.'),
 n=>q('Tính ('+n+'/2) : ('+n+'/3).',f(3,2),'Đổi phép chia thành nhân với 3/'+n+', rồi rút gọn.','Đảo phân số thứ hai.')]);
lesson(7,'real',A,'Số thực, căn bậc hai số học và làm tròn','Căn bậc hai số học của a ≥ 0 là số không âm có bình phương bằng a. Trên trục số, giá trị tuyệt đối biểu thị khoảng cách đến 0.',[
 n=>q('Tính √'+n*n+'.',n,n+'² = '+n*n+' và '+n+' không âm.','Tìm số không âm có bình phương bằng số dưới căn.'),
 n=>q('Tính |−'+n+'|.',n,'Khoảng cách từ −'+n+' đến 0 là '+n+'.','Khoảng cách không âm.'),
 n=>q('Làm tròn '+n+',468 đến hàng phần mười.',n+.5,'Chữ số hàng phần trăm là 6, tăng hàng phần mười từ 4 lên 5.','Xem chữ số ngay bên phải hàng cần làm tròn.')]);
lesson(7,'proportion',A,'Tỉ lệ thức, tỉ lệ thuận và tỉ lệ nghịch','Trong tỉ lệ thức a/b = c/d, ta có ad = bc. Tỉ lệ thuận giữ nguyên thương y/x. Tỉ lệ nghịch giữ nguyên tích xy.',[
 n=>q('Tìm x biết x/3 = '+n+'/6.',f(n,2),'Nhân hai vế với 3, được x = '+n+'/2.','Dùng tích chéo.'),
 n=>q('3 quyển vở giá '+3*n+' nghìn đồng. 5 quyển cùng loại giá bao nhiêu nghìn đồng?',5*n,'Giá một quyển là '+n+' nghìn. Nhân 5.','Tìm đơn giá.'),
 n=>q('4 máy giống nhau làm xong việc trong '+(3*n)+' giờ. 6 máy cần bao nhiêu giờ?',2*n,'Tổng công là '+12*n+' máy-giờ. Chia cho 6.','Số máy tăng thì thời gian giảm, tổng công giữ nguyên.')]);
lesson(7,'polynomial',A,'Biểu thức đại số và đa thức một biến','Cộng, trừ các hạng tử cùng bậc bằng cách cộng, trừ hệ số. Bậc của đa thức khác 0 là số mũ cao nhất có hệ số khác 0.',[
 n=>q('Tính giá trị của 2x² − x tại x = '+n+'.',2*n*n-n,'Thay x = '+n+' rồi tính bình phương trước.','Thế giá trị của x.'),
 n=>q('Hệ số của x² trong ('+n+'x² + 3x) + (2x² − x) là bao nhiêu?',n+2,'Cộng các hệ số cùng bậc: '+n+' + 2.','Chỉ gom hạng tử có x².'),
 n=>q('Bậc của đa thức 3x^'+(n+2)+' − 2x + 1 là bao nhiêu?',n+2,'Số mũ lớn nhất có hệ số khác 0 là '+(n+2)+'.','Xem hạng tử có số mũ lớn nhất.')]);
lesson(7,'parallel',G,'Góc đối đỉnh và đường thẳng song song','Hai góc đối đỉnh bằng nhau. Nếu hai đường thẳng song song, hai góc so le trong bằng nhau và hai góc trong cùng phía bù nhau.',[
 n=>q('Một góc bằng '+(30+n)+'°. Tính góc đối đỉnh với nó (độ).',30+n,'Hai góc đối đỉnh có cùng số đo.','Đối đỉnh, không phải kề bù.'),
 n=>q('Hai góc kề bù. Góc thứ nhất '+(40+n)+'°. Góc thứ hai bằng bao nhiêu độ?',140-n,'Tổng hai góc kề bù bằng 180°.','Lấy 180° trừ góc đã biết.'),
 n=>q('Hai đường thẳng song song bị cắt bởi một cát tuyến. Một góc so le trong bằng '+(63+n)+'°. Góc còn lại bằng bao nhiêu độ?',63+n,'Vì hai đường thẳng song song, hai góc so le trong bằng nhau.','Xác định đúng cặp góc.')]);
lesson(7,'triangle',G,'Tam giác, bằng nhau và các đường đồng quy','Tổng ba góc của tam giác bằng 180°. Hai tam giác bằng nhau theo các trường hợp như cạnh–cạnh–cạnh hoặc cạnh–góc xen giữa–cạnh.',[
 n=>q('Hai góc của tam giác là '+(40+n)+'° và 55°. Góc thứ ba bằng bao nhiêu độ?',85-n,'Lấy 180° trừ tổng hai góc đã biết.','Tổng ba góc trong tam giác bằng 180°.'),
 n=>q('Tam giác cân có góc ở đỉnh '+(40+2*n)+'°. Mỗi góc ở đáy bằng bao nhiêu độ?',70-n,'Hai góc đáy bằng nhau, nên lấy 180° trừ góc đỉnh rồi chia 2.','Hai góc ở đáy bằng nhau.'),
 ()=>choice('Giao điểm ba đường trung tuyến là gì?','Trọng tâm',['Trực tâm','Tâm đường tròn nội tiếp','Tâm đường tròn ngoại tiếp'],'Ba đường trung tuyến đồng quy tại trọng tâm.','Trung tuyến đi từ đỉnh đến trung điểm cạnh đối diện.')]);
lesson(7,'triangle-relations',G,'Quan hệ cạnh và góc trong tam giác','Cạnh lớn hơn đối diện góc lớn hơn. Tổng hai cạnh của tam giác luôn lớn hơn cạnh còn lại.',[
 n=>choice('Bộ nào có thể là độ dài ba cạnh tam giác?',rows([n+2,n+3,n+4]),[rows([2,3,5]),rows([2,3,6]),rows([1,3,6])],'Chỉ bộ đúng có tổng hai cạnh ngắn nhất lớn hơn cạnh dài nhất.','Kiểm tra tổng hai cạnh nhỏ.'),
 n=>q('Tam giác có AB = '+(n+4)+' cm, AC = '+(n+1)+' cm, BC = '+(n+2)+' cm. Cạnh đối diện góc lớn nhất dài bao nhiêu cm?',n+4,'Cạnh dài nhất đối diện góc lớn nhất.','So sánh ba độ dài.'),
 ()=>choice('Trong tam giác ABC, nếu AB > AC thì kết luận nào đúng?','Góc C lớn hơn góc B',['Góc B lớn hơn góc C','Góc B bằng góc C','Góc A bằng góc C'],'AB đối diện góc C và AC đối diện góc B.','Xác định góc đối diện từng cạnh.')]);
lesson(7,'solids',G,'Hình hộp chữ nhật và lăng trụ đứng','Thể tích lăng trụ đứng bằng diện tích đáy nhân chiều cao. Diện tích xung quanh bằng chu vi đáy nhân chiều cao.',[
 n=>q('Lăng trụ đứng có diện tích đáy '+(n+7)+' cm², cao 4 cm. Tính thể tích (cm³).',4*(n+7),'Nhân diện tích đáy với chiều cao.','Dùng V = S đáy × h.'),
 n=>q('Lăng trụ đứng có chu vi đáy '+(n+8)+' cm và cao 5 cm. Tính diện tích xung quanh (cm²).',5*(n+8),'Lấy chu vi đáy nhân chiều cao.','Mặt bên trải ra có chiều rộng bằng chu vi đáy.'),
 n=>q('Hình hộp chữ nhật kích thước '+n+' × 3 × 4 cm có thể tích bao nhiêu cm³?',12*n,'Diện tích đáy là '+n+' × 3. Nhân thêm chiều cao 4.','Nhân ba kích thước.')]);
lesson(7,'charts',D,'Biểu đồ quạt tròn và biểu đồ đoạn thẳng','Tỉ lệ trong biểu đồ quạt tròn được biểu diễn bằng góc ở tâm. Biểu đồ đoạn thẳng thể hiện sự thay đổi theo thời gian.',[
 n=>q('Một nhóm chiếm 25% tổng số. Góc ở tâm của hình quạt biểu diễn nhóm đó bằng bao nhiêu độ?',90,'Lấy 360° × 25% = 90°.','Toàn bộ hình tròn là 360°.'),
 n=>q('Dãy giá trị theo ba ngày là '+rows([n,n+6,n+2])+'. Ngày thứ hai tăng bao nhiêu so với ngày đầu?',6,'Lấy ngày 2 trừ ngày 1.','Chọn hai điểm theo đúng thứ tự.'),
 n=>q('Lớp có '+10*n+' học sinh. Tính số học sinh tương ứng với 30% của lớp.',3*n,'Nhân tổng số với 30/100.','Đổi phần trăm sang phân số.')]);
lesson(7,'events',D,'Biến cố và xác suất trong phép thử đơn giản','Biến cố chắc chắn có xác suất 1; biến cố không thể có xác suất 0. Với các kết quả đồng khả năng, đếm số kết quả thuận lợi và số kết quả có thể.',[
 ()=>q('Gieo một xúc xắc cân đối. Xác suất ra số chẵn là bao nhiêu?',f(1,2),'Có 3 mặt chẵn trong 6 mặt nên xác suất là 3/6.','Liệt kê các mặt chẵn.'),
 ()=>q('Gieo một xúc xắc 6 mặt. Xác suất ra mặt 7 chấm là bao nhiêu?',0,'Không có mặt 7 chấm. Đây là biến cố không thể.','Kiểm tra kết quả có thể xuất hiện không.'),
 ()=>q('Gieo một xúc xắc 6 mặt. Xác suất ra số nhỏ hơn 7 bằng bao nhiêu?',1,'Mọi mặt đều có số chấm từ 1 đến 6.','Đây là biến cố chắc chắn.')]);
lesson(8,'multivariate',A,'Đơn thức và đa thức nhiều biến','Bậc của đơn thức bằng tổng các số mũ. Khi nhân đơn thức, nhân hệ số và cộng số mũ của từng biến.',[
 n=>q('Bậc của 3x^'+n+'y² là bao nhiêu?',n+2,'Cộng số mũ của x và y: '+n+' + 2.','Hệ số 3 không ảnh hưởng bậc.'),
 n=>q('Tính giá trị của xy + 2x tại x = '+n+', y = 3.',5*n,'Thế giá trị vào, được '+n+' × 3 + 2 × '+n+'.','Thay cả hai biến.'),
 n=>q('Tìm hệ số của x²y trong '+n+'x²y + 3x²y.',n+3,'Hai đơn thức đồng dạng, cộng hệ số.','Giữ nguyên phần biến.')]);
lesson(8,'identities',A,'Hằng đẳng thức và phân tích đa thức','(a + b)² = a² + 2ab + b². a² − b² = (a − b)(a + b). Phân tích đa thức thường bắt đầu bằng việc tìm nhân tử chung.',[
 n=>q('Hệ số của x khi khai triển (x + '+n+')² là bao nhiêu?',2*n,'Hạng tử giữa là 2 × x × '+n+'.','Nhớ hạng tử 2ab.'),
 n=>choice('Phân tích x² − '+n*n+' thành nhân tử.','(x − '+n+')(x + '+n+')',['(x − '+n+')²','(x + '+n+')²','x(x − '+n+')'],'Nhận ra hiệu hai bình phương: x² − '+n+'².','Dùng a² − b².'),
 n=>q('Tính nhanh '+(n+1)+'² − '+n+'².',2*n+1,'Hiệu hai bình phương bằng tích của hiệu 1 và tổng '+(2*n+1)+'.','Hai số hơn kém nhau 1.')]);
lesson(8,'rational-expressions',A,'Phân thức đại số','Phân thức có nghĩa khi mẫu khác 0. Chỉ rút gọn nhân tử chung; điều kiện xác định của biểu thức ban đầu vẫn cần được giữ.',[
 n=>q('Giá trị nào làm phân thức 1/(x − '+n+') không xác định?',n,'Mẫu x − '+n+' bằng 0 khi x = '+n+'.','Giải phương trình mẫu bằng 0.'),
 n=>q('Với x khác 0, tính '+n+'x/(2x).',f(n,2),'Rút gọn nhân tử x vì x khác 0.','Không bỏ điều kiện x khác 0.'),
 n=>choice('Rút gọn (x² − '+n*n+')/(x − '+n+'), với x khác '+n+'.','x + '+n,['x − '+n,'x² + '+n,'x'],'Phân tích tử thành (x − '+n+')(x + '+n+') rồi rút gọn.','Tử là hiệu hai bình phương.')]);
lesson(8,'linear-equation',A,'Phương trình bậc nhất một ẩn','Với ax + b = 0, a khác 0, chuyển b sang vế phải rồi chia cả hai vế cho a.',[
 n=>q('Giải 3x + 2 = '+(3*n+2)+'. Nhập x.',n,'Trừ hai vế cho 2, rồi chia hai vế cho 3.','Đưa 3x đứng riêng.'),
 n=>q('Giải 2(x − 1) = '+2*n+'. Nhập x.',n+1,'Chia hai vế cho 2, rồi cộng 1.','Có thể chia trước khi bỏ ngoặc.'),
 n=>q('Hai số liên tiếp có tổng '+(2*n+1)+'. Số nhỏ hơn là bao nhiêu?',n,'Gọi số nhỏ là x. Ta có x + (x + 1) = '+(2*n+1)+'.','Số lớn hơn số nhỏ đúng 1.')]);
lesson(8,'graph',A,'Hàm số bậc nhất và đồ thị','Đồ thị y = ax + b đi qua (0; b). Với a dương hàm số đồng biến; với a âm hàm số nghịch biến.',[
 n=>q('Cho y = 2x − 1. Tại x = '+n+', y bằng bao nhiêu?',2*n-1,'Thay x vào biểu thức y = 2x − 1.','Tính 2x trước.'),
 n=>q('Đường thẳng y = 3x '+signs(n-7)+' cắt trục tung tại tung độ nào?',n-7,'Tại trục tung x = 0, nên y = '+(n-7)+'.','Cho x = 0.'),
 n=>q('Hệ số góc của đường thẳng y = −'+n+'x + 5 là bao nhiêu?',-n,'Hệ số góc là hệ số của x.','Đọc cả dấu âm.')]);
lesson(8,'quadrilaterals',G,'Tứ giác và các hình đặc biệt','Tổng các góc trong một tứ giác bằng 360°. Hai đường chéo của hình bình hành cắt nhau tại trung điểm mỗi đường.',[
 n=>q('Ba góc của tứ giác là 90°, 80° và '+(90+n)+'°. Góc còn lại bằng bao nhiêu độ?',100-n,'Tổng bốn góc là 360°. Trừ tổng ba góc đã biết.','Cộng ba số đã cho.'),
 n=>q('Hai đường chéo hình bình hành ABCD gặp nhau tại O. AC = '+2*n+' cm. Tính AO (cm).',n,'O là trung điểm AC, nên AO = AC/2.','Dùng tính chất đường chéo.'),
 ()=>choice('Hình bình hành có một góc vuông là hình gì?','Hình chữ nhật',['Hình thoi bất kỳ','Hình thang cân bất kỳ','Tam giác vuông'],'Góc kề bù và góc đối bằng nhau, nên cả bốn góc đều vuông.','Dùng tính chất góc của hình bình hành.')]);
lesson(8,'thales',G,'Định lí Thalès, đường trung bình và phân giác','Đường song song với một cạnh tam giác chia hai cạnh còn lại theo cùng tỉ số. Đường phân giác chia cạnh đối diện theo tỉ số hai cạnh kề.',[
 n=>q('Trong tam giác ABC, M ∈ AB, N ∈ AC, MN song song BC. AM/AB = 1/2, AC = '+2*n+' cm. Tính AN (cm).',n,'Theo Thalès, AN/AC = AM/AB = 1/2.','Dùng tỉ số trên hai cạnh.'),
 n=>q('Đường trung bình của tam giác song song với cạnh dài '+2*n+' cm có độ dài bao nhiêu cm?',n,'Đường trung bình bằng nửa cạnh song song với nó.','Chia cạnh tương ứng cho 2.'),
 n=>q('Trong tam giác ABC, phân giác AD cắt BC tại D. AB/AC = 2/3, DC = '+3*n+' cm. Tính BD (cm).',2*n,'BD/DC = AB/AC = 2/3. Lấy DC nhân 2/3.','Dùng tỉ số hai cạnh kề góc A.')]);
lesson(8,'pythagoras',G,'Định lí Pythagore','Trong tam giác vuông có hai cạnh góc vuông a, b và cạnh huyền c, ta có a² + b² = c².',[
 n=>q('Tam giác vuông có hai cạnh góc vuông '+3*n+' cm và '+4*n+' cm. Tính cạnh huyền (cm).',5*n,'Bộ 3–4–5 nhân cùng hệ số '+n+' vẫn thỏa Pythagore.','Căn bậc hai của tổng hai bình phương.'),
 n=>q('Tam giác vuông có cạnh huyền '+5*n+' cm và một cạnh góc vuông '+3*n+' cm. Tính cạnh còn lại (cm).',4*n,'Lấy bình phương cạnh huyền trừ bình phương cạnh đã biết rồi khai căn.','Dùng c² − a².'),
 ()=>choice('Tam giác nào vuông?','6; 8; 10',['3; 4; 6','5; 5; 6','4; 6; 7'],'6² + 8² = 100 = 10².','Kiểm tra cạnh dài nhất làm cạnh huyền.')]);
lesson(8,'similarity',G,'Tam giác đồng dạng','Các góc tương ứng bằng nhau, các cạnh tương ứng tỉ lệ. Nếu tỉ số đồng dạng là k thì tỉ số diện tích là k².',[
 n=>q('Hai tam giác đồng dạng. Một cạnh của tam giác nhỏ dài '+n+' cm, cạnh tương ứng gấp 3 lần. Tính cạnh của tam giác lớn (cm).',3*n,'Nhân độ dài tương ứng với 3.','Dùng tỉ số cạnh tương ứng.'),
 n=>q('Hai tam giác đồng dạng có tỉ số cạnh lớn/nhỏ bằng 2. Diện tích tam giác nhỏ là '+n+' cm². Tính diện tích tam giác lớn (cm²).',4*n,'Diện tích tăng theo bình phương tỉ số cạnh: 2² = 4.','Tỉ số diện tích khác tỉ số cạnh.'),
 ()=>choice('Điều kiện nào đủ để hai tam giác đồng dạng?','Hai góc tương ứng bằng nhau',['Một cạnh bằng nhau','Hai chu vi bằng nhau','Một góc bằng nhau'],'Hai góc tương ứng bằng nhau thì góc thứ ba cũng bằng nhau.','Nhớ trường hợp góc–góc.')]);
lesson(8,'pyramid',G,'Hình chóp tam giác đều và tứ giác đều','Thể tích hình chóp bằng một phần ba diện tích đáy nhân chiều cao. Diện tích xung quanh của hình chóp đều bằng nửa chu vi đáy nhân trung đoạn.',[
 n=>q('Hình chóp có diện tích đáy '+3*n+' cm², cao 5 cm. Tính thể tích (cm³).',5*n,'V = '+3*n+' × 5 / 3.','Nhân đáy với chiều cao rồi chia 3.'),
 n=>q('Hình chóp đều có chu vi đáy '+4*n+' cm, trung đoạn 3 cm. Tính diện tích xung quanh (cm²).',6*n,'Lấy nửa chu vi đáy là '+2*n+' rồi nhân 3.','Dùng nửa chu vi đáy.'),
 n=>q('Hình chóp tứ giác đều có cạnh đáy '+n+' cm và chiều cao 3 cm. Tính thể tích (cm³).',n*n,'Đáy là hình vuông diện tích '+n*n+'; nhân 3 rồi chia 3.','Tính diện tích đáy trước.')]);
lesson(8,'data-methods',D,'Thu thập, phân loại và biểu diễn dữ liệu','Phân biệt dữ liệu định tính và định lượng. Chọn biểu đồ phù hợp với mục đích so sánh, cơ cấu hoặc theo dõi biến động.',[
 ()=>choice('Dữ liệu nào là định lượng?','Chiều cao của học sinh',['Môn thể thao yêu thích','Màu áo','Tên lớp'],'Chiều cao được đo và biểu diễn bằng số.','Tìm dữ liệu có thể đo bằng số.'),
 ()=>choice('Biểu đồ nào phù hợp để theo dõi nhiệt độ qua các ngày?','Biểu đồ đoạn thẳng',['Biểu đồ quạt tròn','Sơ đồ cây','Trục đối xứng'],'Đường nối các điểm cho thấy xu hướng thay đổi theo thời gian.','Tìm biểu đồ thể hiện xu hướng.'),
 n=>q('Hai nhóm có '+n+' và '+3*n+' người. Nhóm thứ nhất chiếm bao nhiêu phần trăm?',25,'Tổng là '+4*n+'. Nhóm 1 chiếm 1/4.','Chia cho tổng của hai nhóm.')]);
lesson(8,'experimental',D,'Xác suất thực nghiệm và xác suất lí thuyết','Xác suất thực nghiệm lấy từ kết quả đã quan sát. Xác suất lí thuyết dùng mô hình phép thử; hai giá trị có thể khác nhau trong một số lượt thử hữu hạn.',[
 n=>q('Trong '+10*n+' lượt tung xu, có '+6*n+' lượt ngửa. Tìm xác suất thực nghiệm mặt ngửa.',f(3,5),'Tỉ số '+6*n+'/'+10*n+' rút gọn thành 3/5.','Dùng số lần thực hiện thực tế.'),
 ()=>q('Xác suất lí thuyết ra mặt ngửa của đồng xu cân đối là bao nhiêu?',f(1,2),'Hai kết quả đồng khả năng và có một kết quả thuận lợi.','Mô hình có hai mặt.'),
 ()=>choice('Khi tăng số lần thử, tần suất thực nghiệm thường có xu hướng nào?','Gần xác suất lí thuyết hơn',['Luôn bằng 1','Luôn bằng 0','Luôn đúng bằng xác suất lí thuyết ở mọi lượt'],'Nhiều lần thử làm tần suất thực nghiệm thường ổn định hơn.','Phân biệt xu hướng với bảo đảm tuyệt đối.')]);

lesson(9,'systems',A,'Phương trình và hệ bậc nhất hai ẩn','Có thể dùng thế hoặc cộng đại số. Khi tìm được một ẩn, thay lại để tìm ẩn còn lại và kiểm tra cả hai phương trình.',[
 n=>q('Cho hệ x + y = '+(n+4)+'; x − y = '+(n-4)+'. Tìm x.',n,'Cộng hai phương trình được 2x = '+2*n+'.','Cộng hai vế để khử y.'),
 n=>q('Cho hệ x = y + 2; x + y = '+(2*n+2)+'. Tìm y.',n,'Thế x = y + 2 vào phương trình tổng, được 2y + 2 = '+(2*n+2)+'.','Dùng phương pháp thế.'),
 n=>q('Cho 2x + 3y = '+(2*n+6)+' và y = 2. Tìm x.',n,'Thay y = 2, được 2x = '+2*n+'.','Tính 3y trước.')]);
lesson(9,'inequalities',A,'Bất đẳng thức, bất phương trình và phương trình quy về bậc nhất','Đổi chiều bất phương trình khi nhân hoặc chia hai vế cho số âm. Với phương trình chứa mẫu, kiểm tra điều kiện xác định trước khi nhận nghiệm.',[
 n=>choice('Giải −2x > −'+2*n+'.','x < '+n,['x > '+n,'x ≤ '+n,'x ≥ '+n],'Chia hai vế cho −2 nên phải đổi chiều.','Chú ý hệ số âm.'),
 n=>q('Giải x/'+n+' = 3. Nhập x.',3*n,'Nhân cả hai vế với '+n+'.','Mẫu là hằng số khác 0.'),
 n=>choice('Giải (x − '+n+')(x + 1) = 0.','x = '+n+' hoặc x = −1',['Chỉ x = '+n,'Chỉ x = 1','Vô nghiệm'],'Tích bằng 0 khi ít nhất một nhân tử bằng 0.','Giải riêng từng nhân tử.')]);
lesson(9,'radicals',A,'Căn bậc hai, căn bậc ba và biến đổi căn thức','√(a²) = |a| với mọi số thực a. Căn bậc ba của số âm là số âm; điều kiện của căn bậc hai là biểu thức dưới căn không âm.',[
 n=>q('Tính √(('+(-n)+')²).',n,'Căn bậc hai số học của bình phương bằng giá trị tuyệt đối.','Kết quả căn bậc hai số học không âm.'),
 n=>q('Tính ∛(−'+n**3+').',-n,'Vì (−'+n+')³ = −'+n**3+'.','Căn bậc ba giữ dấu.'),
 n=>q('Tìm giá trị nhỏ nhất của x để √(x − '+n+') có nghĩa.',n,'Điều kiện x − '+n+' ≥ 0, tức x ≥ '+n+'.','Biểu thức dưới căn không âm.')]);
lesson(9,'parabola',A,'Hàm số y = ax² và đồ thị parabol','Đồ thị y = ax² với a khác 0 nhận trục tung làm trục đối xứng. Khi a dương, parabol mở lên; khi a âm, parabol mở xuống.',[
 n=>q('Cho y = 2x². Tính y tại x = −'+n+'.',2*n*n,'Bình phương số âm cho số dương: y = 2 × '+n*n+'.','Bình phương trước khi nhân 2.'),
 n=>q('Đồ thị y = ax² đi qua điểm (2; '+4*n+'). Tìm a.',n,'Thay x = 2, y = '+4*n+'. Ta có 4a = '+4*n+'.','Thế tọa độ điểm vào phương trình.'),
 ()=>choice('Trục đối xứng của y = −3x² là gì?','Trục tung',['Trục hoành','Đường y = x','Đường x = 1'],'y có cùng giá trị tại x và −x.','Xét hai điểm có hoành độ đối nhau.')]);
lesson(9,'quadratic',A,'Phương trình bậc hai và hệ thức Viète','Với ax² + bx + c = 0, a khác 0, xét Δ = b² − 4ac. Khi có hai nghiệm, tổng bằng −b/a và tích bằng c/a.',[
 n=>q('Tổng hai nghiệm của x² − '+(n+1)+'x + '+n+' = 0 bằng bao nhiêu?',n+1,'Theo Viète, x₁ + x₂ = −b/a = '+(n+1)+'.','Chú ý dấu của b.'),
 n=>q('Tích hai nghiệm của x² − '+(n+1)+'x + '+n+' = 0 bằng bao nhiêu?',n,'Theo Viète, x₁x₂ = c/a = '+n+'.','Đọc hệ số tự do.'),
 n=>q('Tính Δ của x² − '+2*n+'x + '+n*n+' = 0.',0,'Δ = ('+(-2*n)+')² − 4 × '+n*n+' = 0. Phương trình có nghiệm kép.','Bình phương b rồi trừ 4ac.')]);
lesson(9,'trigonometry',G,'Tỉ số lượng giác trong tam giác vuông','Với một góc nhọn, sin = đối/huyền, cos = kề/huyền, tan = đối/kề. Xác định cạnh đối và cạnh kề theo góc đang xét.',[
 n=>q('Trong tam giác vuông, cạnh đối góc α dài '+3*n+' và cạnh huyền dài '+5*n+'. Tìm sin α.',f(3,5),'sin α = đối/huyền = 3/5.','Xác định cạnh đối.'),
 n=>q('Cạnh kề góc α dài '+4*n+' và cạnh huyền dài '+5*n+'. Tìm cos α.',f(4,5),'cos α = kề/huyền = 4/5.','Cạnh kề ở đây không phải cạnh huyền.'),
 n=>q('Cạnh đối góc α dài '+3*n+' và cạnh kề dài '+4*n+'. Tìm tan α.',f(3,4),'tan α bằng cạnh đối chia cạnh kề.','Tangent không dùng cạnh huyền.')]);
lesson(9,'circles',G,'Đường tròn, tiếp tuyến, dây và cung','Tiếp tuyến vuông góc với bán kính tại tiếp điểm. Hai tiếp tuyến kẻ từ cùng một điểm ngoài đường tròn có độ dài bằng nhau.',[
 n=>q('PA và PB là hai tiếp tuyến từ P. PA = '+n+' cm. Tính PB (cm).',n,'Hai đoạn tiếp tuyến xuất phát từ cùng điểm P bằng nhau.','Áp dụng tính chất hai tiếp tuyến cắt nhau.'),
 n=>q('Đường tròn có bán kính '+n+' cm. Đường kính dài bao nhiêu cm?',2*n,'Đường kính bằng hai lần bán kính.','D = 2R.'),
 ()=>q('Góc tạo bởi tiếp tuyến và bán kính tại tiếp điểm bằng bao nhiêu độ?',90,'Bán kính qua tiếp điểm vuông góc tiếp tuyến.','Nhớ dấu hiệu nhận biết tiếp tuyến.')]);
lesson(9,'inscribed',G,'Góc nội tiếp và tứ giác nội tiếp','Góc nội tiếp bằng nửa số đo cung bị chắn. Hai góc đối của tứ giác nội tiếp có tổng bằng 180°.',[
 n=>q('Góc nội tiếp chắn cung có số đo '+(80+2*n)+'°. Góc đó bằng bao nhiêu độ?',40+n,'Lấy nửa số đo cung bị chắn.','Chia số đo cung cho 2.'),
 n=>q('Tứ giác ABCD nội tiếp. Góc A bằng '+(70+n)+'°. Góc C bằng bao nhiêu độ?',110-n,'Hai góc đối bù nhau, nên C = 180° − A.','A đối diện C.'),
 ()=>q('Góc nội tiếp chắn đường kính bằng bao nhiêu độ?',90,'Đường kính chắn nửa đường tròn, cung 180° nên góc bằng 90°.','Một nửa của 180°.')]);
lesson(9,'circular-measures',G,'Độ dài cung, hình quạt và đa giác đều','Cung n độ có độ dài πRn/180. Diện tích quạt n độ bằng πR²n/360. Các góc ở tâm giữa hai đỉnh liên tiếp của đa giác đều bằng nhau.',[
 n=>q('Tính độ dài cung 90° của đường tròn bán kính '+2*n+' cm. Nhập theo π, ví dụ 2π.',pi(n),'Một phần tư chu vi bằng (2π × '+2*n+')/4 = '+pi(n)+'.','90° chiếm 1/4 vòng tròn.'),
 n=>q('Tính diện tích hình quạt 90° bán kính '+2*n+' cm. Nhập theo π.',pi(n*n),'Một phần tư diện tích hình tròn: π × '+(4*n*n)+'/4.','Chia diện tích toàn hình tròn cho 4.'),
 n=>q('Đa giác đều có '+(n+3)+' cạnh. Tính góc ở tâm giữa hai đỉnh liên tiếp (độ), có thể nhập phân số.',f(360,n+3),'Chia 360° thành '+(n+3)+' góc bằng nhau.','Dùng 360° chia số cạnh.')]);
lesson(9,'space',G,'Hình trụ, hình nón và hình cầu','V hình trụ = πr²h. V hình nón = πr²h/3. V hình cầu = 4πr³/3.',[
 n=>q('Hình trụ bán kính đáy '+n+' cm, cao 2 cm. Nhập thể tích theo π.',pi(2*n*n),'V = π × '+n*n+' × 2.','Tính diện tích đáy tròn trước.'),
 n=>q('Hình nón bán kính đáy '+n+' cm, cao 3 cm. Nhập thể tích theo π.',pi(n*n),'V = π × '+n*n+' × 3 / 3.','Hình nón có hệ số 1/3.'),
 n=>q('Hình cầu bán kính '+3*n+' cm. Nhập thể tích theo π.',pi(36*n**3),'Thay r = '+3*n+' vào V = 4πr³/3.','Lũy thừa bậc ba của bán kính.')]);
lesson(9,'frequency',D,'Bảng tần số, tần số tương đối và dữ liệu ghép nhóm','Tần số là số lần xuất hiện; tần số tương đối bằng tần số chia tổng số quan sát. Khi ghép nhóm, mỗi giá trị thuộc đúng một nhóm.',[
 n=>q('Một nhóm có '+3*n+' kết quả trong '+10*n+' quan sát. Tần số tương đối của nhóm bằng bao nhiêu phần trăm?',30,'Lấy '+3*n+'/'+10*n+' = 0,3 = 30%.','Chia tần số cho tổng quan sát.'),
 n=>q('Bảng có ba nhóm với tần số '+rows([n,n+2,n+3])+'. Tổng số quan sát là bao nhiêu?',3*n+5,'Cộng tần số của tất cả nhóm.','Mỗi quan sát được đếm một lần.'),
 ()=>choice('Giá trị 10 thuộc nhóm nào khi các nhóm là [0; 10), [10; 20), [20; 30)?','[10; 20)',['[0; 10)','[20; 30)','Cả hai nhóm đầu'],'Dấu [ lấy đầu mút trái; dấu ) bỏ đầu mút phải.','Xem đầu mút được lấy hay bị loại.')]);
lesson(9,'sample-space',D,'Không gian mẫu và xác suất','Không gian mẫu gồm tất cả kết quả có thể. Với các kết quả đồng khả năng, P(A) = số kết quả thuận lợi / tổng số kết quả.',[
 n=>q('Hộp có '+n+' bi đỏ và '+2*n+' bi xanh giống nhau về kích thước, lấy ngẫu nhiên một bi. Tìm xác suất lấy bi đỏ.',f(1,3),'Có '+n+' kết quả thuận lợi trong '+3*n+' kết quả đồng khả năng.','Đếm bi đỏ và tổng số bi.'),
 ()=>q('Tung hai đồng xu cân đối độc lập. Xác suất có đúng một mặt ngửa bằng bao nhiêu?',f(1,2),'Có 4 kết quả đồng khả năng; ngửa–sấp và sấp–ngửa là hai kết quả thuận lợi.','Liệt kê theo thứ tự đồng xu thứ nhất và thứ hai.'),
 ()=>q('Gieo hai xúc xắc cân đối độc lập. Có bao nhiêu kết quả phân biệt theo thứ tự?',36,'Mỗi trong 6 kết quả của xúc xắc thứ nhất kết hợp được với 6 kết quả của xúc xắc thứ hai.','Dùng quy tắc nhân.')]);

const content=topics.map(topic=>({...topic,examples:topic.examples.map((make,i)=>make(3+i))}));
if (typeof module!=='undefined') module.exports={topics,content};
