const mathLabs = (() => {
  const byGrade = { 6: 'fractions', 7: 'events', 8: 'pythagoras', 9: 'parabola' };
  const vi = value => new Intl.NumberFormat('vi-VN', { maximumFractionDigits: 2 }).format(value);
  const slider = (label, name, min, max, value) => `<label class="lab-control">${label}<input type="range" name="${name}" min="${min}" max="${max}" value="${value}"></label>`;
  const labs = {
    fractions: {
      title: 'Ghép hai phần bằng nhau',
      challenge: 'Giữ thanh thứ nhất ở 1/2. Đổi tử và mẫu của thanh thứ hai để phần tô màu có cùng độ dài, với mẫu lớn hơn 2.',
      controls: slider('Tử số', 'numerator', 0, 4, 1) + slider('Mẫu số', 'denominator', 2, 12, 4),
      visual: '<div class="fraction-row"><span>1/2</span><div id="fraction-reference" class="fraction-bar" aria-label="Một phần hai"></div></div><div class="fraction-row"><span id="fraction-value"></span><div id="fraction-variable" class="fraction-bar"></div></div>',
      bind(root, status) {
        const numerator = root.querySelector('[name=numerator]');
        const denominator = root.querySelector('[name=denominator]');
        function bar(target, n, d) {
          target.style.gridTemplateColumns = `repeat(${d}, minmax(0, 1fr))`;
          target.setAttribute('role', 'img');
          target.setAttribute('aria-label', `Tô ${n} trong ${d} phần`);
          target.innerHTML = Array.from({ length:d }, (_, index) => `<span aria-hidden="true"${index < n ? ' class="filled"' : ''}></span>`).join('');
        }
        function update() {
          const d = Number(denominator.value);
          numerator.max = d;
          const n = Number(numerator.value);
          root.querySelector('#fraction-value').textContent = n + '/' + d;
          bar(root.querySelector('#fraction-variable'), n, d);
          status.textContent = 2*n === d && d > 2
            ? `Đúng rồi. ${n}/${d} = 1/2 vì hai thanh được tô cùng một độ dài.`
            : `Đang tô ${n} trong ${d} phần. Thử để số phần được tô bằng nửa số phần của cả thanh.`;
        }
        bar(root.querySelector('#fraction-reference'), 1, 2);
        root.addEventListener('input', update);
        update();
      }
    },
    events: {
      title: 'Thử tung đồng xu',
      challenge: 'Đoán xem tỉ lệ mặt ngửa có bằng 50% sau đúng 10 lần tung không. Sau đó thử thêm 100 lần và so sánh.',
      controls: '<div class="actions"><button type="button" class="button primary" data-toss="10">Tung 10 lần</button><button type="button" class="button secondary" data-toss="100">Tung 100 lần</button><button type="button" class="button secondary" data-reset>Tung lại từ đầu</button></div>',
      visual: '<div class="coin-bars"><div><span>Mặt ngửa <strong id="heads-count">0</strong></span><progress id="heads" aria-label="Tỉ lệ mặt ngửa" value="0" max="100"></progress></div><div><span>Mặt sấp <strong id="tails-count">0</strong></span><progress id="tails" aria-label="Tỉ lệ mặt sấp" value="0" max="100"></progress></div></div>',
      bind(root, status) {
        let total = 0, heads = 0;
        root.addEventListener('click', event => {
          const button = event.target.closest('button');
          if (!button) return;
          if (button.hasAttribute('data-reset')) { total=0; heads=0; }
          else if (button.dataset.toss) {
            const n = Number(button.dataset.toss);
            for (let i=0; i<n; i++) if (Math.random()<0.5) heads++;
            total+=n;
          } else return;
          const percent = total ? heads*100/total : 0;
          root.querySelector('#heads').value = percent;
          root.querySelector('#tails').value = total ? 100-percent : 0;
          root.querySelector('#heads-count').textContent = heads;
          root.querySelector('#tails-count').textContent = total-heads;
          status.textContent = total
            ? `${total} lượt · Tỉ lệ ngửa: ${vi(percent)}% · Xác suất lí thuyết: 50%. Tỉ lệ quan sát có thể khác 50%.`
            : 'Chưa tung lần nào.';
        });
        status.textContent = 'Chưa tung lần nào.';
      }
    },
    pythagoras: {
      title: 'Tìm cạnh huyền bằng 5',
      challenge: 'Đổi độ dài hai cạnh góc vuông để tìm tam giác có cạnh huyền đúng bằng 5.',
      controls: slider('Cạnh góc vuông a', 'a', 1, 8, 2) + slider('Cạnh góc vuông b', 'b', 1, 8, 4),
      visual: '<canvas width="500" height="245" role="img"></canvas>',
      bind(root, status) {
        const canvas = root.querySelector('canvas'), c = canvas.getContext('2d');
        function update() {
          const a = Number(root.querySelector('[name=a]').value);
          const b = Number(root.querySelector('[name=b]').value);
          const square = a*a+b*b;
          const hyp = Math.sqrt(square);
          c.clearRect(0,0,500,245);
          const scale = 18;
          c.fillStyle='#e9e0ff';c.strokeStyle='#5038a5';c.lineWidth=3;
          c.beginPath();c.moveTo(170,195);c.lineTo(170+a*scale,195);c.lineTo(170,195-b*scale);c.closePath();c.fill();c.stroke();
          c.strokeRect(170,182,13,13);
          c.font='bold 16px system-ui';c.fillStyle='#241b49';
          c.fillText('a = '+a,165+a*scale/2,220);c.fillText('b = '+b,112,195-b*scale/2);
          c.fillText('c ≈ '+vi(hyp),182+a*scale/2,175-b*scale/2);
          canvas.setAttribute('aria-label',`Tam giác vuông: a bằng ${a}, b bằng ${b}, c xấp xỉ ${vi(hyp)}`);
          status.textContent = `${a}² + ${b}² = ${square}. Cạnh huyền c = √${square}${square===25 ? ' = 5. Em đã tìm đúng!' : ' ≈ '+vi(hyp)+'.'}`;
        }
        root.addEventListener('input',update);update();
      }
    },
    parabola: {
      title: 'Đổi dấu hệ số, đổi hướng parabol',
      challenge: 'Dự đoán đồ thị mở về đâu khi a âm. Thử đổi từ a = 1 sang a = −1, rồi so sánh hai điểm có hoành độ x = 2.',
      controls: '<label class="lab-control">Hệ số a<select name="coefficient"><option value="-2">−2</option><option value="-1">−1</option><option value="-0.5">−0,5</option><option value="0.5">0,5</option><option value="1" selected>1</option><option value="2">2</option></select></label>',
      visual: '<canvas width="500" height="245" role="img"></canvas>',
      bind(root,status) {
        const canvas = root.querySelector('canvas'), c=canvas.getContext('2d');
        function update() {
          const a=Number(root.querySelector('select').value);
          c.clearRect(0,0,500,245);
          c.save();c.beginPath();c.rect(25,12,450,220);c.clip();
          c.translate(250,122);
          c.strokeStyle='#ded9ed';c.lineWidth=1;c.beginPath();
          for(let i=-10;i<=10;i++){const x=i*22;c.moveTo(x,-110);c.lineTo(x,110);}
          for(let i=-5;i<=5;i++){const y=i*22;c.moveTo(-225,y);c.lineTo(225,y);}
          c.stroke();c.strokeStyle='#6c638a';c.beginPath();c.moveTo(-225,0);c.lineTo(225,0);c.moveTo(0,-110);c.lineTo(0,110);c.stroke();
          c.fillStyle='#302454';c.font='14px system-ui';c.fillText('x',205,17);c.fillText('y',10,-95);
          c.strokeStyle='#5038a5';c.lineWidth=3;c.beginPath();
          for(let px=-224;px<=224;px++){const x=px/34, py=-a*x*x*10; if(px===-224)c.moveTo(px,py);else c.lineTo(px,py);}
          c.stroke();c.fillStyle='#15664c';c.beginPath();c.arc(68,-a*40,5,0,Math.PI*2);c.fill();
          c.restore();
          canvas.setAttribute('aria-label',`Parabol y = ${vi(a)}x bình phương, mở ${a>0?'lên':'xuống'}`);
          status.textContent=`a = ${vi(a)} · Đồ thị mở ${a>0?'lên':'xuống'} · Khi x = 2, y = ${vi(4*a)}.`;
        }
        root.addEventListener('change',update);update();
      }
    }
  };
  function markup(id) {
    const lab = labs[id];
    return lab ? `<section class="panel math-lab" id="kham-pha" data-lab="${id}" aria-labelledby="lab-title"><p class="eyebrow">Thử một thao tác</p><h2 id="lab-title">${lab.title}</h2><p class="lab-challenge">${lab.challenge}</p><div class="lab-visual">${lab.visual}</div><div class="lab-controls">${lab.controls}</div><p class="lab-status" aria-live="polite"></p></section>` : '';
  }
  function attach() {
    const root = document.querySelector('[data-lab]');
    if (root) labs[root.dataset.lab].bind(root,root.querySelector('.lab-status'));
  }
  return { byGrade, markup, attach };
})();
