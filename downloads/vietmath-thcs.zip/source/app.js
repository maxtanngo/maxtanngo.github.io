(() => {
'use strict';
const grades=[6,7,8,9];
const strands=[A,G,D];
const main=document.getElementById('main');
const gradeInput=document.getElementById('grade');
const byId=new Map(topics.map(t=>[t.id,t]));
const key='vietmath-thcs-v1';
const empty=()=>({grade:6,attempts:[],mistakes:[]});
let data=empty();
let saveError=false;
const validQuestion=item=>item && byId.has(item.topic) && typeof item.prompt==='string' &&
 typeof item.answer==='string' && typeof item.solution==='string' && typeof item.hint==='string' &&
 (item.choices===undefined || Array.isArray(item.choices)&&item.choices.every(x=>typeof x==='string'));
try{
 const saved=JSON.parse(localStorage.getItem(key));
 if(saved && grades.includes(saved.grade) && Array.isArray(saved.attempts) && Array.isArray(saved.mistakes)){
   data={grade:saved.grade,
     attempts:saved.attempts.filter(a=>a&&grades.includes(a.grade)&&typeof a.title==='string'&&typeof a.at==='string'&&Number.isInteger(a.right)&&Number.isInteger(a.total)&&a.total>=a.right&&a.right>=0).slice(0,200),
     mistakes:saved.mistakes.filter(validQuestion).slice(0,300)};
 }
}catch{saveError=true;}
let active=null;
let topicFilter='';
let search='';
let clockId;
const routes=['lo-trinh','luyen-de','on-loi','tien-do','nguon'];
const e=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
const selectedTopics=()=>topics.filter(t=>t.grade===data.grade);
const recent=()=>data.attempts.filter(a=>a.grade===data.grade);
const trained=t=>data.attempts.some(a=>a.topic===t.id&&a.mode==='practice'&&a.total===3&&a.right>=2);
const mistakes=()=>data.mistakes.filter(m=>byId.get(m.topic).grade===data.grade);
const currentRoute=()=>location.hash.slice(1)||'lo-trinh';
const title=(name,description)=>`<header class="page-title"><h1>${e(name)}</h1><p>${e(description)}</p></header>`;
const button=(name,action,value='',primary=true)=>`<button type="button" class="button ${primary?'primary':'secondary'}" data-action="${action}" data-value="${e(value)}">${e(name)}</button>`;
const link=(name,href,primary=true)=>`<a class="button ${primary?'primary':'secondary'}" href="${e(href)}">${e(name)}</a>`;
function save(){
 try{localStorage.setItem(key,JSON.stringify(data));saveError=false;}
 catch{saveError=true;}
}
function page(html){
 main.innerHTML=(saveError?'<p class="panel form-error" role="alert">Trình duyệt chưa lưu được tiến độ.</p>':'')+html;
}
function normalize(s){
 return String(s).normalize('NFC').toLocaleLowerCase('vi').trim().replace(/[−–]/g,'-').replace(/\s+/g,'').replace(/\bpi\b/g,'π');
}
function number(s){
 const x=s.replace(',','.');
 if(/^[+-]?\d+(?:\.\d+)?$/.test(x))return Number(x);
 const m=x.match(/^([+-]?\d+)\/([+-]?\d+)$/);
 if(m&&Number(m[2])!==0)return Number(m[1])/Number(m[2]);
}
function same(input,expected){
 const x=normalize(input),y=normalize(expected);
 if(x===y)return true;
 const coef=s=>s.endsWith('π')?number(s.slice(0,-1).replace(/\*$/,'')||'1'):undefined;
 const a=x.endsWith('π')&&y.endsWith('π')?coef(x):number(x);
 const b=x.endsWith('π')&&y.endsWith('π')?coef(y):number(y);
 return Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<1e-9;
}
function random(max){return Math.floor(Math.random()*max);}
function shuffle(list){
 const result=[...list];
 for(let i=result.length-1;i>0;i--){const j=random(i+1);[result[i],result[j]]=[result[j],result[i]];}
 return result;
}
function makeQuestions(topic){
 return shuffle(topic.examples).map(make=>({ ...make(2+random(8)),topic:topic.id }));
}
function draw(){
 const canvas=document.querySelector('#plot');
 if(!canvas)return;
 const c=canvas.getContext('2d');
 c.save();c.translate(188,105);
 c.strokeStyle='#69588d';c.lineWidth=.7;
 for(let x=-168;x<=168;x+=21){c.beginPath();c.moveTo(x,-84);c.lineTo(x,84);c.stroke();}
 for(let y=-84;y<=84;y+=21){c.beginPath();c.moveTo(-168,y);c.lineTo(168,y);c.stroke();}
 c.strokeStyle='#d6cbee';c.lineWidth=1.15;
 c.beginPath();c.moveTo(-172,0);c.lineTo(175,0);c.moveTo(0,88);c.lineTo(0,-89);c.stroke();
 c.fillStyle='#e8dfff';c.font='13px system-ui';c.fillText('x',164,17);c.fillText('y',9,-81);
 if(data.grade<8){
   c.strokeStyle='#c8b5ff';c.lineWidth=3;c.beginPath();c.moveTo(-126,63);c.lineTo(126,63);c.lineTo(-126,-63);c.closePath();c.stroke();
   c.strokeRect(-126,49,14,14);
   c.fillText('A',-144,66);c.fillText('B',131,66);c.fillText('C',-145,-58);
 }else{
   c.strokeStyle='#c8b5ff';c.lineWidth=3;c.beginPath();
   for(let x=-144;x<=144;x++){
     const y=data.grade===9?-x*x/255:-x*.44-20;
     if(x===-144)c.moveTo(x,y);else c.lineTo(x,y);
   }
   c.stroke();c.fillText(data.grade===9?'y = x²':'y = ax + b',55,-69);
 }
 c.restore();
}
function renderTopicGrid(){
 const box=document.getElementById('topics');
 if(!box)return;
 const simplify=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').toLowerCase();
 const result=selectedTopics().filter(t=>(!topicFilter||topicFilter===t.strand)&&simplify(t.title).includes(simplify(search)));
 box.innerHTML=result.length?result.map(t=>`<article class="topic"><span class="tag">${e(t.strand)}</span><h3>${e(t.title)}</h3><small>${trained(t)?'Đã đạt mục tiêu luyện tập':'Lý thuyết và 3 dạng câu hỏi'}</small><div class="actions"><a class="text-link" href="#bai/${t.id}">Mở bài học →</a></div></article>`).join(''):'<p class="panel">Không tìm thấy chủ đề phù hợp.</p>';
}
function roadmap(){
 const list=selectedTopics(),next=list.find(t=>!trained(t))||list[0];
 const done=list.filter(trained).length;
 page(`<section class="hero"><div><p class="eyebrow">Toán cấp 2 · Lớp ${data.grade}</p><h1>VietMath THCS</h1><p>Học theo chủ đề, luyện từng kỹ năng và quay lại những câu em còn vướng.</p><div class="actions">${link(done?'Tiếp tục học →':'Học bài đầu tiên →','#bai/'+next.id)} ${link('Khám phá bằng hình','#bai/'+mathLabs.byGrade[data.grade],false)}</div></div><canvas id="plot" width="376" height="214" role="img" aria-label="${data.grade===9?'Đồ thị parabol':data.grade===8?'Đồ thị đường thẳng':'Hình tam giác vuông'}"></canvas></section>
 <section class="stats" aria-label="Tiến độ lớp ${data.grade}"><div class="stat"><strong>${done}/${list.length}</strong><span>Chủ đề đạt mục tiêu</span></div><div class="stat"><strong>${recent().length}</strong><span>Lượt đã làm</span></div><div class="stat"><strong>${mistakes().length}</strong><span>Câu cần ôn</span></div></section>
 <section aria-labelledby="topic-heading"><div class="section-head"><div><h2 id="topic-heading">Chủ đề lớp ${data.grade}</h2><p>Luyện đạt từ 2/3 câu đúng để đánh dấu một chủ đề.</p></div><div class="filters"><input type="search" id="search" aria-label="Tìm chủ đề" placeholder="Tìm chủ đề…" value="${e(search)}"><select id="strand" aria-label="Lọc theo mạch kiến thức"><option value="">Tất cả mạch</option>${strands.map(s=>`<option value="${e(s)}" ${s===topicFilter?'selected':''}>${e(s)}</option>`).join('')}</select></div></div><div class="grid" id="topics"></div></section>`);
 renderTopicGrid();draw();
}
function lessonView(id){
 const t=byId.get(id);
 if(!t||t.grade!==data.grade){roadmap();return;}
 const example=content.find(x=>x.id===id).examples[0];
 page(`<div class="reading"><a href="#lo-trinh" class="text-link">← Lộ trình lớp ${t.grade}</a><header class="page-title"><p class="eyebrow">${e(t.strand)}</p><h1>${e(t.title)}</h1></header><section class="panel"><h2>Kiến thức cần nhớ</h2><p class="formula">${e(t.rule)}</p></section>${mathLabs.markup(id)}<section class="panel"><h2>Ví dụ có lời giải</h2><p><strong>${e(example.prompt)}</strong></p><p>${e(example.solution)}</p><p>Đáp án: <strong>${e(example.answer)}</strong></p></section><div class="actions">${button('Luyện 3 câu','practice',id)} ${link('Chọn chủ đề khác','#lo-trinh',false)}</div></div>`);
 mathLabs.attach();
}
function examView(){
 page(title('Luyện đề lớp '+data.grade,'Chọn một bài luyện theo mạch hoặc làm đề tổng hợp có đồng hồ.')+`<div class="mode-grid">${strands.map(s=>`<article class="mode"><h2>${e(s)}</h2><p>6 câu luyện tập. Xem gợi ý và lời giải sau từng câu.</p>${button('Bắt đầu luyện','strand-exam',s)}</article>`).join('')}<article class="mode"><h2>${data.grade===9?'Ôn tổng hợp trước khi vào 10':'Đề tổng hợp'}</h2><p>12 câu trong 20 phút, đủ ba mạch. Xem lời giải sau khi nộp.</p>${button('Bắt đầu làm đề','exam')}</article></div>`);
}
function errorsView(){
 const list=mistakes();
 page(title('Ôn câu sai','Mỗi câu trả lời đúng khi ôn sẽ được gỡ khỏi danh sách cần ôn.')+
 (list.length?`<div class="panel">${button('Ôn '+Math.min(list.length,12)+' câu','review')}${list.slice(0,12).map(x=>`<div class="result-item"><span class="tag">${e(byId.get(x.topic).title)}</span><p>${e(x.prompt)}</p></div>`).join('')}</div>`:'<div class="panel"><p>Chưa có câu cần ôn ở lớp này.</p><div class="actions">'+link('Chọn bài để học','#lo-trinh')+'</div></div>'));
}
function progressView(){
 const list=recent();
 const stats=strands.map(s=>{const entries=list.flatMap(x=>x.strands?.[s]?[x.strands[s]]:[]);return {s,right:entries.reduce((a,x)=>a+x.right,0),total:entries.reduce((a,x)=>a+x.total,0)};});
 page(title('Tiến độ lớp '+data.grade,'Kết quả các lượt đã nộp trên trình duyệt này.')+`<div class="stats">${stats.map(x=>`<div class="stat"><strong>${x.total?x.right+'/'+x.total:'—'}</strong><span>${e(x.s)}</span></div>`).join('')}</div><section class="panel"><h2>Lịch sử học</h2>${list.length?list.slice(0,20).map(a=>`<div class="result-item"><strong>${e(a.title)}</strong><p>${a.right}/${a.total} câu đúng · ${e(new Date(a.at).toLocaleDateString('vi-VN'))}</p></div>`).join(''):'<p>Chưa có lượt học được nộp.</p>'}</section>`);
}
function sources(){
 page(title('Nguồn nội dung','Các chủ đề được biên soạn theo mạch kiến thức Toán THCS trong Chương trình GDPT 2018.')+
 '<section class="panel"><p>App dùng để học và ôn theo chủ đề. Nội dung hiện có gồm lý thuyết tóm tắt, ví dụ và bài luyện tự chấm. Đề tổng hợp lớp 9 là đề tự luyện.</p><ul class="source-list"><li><a href="https://thcsandong.haiphong.edu.vn/van-ban-bo-gddt/chuong-trinh-giao-duc-pho-thong-mon-toan-ban-hanh-kem-theo-thong-tu-so-322018tt/vbct/20343/91425">Chương trình GDPT môn Toán</a></li><li><a href="https://luyentap.vio.edu.vn/">VioEdu</a> · luyện tương tác theo khối lớp</li><li><a href="https://olm.vn/bg/toan-6-16438?week=0">OLM</a> · học và luyện theo chương, bài</li><li><a href="https://support.khanacademy.org/hc/en-us/articles/360037494231-What-are-Mastery-Challenges">Khan Academy</a> · ôn theo kỹ năng</li><li><a href="https://hoctot.hocmai.vn/">HOCMAI</a> · lộ trình ôn lớp 9 và vào 10</li></ul></section>');
}
function render(){
 gradeInput.value=String(data.grade);
 const route=currentRoute();
 for(const a of document.querySelectorAll('#navigation a')){
   const selected=a.hash==='#'+route||(route.startsWith('bai/')&&a.hash==='#lo-trinh');
   if(selected)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');
 }
 if(active&&route==='lam-bai'){active.finished?renderResult():renderQuiz();return;}
 if(active&&!active.finished){clearInterval(clockId);active=null;}
 if(route.startsWith('bai/'))lessonView(route.slice(4));
 else if(route==='luyen-de')examView();
 else if(route==='on-loi')errorsView();
 else if(route==='tien-do')progressView();
 else if(route==='nguon')sources();
 else roadmap();
}
function start(mode,questions,name,topic){
 if(!questions.length)return;
 clearInterval(clockId);
 active={mode,questions:questions.map(q=>({...q,choices:q.choices&&shuffle(q.choices)})),title:name,topic,index:0,answers:[],draft:'',hint:false,checked:false,finished:false,deadline:mode==='exam'?Date.now()+1200000:0};
 location.hash='lam-bai';render();
 if(active.deadline)clockId=setInterval(updateTimer,250);
 main.focus();window.scrollTo(0,0);
}
function updateTimer(){
 if(!active||active.finished)return;
 const seconds=Math.max(0,Math.ceil((active.deadline-Date.now())/1000));
 const timer=document.getElementById('timer');
 if(timer)timer.textContent=Math.floor(seconds/60)+':'+String(seconds%60).padStart(2,'0');
 if(!seconds)finish();
}
function renderQuiz(){
 const s=active, current=s.questions[s.index],checked=s.checked;
 const last=s.index===s.questions.length-1;
 const latest=checked?s.answers[s.index]:null;
 const opts=current.choices?`<fieldset class="options"><legend class="visually-hidden">Phương án trả lời</legend>${current.choices.map(opt=>`<label class="option"><input type="radio" name="answer" value="${e(opt)}" ${s.draft===opt?'checked':''} ${checked?'disabled':''}><span>${e(opt)}</span></label>`).join('')}</fieldset>`:
 `<label for="answer">Đáp án của em</label><input class="answer-field" id="answer" name="answer" value="${e(s.draft)}" autocomplete="off" ${checked?'disabled':''}><p class="help">Có thể nhập số, phân số như 2/3 hoặc biểu thức theo π khi đề yêu cầu.</p>`;
 page(`<div class="reading">${title(s.title,'Lớp '+data.grade)}<section class="panel"><div class="quiz-meta"><span>Câu ${s.index+1}/${s.questions.length}</span>${s.deadline?'<span id="timer" aria-label="Thời gian còn lại">20:00</span>':''}</div><progress aria-label="Tiến trình làm bài" value="${s.index+(checked?1:0)}" max="${s.questions.length}"></progress><p class="tag">${e(byId.get(current.topic).strand)}</p><h2 class="prompt" id="prompt">${e(current.prompt)}</h2><form id="answer-form" aria-labelledby="prompt">${opts}<p class="form-error" id="answer-error" role="status"></p>
 ${s.hint?`<p class="formula" role="status">${e(current.hint)}</p>`:''}
 ${checked?`<div class="feedback ${latest.correct?'correct':'incorrect'}" role="status"><strong>${latest.correct?'Chính xác':'Chưa đúng · Đáp án: '+e(current.answer)}</strong><p>${e(current.solution)}</p></div>`:''}
 <div class="actions">${checked?button(last?'Xem kết quả':'Câu tiếp theo','next'):`<button type="submit" class="button primary">${s.mode==='exam'?(last?'Nộp đề':'Câu tiếp theo'):'Kiểm tra đáp án'}</button>`}
 ${!checked&&s.mode!=='exam'?button(s.hint?'Ẩn gợi ý':'Xem gợi ý','hint','',false):''}
 ${!checked&&s.mode==='exam'?button(last?'Nộp đề và bỏ trống câu này':'Bỏ qua','skip','',false):''}
 ${button('Rời bài','exit','',false)}</div></form></section></div>`);
 if(s.deadline)updateTimer();
}
function submitAnswer(skip=false){
 if(!active||active.checked||active.finished)return;
 const s=active;
 if(s.deadline&&Date.now()>=s.deadline){finish();return;}
 if(!skip&&!s.draft.trim()){document.getElementById('answer-error').textContent='Em hãy nhập hoặc chọn đáp án.';return;}
 const question=s.questions[s.index];
 s.answers[s.index]={value:s.draft,correct:!skip&&same(s.draft,question.answer),skipped:skip};
 if(s.mode==='exam'){next();return;}
 s.checked=true;
 if(s.index===s.questions.length-1)record();
 renderQuiz();document.querySelector('[data-action="next"]')?.focus();
}
function next(){
 if(active.index===active.questions.length-1){finish();return;}
 active.index++;active.draft='';active.hint=false;active.checked=false;renderQuiz();document.querySelector('#prompt')?.scrollIntoView({block:'nearest'});
}
function record(){
 const s=active;
 if(s.recorded)return;
 s.recorded=true;
 const results={};
 let right=0,total=0;
 s.questions.forEach((q,i)=>{
  const a=s.answers[i];
  if(!a||a.skipped)return;
  const strand=byId.get(q.topic).strand;
  const sum=results[strand]??={right:0,total:0};
  sum.total++;total++;
  data.mistakes=data.mistakes.filter(m=>m.topic!==q.topic||m.prompt!==q.prompt);
  if(a.correct){sum.right++;right++;}else data.mistakes.unshift(q);
 });
 if(total>0)data.attempts.unshift({grade:data.grade,title:s.title,topic:s.topic,mode:s.mode,at:new Date().toISOString(),right,total,strands:results});
 data.attempts=data.attempts.slice(0,200);data.mistakes=data.mistakes.slice(0,300);save();
}
function finish(){
 if(!active||active.finished)return;
 clearInterval(clockId);
 record();active.finished=true;renderResult();main.focus();window.scrollTo(0,0);
}
function renderResult(){
 const s=active, right=s.answers.filter(a=>a.correct).length, answered=s.answers.filter(a=>!a.skipped).length;
 page(`<div class="reading">${title('Kết quả',s.title)}<section class="panel"><p class="result-score">${right}/${s.questions.length} đúng</p><p>Đã trả lời ${answered} câu · ${s.questions.length-answered} câu chưa trả lời</p><div class="actions">${link('Tiếp tục học','#lo-trinh')}${link('Ôn câu sai','#on-loi',false)}${link('Xem tiến độ','#tien-do',false)}</div></section><section class="panel"><h2>Lời giải từng câu</h2>${s.questions.map((q,i)=>`<div class="result-item"><h3>${i+1}. ${e(q.prompt)}</h3><p>Em trả lời: ${e(s.answers[i]?.value||'Chưa trả lời')} · Đáp án: <strong>${e(q.answer)}</strong></p><p>${e(q.solution)}</p></div>`).join('')}</section></div>`);
}
function leaveAllowed(){
 return !active||active.finished||active.recorded||!active.answers.length||confirm('Rời bài sẽ bỏ lượt làm chưa hoàn thành. Em có muốn rời bài?');
}
main.addEventListener('click',event=>{
 const control=event.target.closest('[data-action]');
 if(!control)return;
 const action=control.dataset.action, value=control.dataset.value;
 if(action==='practice'){const t=byId.get(value);start('practice',makeQuestions(t),t.title,t.id);}
 if(action==='strand-exam'){const list=shuffle(selectedTopics().filter(t=>t.strand===value));start('strand',shuffle(list.flatMap(makeQuestions)).slice(0,6),value);}
 if(action==='exam'){
   const questions=strands.flatMap(strand=>shuffle(selectedTopics().filter(t=>t.strand===strand).flatMap(makeQuestions)).slice(0,4));
   start('exam',shuffle(questions),data.grade===9?'Đề tự luyện lớp 9 · Chuẩn bị vào 10':'Đề tổng hợp lớp '+data.grade);
 }
 if(action==='review')start('review',mistakes().slice(0,12),'Ôn câu sai');
 if(action==='next')next();
 if(action==='skip')submitAnswer(true);
 if(action==='hint'){active.hint=!active.hint;renderQuiz();document.querySelector('[data-action="hint"]')?.focus();}
 if(action==='exit'&&leaveAllowed()){clearInterval(clockId);active=null;location.hash='lo-trinh';}
});
main.addEventListener('submit',event=>{if(event.target.id==='answer-form'){event.preventDefault();submitAnswer();}});
main.addEventListener('input',event=>{
 if(event.target.id==='search'){search=event.target.value;renderTopicGrid();}
 if(active&&event.target.name==='answer')active.draft=event.target.value;
});
main.addEventListener('change',event=>{
 if(event.target.id==='strand'){topicFilter=event.target.value;renderTopicGrid();}
 if(active&&event.target.name==='answer')active.draft=event.target.value;
});
document.querySelector('.skip').addEventListener('click',event=>{event.preventDefault();main.focus();});
document.addEventListener('click',event=>{
 const a=event.target.closest('a[href^="#"]');
 if(a&&a.hash!=='#main'&&currentRoute()==='lam-bai'&&!leaveAllowed())event.preventDefault();
});
gradeInput.addEventListener('change',()=>{
 if(!leaveAllowed()){gradeInput.value=String(data.grade);return;}
 clearInterval(clockId);active=null;
 data.grade=Number(gradeInput.value);topicFilter='';search='';save();
 if(routes.includes(currentRoute()))render();else location.hash='lo-trinh';
});
window.addEventListener('hashchange',()=>{if(currentRoute()!=='main'){render();main.focus();window.scrollTo(0,0);}});
render();
})();
