#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if ! command -v uv >/dev/null 2>&1; then
    printf '%s\n' 'Cài uv trước: https://docs.astral.sh/uv/getting-started/installation/' >&2
    exit 1
fi
export GRADIO_SERVER_NAME=127.0.0.1 GRADIO_SERVER_PORT=7860 GRADIO_SHARE=false
exec uv run --locked vieneu-web
